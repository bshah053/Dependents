﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Chubb.Tracker.EnterpriseIntegration.CRM.Model;
using Chubb.Tracker.TrackerReportingService.Data.Interfaces;
using Chubb.Tracker.TrackerReportingService.Data.Database;
using Chubb.Tracker.ServiceModel.TrackingReporting;
using System.Data;
using System.Data.SqlClient;
using Chubb.Tracker.Framework.Helper;

namespace Chubb.Tracker.TrackerReportingService.Data.Implementation
{
    public class TrackerReportingEnterpriseIntegrationRepository : ITrackerReportingEnterpriseIntegrationRepository
    {
        public TrackingReportingServiceEntitiesContainer context;

        public TrackerReportingEnterpriseIntegrationRepository()
        {
            context = new TrackingReportingServiceEntitiesContainer();
        }

        public List<CustomerInputGUIDModel> GetCustomerGUID(CustomerProfileInputModel objCustomerProfileInputModel)
        {
            List<CustomerInputGUIDModel> objViewCustomerOutputModel = new List<CustomerInputGUIDModel>();
            using (context)
            {
                var GetCustomerGUID = context.USP_GetCustomerGUID(objCustomerProfileInputModel.Name, objCustomerProfileInputModel.ClientID);
                foreach (USP_GetCustomerGUID_Result values in GetCustomerGUID)
                {
                    if (values.CRMGUID != null)
                    {
                        objViewCustomerOutputModel.Add(new CustomerInputGUIDModel
                        {

                            CRMGUID = values.CRMGUID

                        });
                    }

                }

                if (objViewCustomerOutputModel.Count > 0)
                {
                    objViewCustomerOutputModel[0].PageNumber = objCustomerProfileInputModel.PageNumber;
                    objViewCustomerOutputModel[0].DataCountPerPage = objCustomerProfileInputModel.PageSize;
                }
            }
            return objViewCustomerOutputModel;
        }

        public List<ProducerInputGUIDModel> GetProducerGUID(ProducerDetailsInputModel objViewProducerInputModel)
        {
            List<ProducerInputGUIDModel> objViewProducerOutputModel = new List<ProducerInputGUIDModel>();
            using (context)
            {
                var GetProducerGUID = context.USP_GetCRMProducerGUID(objViewProducerInputModel.Name, objViewProducerInputModel.AddressLine1, objViewProducerInputModel.AddressLine2, objViewProducerInputModel.City, objViewProducerInputModel.StateCode, objViewProducerInputModel.ZipCode, objViewProducerInputModel.Region, objViewProducerInputModel.Branch, objViewProducerInputModel.PASCode,
                    objViewProducerInputModel.NationalCode, objViewProducerInputModel.MasterCode, objViewProducerInputModel.LChubbCode, objViewProducerInputModel.LegacySourceCode);
                foreach (USP_GetCRMProducerGUID_Result values in GetProducerGUID)
                {
                    objViewProducerOutputModel.Add(new ProducerInputGUIDModel
                    {

                        CRMGUID = values.CRMGUID
                    });
                }
                if (objViewProducerOutputModel.Count > 0)
                {
                    objViewProducerOutputModel[0].PageNumber = objViewProducerInputModel.PageNumber;
                    objViewProducerOutputModel[0].DataCountPerPage = objViewProducerInputModel.DataCountPerPage;
                }

            }
            return objViewProducerOutputModel;
        }
        public List<ProducerInputGUIDModel> GetCRMProducerGUID(ProducerDetailsCRMInputModel objViewProducerInputModel)
        {
            List<ProducerInputGUIDModel> objViewProducerOutputModel = new List<ProducerInputGUIDModel>();
            using (context)
            {
                //TRKR -2847 Added Parent Indicator
                var GetProducerGUID = context.USP_GetProducerCRMGUID(objViewProducerInputModel.Name, objViewProducerInputModel.Region, objViewProducerInputModel.Branch, objViewProducerInputModel.ParentProducerInd);
                foreach (USP_GetProducerCRMGUID_Result values in GetProducerGUID)
                {
                    objViewProducerOutputModel.Add(new ProducerInputGUIDModel
                    {

                        CRMGUID = values.CRMGUID
                    });
                }
                if (objViewProducerOutputModel.Count > 0)
                {
                    objViewProducerOutputModel[0].PageNumber = objViewProducerInputModel.PageNumber;
                    objViewProducerOutputModel[0].DataCountPerPage = objViewProducerInputModel.PageSize;
                }

            }
            return objViewProducerOutputModel;
        }
        public List<ProducerInputGUIDModel> GetCRMBranchGUID(BranchDetailsCRMInputModel objViewBranchInputModel)
        {
            List<ProducerInputGUIDModel> objViewProducerOutputModel = new List<ProducerInputGUIDModel>();
            using (context)
            {
                var GetProducerGUID = context.USP_GetProducerBranchCRMGUID(objViewBranchInputModel.UserID, objViewBranchInputModel.Branch);
                foreach (USP_GetProducerBranchCRMGUID_Result values in GetProducerGUID)
                {
                    objViewProducerOutputModel.Add(new ProducerInputGUIDModel
                    {

                        CRMGUID = values.CRMGUID
                    });
                }
                if (objViewProducerOutputModel.Count > 0)
                {
                    objViewProducerOutputModel[0].PageNumber = objViewBranchInputModel.PageNumber;
                    objViewProducerOutputModel[0].DataCountPerPage = objViewBranchInputModel.PageSize;
                }

            }
            return objViewProducerOutputModel;
        }
        public AccountingMonthClosedDatesOutputModel GetAccountingMonthClosedDatesRov(ROVInputModel goalsInputModel)
        {
            AccountingMonthClosedDatesOutputModel accountingMonthClosedDatesOutputModel = new AccountingMonthClosedDatesOutputModel();
            using (var context = new TrackingReportingServiceEntitiesContainer())
            {
                var dateValues = context.USP_AccountingMonth_ClosedDates(goalsInputModel.AccountMonth, goalsInputModel.AccountYear, goalsInputModel.TimeFrame);

                foreach (USP_AccountingMonth_ClosedDates_Result values in dateValues)
                {
                    accountingMonthClosedDatesOutputModel.StartDate = values.StartDate;
                    accountingMonthClosedDatesOutputModel.EndDate = values.EndDate;
                }

            }
            return accountingMonthClosedDatesOutputModel;
        }



        public List<ROVOutputModel> GetROVReport(ROVInputModel trackingReportingCommonFilterInputModel)
        {

            List<ROVOutputModel> rovReport = new List<ROVOutputModel>();

            using (var context = new TrackingReportingServiceEntitiesContainer())
            {
                DataTable dtProducerName = new DataTable();
                dtProducerName.Columns.Add("ProducerName", typeof(string));
                foreach (var item in trackingReportingCommonFilterInputModel.ProducerName)
                {
                    dtProducerName.Rows.Add(Convert.ToString(item));
                }
                DataTable dtPASCode = new DataTable();
                dtPASCode.Columns.Add("PASCode", typeof(string));
                foreach (var item in trackingReportingCommonFilterInputModel.PASCode)
                {
                    dtPASCode.Rows.Add(Convert.ToString(item));
                }


                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("@UserID", trackingReportingCommonFilterInputModel.UserID));
                param.Add(new SqlParameter("@AccountMonth", trackingReportingCommonFilterInputModel.AccountMonth));
                param.Add(new SqlParameter("@AccountYear", trackingReportingCommonFilterInputModel.AccountYear));
                param.Add(new SqlParameter("@TimeFrame", trackingReportingCommonFilterInputModel.TimeFrame));
                param.Add(new SqlParameter("@CompanyName", trackingReportingCommonFilterInputModel.CompanyName != null ? UtilityHelper.ListValueToCommaSeperated(trackingReportingCommonFilterInputModel.CompanyName, "|") : string.Empty));
                param.Add(new SqlParameter("@Currency", trackingReportingCommonFilterInputModel.Currency != null ? trackingReportingCommonFilterInputModel.Currency : string.Empty));
                param.Add(new SqlParameter("@ProducerRegion", trackingReportingCommonFilterInputModel.ProducerRegion != null ? UtilityHelper.ListValueToCommaSeperated(trackingReportingCommonFilterInputModel.ProducerRegion, "|") : string.Empty));
                param.Add(new SqlParameter("@ProducerBranch", trackingReportingCommonFilterInputModel.ProducerBranch != null ? UtilityHelper.ListValueToCommaSeperated(trackingReportingCommonFilterInputModel.ProducerBranch, "|") : string.Empty));
                param.Add(new SqlParameter("@PageNumber", trackingReportingCommonFilterInputModel.PageNumber != 0 ? trackingReportingCommonFilterInputModel.PageNumber : 0));
                param.Add(new SqlParameter("@PageSize", trackingReportingCommonFilterInputModel.PageSize != 0 ? trackingReportingCommonFilterInputModel.PageSize : 0));

                SqlParameter objParam1 = new SqlParameter("@ProducerNameTableData", SqlDbType.Structured);
                objParam1.Value = dtProducerName;
                objParam1.TypeName = "[edesk_forecast_web].[ProducerNameUDT]";
                param.Add(objParam1);

                SqlParameter objParam2 = new SqlParameter("@PASCodeTableData", SqlDbType.Structured);
                objParam2.Value = dtPASCode;
                objParam2.TypeName = "[edesk_forecast_web].PASCodeUDT";
                param.Add(objParam2);

                string command = "EXEC USP_ROVAtGlance @UserID,@AccountMonth,@AccountYear,@TimeFrame,@Currency,@CompanyName,@ProducerNameTableData,@PASCodeTableData,@ProducerRegion,@ProducerBranch,@PageNumber,@PageSize";
                rovReport = context.Database.SqlQuery<ROVOutputModel>(command, param.ToArray()).ToList();

            }
            return rovReport;
        }

    }
}