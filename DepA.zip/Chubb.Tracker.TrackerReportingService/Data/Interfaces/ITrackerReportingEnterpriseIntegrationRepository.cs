﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Chubb.Tracker.EnterpriseIntegration.CRM.Model;
using Chubb.Tracker.ServiceModel.TrackingReporting;

namespace Chubb.Tracker.TrackerReportingService.Data.Interfaces
{
    public interface ITrackerReportingEnterpriseIntegrationRepository
    {
        List<CustomerInputGUIDModel> GetCustomerGUID(CustomerProfileInputModel objCustomerProfileInputModel);
        List<ProducerInputGUIDModel> GetProducerGUID(ProducerDetailsInputModel objProducerDetailsInputModel);
        List<ProducerInputGUIDModel> GetCRMProducerGUID(ProducerDetailsCRMInputModel objProducerDetailsInputModel);
        List<ProducerInputGUIDModel> GetCRMBranchGUID(BranchDetailsCRMInputModel objBranchDetailsInputModel);
        List<ROVOutputModel> GetROVReport(ROVInputModel loadReportInputModel);
        AccountingMonthClosedDatesOutputModel GetAccountingMonthClosedDatesRov(ROVInputModel goalsInputModel);
    }
}