﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using Chubb.Tracker.EnterpriseIntegration.CRM.Model;

namespace Chubb.Tracker.TrackerReportingService.Facade.Interfaces
{
    public interface ITrackerReportingEnterpriseIntegrationFacade
    {
        List<ContactOutputModel> GetContactbyprodlocation(ContactDetailsInputModel objcontactDetailsInputModel);
        List<ContactOutputModel> GetContactbyCustomer(CustomerProfileInputModel objCustomerProfileInputModel);
        List<ContactOutputModel> GetContactbyProducer(ProducerDetailsCRMInputModel objProducerDetailsInputModel);
        //List<MeetingDetailsOutputModel> GetMeetingbyCustomer(CustomerDetailsInputModel objViewCustomerMeetingInputModel);
        List<MeetingDetailsInfoOutputModel> GetMeetingbyProducer(ProducerDetailsCRMInputModel objViewProducerMeetingInputModel);
        UserCRMDynamicDetailsOutputModel GetCRMDynamicUserDetails(String UserID);
        List<AttachmentsDetailsOutputModel> GetAttachmentsbyProducer(ProducerDetailsCRMInputModel objViewProducerAttachmentsInputModel);
        List<NotesDetailsOutputModel> GetNotesbyProducer(ProducerDetailsCRMInputModel objViewProducerNotesInputModel);
        List<UserTaskOutputModel> GetTaskbyProducer(ProducerDetailsCRMInputModel objViewProducerTaskInputModel);
        List<CRMCompletedActivitiesOutputModel> GetCRMCompletedActivitiesByProducer(ProducerDetailsCRMInputModel objProducerDetailsCRMInputModel);
        List<MeetingDetailsOutputModel> GetCRMMeetingByBranch(BranchDetailsCRMInputModel objViewBranchMeetingInputModel);
        List<CRMCompletedActivitiesOutputModel> GetCRMCompletedActivitiesByCustomer(CustomerProfileInputModel objCustomerProfileInputModel);
        List<UserTaskOutputModel> GetCRMTaskByCustomer(CustomerProfileInputModel objCustomerProfileInputModel);
        List<NotesDetailsOutputModel> GetNotesbyCustomer(CustomerProfileInputModel objCustomerProfileInputModel);
        List<MeetingDetailsInfoOutputModel> GetMeetingbyCustomer(CustomerProfileInputModel objCustomerProfileInputModel);
        List<ROVOutputModel> GetROVReport(ROVInputModel loadReportInputModel);
        StringBuilder GetROVReportExcel(ROVInputModel loadReportInputModel);
        SummaryActivityOutputModel GetTravelScorecard(SummaryActivityInputModel objSummaryActivityInputModel);

    }

}   