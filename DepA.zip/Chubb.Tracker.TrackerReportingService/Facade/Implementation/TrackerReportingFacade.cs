﻿using Chubb.Tracker.ServiceModel.TrackingReporting;
using Chubb.Tracker.TrackerReportingService.Business.Interfaces;
using Chubb.Tracker.TrackerReportingService.Facade.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Chubb.Tracker.EnterpriseIntegration.DNB.Model;
using Chubb.Tracker.Framework.Unity;
using Chubb.Tracker.ServiceModel.TrackerReporting;
using Chubb.Tracker.EnterpriseIntegration.CRM.Activities;
using System.Text;
using Chubb.Tracker.EnterpriseIntegration.CRM.Model;
using Chubb.Tracker.ServiceModel.Submission;

namespace Chubb.Tracker.TrackerReportingService.Facade.Implementation
{
    public class TrackerReportingFacade : ITrackerReportingFacade
    {

        private readonly ITrackerReportingBO _trackerReportingBO = UnityManager.Resolve<ITrackerReportingBO>();
        private readonly ITrackerReportingEnterpriseIntegrationBO _trackerReportingEnterpriseIntegrationBO = UnityManager.Resolve<ITrackerReportingEnterpriseIntegrationBO>();
        private readonly Activities objGetActivities = new Activities();
        public List<UWNewBusinessGoalsQuoteRatioOutputModel> GetUnderWriterNewBusinessQuoteRatioData(LoadUWGoalsInputModel UWNBQuoteRatioDetails)
        {

            List<UWNewBusinessGoalsQuoteRatioOutputModel> uWNewBusinessGoalsQuoteRatioOutputModel = _trackerReportingBO.ProcessUnderWriterNewBusinessQuoteRatioData(UWNBQuoteRatioDetails);
            return uWNewBusinessGoalsQuoteRatioOutputModel;
        }
        public List<DropdownOutputValues> GetCreditedRegionFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCreditedRegionFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetCreditedBranchFilter(List<string> Region)
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCreditedBranchFilter(Region);
            return listDetails;
        }
        public List<CreditedRegionBranchOutputModel> GetCreditedRegionBranchFilter()
        {
            List<CreditedRegionBranchOutputModel> listDetails = _trackerReportingBO.GetCreditedRegionBranchFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetCompanyFilter(string UserID)
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCompanyFilter(UserID);
            return listDetails;
        }
        public List<DropdownOutputValues> GetDivisionFilter(string UserID, List<string> Company)
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetDivisionFilter(UserID, Company);
            return listDetails;
        }
        public List<DropdownOutputValues> GetOwnerUnitFilter(string UserID, List<string> Company)
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetOwnerUnitFilter(UserID, Company);
            return listDetails;
        }
        public List<DropdownOutputValues> GetUnitFilter(UnitFilterData UnitFilterData)
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetUnitFilter(UnitFilterData);
            return listDetails;
        }
        public List<DropdownOutputValues> GetSegmentFilter(SegmentFilterData segmentFilterData)
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetSegmentFilter(segmentFilterData);
            return listDetails;
        }
        public List<DropdownOutputValues> GetSubSegmentFilter(SubsegmentFilterData subsegmentFilterData)
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetSubSegmentFilter(subsegmentFilterData);
            return listDetails;
        }
        public List<DropdownOutputValues> GetMCCFilter(MCCFilterData mccFilterData)
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetMCCFilter(mccFilterData);
            return listDetails;
        }
        public List<DropdownOutputValues> GetPortfolioClassFilter(PortfolioClassFilterData portfolioClassFilterData)
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetPortfolioClassFilter(portfolioClassFilterData);
            return listDetails;
        }

        public List<DropdownOutputValues> GetStatusFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetStatusFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetAdvanceSort(string SortReportName)
        {
            List<DropdownOutputValues> sortDetails = _trackerReportingBO.GetAdvanceSort(SortReportName);
            return sortDetails;
        }

        public List<DropdownOutputValues> GetImpediment()
        {
            List<DropdownOutputValues> impedimentDetails = _trackerReportingBO.GetImpediment();
            return impedimentDetails;
        }

        public List<DropdownOutputValues> GetSuccessfulProducer()
        {
            List<DropdownOutputValues> successfulProducerDetails = _trackerReportingBO.GetSuccessfulProducer();
            return successfulProducerDetails;
        }

        public List<DropdownOutputValues> GetLostReasonByStatus(string Status, string Unit, string Segment)
        {
            List<DropdownOutputValues> lostReasonDetails = _trackerReportingBO.GetLostReasonByStatus(Status, Unit, Segment);
            return lostReasonDetails;
        }

        public List<DropdownOutputValues> GetUWRegionByUWBranch(string uwBranch)
        {
            List<DropdownOutputValues> uwRegionName = _trackerReportingBO.GetUWRegionByUWBranch(uwBranch);
            return uwRegionName;
        }

        public int DeleteTransactionByRecordNo(TransactionInputModel transactionInputModel)
        {
            return _trackerReportingBO.DeleteTransactionByRecordNo(transactionInputModel);
        }
        public int CopyTransactionByRecordNo(TransactionInputModel transactionInputModel)
        {
            return _trackerReportingBO.CopyTransactionByRecordNo(transactionInputModel);
        }
        public int CopyLinkedSubmissionTransactionByRecordNo(TransactionInputModel transactionInputModel)
        {
            return _trackerReportingBO.CopyLinkedSubmissionTransactionByRecordNo(transactionInputModel);
        }
        public int MoveToNextTermByRecordNo(PostMortemUpdateInputModel portMortemUpdateInputModel)
        {
            return _trackerReportingBO.MoveToNextTermByRecordNo(portMortemUpdateInputModel);
        }

        public List<DropdownOutputValues> GetEstPlacementFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetEstPlacementFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetTPAFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetTPAFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetTScore()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetTScore();
            return listDetails;
        }
        public List<SICOutputModel> GetSICCodeFilter()
        {
            List<SICOutputModel> listDetails = _trackerReportingBO.GetSICCodeFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetCRMCallTypeFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCRMCallTypeFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetCRMContactPreferenceFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCRMContactPreferenceFilter();
            return listDetails;
        }
       
        public List<DropdownOutputValues> GetCRMEventTypeFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCRMEventTypeFilter();
            return listDetails;
        }
        
        public List<DropdownOutputValues> GetCornerstoneValues()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCornerstoneValues();
            return listDetails;
        }
        public List<DropdownOutputValues> GetCRMCompanyOwnerTypeFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCRMCompanyOwnerTypeFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetCRMChubbMarketSegmentFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCRMChubbMarketSegmentFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetCRMStatusTypeFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCRMStatusTypeFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetCRMContactTypeFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCRMContactTypeFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetCRMRoleFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCRMRoleFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetCRMProductSpecializationFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCRMProductSpecializationFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetCRMIndustrySpecializationFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCRMIndustrySpecializationFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetCRMChubbBusinessUnitFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCRMChubbBusinessUnitFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetCRMProducerFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCRMProducerFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetCRMActivityTypeFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCRMActivityTypeFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetCRMUserTypeFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCRMUserTypeFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetIncumbentFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetIncumbentFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetRelationshipTypeFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetRelationshipTypeFilter();
            return listDetails;
        }

        public List<DropdownOutputValues> GetProducerStateFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetProducerStateFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetProducerCityFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetProducerCityFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetInsuredStateFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetInsuredStateFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetInsuredCityFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetInsuredCityFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetIndustryFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetIndustryFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetProductFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetProductFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetUWBranchFilter(List<string> Region)
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetUWBranchFilter(Region);
            return listDetails;
        }

        public List<DropdownOutputValues> GetCurrencyFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCurrencyFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetCapacityFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCapacityFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetPGroupFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetPGroupFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetCustomerGroupFilter()//TRKR-5701
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCustomerGroupFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetProducerBranchFilter(ProducerBranchFilterInputModel objProducerBranchFilterInputModel)
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetProducerBranchFilter(objProducerBranchFilterInputModel);
            return listDetails;
        }
        public List<DropdownOutputValues> GetProducerRegionFilter(ProducerRegionFilterInputModel objProducerRegionFilterInputModel)
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetProducerRegionFilter(objProducerRegionFilterInputModel);
            return listDetails;
        }
        public List<DropdownOutputValues> GetProducerGroupFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetProducerGroupFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetTClassFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetTClassFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetTerrorCoverageFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetTerrorCoverageFilter();
            return listDetails;
        }
        public DropdownOutputValues GetMaximumForecastAmount()
        {
            DropdownOutputValues details = _trackerReportingBO.GetMaximumForecastAmount();
            return details;
        }
        public List<DropdownOutputValues> GetUnderwriterFilter(string FilterName)
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetUnderwriterFilter(FilterName);
            return listDetails;
        }

        public List<DropdownOutputValues> GetCountryNameFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCountryNameFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetequityfirmFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetequityfirmFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetRelationshipManagerFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetRelationshipManagerFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetCABDescriptionFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetCABDescriptionFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetIndustryPracticeFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetIndustryPracticeFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetIndustryPracticeDetailFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetIndustryPracticeDetailFilter();
            return listDetails;
        }
        public List<CustomerFilterOutputModel> GetCustomerFilter(CustomerFilterInputModel CustomerFilterInputModel)
        {
            List<CustomerFilterOutputModel> listDetails = _trackerReportingBO.GetCustomerFilter(CustomerFilterInputModel);
            return listDetails;
        }
        public List<InsuredDNBDetailOutputModel> GetInsuredDetailByDBNumber(string DBNumber)
        {
            List<InsuredDNBDetailOutputModel> listDetails = _trackerReportingBO.GetInsuredDetailByDBNumber(DBNumber);
            return listDetails;
        }

        public List<ProducerDetailOutputModel> GetProducerDetailsByCode(string ProducerCode)
        {
            List<ProducerDetailOutputModel> listDetails = _trackerReportingBO.GetProducerDetailsByCode(ProducerCode);
            return listDetails;
        }

        public List<ScorecardOverviewOutputModel> GetScorecardOverview(LoadReportInputModel loadReportInputModel)
        {
            List<ScorecardOverviewOutputModel> scorecardOverviewOutputModel = _trackerReportingBO.GetScorecardOverview(loadReportInputModel);
            return scorecardOverviewOutputModel;
        }

        public List<ScorecardAmountPerDivionOutputModel> GetScorecardAmountPerDivision(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<ScorecardAmountPerDivionOutputModel> scorecardAmountOutputModel = _trackerReportingBO.GetScorecardAmountPerDivision(trackingReportingCommonFilterInputModel);
            return scorecardAmountOutputModel;
        }
        public List<ScorecardAmountPerDivionOutputModel> GetNetScorecardAmountPerDivision(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<ScorecardAmountPerDivionOutputModel> netScorecardAmountOutputModel = _trackerReportingBO.GetNetScorecardAmountPerDivision(trackingReportingCommonFilterInputModel);
            return netScorecardAmountOutputModel;
        }
        public List<RegionalScorecardAmountPerRegionOutputModel> GetRegionalScorecardAmountPerRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<RegionalScorecardAmountPerRegionOutputModel> scorecardAmountOutputModel = _trackerReportingBO.GetRegionalScorecardAmountPerRegion(trackingReportingCommonFilterInputModel);
            return scorecardAmountOutputModel;
        }
        //public List<ForecastVariationOutputModel> GetForecastVariation(ForecastVariationInputModel variationInputModel)
        //{
        //    List<ForecastVariationOutputModel> forecastVariation = _trackerReportingBO.GetForecastVariation(variationInputModel);
        //    return forecastVariation;
        //}
        public List<RegionalScorecardAmountPerRegionOutputModel> GetNetScorecardAmountPerRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<RegionalScorecardAmountPerRegionOutputModel> netAmountOutputModel = _trackerReportingBO.GetNetScorecardAmountPerRegion(trackingReportingCommonFilterInputModel);
            return netAmountOutputModel;
        }
        public List<UWPipelineDetails> GetUWPipelineDetailsTargets(LoadReportInputModel loadReportInputModel)
        {
            List<UWPipelineDetails> uwPipilineDetails = _trackerReportingBO.GetUWPipelineDetailsTargets(loadReportInputModel);
            return uwPipilineDetails;
        }
        public List<UWPipelineDetails> GetUWPipelineDetailsRenewals(LoadReportInputModel loadReportInputModel)
        {
            List<UWPipelineDetails> uwPipilineDetails = _trackerReportingBO.GetUWPipelineDetailsRenewals(loadReportInputModel);
            return uwPipilineDetails;
        }
        public List<UWPipelineDetails> GetUWPipelineDetailsNewBusiness(LoadReportInputModel loadReportInputModel)
        {
            List<UWPipelineDetails> uwPipilineDetails = _trackerReportingBO.GetUWPipelineDetailsNewBusiness(loadReportInputModel);
            return uwPipilineDetails;
        }
        public List<ScorecardRenewalByStatusOutputModel> GetScorecardRenewalByStatus(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<ScorecardRenewalByStatusOutputModel> scoreCardDeatils = _trackerReportingBO.GetScorecardRenewalByStatus(trackingReportingCommonFilterInputModel);
            return scoreCardDeatils;
        }
        public List<RegionalScorecardRenewalByStatusOutputModel> GetRegionalScorecardRenewalByStatus(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<RegionalScorecardRenewalByStatusOutputModel> regionalScoreCardDeatils = _trackerReportingBO.GetRegionalScorecardRenewalByStatus(trackingReportingCommonFilterInputModel);
            return regionalScoreCardDeatils;
        }
        public List<ScorecardByStatusOutputModel> GetScorecardNewBusinessByStatus(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<ScorecardByStatusOutputModel> scoreCardDeatils = _trackerReportingBO.GetScorecardNewBusinessByStatus(trackingReportingCommonFilterInputModel);
            return scoreCardDeatils;
        }
        public List<RegionalScorecardNewBusinessByStatusOutputModel> GetRegionalScorecardNewBusinessByStatus(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<RegionalScorecardNewBusinessByStatusOutputModel> regionalScoreCardDeatils = _trackerReportingBO.GetRegionalScorecardNewBusinessByStatus(trackingReportingCommonFilterInputModel);
            return regionalScoreCardDeatils;
        }
        public List<UWSummaryPipelineDetails> GetUWSummaryPipelineDetails(LoadReportInputModel loadReportInputModel)
        {
            List<UWSummaryPipelineDetails> summaryPipelineDetails = _trackerReportingBO.GetUWSummaryPipelineDetails(loadReportInputModel);
            return summaryPipelineDetails;
        }

        public List<UWSummaryNBLostAndDeclineOutputModel> GetUWSummaryNewBusinessLostAndDeclineDetails(LoadReportInputModel loadReportInputModel)
        {
            List<UWSummaryNBLostAndDeclineOutputModel> summaryPipelineDetails = _trackerReportingBO.GetUWSummaryNewBusinessLostAndDeclineDetails(loadReportInputModel);
            return summaryPipelineDetails;
        }
        public List<ProducerLookupOutputModel> GetProducerLookupOverview(ProducerLookupInputModel producerLookupInputModel)
        {
            List<ProducerLookupOutputModel> brokerlookupoutputmodel = _trackerReportingBO.GetProducerLookupOverview(producerLookupInputModel);
            return brokerlookupoutputmodel;
        }
        public List<DetailReport> GetDetailReport(TrackingReportingCommonFilterInputModel loadReportInputModel)
        {
            List<DetailReport> detailReport = _trackerReportingBO.GetDetailReport(loadReportInputModel);
            return detailReport;
        }
        public List<DetailReport> GetArchiveDetailReport(TrackingReportingCommonFilterInputModel loadReportInputModel)
        {
            List<DetailReport> archivedetailReport = _trackerReportingBO.GetArchiveDetailReport(loadReportInputModel);
            return archivedetailReport;
        }
        public List<TargetReportOutputModel> GetTargetReport(TrackingReportingCommonFilterInputModel loadReportInputModel)
        {
            List<TargetReportOutputModel> targetReport = _trackerReportingBO.GetTargetReport(loadReportInputModel);
            return targetReport;
        }
        public InsuredReportOutputModel GetInsuredReport(InsuredSearchFilterInputModel loadReportInputModel)
        {
            InsuredReportOutputModel objInsuredReport = _trackerReportingBO.GetInsuredReport(loadReportInputModel);
            return objInsuredReport;
        }
        public InsuredReportOutputModel GetArchiveInsuredReport(InsuredSearchFilterInputModel loadReportInputModel)
        {
            InsuredReportOutputModel objInsuredReport = _trackerReportingBO.GetArchiveInsuredReport(loadReportInputModel);
            return objInsuredReport;
        }
        //public List<DNBLookupOutputModel> GetDNBCompanyLookup(string CompanyName, string StateCode)
        //{
        //    string CountryCode = _trackerReportingBO.GetDNBCountryCode(CompanyName, StateCode);

        //    List<DNBLookupOutputModel> objLookupDbOutputModel = null;
        //    if (!string.IsNullOrEmpty(CountryCode))
        //    {
        //        objLookupDbOutputModel = _trackerReportingEnterpriseIntegrationBO.GetDBNCompanyLookup(CompanyName, StateCode, CountryCode);
        //    }
        //    return objLookupDbOutputModel;
        //}
        public List<UWSummaryAtGlanceoutputModel> GetUWSummaryAtGlance(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            int ProducerVisitsYTDCount = 0;
            ReportingGoalsFilterOutputModel reportingGoalsFilter = new ReportingGoalsFilterOutputModel();
            if ((trackingReportingCommonFilterInputModel.ProducerName != null && trackingReportingCommonFilterInputModel.ProducerName.Count > 0))
            {
                reportingGoalsFilter = _trackerReportingBO.GetReportingGoalsFilter(trackingReportingCommonFilterInputModel);
                ProducerVisitsYTDCount = objGetActivities.GetCRMReportingGoalsVisitCount(reportingGoalsFilter.ProducerCRMGUID, reportingGoalsFilter.StartDate, reportingGoalsFilter.EndDate);
            }
            List<UWSummaryAtGlanceoutputModel> summaryAtGlance = _trackerReportingBO.GetUWSummaryAtGlance(trackingReportingCommonFilterInputModel, ProducerVisitsYTDCount);
            return summaryAtGlance;
        }
        public List<UWSummaryNewBusinessoutputModel> GetUWSummaryNewBusiness(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<UWSummaryNewBusinessoutputModel> summaryNewBusiness = _trackerReportingBO.GetUWSummaryNewBusiness(trackingReportingCommonFilterInputModel);
            return summaryNewBusiness;
        }
        public List<UWSummaryNewBusinessoutputModel> GetUWSummaryNewBusinessTotal(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<UWSummaryNewBusinessoutputModel> summaryNewBusinessTotal = _trackerReportingBO.GetUWSummaryNewBusinessTotal(trackingReportingCommonFilterInputModel);
            return summaryNewBusinessTotal;
        }
        public List<UWSummaryRenewaloutputModel> GetUWSummaryRenewal(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<UWSummaryRenewaloutputModel> summaryRenewal = _trackerReportingBO.GetUWSummaryRenewal(trackingReportingCommonFilterInputModel);
            return summaryRenewal;
        }
        public List<UWSummaryRenewaloutputModel> GetUWSummaryRenewalTotal(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<UWSummaryRenewaloutputModel> summaryRenewaltotal = _trackerReportingBO.GetUWSummaryRenewalTotal(trackingReportingCommonFilterInputModel);
            return summaryRenewaltotal;
        }

        public List<UWSummaryTotalforecasteoutputModel> GetUWSummaryTotalForecast(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<UWSummaryTotalforecasteoutputModel> summaryTotalForecast = _trackerReportingBO.GetUWSummaryTotalForecast(trackingReportingCommonFilterInputModel);
            return summaryTotalForecast;
        }
        public List<UWSummaryTotalforecasteoutputModel> GetUWSummaryTotalForecastTotal(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<UWSummaryTotalforecasteoutputModel> summaryTotalForecastTotal = _trackerReportingBO.GetUWSummaryTotalForecastTotal(trackingReportingCommonFilterInputModel);
            return summaryTotalForecastTotal;
        }
        public List<UWGoalsNewBusinessOutputModel> GetUWGoalsNewBusiness(LoadReportInputModel loadReportInputModel)
        {
            List<UWGoalsNewBusinessOutputModel> goalsNewBusiness = _trackerReportingBO.GetUWGoalsNewBusiness(loadReportInputModel);
            return goalsNewBusiness;
        }
        public List<UWGoalsHitQuoteRatioOutputModel> GetUWGoalsHitRatio(LoadReportInputModel loadReportInputModel)
        {
            List<UWGoalsHitQuoteRatioOutputModel> goalsHitRatio = _trackerReportingBO.GetUWGoalsHitRatio(loadReportInputModel);
            return goalsHitRatio;
        }
        public UWGoalsHitQuoteRatioDetailsOutputModel GetUWGoalsHitRatioDetails(LoadReportInputModel loadReportInputModel)
        {
            UWGoalsHitQuoteRatioDetailsOutputModel goalsHitRatioDetails = _trackerReportingBO.GetUWGoalsHitRatioDetails(loadReportInputModel);
            return goalsHitRatioDetails;
        }
        public TravelGoalsOutputModel GetTravelGoals(TravelGoalsInputModel goalsInputModel)
        {
            AccountingMonthClosedDatesOutputModel accountingMonthClosedDates = _trackerReportingBO.GetAccountingMonthClosedDates(goalsInputModel);
            string EmailId = _trackerReportingBO.GetEmailID(goalsInputModel.UserID);
            int NoOfVisits = objGetActivities.GetCRMTravelGoalsVisitCount(EmailId, goalsInputModel.VisitType, accountingMonthClosedDates.StartDate, accountingMonthClosedDates.EndDate);
            TravelGoalsOutputModel goalstravelDetails = _trackerReportingBO.GetTravelGoals(goalsInputModel, NoOfVisits);
            return goalstravelDetails;
        }

        public UWGoalsHitQuoteRatioDetailsOutputModel GetUWGoalsQuoteRatioDetails(LoadReportInputModel loadReportInputModel)
        {
            UWGoalsHitQuoteRatioDetailsOutputModel goalsQuoteRatioDetails = _trackerReportingBO.GetUWGoalsQuoteRatioDetails(loadReportInputModel);
            return goalsQuoteRatioDetails;
        }

        public HelpOutputValues GetHelpDetails(string UserID)
        {
            HelpOutputValues objhelpFile = _trackerReportingBO.GetHelpDetails(UserID);
            return objhelpFile;
        }
        public List<ForecastByBusinessSegmentOutputModel> GetForecastSummary(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<ForecastByBusinessSegmentOutputModel> forecastSummary = _trackerReportingBO.GetForecastSummary(trackingReportingCommonFilterInputModel);
            return forecastSummary;
        }
        public List<ForecastByBusinessSegmentOutputModel> GetForecastSummaryTotal(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<ForecastByBusinessSegmentOutputModel> forecastSummary = _trackerReportingBO.GetForecastSummaryTotal(trackingReportingCommonFilterInputModel);
            return forecastSummary;
        }
        public List<ForecastRegionDataOutputModel> GetForecastRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<ForecastRegionDataOutputModel> forecastRegion = _trackerReportingBO.GetForecastRegion(trackingReportingCommonFilterInputModel);
            return forecastRegion;
        }
        public List<ForecastRegionDataOutputModel> GetForecastRegionTotal(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<ForecastRegionDataOutputModel> forecastRegionTotal = _trackerReportingBO.GetForecastRegionTotal(trackingReportingCommonFilterInputModel);
            return forecastRegionTotal;
        }
        public FilterDataOutputModel SaveFilterDetails(LoadFilterInputModel loadFilterInputModel)
        {
            FilterDataOutputModel details = _trackerReportingBO.SaveFilterDetails(loadFilterInputModel);
            return details;
        }

        public List<ForecastVariationOutputModel> GetForecastVariation(ForecastVariationInputModel forecastVariationInputModel)
        {
            List<ForecastVariationOutputModel> forecastVariation = _trackerReportingBO.GetForecastVariation(forecastVariationInputModel);
            return forecastVariation;
        }

        public List<GetFilterOutputModel> GetMySavedOrRecentViewReports(GetFilterInputModel getFilterInputModel)
        {
            List<GetFilterOutputModel> filterReport = _trackerReportingBO.GetMySavedOrRecentViewReports(getFilterInputModel);
            return filterReport;
        }

        public List<UWGoalsHitQuoteRatioOutputModel> GetUWGoalsQuoteRatio(LoadReportInputModel loadReportInputModel)
        {
            List<UWGoalsHitQuoteRatioOutputModel> goalsQuoteRatio = _trackerReportingBO.GetUWGoalsQuoteRatio(loadReportInputModel);
            return goalsQuoteRatio;
        }

        public List<DropdownOutputValues> GetAccountingMonthFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetAccountingMonthFilter();
            return listDetails;
        }

        public List<DropdownOutputValues> GetAccountingYearFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetAccountingYearFilter();
            return listDetails;
        }

        public List<DropdownOutputValues> GetTargetTypeFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetTargetTypeFilter();
            return listDetails;
        }

        public List<DropdownOutputValues> GetTransactionTypeFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetTransactionTypeFilter();
            return listDetails;
        }

        public List<DropdownOutputValues> GetProgramFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetProgramFilter();
            return listDetails;
        }

        public List<DropdownOutputValues> GetMarketingManagerFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetMarketingManagerFilter();
            return listDetails;
        }

        public List<DropdownOutputValues> GetDataSourceFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetDataSourceFilter();
            return listDetails;
        }

        public List<DropdownOutputValues> GetChubbIndustryFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetChubbIndustryFilter();
            return listDetails;
        }

        public List<DropdownOutputValues> GetUWRegionFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetUWRegionFilter();
            return listDetails;
        }

        public List<Chubb5000DetailListOutputModel> GetChubb5000DetailListDetails(Chubb5000DetailListInputModel chubb5000DetailListInputModel)
        {
            List<Chubb5000DetailListOutputModel> chubb5000DetailList = _trackerReportingBO.GetChubb5000DetailListDetails(chubb5000DetailListInputModel);
            return chubb5000DetailList;
        }
        public List<GetProducerGoalsOutputModel> GetProfilePlanGoalReport(string ProducerProfileName)
        {
            List<GetProducerGoalsOutputModel> producerGoalDetails = _trackerReportingBO.GetProfilePlanGoalReport(ProducerProfileName);
            return producerGoalDetails;
        }

        public string SaveProfilePlanGoalReport(List<ProducerProfileGoalModel> getproducerProfileInputModel)
        {
            string producerGoalDetails = _trackerReportingBO.SaveProfilePlanGoalReport(getproducerProfileInputModel);
            return producerGoalDetails;
        }
        public string AddProfilePlanGoalReport(List<AddProducerProfileGoalModel> getproducerProfileInputModel)
        {
            string producerGoalDetails = _trackerReportingBO.AddProfilePlanGoalReport(getproducerProfileInputModel);
            return producerGoalDetails;
        }
        
 
        public GetProducerAtGlanceOutputModel GetProfileAtGlance(string ProducerProfileName)
        {
            GetProducerAtGlanceOutputModel producerGoalDetails = _trackerReportingBO.GetProfileAtGlance(ProducerProfileName);
            return producerGoalDetails;
        }

        public List<ProducerFilterOutputModel> GetProducerFilter(ProducerFilterInputModel objProducerFilterInputModel)
        {
            List<ProducerFilterOutputModel> listDetails = _trackerReportingBO.GetProducerFilter(objProducerFilterInputModel);
            return listDetails;
        }

        public List<DropdownOutputValues> GetPASCodeFilter(PasCodeFilterInputModel objPasCodeFilterInputModel)
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetPASCodeFilter(objPasCodeFilterInputModel);
            return listDetails;
        }

        public List<TrackerQueueDetailsOutputModel> GetTrackerQueue(TrackerQueueInputModel trackerQueueInputModel)
        {
            List<TrackerQueueDetailsOutputModel> trackerQueueOutputModel = _trackerReportingBO.GetTrackerQueue(trackerQueueInputModel);
            return trackerQueueOutputModel;
        }

        public List<NonCoreElementsOutputModel> GetNonCoreElements(string userID)
        {
            List<NonCoreElementsOutputModel> nonCorElements = _trackerReportingBO.GetNonCoreElements(userID);
            return nonCorElements;
        }

        public List<CoreElementsOutputModel> GetCoreElements(string userID)
        {
            List<CoreElementsOutputModel> coreElements = _trackerReportingBO.GetCoreElements(userID);
            return coreElements;
        }

        public List<MultiNoncoreElementsOutputModel> GetMultiNoncoreElements(string userID)
        {
            List<MultiNoncoreElementsOutputModel> multinoncoreElements = _trackerReportingBO.GetMultiNoncoreElements(userID);
            return multinoncoreElements;
        }

        public StringBuilder ExportData(ExportInputModel exportInputModel)
        {
            StringBuilder exportData = _trackerReportingBO.ExportData(exportInputModel);
            return exportData;
        }
        public List<CustomerProfileSummaryOutputModel> GetCustomerProfileSummary(CustomerPofileSummaryInputModel customerProfilesummaryInputModel)
        {
            List<CustomerProfileSummaryOutputModel> summary = _trackerReportingBO.GetCustomerProfileSummary(customerProfilesummaryInputModel);
            return summary;
        }

        public string SaveOrUpdateRecords(TrackQueueInputPageInputModel trackQueueInputPageInputModel)
        {
            string Saveuserdetails = _trackerReportingBO.SaveOrUpdateRecords(trackQueueInputPageInputModel);
            return Saveuserdetails;


        }
        public List<BrokerProfileOutputModel> GetBrokerProfile(BrokerProfileInputModel brokerProfileInputModel)
        {
            List<BrokerProfileOutputModel> brokerProfile = _trackerReportingBO.GetBrokerProfile(brokerProfileInputModel);
            return brokerProfile;

        }
        public string SaveSubmissionRouting(SubmissionRoutingModel objSubmissionRoutingInputModel)
        {
            string saveSubmissionRouting = _trackerReportingBO.SaveSubmissionRouting(objSubmissionRoutingInputModel);
            return saveSubmissionRouting;
        }

        public List<DropdownOutputValues> GetOwnerRegionFilter()
        {
            List<DropdownOutputValues> region = _trackerReportingBO.GetOwnerRegionFilter();
            return region;
        }
        public List<DropdownOutputValues> GetTopCarrierFilter()
        {
            List<DropdownOutputValues> region = _trackerReportingBO.GetTopCarrierFilter();
            return region;
        }
        public CurrentAccountingYearMonthOutputModel GetCurrentAccountingYearMonth()
        {
            CurrentAccountingYearMonthOutputModel yrmonth = _trackerReportingBO.GetCurrentAccountingYearMonth();
            return yrmonth;
        }

        public List<DropdownOutputValues> GetCustomerProfileOwnerFilter()
        {
            List<DropdownOutputValues> customerProfileOwner = _trackerReportingBO.GetCustomerProfileOwnerFilter();
            return customerProfileOwner;
        }
        public List<DropdownOutputValues> GetProducerProductBrokeredFilter(int brokerId, int BrokerOfficeId)
        {
            List<DropdownOutputValues> producerBroker = _trackerReportingBO.GetProducerProductBrokeredFilter(brokerId, BrokerOfficeId);
            return producerBroker;
        }


        public List<DropdownOutputValues> GetProducerProfileOwnerFilter()
        {
            List<DropdownOutputValues> producerProfileOwner = _trackerReportingBO.GetProducerProfileOwnerFilter();
            return producerProfileOwner;
        }
        public List<GetSubmissionRouting> GetSubmissionRoutingData(string UserID)
        {
            List<GetSubmissionRouting> getSubmissionRoutingData = _trackerReportingBO.GetSubmissionRoutingData(UserID);
            return getSubmissionRoutingData;
        }
        public string DeleteSubmissionRoutingData(string ScheduleID)
        {
            string getSubmissionRoutingData = _trackerReportingBO.DeleteSubmissionRoutingData(ScheduleID);
            return getSubmissionRoutingData;
        }
        public string DeleteSavedFilterData(List<string> FilterID)
        {
            string getDeleteSavedFilterData = _trackerReportingBO.DeleteSavedFilterData(FilterID);
            return getDeleteSavedFilterData;
        }
        public SubmissionRoutingModel UpdateSubmissionRoutingData(string ScheduleID)
        {
            SubmissionRoutingModel getSubmissionRoutingData = _trackerReportingBO.UpdateSubmissionRoutingData(ScheduleID);
            return getSubmissionRoutingData;
        }
        public List<ProducerReportOuputModel> GetProducerReport(ProducerReportInputModel objProducerDetailsInputModel)
        {
            List<ProducerReportOuputModel> producerReport = _trackerReportingBO.GetProducerReport(objProducerDetailsInputModel);
            return producerReport;
        }
        public List<ProducerKeyProfileOuputModel> GetProducerKeyProfile(ProducerKeyprofileInputModel objProducerDetailsInputModel)
        {
            List<ProducerKeyProfileOuputModel> producerReport = _trackerReportingBO.GetProducerKeyProfile(objProducerDetailsInputModel);
            return producerReport;
        }
        public List<ProducerScorecardFilterOutputModel> GetProducerScorecardvalue(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<ProducerScorecardFilterOutputModel> producerscore = _trackerReportingBO.GetProducerScorecardvalue(trackingReportingCommonFilterInputModel);
            return producerscore;
        }
        public List<LostandDeclinedBusinessOutputModel> GetInsuredLostandDeclinedBusiness(LostandDeclinedInsuredInputModel LostandDeclinedInsuredInputModel)
        {
            List<LostandDeclinedBusinessOutputModel> lostAndDeclinedBussiness = _trackerReportingBO.GetInsuredLostandDeclinedBusiness(LostandDeclinedInsuredInputModel);
            return lostAndDeclinedBussiness;
        }

        public List<DynamicPipelinesOutputModel> GetDynamicsPipelinesDetails(DynamicPipelinesInputModel objDynamicPipelinesInputModel)
        {
            List<DynamicPipelinesOutputModel> GetDynamicsPipelinesDetails = _trackerReportingBO.GetDynamicsPipelinesDetails(objDynamicPipelinesInputModel);
            return GetDynamicsPipelinesDetails;
        }

        public string SavedProfileCoreElements(SavedProfileCoreElementInputModel savedProfileCoreElementInputModel)
        {
            string CoreElements = _trackerReportingBO.SavedProfileCoreElements(savedProfileCoreElementInputModel);
            return CoreElements;
        }

        public string GetUWSaveGoalsNewBusiness(string UserID, long GoalAMount)
        {
            string saveGoals = _trackerReportingBO.GetUWSaveGoalsNewBusiness(UserID, GoalAMount);
            return saveGoals;
        }
        public string GetTravelSaveGoals(string UserID, long GoalAmount, string VisitType)
        {
            string travelsaveGoals = _trackerReportingBO.GetTravelSaveGoals(UserID, GoalAmount, VisitType);
            return travelsaveGoals;
        }
        public string SavedProfileNonCoreElements(SavedProfileNonCoreElementInputModel savedProfileNonCoreElementInputModel)
        {
            string CoreElements = _trackerReportingBO.SavedProfileNonCoreElements(savedProfileNonCoreElementInputModel);
            return CoreElements;
        }

        public string SavedProfileMultiNonCoreElements(SavedProfileMultiNonCoreElementInputModel savedProfileMultiNonCoreElementInputModel)
        {
            string CoreElements = _trackerReportingBO.SavedProfileMultiNonCoreElements(savedProfileMultiNonCoreElementInputModel);
            return CoreElements;
        }

        public string SaveUnderwritting(UnderwrittingInputModel objUnderwrittingInputModel)
        {
            string saveUnderwritting = _trackerReportingBO.SaveUnderwritting(objUnderwrittingInputModel);
            return saveUnderwritting;
        }

        public string SaveClaimsHandling(ClaimsHandlingInputModel objClaimsHandlingInputModel)
        {
            string saveClaimsHandling = _trackerReportingBO.SaveClaimsHandling(objClaimsHandlingInputModel);
            return saveClaimsHandling;
        }
        public string SaveRelationShip(RelationShipInputModel objRelationShipInputModel)
        {
            string saveRelationShip = _trackerReportingBO.SaveRelationShip(objRelationShipInputModel);
            return saveRelationShip;
        }
        public string SaveCarrierThreat(CarrierThreatsInputModel objCarrierThreatsInputModel)
        {
            string saveCarrierThreat = _trackerReportingBO.SaveCarrierThreat(objCarrierThreatsInputModel);
            return saveCarrierThreat;
        }
        public string SaveProducerRecordThreat(ProducerRecordThreatsInputModel objSaveProducerRecordThreatInputModel)
        {
            string saveProducerRecordThreat = _trackerReportingBO.SaveProducerRecordThreat(objSaveProducerRecordThreatInputModel);
            return saveProducerRecordThreat;
        }
        public List<UnderwrittingOutputModel> GetUnderwritting(string clientName)
        {
            List<UnderwrittingOutputModel> getUnderwritting = _trackerReportingBO.GetUnderwritting(clientName);
            return getUnderwritting;
        }

        public List<ClaimsHandlingOutputModel> GetClaimsHandling(string clientName)
        {
            List<ClaimsHandlingOutputModel> getClaimsHandling = _trackerReportingBO.GetClaimsHandling(clientName);
            return getClaimsHandling;
        }
        public List<RelationShipOutputModel> GetRelationship(string clientName)
        {
            List<RelationShipOutputModel> getRelationship = _trackerReportingBO.GetRelationship(clientName);
            return getRelationship;
        }
        public List<CarrierThreatsOutputModel> GetCarrierThreats(string clientName)
        {
            List<CarrierThreatsOutputModel> getCarrierThreat = _trackerReportingBO.GetCarrierThreats(clientName);
            return getCarrierThreat;
        }
        public List<ProducerRecordThreatsOutputModel> GetProducerRecordThreats(string clientName)
        {
            List<ProducerRecordThreatsOutputModel> getProducerRecordThreat = _trackerReportingBO.GetProducerRecordThreats(clientName);
            return getProducerRecordThreat;
        }
        public string SaveLossNote(LossNoteInputModel objLossNoteInputModel)
        {
            string saveLossNote = _trackerReportingBO.SaveLossNote(objLossNoteInputModel);
            return saveLossNote;
        }
        public List<LossNoteOutputModel> GetLossNotes(string clientName)
        {
            List<LossNoteOutputModel> lossNotes = _trackerReportingBO.GetLossNotes(clientName);
            return lossNotes;
        }
        public string SaveAccountMarketed(AccountMarketedInputModel objAccountMarketedInputModel)
        {
            string saveAccountMarketed = _trackerReportingBO.SaveAccountMarketed(objAccountMarketedInputModel);
            return saveAccountMarketed;
        }
        public List<AccountMarketedOuputModel> GetAccountMarketed(string clientName)
        {
            List<AccountMarketedOuputModel> accountMarketed = _trackerReportingBO.GetAccountMarketed(clientName);
            return accountMarketed;
        }
        public string SaveRenewalStrategy(RenewalStrategyInputModel objRenewalStrategyInputModel)
        {
            string renewalStrategy = _trackerReportingBO.SaveRenewalStrategy(objRenewalStrategyInputModel);
            return renewalStrategy;
        }
        public string SaveRiskEngineeringService(RiskEngineeringServiceInputModel objRiskEngineeringServiceInputModel)
        {
            string riskEngineeringService = _trackerReportingBO.SaveRiskEngineeringService(objRiskEngineeringServiceInputModel);
            return riskEngineeringService;
        }
        public string SaveClaimServices(ClaimServicesInputModel objClaimServicesInputModel)
        {
            string claimServices = _trackerReportingBO.SaveClaimServices(objClaimServicesInputModel);
            return claimServices;
        }

        public List<RenewalStrategyOutputModel> GetRenewalStrategy(string clientName)
        {
            List<RenewalStrategyOutputModel> strategy = _trackerReportingBO.GetRenewalStrategy(clientName);
            return strategy;
        }

        public List<RiskEngineeringServiceOutputModel> GetRiskengineeringService(string clientName)
        {
            List<RiskEngineeringServiceOutputModel> riskEngineering = _trackerReportingBO.GetRiskengineeringService(clientName);
            return riskEngineering;
        }
        public List<ClaimServicesOutputModel> GetClaimServices(string clientName)
        {
            List<ClaimServicesOutputModel> claimServices = _trackerReportingBO.GetClaimServices(clientName);
            return claimServices;
        }


        public List<DropdownOutputValues> GetPageDropdownDetails(ScreenDropdownInputModel screenDropdownModel)
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetPageDropdownDetails(screenDropdownModel);
            return listDetails;
        }
        public List<StewardshipCoverageOutputModel> GetStewardshipCoverage(string clientName)
        {
            List<StewardshipCoverageOutputModel> coverage = _trackerReportingBO.GetStewardshipCoverage(clientName);
            return coverage;
        }
        public List<StewardshipLineOfBusinessOutputModel> GetStewardshipLineOfBusiness(string clientName)
        {
            List<StewardshipLineOfBusinessOutputModel> business = _trackerReportingBO.GetStewardshipLineOfBusiness(clientName);
            return business;
        }
        public string SaveStewardshipLineOfBusinessComment(StewardshipBusinessCommentInputModel objBusinessCommentInputModel)
        {
            string lineOfBusinessComment = _trackerReportingBO.SaveStewardshipLineOfBusinessComment(objBusinessCommentInputModel);
            return lineOfBusinessComment;
        }
        public List<AccountOutputModel> GetAccount(string clientName)
        {
            var endDate = DateTime.Now;
            var startDate = endDate.AddYears(-1);
            Guid? guid = _trackerReportingBO.GetGuidByClientName(clientName);
            int noOfVisits = objGetActivities.GetAccountVisitCount(guid, startDate, endDate);
            List<AccountOutputModel> account = _trackerReportingBO.GetAccount(clientName, noOfVisits);
            return account;
        }
        public List<InsuredGlanceOutputModel> GetInsuredGlanceDetails(int ClientID)
        {
            List<InsuredGlanceOutputModel> InsuredGlanceDetails = _trackerReportingBO.GetInsuredGlanceDetails(ClientID);
            return InsuredGlanceDetails;
        }

        public List<InsuredHistoricalForecastOutputModel> GetInsuredHistoricalForecastDetails(int ClientID)
        {
            List<InsuredHistoricalForecastOutputModel> InsuredHistoricalForecastDetails = _trackerReportingBO.GetInsuredHistoricalForecastDetails(ClientID);
            return InsuredHistoricalForecastDetails;
        }
        public List<InsuredInformationOutputModel> GetInsuredInformationDetails(int ClientID)
        {
            List<InsuredInformationOutputModel> InsuredInformationDetails = _trackerReportingBO.GetInsuredInformationDetails(ClientID);
            return InsuredInformationDetails;
        }

        public List<StewardshipRententionOuputModel> GetStewardshipRentention(string clientName)
        {
            List<StewardshipRententionOuputModel> rentention = _trackerReportingBO.GetStewardshipRentention(clientName);
            return rentention;
        }
        public List<InsuredSummaryOutputModel> GetInsuredCurrentInforceSummary(LostandDeclinedInsuredInputModel objLostandDeclinedInsuredInputModel)
        {
            List<InsuredSummaryOutputModel> InsuredCurrentInforceSummary = _trackerReportingBO.GetInsuredCurrentInforceSummary(objLostandDeclinedInsuredInputModel);
            return InsuredCurrentInforceSummary;
        }

        public List<InsuredSummaryOutputModel> GetInsuredTargetSummary(LostandDeclinedInsuredInputModel objLostandDeclinedInsuredInputModel)
        {
            List<InsuredSummaryOutputModel> InsuredTargetSummary = _trackerReportingBO.GetInsuredTargetSummary(objLostandDeclinedInsuredInputModel);
            return InsuredTargetSummary;
        }
        public string DeleteInsuredSummaryDetails(int ClientID, int ProductNo)
        {
            string deleteinsuredsummarydtls = _trackerReportingBO.DeleteInsuredSummaryDetails(ClientID, ProductNo);
            return deleteinsuredsummarydtls;
        }

        public List<PoliciesTargetsOutputModel> GetPoliciesTarget(string UserID)
        {
            List<PoliciesTargetsOutputModel> objGetPoliciesTarget = _trackerReportingBO.GetPoliciesTarget(UserID);
            return objGetPoliciesTarget;
        }



        public string ExcludeInsuredSummaryDetails(InsuredSummaryExludeAccountsInputModel objInsuredSummaryExludeAccountsInputModel)
        {
            string excludeinsuredsummarydtls = _trackerReportingBO.ExcludeInsuredSummaryDetails(objInsuredSummaryExludeAccountsInputModel);
            return excludeinsuredsummarydtls;
        }
        public string IncludeInsuredSummaryDetails(string ClientID, List<string> RecordNo)
        {
            string includeinsuredsummarydtls = _trackerReportingBO.IncludeInsuredSummaryDetails(ClientID, RecordNo);
            return includeinsuredsummarydtls;
        }

        public List<InsuredDNBSearchOutputModel> GetInsuredDNBDetails(string ClientID)
        {
            List<InsuredDNBSearchOutputModel> objGetInsuredDNBDetails = _trackerReportingBO.GetInsuredDNBDetails(ClientID);
            return objGetInsuredDNBDetails;
        }

        public List<DNBHierarchySearchOutputModel> GetInsuredDNBHierarchySearch(string DunsNo)
        {
            List<DNBHierarchySearchOutputModel> objGetInsuredDNBHierarchySearch = _trackerReportingBO.GetInsuredDNBHierarchySearch(DunsNo);
            return objGetInsuredDNBHierarchySearch;
        }
        public string UpdateInsuredInformation(UpdateInsuredInputModel objUpdateInsuredInputModel)
        {
            string updateinsuredsummarydtls = _trackerReportingBO.UpdateInsuredInformation(objUpdateInsuredInputModel);
            return updateinsuredsummarydtls;
        }
        public List<InsuredCurrentInforceMappingOutputModel> GetExcludeCurrentBusinessAccounts(int ClientID)
        {
            List<InsuredCurrentInforceMappingOutputModel> objGetExcludeCurrentBusinessAccounts = _trackerReportingBO.GetExcludeCurrentBusinessAccounts(ClientID);
            return objGetExcludeCurrentBusinessAccounts;
        }
        public List<InsuredCurrentInforceMappingOutputModel> GetExcludeLostDeclinedBusinessAccounts(int ClientID)
        {
            List<InsuredCurrentInforceMappingOutputModel> objGetExcludeLostDeclinedBusinessAccounts = _trackerReportingBO.GetExcludeLostDeclinedBusinessAccounts(ClientID);
            return objGetExcludeLostDeclinedBusinessAccounts;
        }
        public List<PoliciesTargetDetailsOutputModel> GetPoliciesTargetdetails(string RecordGUID)
        {
            List<PoliciesTargetDetailsOutputModel> objGetPoliciesTargetdetails = _trackerReportingBO.GetPoliciesTargetdetails(RecordGUID);
            return objGetPoliciesTargetdetails;
        }
        public List<DropdownOutputValues> GetInsuredAccountType()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetInsuredAccountType();
            return listDetails;
        }
        public List<DropdownOutputValues> GetInsuredDunsNumber(InsuredDunsNumberInputModel InsuredDunsNumberInputModel)
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetInsuredDunsNumber(InsuredDunsNumberInputModel);
            return listDetails;
        }

        public string GetQuickXcelExport(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = _trackerReportingBO.GetQuickXcelExport(trackingReportingCommonFilterInputModel);
            return outputFilePath;
        }


        public List<GetScorecardGrowthMixOutputModel> GetScorecardGrowthMix(GetScorecardGrowthMixInputModel GetScorecardGrowthMixInputModel)
        {
            List<GetScorecardGrowthMixOutputModel> GetScorecardGrowthMix = _trackerReportingBO.GetScorecardGrowthMix(GetScorecardGrowthMixInputModel);
            return GetScorecardGrowthMix;
        }


        public List<string> ProducerProfileDownload(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<string> forecastSummary = _trackerReportingBO.ProducerProfileDownload(trackingReportingCommonFilterInputModel);
            return forecastSummary;
        }

        public StringBuilder GetUWSummaryNewBusinessTotalDownload(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            StringBuilder forecastSummary = _trackerReportingBO.GetUWSummaryNewBusinessTotalDownload(trackingReportingCommonFilterInputModel);
            return forecastSummary;
        }

        public StringBuilder GetUWSummaryRenewalTotalDownload(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            StringBuilder forecastSummary = _trackerReportingBO.GetUWSummaryRenewalTotalDownload(trackingReportingCommonFilterInputModel);
            return forecastSummary;
        }
        public StringBuilder GetUWSummaryTotalForecastTotalDownload(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            StringBuilder forecastSummary = _trackerReportingBO.GetUWSummaryTotalForecastTotalDownload(trackingReportingCommonFilterInputModel);
            return forecastSummary;
        }
        public string UpdateInsuredSummaryComments(int ClientID, string Comments, char CommentsFor)
        {
            string Result = _trackerReportingBO.UpdateInsuredSummaryComments(ClientID, Comments, CommentsFor);
            return Result;
        }
        public List<DropdownOutputValues> GetOwnerBranchFilter(List<string> Region)
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetOwnerBranchFilter(Region);
            return listDetails;
        }
        public List<CreditedRegionBranchOutputModel> GetOwnerRegionBranchFilters()
        {
            List<CreditedRegionBranchOutputModel> listDetails = _trackerReportingBO.GetOwnerRegionBranchFilters();
            return listDetails;
        }

        public List<GetCustomerProfileInformationDetailsOutputModel> GetCustomerProfileInformationDetails(GetCustomerProfileInformationDetailsInputModel GetCustomerProfileInformationDetailsInputModel)
        {
            List<GetCustomerProfileInformationDetailsOutputModel> GetCustomerProfileInformationDetails = _trackerReportingBO.GetCustomerProfileInformationDetails(GetCustomerProfileInformationDetailsInputModel);
            return GetCustomerProfileInformationDetails;
        }
        public List<GetNetScorecardbyDivisionOutputModel> GetNetScorecardbyDivision(GetNetScorecardbyDivisionInputModel GetNetScorecardbyDivisionInputModel)
        {
            List<GetNetScorecardbyDivisionOutputModel> GetNetScorecardbyDivision = _trackerReportingBO.GetNetScorecardbyDivision(GetNetScorecardbyDivisionInputModel);
            return GetNetScorecardbyDivision;
        }
        public List<GetNetScorecardbyRegionOutputModel> GetNetScorecardbyRegion(GetNetScorecardbyDivisionInputModel GetNetScorecardbyDivisionInputModel)
        {
            List<GetNetScorecardbyRegionOutputModel> GetNetScorecardbyRegion = _trackerReportingBO.GetNetScorecardbyRegion(GetNetScorecardbyDivisionInputModel);
            return GetNetScorecardbyRegion;
        }
        public List<GetHomeOfficeMarginbypercentageOutputModel> GetHomeOfficeMarginbypercentage(GetHomeOfficeMarginInputModel GetHomeOfficeMarginInputModel)
        {
            List<GetHomeOfficeMarginbypercentageOutputModel> GetHomeOfficeMarginbypercentage = _trackerReportingBO.GetHomeOfficeMarginbypercentage(GetHomeOfficeMarginInputModel);
            return GetHomeOfficeMarginbypercentage;
        }
        public List<GetHomeOfficeMarginbyCurrencyOutputModel> GetHomeOfficeMarginbyCurrency(GetHomeOfficeMarginInputModel GetHomeOfficeMarginInputModel)
        {
            List<GetHomeOfficeMarginbyCurrencyOutputModel> GetHomeOfficeMarginbyCurrency = _trackerReportingBO.GetHomeOfficeMarginbyCurrency(GetHomeOfficeMarginInputModel);
            return GetHomeOfficeMarginbyCurrency;
        }

        public byte[] GetQuickPdfExport(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            byte[] forecastSummary = _trackerReportingBO.GetQuickPdfExport(trackingReportingCommonFilterInputModel);
            return forecastSummary;
        }

        public List<string> GetScorecardDownload(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<string> ScorecardDownload = _trackerReportingBO.GetScorecardDownload(trackingReportingCommonFilterInputModel);
            return ScorecardDownload;
        }

        public byte[] ExportCustomerDocument(int ClientID)
        {
            byte[] exportWordDocument = _trackerReportingBO.ExportCustomerDocument(ClientID);
            return exportWordDocument;
        }

        public List<BulkUpdateLoad> GetBulkUpdateLoad(BulkUpdateLoadInputModel bulkUpdateLoadInputModel)
        {
            List<BulkUpdateLoad> bulkupdateload = _trackerReportingBO.GetBulkUpdateLoad(bulkUpdateLoadInputModel);
            return bulkupdateload;
        }

        public int GetBulkUpdateSave(BulkUpdateSave bulkUpdateSave)
        {
            return _trackerReportingBO.GetBulkUpdateSave(bulkUpdateSave);

        }

        public List<PostMortemUpdateInputModel> GetPostMortermDetails(int RecordNumber)
        {
            List<PostMortemUpdateInputModel> postmortermdetails = _trackerReportingBO.GetPostMortermDetails(RecordNumber);
            return postmortermdetails;
        }

        public string GetHelpFilePath(int FileID)
        {
            string strFilePath = _trackerReportingBO.GetHelpFilePath(FileID);
            return strFilePath;
        }

        public List<InsuredSearchOutputModel> GetInsuredName(string strInsuredName)
        {
            List<InsuredSearchOutputModel> listDetails = _trackerReportingBO.GetInsuredName(strInsuredName);
            return listDetails;
        }

        public List<OptionsGroupItems> GetInsuredWildcardSearchResult(string filterValue)
        {
            List<OptionsGroupItems> listDetails = _trackerReportingBO.GetInsuredWildcardSearchResult(filterValue);
            return listDetails;
        }

        public List<SuretyScorecardByBondCategoryOutputModel> GetSuretyScorecardByBondCategory(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<SuretyScorecardByBondCategoryOutputModel> suretyDetails = _trackerReportingBO.GetSuretyScorecardByBondCategory(trackingReportingCommonFilterInputModel);
            return suretyDetails;
        }
        public List<SuretyScorecardByCreditedRegionOutputModel> GetSuretyScorecardByCreditedRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<SuretyScorecardByCreditedRegionOutputModel> suretyDetails = _trackerReportingBO.GetSuretyScorecardByCreditedRegion(trackingReportingCommonFilterInputModel);
            return suretyDetails;
        }
        public List<RegionalMarginOutputModel> GetRegionalMargin(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<RegionalMarginOutputModel> regionalMargin = _trackerReportingBO.GetRegionalMargin(trackingReportingCommonFilterInputModel);
            return regionalMargin;
        }
        public List<GrowthMixByBusinessOutputModel> GetGrowthMixMarginByBusiness(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<GrowthMixByBusinessOutputModel> growthMixByBusiness = _trackerReportingBO.GetGrowthMixMarginByBusiness(trackingReportingCommonFilterInputModel);
            return growthMixByBusiness;
        }
        public List<GrowthMixByRegionOutputModel> GetGrowthMixMarginByRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<GrowthMixByRegionOutputModel> growthMixByRegion = _trackerReportingBO.GetGrowthMixMarginByRegion(trackingReportingCommonFilterInputModel);
            return growthMixByRegion;
        }
        public List<HomeOfficeMarginPercentByBusinessOutputModel> GetHomeOfficeMarginPercentByBusiness(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<HomeOfficeMarginPercentByBusinessOutputModel> marginDetails = _trackerReportingBO.GetHomeOfficeMarginPercentByBusiness(trackingReportingCommonFilterInputModel);
            return marginDetails;
        }
        public List<HomeOfficeMarginPercentByCreditedRegionOutputModel> GetHomeOfficeMarginPercentByCreditedRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
         {
            List<HomeOfficeMarginPercentByCreditedRegionOutputModel> marginDetails = _trackerReportingBO.GetHomeOfficeMarginPercentByCreditedRegion(trackingReportingCommonFilterInputModel);
            return marginDetails;
        }
        public List<HomeOfficeMarginByBusinessSegmentOutputModel> GetHomeOfficeMarginByBusinessSegment(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<HomeOfficeMarginByBusinessSegmentOutputModel> marginDetails = _trackerReportingBO.GetHomeOfficeMarginByBusinessSegment(trackingReportingCommonFilterInputModel);
            return marginDetails;
        }
        public List<HomeOfficeMarginByCreditedRegionOutputModel> GetHomeOfficeMarginByCreditedRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<HomeOfficeMarginByCreditedRegionOutputModel> marginDetails = _trackerReportingBO.GetHomeOfficeMarginByCreditedRegion(trackingReportingCommonFilterInputModel);
            return marginDetails;
        }
        public bool GetRecordNavigation(int RecordNumber)
        {
            bool bCheckNavigation = _trackerReportingBO.GetRecordNavigation(RecordNumber);
            return bCheckNavigation;
        }
        public List<PassCodeDetailsOutputModel> GetPasCodeDetails(PassCodeDetailsInputModell passCodeDetailsInputModell)
        {
            List<PassCodeDetailsOutputModel> pascodeDetails = _trackerReportingBO.GetPasCodeDetails(passCodeDetailsInputModell);
            return pascodeDetails;
        }
        public List<ERCSummaryOutputModel> GetERCSummaryDetails(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<ERCSummaryOutputModel> ercsummary = _trackerReportingBO.GetERCSummaryDetails(trackingReportingCommonFilterInputModel);
            return ercsummary;
        }
        public List<EditProfileOutputModel> GetEditProfileDetails(EditProfileInputModel editProfileInputModel)
        {
            List<EditProfileOutputModel> editProfile = _trackerReportingBO.GetEditProfileDetails(editProfileInputModel);
            return editProfile;
        }
              
        public List<ERCDetailOutputModel> GetERCDetails(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<ERCDetailOutputModel> ercdetail = _trackerReportingBO.GetERCDetails(trackingReportingCommonFilterInputModel);
            return ercdetail;
        }
        public List<UnitSegmentDetailsOutputModel> GetUnitSegmentDetailsByUserID(string userID)
        {
            List<UnitSegmentDetailsOutputModel> unitSegmentDetails = _trackerReportingBO.GetUnitSegmentDetailsByUserID(userID);
            return unitSegmentDetails;
        }

        public List<SubmissionDetails> GetSubmissionDetails(int RecordNumber)
        {
            List<SubmissionDetails> submissionDetails = _trackerReportingBO.GetSubmissionDetails(RecordNumber);
            return submissionDetails;
        }
        public string GetEditProfileSave(EditProfileSaveInputModel editProfileSaveInputModel)
        {
            string profileSave = _trackerReportingBO.GetEditProfileSave(editProfileSaveInputModel);
            return profileSave;
        }
        public string GetLinkedReport(string FileName)
        {
            string strFilePath = _trackerReportingBO.GetLinkedReport(FileName);
            return strFilePath;
        }

        public List<TargetProgressionByBranchOutputModel> GetTargetProgressionByBranch(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingBO.GetTargetProgressionByBranch(trackingReportingCommonFilterInputModel);
        }

        public List<TargetProgressionByRegionOutputModel> GetTargetProgressionByRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingBO.GetTargetProgressionByRegion(trackingReportingCommonFilterInputModel);
        }

        public TargetProgressionByLobOutputModel GetTargetProgressionByLob(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingBO.GetTargetProgressionByLob(trackingReportingCommonFilterInputModel);
        }

        public StringBuilder GetForecastVariationExcel(ForecastVariationInputModel forecastVariationInputModel)
        {
            StringBuilder forcastVariation = _trackerReportingBO.GetForecastVariationExcel(forecastVariationInputModel);
            return forcastVariation;
        }
        public List<DropdownOutputValues> GetServiceBranchFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetServiceBranchFilter();
            return listDetails;
        }
        public List<DropdownOutputValues> GetPolicyTypeFilter()
        {
            List<DropdownOutputValues> listDetails = _trackerReportingBO.GetPolicyTypeFilter();
            return listDetails;
        }
        public List<DeeplinkAppFiltersResult> GetDeeplinkAppFiltersByID(string userID, int applicationID)
        {
            List<DeeplinkAppFiltersResult> deeplinkAppFilters = _trackerReportingBO.GetDeeplinkAppFiltersByID(userID, applicationID);
            return deeplinkAppFilters;
        }
        public List<string> GetPinnedReportsByID(string userID)
        {
            List<string> PinnedReports = _trackerReportingBO.GetPinnedReportsByID(userID);
            return PinnedReports;
        }
        public string SavePinnedReportsByID(SavePinnedReportsInputModel savePinnedReportsInputModel)
        {
            return _trackerReportingBO.SavePinnedReportsByID(savePinnedReportsInputModel);
        }
    }
}