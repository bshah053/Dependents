﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Chubb.Tracker.EnterpriseIntegration.CRM.Model;
using Chubb.Tracker.TrackerReportingService.Facade.Interfaces;
using Chubb.Tracker.TrackerReportingService.Business.Interfaces;
using Chubb.Tracker.Framework.Unity;
using System.Text;

namespace Chubb.Tracker.TrackerReportingService.Facade.Implementation
{
    public class TrackerReportingEnterpriseIntegrationFacade : ITrackerReportingEnterpriseIntegrationFacade
    {

        private readonly ITrackerReportingEnterpriseIntegrationBO _trackerReportingEnterpriseIntegrationBO = UnityManager.Resolve<ITrackerReportingEnterpriseIntegrationBO>();      
        

        public List<ContactOutputModel> GetContactbyCustomer(CustomerProfileInputModel objCustomerProfileInputModel)
        {
            List<ContactOutputModel> objCRMContactbyCustomer = _trackerReportingEnterpriseIntegrationBO.GetContactbyCustomer(objCustomerProfileInputModel);
            return objCRMContactbyCustomer;
        }

        public List<ContactOutputModel> GetContactbyProducer(ProducerDetailsCRMInputModel objProducerDetailsInputModel)
        {
            List<ContactOutputModel> objCRMContactbyProducer = _trackerReportingEnterpriseIntegrationBO.GetContactbyProducer(objProducerDetailsInputModel);
            return objCRMContactbyProducer;
        }

        //public List<MeetingDetailsOutputModel> GetMeetingbyCustomer(CustomerDetailsInputModel objViewCustomerMeetingInputModel)
        //{
        //    List<MeetingDetailsOutputModel> objCRMMeetingbyCustomer = _trackerReportingEnterpriseIntegrationBO.GetMeetingbyCustomer(objViewCustomerMeetingInputModel);
        //    return objCRMMeetingbyCustomer;
        //}

        public List<MeetingDetailsInfoOutputModel> GetMeetingbyProducer(ProducerDetailsCRMInputModel objViewProducerMeetingInputModel)
        {
            List<MeetingDetailsInfoOutputModel> objCRMMeetingbyProducer = _trackerReportingEnterpriseIntegrationBO.GetMeetingbyProducer(objViewProducerMeetingInputModel);
            return objCRMMeetingbyProducer;
        }
        public List<ContactOutputModel> GetContactbyprodlocation(ContactDetailsInputModel objcontactDetailsInputModel)
        {
            List<ContactOutputModel> objCrmContactbyprodlocation = _trackerReportingEnterpriseIntegrationBO.GetContactbyProdLocation(objcontactDetailsInputModel);
            return objCrmContactbyprodlocation;
        }

        public UserCRMDynamicDetailsOutputModel GetCRMDynamicUserDetails(String UserID)
        {
            UserCRMDynamicDetailsOutputModel objCRMDetialsOutput = _trackerReportingEnterpriseIntegrationBO.GetCRMDynamicUserDetails(UserID);
            return objCRMDetialsOutput;
        }
        public List<AttachmentsDetailsOutputModel> GetAttachmentsbyProducer(ProducerDetailsCRMInputModel objViewProducerAttachmentsInputModel)
        {
            List<AttachmentsDetailsOutputModel> objCRMAttachmentsbyProducer = _trackerReportingEnterpriseIntegrationBO.GetAttachmentsbyProducer(objViewProducerAttachmentsInputModel);
            return objCRMAttachmentsbyProducer;
        }
        public List<NotesDetailsOutputModel> GetNotesbyProducer(ProducerDetailsCRMInputModel objViewProducerNotesInputModel)
        {
            List<NotesDetailsOutputModel> objCRMNotesbyProducer = _trackerReportingEnterpriseIntegrationBO.GetNotesbyProducer(objViewProducerNotesInputModel);
            return objCRMNotesbyProducer;
        }
        public List<UserTaskOutputModel> GetTaskbyProducer(ProducerDetailsCRMInputModel objViewProducerNotesInputModel)
        {
            List<UserTaskOutputModel> objCRMTaskbyProducer = _trackerReportingEnterpriseIntegrationBO.GetTaskbyProducer(objViewProducerNotesInputModel);
            return objCRMTaskbyProducer;
        }

        public List<CRMCompletedActivitiesOutputModel> GetCRMCompletedActivitiesByProducer(ProducerDetailsCRMInputModel objProducerDetailsCRMInputModel)
        {
            List<CRMCompletedActivitiesOutputModel> objGetCRMCompletedActivitiesByProducer = _trackerReportingEnterpriseIntegrationBO.GetCRMCompletedActivitiesByProducer(objProducerDetailsCRMInputModel);
            return objGetCRMCompletedActivitiesByProducer;
        }
        public List<MeetingDetailsOutputModel> GetCRMMeetingByBranch(BranchDetailsCRMInputModel objViewBranchMeetingInputModel)
        {
            List<MeetingDetailsOutputModel> objCRMMeetingbyBranch = _trackerReportingEnterpriseIntegrationBO.GetCRMMeetingByBranch(objViewBranchMeetingInputModel);
            return objCRMMeetingbyBranch;
        }
        public List<CRMCompletedActivitiesOutputModel> GetCRMCompletedActivitiesByCustomer(CustomerProfileInputModel objCustomerProfileInputModel)
        {
            List<CRMCompletedActivitiesOutputModel> objCRMCompletedActivitiesByCustomer = _trackerReportingEnterpriseIntegrationBO.GetCRMCompletedActivitiesByCustomer(objCustomerProfileInputModel);
            return objCRMCompletedActivitiesByCustomer;
        }

        public List<UserTaskOutputModel> GetCRMTaskByCustomer(CustomerProfileInputModel objCustomerProfileInputModel)
        {
            List<UserTaskOutputModel> objCRMTaskbyCustomer = _trackerReportingEnterpriseIntegrationBO.GetCRMTaskByCustomer(objCustomerProfileInputModel);
            return objCRMTaskbyCustomer;
        }
        public List<NotesDetailsOutputModel> GetNotesbyCustomer(CustomerProfileInputModel objCustomerProfileInputModel)
        {
            List<NotesDetailsOutputModel> objCRMNotesbyCustomer = _trackerReportingEnterpriseIntegrationBO.GetNotesbyCustomer(objCustomerProfileInputModel);
            return objCRMNotesbyCustomer;
        }
        public List<MeetingDetailsInfoOutputModel> GetMeetingbyCustomer(CustomerProfileInputModel objCustomerProfileInputModel)
        {
            List<MeetingDetailsInfoOutputModel> objCRMMeetingbyCustomer = _trackerReportingEnterpriseIntegrationBO.GetMeetingbyCustomer(objCustomerProfileInputModel);
            return objCRMMeetingbyCustomer;
        }

        public List<ROVOutputModel> GetROVReport(ROVInputModel loadReportInputModel)
        {
            List<ROVOutputModel> rovReport = _trackerReportingEnterpriseIntegrationBO.GetROVReport(loadReportInputModel);
            return rovReport;
        }
        public StringBuilder GetROVReportExcel(ROVInputModel loadReportInputModel)
        {
            StringBuilder rovexcel = _trackerReportingEnterpriseIntegrationBO.GetROVReportExcel(loadReportInputModel);
            return rovexcel;
        }

        public SummaryActivityOutputModel GetTravelScorecard(SummaryActivityInputModel objSummaryActivityInputModel)
        {
            return _trackerReportingEnterpriseIntegrationBO.GetTravelScorecard(objSummaryActivityInputModel);
        }
    }

}