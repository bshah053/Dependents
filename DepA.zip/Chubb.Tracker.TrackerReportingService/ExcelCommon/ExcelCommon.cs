﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Reflection;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Spreadsheet;
using Chubb.Tracker.Framework.Helper;
using Chubb.Tracker.Framework.ExcelEngine;
using Chubb.Tracker.ServiceModel.TrackingReporting;
using Chubb.Tracker.TrackerReportingService.Data.Implementation;
#endregion Namespaces

namespace Chubb.Tracker.TrackerReportingService.ExcelCommon
{
    /// <summary>
    /// Author			 Created Date		Last Modified		Last Modified By		 Comments
    /// Sureshkumar G    04-June-2020                                                     Initial Version.
    ///                                      06-June-2020         Sureshkumar G           Added new method ExportToXcel to create Xcel file based on the datasource. 
    ///                                      12-June-2020         Sureshkumar G           Implemented common function to export excel.
    ///                                      02-September-2020    Sureshkumar G           Added new method for Regional & Net Scorecard
    /// </summary>
    public static class ExcelCommon
    {

        #region Public Methods

        /// <summary>
        /// To Create Xcel file based on the given datasource.
        /// </summary>
        /// <param name="inputFilterValueModel"></param>
        /// <param name="sourceTable"></param>
        /// <returns></returns>
        public static string ExportToXcel(Object inputFilterValueModel, DataTable sourceTable)
        {
            string outputFilePath = string.Empty;
            try
            {
                ExcelCreationInputModel excelCreationInputModel = new ExcelCreationInputModel();
                TrackerReportingRepository _trackerReportingRepository = new TrackerReportingRepository();

                //To Assign Default Value
                AssignDefaultValue(excelCreationInputModel, inputFilterValueModel);
                List<ExcelColumnMappingOutputModel> excelColumnMappingDetails = _trackerReportingRepository.GetExcelColumnMapping(excelCreationInputModel.ReportName);

                string[] xlWidthCollection = excelColumnMappingDetails.Select(x => x.XLColumnWidth).ToArray();
                
                outputFilePath = ExcelEngine.GetXLOutputPath(excelCreationInputModel.ReportName, excelCreationInputModel.UserId);
                int xlRowStartIndex = 1;
                UInt32Value sheeIdValue = 1;

                using (SpreadsheetDocument xlDocument = SpreadsheetDocument.Create(outputFilePath, SpreadsheetDocumentType.Workbook))
                {
                    //Create new xl worksheet part and new sheet
                    WorksheetPart xlWorksheetPart = ExcelEngine.CreateXLWorksheetPartAndSheets(xlDocument, sheeIdValue, excelCreationInputModel.SheetName);

                    using (var xlWriter = OpenXmlWriter.Create(xlWorksheetPart))
                    {
                        List<OpenXmlAttribute> xmlAttribute = null;
                        xlWriter.WriteStartElement(new Worksheet());
                        //Freeze header of report
                        ExcelEngine.SetHeaderRowFrozen(xlWriter, excelCreationInputModel.ReportName);
                        //Set Column Width 
                        if (xlWidthCollection != null && xlWidthCollection.Length > 0) { ExcelEngine.SetXLColumnWidth(xmlAttribute, xlWriter, xlWidthCollection); }

                        xlWriter.WriteStartElement(new SheetData());
                        //To Write Download Report Header Text
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, xlRowStartIndex.ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        ExcelEngine.WriteDataToExcel(xlWriter, excelCreationInputModel.ReportHeaderName, "string", 5);
                        //For Download Report Header Value End Element
                        xlWriter.WriteEndElement();

                        //To Write Excel Column Header Text
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex + 1).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        ExcelHeaderCreation(xlWriter, excelColumnMappingDetails, sourceTable);
                        //ForHeader Value End Element
                        xlWriter.WriteEndElement();

                        //To Write XL Rows
                        int rowIndex = 0;
                        ExcelRowCreation(xmlAttribute, xlWriter, excelColumnMappingDetails, sourceTable, ref rowIndex, xlRowStartIndex);

                        //To Write Blank Row.
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (rowIndex + (xlRowStartIndex + 2)).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                        //For row value end element
                        xlWriter.WriteEndElement();
                        rowIndex++;

                        //To Write Filter Rows header
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (rowIndex + (xlRowStartIndex + 2)).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        ExcelEngine.WriteDataToExcel(xlWriter, excelCreationInputModel.SearchCriteriaName, "string", 7);
                        //For row value end element
                        xlWriter.WriteEndElement();
                        rowIndex++;

                        //To Write Filter Rows Values
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (rowIndex + (xlRowStartIndex + 2)).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        WriteFilterValues(xlWriter, inputFilterValueModel);
                        //For row value end element
                        xlWriter.WriteEndElement();

                        //For final end element
                        xlWriter.WriteStartElement(new Workbook());
                        xlWriter.WriteStartElement(new Worksheet());
                    }
                    //Create XL Workbook Part.
                    ExcelEngine.CreateXLWorkbookPart(xlDocument);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outputFilePath;
        }

        /// <summary>
        /// To Create Structured/hierarchical excel like scorecard report
        /// </summary>
        /// <param name="excelCreationInputModel"></param>
        /// <param name="trackingReportingCommonFilterInputModel"></param>
        /// <param name="xlDocument"></param>
        /// <param name="xlWorksheetPart"></param>
        /// <param name="xlWorkbookPart"></param>
        /// <param name="xlSheets"></param>
        /// <param name="sourceTable"></param>
        /// <param name="groupLevel"></param>
        public static void CreateCustomXcelSheet(ExcelCreationInputModel excelCreationInputModel,
            TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel,
            SpreadsheetDocument xlDocument, WorksheetPart xlWorksheetPart, WorkbookPart xlWorkbookPart,
            Sheets xlSheets, DataTable sourceTable,int groupLevel
            )
       {
            excelCreationInputModel.SearchCriteriaName = excelCreationInputModel.SearchCriteriaName != string.Empty ? "Selected Search Criteria" : excelCreationInputModel.SearchCriteriaName;
            TrackerReportingRepository _trackerReportingRepository = new TrackerReportingRepository();
            List<ExcelColumnMappingOutputModel> excelColumnMappingDetails = _trackerReportingRepository.GetExcelColumnMapping(excelCreationInputModel.ReportName);
            string[] xlWidthCollection = excelColumnMappingDetails.Select(x => x.XLColumnWidth).ToArray();
            int xlRowStartIndex = 1;
            UInt32Value sheeIdValue = Convert.ToUInt32(excelCreationInputModel.SheeIdValue);
            try
            {
                //Create new xl worksheet part and new sheet
                xlWorksheetPart = CreateAndXLSheet(xlWorksheetPart, xlWorkbookPart, xlSheets, sheeIdValue, excelCreationInputModel.SheetName);
                using (var xlWriter = OpenXmlWriter.Create(xlWorksheetPart))
                {
                    List<OpenXmlAttribute> xmlAttribute = null;
                    xlWriter.WriteStartElement(new Worksheet());
                    //Freeze header of report
                    ExcelEngine.SetHeaderRowFrozen(xlWriter, excelCreationInputModel.ReportName);
                    //Set Column Width 
                    if (xlWidthCollection != null && xlWidthCollection.Length > 0) ExcelEngine.SetXLColumnWidth(xmlAttribute, xlWriter, xlWidthCollection);

                    xlWriter.WriteStartElement(new SheetData());
                    
                    //To Write Download Report Header Text
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, xlRowStartIndex.ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    ExcelEngine.WriteDataToExcel(xlWriter, excelCreationInputModel.ReportHeaderName, "string", 5);
                    //For Download Report Header Value End Element
                    xlWriter.WriteEndElement();

                    //To Write Blank Row.
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex + 1).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //To Write Excel Column Header Text
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex + 2).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    ExcelHeaderCreationWithCustom(xlWriter, excelColumnMappingDetails, sourceTable, groupLevel, excelCreationInputModel.ReportName);
                    //ForHeader Value End Element
                    xlWriter.WriteEndElement();

                    //To Write XL Rows
                    int rowIndex = 0;
                    ExcelRowCreationWithCustom(xmlAttribute, xlWriter, excelColumnMappingDetails, sourceTable, groupLevel, ref rowIndex, xlRowStartIndex);

                    //To Write Blank Row.
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (rowIndex + (xlRowStartIndex + 3)).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                    //For row value end element
                    xlWriter.WriteEndElement();
                    rowIndex++;

                    //To Write Filter Rows header
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (rowIndex + (xlRowStartIndex + 3)).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    ExcelEngine.WriteDataToExcel(xlWriter, excelCreationInputModel.SearchCriteriaName, "string", 7);
                    //For row value end element
                    xlWriter.WriteEndElement();
                    rowIndex++;

                    //To Write Filter Rows Values
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (rowIndex + (xlRowStartIndex + 3)).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    WriteFilterValues(xlWriter, trackingReportingCommonFilterInputModel);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //For final end element
                    xlWriter.WriteStartElement(new Workbook());
                    xlWriter.WriteStartElement(new Worksheet());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
                {
                excelCreationInputModel = null;
            }
        }

        #endregion Public Methods

        #region Private Methods        

        /// <summary>
        /// To Write Excel row based on datatype
        /// </summary>
        /// <param name="xmlAttribute"></param>
        /// <param name="xlWriter"></param>
        /// <param name="excelColumnMappingDetails"></param>
        /// <param name="sourceTable"></param>
        /// <param name="rowIndex"></param>
        /// <param name="xlRowStartIndex"></param>
        private static void ExcelRowCreation(List<OpenXmlAttribute> xmlAttribute, OpenXmlWriter xlWriter,
            List<ExcelColumnMappingOutputModel> excelColumnMappingDetails, DataTable sourceTable, ref int rowIndex, int xlRowStartIndex)
        {
            if(sourceTable!= null && sourceTable.Rows.Count>0)
            {
                string dataType = string.Empty;
                UInt32Value styleIndexValue = 0;
                for (int soruceRowIndex = 0; soruceRowIndex < sourceTable.Rows.Count; soruceRowIndex++)
                {
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (rowIndex + (xlRowStartIndex + 2)).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);

                    for (int columnIndex = 0; columnIndex < sourceTable.Columns.Count; columnIndex++)
                    {
                        dataType = string.Empty;
                        if (excelColumnMappingDetails != null && excelColumnMappingDetails.Count > 0)
                        {
                        var mappingTable = excelColumnMappingDetails
                            .Where(x => x.ElementName == Convert.ToString(sourceTable.Columns[columnIndex].ColumnName))
                                            .Select(x => new
                                            {
                                                x.ElementName,
                                                x.ElementDataType,
                                                x.StyleIndex
                                            }).SingleOrDefault();
                            if (mappingTable != null) {
                                string cellValue = Convert.ToString(sourceTable.Rows[soruceRowIndex][columnIndex]);
                                dataType = mappingTable.ElementDataType;
                                styleIndexValue = (mappingTable.StyleIndex != null && mappingTable.StyleIndex != "" )  ? Convert.ToUInt32(mappingTable.StyleIndex) : 0;
                                WriteXcelCellValueByDataType(xlWriter, dataType, cellValue, styleIndexValue);
                            }
                        }
                        else
                        {
                            dataType = Convert.ToString(sourceTable.Columns[columnIndex].DataType);
                            string cellValue = Convert.ToString(sourceTable.Rows[soruceRowIndex][columnIndex]);
                            WriteXcelCellValueByDataType(xlWriter, dataType, cellValue, styleIndexValue);
                        }
                    }

                    //ForHeader Value End Element
                    xlWriter.WriteEndElement();
                    rowIndex++;
                }
            }
        }

        /// <summary>
        /// Write Excel Cell Value based on DataType for plain/standard format excel.
        /// </summary>
        /// <param name="xlWriter"></param>
        /// <param name="dataType"></param>
        /// <param name="cellValue"></param>
        /// <param name="styleIndexValue"></param>
        private static void WriteXcelCellValueByDataType(OpenXmlWriter xlWriter, string dataType, string cellValue, UInt32Value styleIndexValue)
                        {
            switch (dataType)
                            {
                                case "string":
                case "System.String":
                    ExcelEngine.WriteDataToExcel(xlWriter, cellValue, "string", styleIndexValue > 1 ? styleIndexValue : 4);
                                    break;
                                case "date":
                    if (!string.IsNullOrEmpty(cellValue)) ExcelEngine.WriteDataToExcel(xlWriter, ExcelEngine.GetDateValue(cellValue), "date", styleIndexValue > 1 ? styleIndexValue : 2);
                    else ExcelEngine.WriteDataToExcel(xlWriter, cellValue, "string", styleIndexValue > 1 ? styleIndexValue : 4);
                                    break;
                                case "number":
                case "System.Int64":
                case "System.Int32":
                case "System.Decimal":
                    ExcelEngine.WriteDataToExcel(xlWriter, cellValue, "number", styleIndexValue > 1 ? styleIndexValue : 3);
                                    break;
                                case "":
                    ExcelEngine.WriteDataToExcel(xlWriter, "", "string", styleIndexValue > 1 ? styleIndexValue : 4);
                                    break;
                                default:
                    ExcelEngine.WriteDataToExcel(xlWriter, cellValue, "string", styleIndexValue > 1 ? styleIndexValue : 4);
                                    break;
                            }
                        }
               
        /// <summary>
        /// To Write Filter Values in footer section.
        /// </summary>
        /// <param name="xlWriter"></param>
        /// <param name="inputFilterValueModel"></param>
        private static void WriteFilterValues(OpenXmlWriter xlWriter,Object inputFilterValueModel)
        {
            string filterValue = string.Empty;
            foreach (PropertyInfo info in inputFilterValueModel.GetType().GetProperties())
            {
                List<string> oTheList = info.GetValue(inputFilterValueModel, null) as List<string>;
                string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                if (info.GetValue(inputFilterValueModel, null) != null && info.GetValue(inputFilterValueModel, null).ToString() != "0" && info.GetValue(inputFilterValueModel, null).ToString() != "")
                {
                    if (!info.PropertyType.Name.Contains("List"))
                    {
                        var value = info.GetValue(inputFilterValueModel, null);
                        //var filter = info.Name + ":" + value + ";";
                        string filter =string.Empty;
                        if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "FilterBy" && info.Name != "GroupBy" && info.Name != "PageNumber" && info.Name != "PageSize" && info.Name != "StrCore" && info.Name != "StrNonCore" && info.Name != "InsulLogic")
                        {
                            if (info.Name == "EffectiveDateStart" || info.Name == "EffectiveDateEnd" || info.Name == "ExpirationDateStart" ||
                            info.Name == "ExpirationDateEnd" || info.Name == "CreateDateStart" || info.Name == "CreateDateEnd")
                            {
                                string xlDateValue = ExcelEngine.GetDateValue(Convert.ToString(value));
                                if (xlDateValue != string.Empty)
                                {
                                    filter = info.Name + " : " + xlDateValue + ";";
                                    ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                }
                            }
                            else if(info.Name != "ExportType" && info.Name != "UserID" && info.Name != "DisableBrowseBy" && info.Name != "ReportName" && info.Name != "Range")
                            {
                                if (!string.IsNullOrEmpty(Convert.ToString(value)))
                                {
                                    filter = info.Name + ":" + value + ";";
                                    ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                }
                            }
                            else if (info.Name == "Range" && Convert.ToString(value) != "=")
                            {
                                filter = info.Name + ":" + value + ";";
                                ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                            }
                        }
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(listValue))
                        {
                            var filter = info.Name + ":" + listValue + ";";
                            ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// To Assign Default values for mandatory elements.
        /// </summary>
        /// <param name="excelCreationInputModel"></param>
        /// <param name="inputFilterValueModel"></param>
        private static void AssignDefaultValue(ExcelCreationInputModel excelCreationInputModel, dynamic inputFilterValueModel)
        {
            excelCreationInputModel.ReportName = inputFilterValueModel.ReportName;
            excelCreationInputModel.SheetName = (inputFilterValueModel.ReportName != null && inputFilterValueModel.ReportName != "") ? inputFilterValueModel.ReportName : "Sheet";
            excelCreationInputModel.UserId = (inputFilterValueModel.UserID != null && inputFilterValueModel.UserID != "" ? inputFilterValueModel.UserID : "");
            excelCreationInputModel.SearchCriteriaName = "Selected Search Criteria";
            if (inputFilterValueModel.ReportName == "Target Report") { excelCreationInputModel.ReportHeaderName = "Target Search"; }
            if (inputFilterValueModel.ReportName == "Forecast Variation") { excelCreationInputModel.ReportHeaderName = "Variation Report : All the figures listed below are in (USD)"; }
        }

        /// <summary>
        /// To Create/Write excel header row for Custom/Structured/hierarchical
        /// </summary>
        /// <param name="xlWriter"></param>
        /// <param name="excelColumnMappingDetails"></param>
        /// <param name="sourceTable"></param>
        /// <param name="groupLevel"></param>
        /// <param name="reportName"></param>
        private static void ExcelHeaderCreationWithCustom(OpenXmlWriter xlWriter, List<ExcelColumnMappingOutputModel> excelColumnMappingDetails,
            DataTable sourceTable, int groupLevel, string reportName)
        {
            if (excelColumnMappingDetails != null && excelColumnMappingDetails.Count > 0)
            {
                for (int columnIndex = (groupLevel == 2 ? 1 : groupLevel == 5 ? 3 : 0); columnIndex < sourceTable.Columns.Count; columnIndex++)
                {
                    string elementHeaderText = string.Empty;
                    if (groupLevel == 2 && columnIndex == 1)
                    {
                        if (reportName == "RegionalScoreCardAmountPerRegion" || reportName == "RegionalScorecardNewBusinessByStatus"
                            || reportName == "RegionalScorecardRenewalByStatus" || reportName == "NetScorecardAmountPerRegion"
                            || reportName == "GrowthMixByRegion" || reportName == "HomeOfficeByRegion" || reportName== "ERCSummaryByCreditedRegion")
                        {
                            elementHeaderText = "Credited Branch/Region";
                        }
                        else if (reportName == "SuretyScorecardByBondCategory" || reportName == "SuretyScorecardByCreditedRegion")
                        {
                            elementHeaderText = "Bond Category";
                        }
                    }
                    else if (groupLevel == 5 && columnIndex == 3)
                    {
                        if (reportName == "NetScorecardAmountPerDivision" || reportName == "ERCSummaryByBusinessSegment" || reportName == "ERCSummaryByPortfolioClass")
                        {
                            elementHeaderText = "Business Segment";
                        }
                        else if (reportName == "RegionalMargin" || reportName == "GrowthMixByBusiness" || reportName == "HomeOfficeByBusinessSegment")
                        {
                            elementHeaderText = "Line of Business";
                        }
                    }
                    else
                    {
                        elementHeaderText = excelColumnMappingDetails
                            .Where(x => x.ElementName == Convert.ToString(sourceTable.Columns[columnIndex].ColumnName))
                            .Select(x => x.ElementHeaderText).SingleOrDefault();
                    }
                    if (!string.IsNullOrEmpty(elementHeaderText))
                    {
                        ExcelEngine.WriteDataToExcel(xlWriter, elementHeaderText, "string", 1);
                    }
                }
            }
        }

        /// <summary>
        /// To Write Excel file Header based on the header text
        /// </summary>
        /// <param name="xlWriter"></param>
        /// <param name="excelColumnMappingDetails"></param>
        /// <param name="sourceTable"></param>
        private static void ExcelHeaderCreation(OpenXmlWriter xlWriter, List<ExcelColumnMappingOutputModel> excelColumnMappingDetails, DataTable sourceTable)
        {
            if (excelColumnMappingDetails != null && excelColumnMappingDetails.Count > 0)
            {
                for (int columnIndex = 0; columnIndex < sourceTable.Columns.Count; columnIndex++)
                {
                    string elementHeaderText = excelColumnMappingDetails
                        .Where(x => x.ElementName == Convert.ToString(sourceTable.Columns[columnIndex].ColumnName))
                        .Select(x => x.ElementHeaderText).SingleOrDefault();
                    if (!string.IsNullOrEmpty(elementHeaderText)) { ExcelEngine.WriteDataToExcel(xlWriter, elementHeaderText, "string", 1); }
                }
            }
            else
            {
                for (int columnIndex = 0; columnIndex < sourceTable.Columns.Count; columnIndex++)
                {
                    ExcelEngine.WriteDataToExcel(xlWriter, sourceTable.Columns[columnIndex].ColumnName, "string", 1);
                }
            }
        }

        /// <summary>
        /// Excel row creation for Custom/Structured/hierarchical
        /// </summary>
        /// <param name="xmlAttribute"></param>
        /// <param name="xlWriter"></param>
        /// <param name="excelColumnMappingDetails"></param>
        /// <param name="sourceTable"></param>
        /// <param name="groupLevel"></param>
        /// <param name="rowIndex"></param>
        /// <param name="xlRowStartIndex"></param>
        private static void ExcelRowCreationWithCustom(List<OpenXmlAttribute> xmlAttribute, OpenXmlWriter xlWriter,
           List<ExcelColumnMappingOutputModel> excelColumnMappingDetails,
           DataTable sourceTable, int groupLevel, ref int rowIndex, int xlRowStartIndex)
        {
            if (sourceTable != null && sourceTable.Rows.Count > 0)
            {
                //1st Level - Company
                string groupColumnNameOne = Convert.ToString(sourceTable.Columns[0].ColumnName);
                //var parentItems = sourceTable.AsEnumerable().GroupBy(group => group.Field<string>(groupColumnNameOne)).OrderBy(row => row.Key);
                var parentItems = groupLevel == 2 ? sourceTable.AsEnumerable().GroupBy(group => group.Field<string>(groupColumnNameOne)).OrderBy(row => row.Key) :
                    sourceTable.AsEnumerable().GroupBy(group => group.Field<string>(groupColumnNameOne));

                foreach (var item in parentItems)
                {
                    if (item.Key != null)
                    {
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (rowIndex + (xlRowStartIndex + 3)).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        WriteCellValueByDataType(xlWriter, excelColumnMappingDetails, item.Key, groupColumnNameOne, 0);

                        for (int columnIndex = groupLevel; columnIndex < sourceTable.Columns.Count; columnIndex++)
                        {
                            string columnName = Convert.ToString(sourceTable.Columns[columnIndex].ColumnName);
                            if (groupLevel == 2)
                            {
                                WriteCellValueByDataType(xlWriter, excelColumnMappingDetails,
                                Convert.ToString(item.ToList().OrderBy(row => row.Field<string>(Convert.ToString(sourceTable.Columns[1].ColumnName))).ToList()[0][columnName]),columnName, 0);
                            }
                            else
                            {
                                WriteCellValueByDataType(xlWriter, excelColumnMappingDetails, Convert.ToString(item.ToList()[0][columnName]), columnName, 0);
                               
                            }
                        }
                        xlWriter.WriteEndElement();
                        rowIndex++;
                    }
                    if (groupLevel > 1)
                    {
                        //2nd Level - Division
                        string groupColumnNameTwo = Convert.ToString(sourceTable.Columns[1].ColumnName);
                        var ChildLevelItemsOne = item.GroupBy(c => c.Field<string>(groupColumnNameTwo)).ToList();
                        foreach (var itemOne in ChildLevelItemsOne)
                        {
                            if (itemOne.Key != null)
                            {
                                xmlAttribute = new List<OpenXmlAttribute>();
                                xmlAttribute.Add(new OpenXmlAttribute("r", null, (rowIndex + (xlRowStartIndex + 3)).ToString()));
                                xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                WriteCellValueByDataType(xlWriter, excelColumnMappingDetails, itemOne.Key, groupColumnNameTwo, 1);

                                for (int columnIndex = groupLevel; columnIndex < sourceTable.Columns.Count; columnIndex++)
                                {
                                    string columnName = Convert.ToString(sourceTable.Columns[columnIndex].ColumnName);
                                    WriteCellValueByDataType(xlWriter, excelColumnMappingDetails, Convert.ToString(itemOne.ToList()[0][columnName]), columnName, 1);
                                   
                                }
                                xlWriter.WriteEndElement();
                                rowIndex++;
                            }
                            //3rd Level - Unit
                            if (groupLevel > 2)
                            {
                                string groupColumnNameThree = Convert.ToString(sourceTable.Columns[2].ColumnName);
                                var ChildLevelItemsTwo = itemOne.GroupBy(c => c.Field<string>(groupColumnNameThree)).ToList();
                                foreach (var itemTwo in ChildLevelItemsTwo)
                                {
                                    if (itemTwo.Key != null)
                                    {
                                        xmlAttribute = new List<OpenXmlAttribute>();
                                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (rowIndex + (xlRowStartIndex + 3)).ToString()));
                                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                        WriteCellValueByDataType(xlWriter, excelColumnMappingDetails, itemTwo.Key, groupColumnNameThree, 1);

                                        for (int columnIndex = groupLevel; columnIndex < sourceTable.Columns.Count; columnIndex++)
                                        {
                                            string columnName = Convert.ToString(sourceTable.Columns[columnIndex].ColumnName);
                                            WriteCellValueByDataType(xlWriter, excelColumnMappingDetails, Convert.ToString(itemTwo.ToList()[0][columnName]), columnName, 2);
                                            
                                        }
                                        xlWriter.WriteEndElement();
                                        rowIndex++;
                                    }
                                    //4th Level
                                    if (groupLevel > 3)
                                    {
                                        string groupColumnNameFour = Convert.ToString(sourceTable.Columns[3].ColumnName);
                                        var ChildLevelItemsThree = itemTwo.GroupBy(c => c.Field<string>(groupColumnNameFour)).ToList();
                                        foreach (var itemThree in ChildLevelItemsThree)
                                        {
                                            if (itemThree.Key != null)
                                            {
                                                xmlAttribute = new List<OpenXmlAttribute>();
                                                xmlAttribute.Add(new OpenXmlAttribute("r", null, (rowIndex + (xlRowStartIndex + 3)).ToString()));
                                                xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                                WriteCellValueByDataType(xlWriter, excelColumnMappingDetails, itemThree.Key, groupColumnNameFour, 1);

                                                for (int columnIndex = groupLevel; columnIndex < sourceTable.Columns.Count; columnIndex++)
                                                {
                                                    string columnName = Convert.ToString(sourceTable.Columns[columnIndex].ColumnName);
                                                    WriteCellValueByDataType(xlWriter, excelColumnMappingDetails, Convert.ToString(itemThree.ToList()[0][columnName]), columnName, 3);
                                                }
                                                xlWriter.WriteEndElement();
                                                rowIndex++;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// To Write cell value based on DataType for Custom/Structured/hierarchical
        /// </summary>
        /// <param name="xlWriter"></param>
        /// <param name="excelColumnMappingDetails"></param>
        /// <param name="cellValue"></param>
        /// <param name="columnName"></param>
        /// <param name="styleRowIndex"></param>
        private static void WriteCellValueByDataType(OpenXmlWriter xlWriter, 
            List<ExcelColumnMappingOutputModel> excelColumnMappingDetails,string cellValue,string columnName,int styleRowIndex)
        {
            var mappingTable = excelColumnMappingDetails
                                .Where(x => x.ElementName == columnName)
                                                .Select(x => new
                                                {
                                                    x.ElementName,
                                                    x.ElementDataType,
                                                    x.StyleIndex
                                                }).SingleOrDefault();

            if (mappingTable != null)
            {
                string[] styleIndex = mappingTable.StyleIndex.Split(';');
                switch (mappingTable.ElementDataType)
                {
                    case "string":
                        ExcelEngine.WriteDataToExcel(xlWriter, cellValue, "string", Convert.ToUInt32(styleIndex[0]));
                        break;
                    case "number":
                        ExcelEngine.WriteDataToExcel(xlWriter, cellValue, "number", Convert.ToUInt32(styleIndex[styleRowIndex]));
                        break;
                    default:
                        ExcelEngine.WriteDataToExcel(xlWriter, cellValue, "string", 4);
                        break;
                }
            }
        }

        /// <summary>
        /// To Create/Add excel sheet for Custom/Structured/hierarchical
        /// </summary>
        /// <param name="xlWorksheetPart"></param>
        /// <param name="xlWorkbookPart"></param>
        /// <param name="xlSheets"></param>
        /// <param name="sheeIdValue"></param>
        /// <param name="sheetName"></param>
        /// <returns></returns>
        private static WorksheetPart CreateAndXLSheet(WorksheetPart xlWorksheetPart, WorkbookPart xlWorkbookPart,
            Sheets xlSheets, UInt32Value sheeIdValue, string sheetName)
        {
            xlWorksheetPart = xlWorkbookPart.AddNewPart<WorksheetPart>();
            Sheet xlSheet = null;
            xlSheet = new Sheet()
            {
                Id = xlWorkbookPart.GetIdOfPart(xlWorksheetPart),
                SheetId = sheeIdValue,
                Name = sheetName
            };
            xlSheets.Append(xlSheet);
            return xlWorksheetPart;
        }

        #endregion Private Methods
    }
}