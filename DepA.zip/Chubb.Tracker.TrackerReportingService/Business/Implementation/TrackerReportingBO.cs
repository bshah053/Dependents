﻿using Chubb.Tracker.ServiceModel.TrackingReporting;
using Chubb.Tracker.TrackerReportingService.Business.Interfaces;
using Chubb.Tracker.TrackerReportingService.Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Chubb.Tracker.EnterpriseIntegration.DNB.Model;
using Chubb.Tracker.Framework.Unity;
using System.Data;
using Chubb.Tracker.Framework.Helper;
using System.Text.RegularExpressions;
using Chubb.Tracker.ServiceModel.TrackerReporting;
using System.Text;
using Chubb.Tracker.TrackerReportingService.Data.Database;
using System.Reflection;
using Winnovative;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using Chubb.Tracker.Framework.ExcelEngine;
using Chubb.Tracker.ServiceModel.Submission;

namespace Chubb.Tracker.TrackerReportingService.Business.Implementation
{
    public class TrackerReportingBO : ITrackerReportingBO
    {
        private readonly ITrackerReportingRepository _trackerReportingRepository = UnityManager.Resolve<ITrackerReportingRepository>();

        public List<UWNewBusinessGoalsQuoteRatioOutputModel> ProcessUnderWriterNewBusinessQuoteRatioData(LoadUWGoalsInputModel UWNBQuoteRatioDetails)
        {
            return _trackerReportingRepository.FetchUnderWriterNewBusinessQuoteRatioData(UWNBQuoteRatioDetails);
        }
        public List<DropdownOutputValues> GetCreditedRegionFilter()
        {
            return _trackerReportingRepository.GetCreditedRegionFilter();
        }
        public List<DropdownOutputValues> GetServiceBranchFilter()
        {
            return _trackerReportingRepository.GetServiceBranchFilter();
        }
        public List<DropdownOutputValues> GetPolicyTypeFilter()
        {
            return _trackerReportingRepository.GetPolicyTypeFilter();
        }
        public List<DropdownOutputValues> GetCRMChubbMarketSegmentFilter()
        {
            return _trackerReportingRepository.GetCRMChubbMarketSegmentFilter();
        }
        public List<DropdownOutputValues> GetCreditedBranchFilter(List<string> Region)
        {
            return _trackerReportingRepository.GetCreditedBranchFilter(Region);
        }
        public List<CreditedRegionBranchOutputModel> GetCreditedRegionBranchFilter()
        {
            return _trackerReportingRepository.GetCreditedRegionBranchFilter();
        }
        public List<DropdownOutputValues> GetCompanyFilter(string UserID)
        {
            return _trackerReportingRepository.GetCompanyFilter(UserID);
        }
        public List<DropdownOutputValues> GetDivisionFilter(string UserID, List<string> Company)
        {
            return _trackerReportingRepository.GetDivisionFilter(UserID, Company);
        }
        public List<DropdownOutputValues> GetOwnerUnitFilter(string UserID, List<string> Company)
        {
            return _trackerReportingRepository.GetOwnerUnitFilter(UserID, Company);
        }
        public List<DropdownOutputValues> GetUnitFilter(UnitFilterData UnitFilterData)
        {
            return _trackerReportingRepository.GetUnitFilter(UnitFilterData);
        }
        public List<DropdownOutputValues> GetSegmentFilter(SegmentFilterData segmentFilterData)
        {
            return _trackerReportingRepository.GetSegmentFilter(segmentFilterData);
        }
        public List<DropdownOutputValues> GetSubSegmentFilter(SubsegmentFilterData subsegmentFilterData)
        {
            return _trackerReportingRepository.GetSubSegmentFilter(subsegmentFilterData);
        }
        public List<DropdownOutputValues> GetMCCFilter(MCCFilterData mccFilterData)
        {
            return _trackerReportingRepository.GetMCCFilter(mccFilterData);//TRKR-7584
        }
        public List<DropdownOutputValues> GetPortfolioClassFilter(PortfolioClassFilterData portfolioClassFilterData)
        {
            return _trackerReportingRepository.GetPortfolioClassFilter(portfolioClassFilterData);
        }
        public List<DropdownOutputValues> GetStatusFilter()
        {
            return _trackerReportingRepository.GetStatusFilter();
        }
        public List<DropdownOutputValues> GetAdvanceSort(string SortReportName)
        {
            return _trackerReportingRepository.GetAdvanceSort(SortReportName);
        }
        public List<DropdownOutputValues> GetImpediment()
        {
            return _trackerReportingRepository.GetImpediment();
        }
        public List<DropdownOutputValues> GetSuccessfulProducer()
        {
            return _trackerReportingRepository.GetSuccessfulProducer();
        }
        public List<DropdownOutputValues> GetLostReasonByStatus(string Status, string Unit, string Segment)
        {
            return _trackerReportingRepository.GetLostReasonByStatus(Status, Unit, Segment);
        }
        public List<DropdownOutputValues> GetUWRegionByUWBranch(string uwBranch)
        {
            return _trackerReportingRepository.GetUWRegionByUWBranch(uwBranch);
        }
        public int DeleteTransactionByRecordNo(TransactionInputModel transactionInputModel)
        {
            return _trackerReportingRepository.DeleteTransactionByRecordNo(transactionInputModel);
        }
        public int CopyTransactionByRecordNo(TransactionInputModel transactionInputModel)
        {
            return _trackerReportingRepository.CopyTransactionByRecordNo(transactionInputModel);
        }
        public int CopyLinkedSubmissionTransactionByRecordNo(TransactionInputModel transactionInputModel)
        {
            return _trackerReportingRepository.CopyLinkedSubmissionTransactionByRecordNo(transactionInputModel);
        }
        public int MoveToNextTermByRecordNo(PostMortemUpdateInputModel portMortemUpdateInputModel)
        {
            return _trackerReportingRepository.MoveToNextTermByRecordNo(portMortemUpdateInputModel);
        }
        public List<SICOutputModel> GetSICCodeFilter()
        {
            return _trackerReportingRepository.GetSICCodeFilter();
        }
        public List<DropdownOutputValues> GetRelationshipManagerFilter()
        {
            return _trackerReportingRepository.GetRelationshipManagerFilter();
        }
        public List<DropdownOutputValues> GetCABDescriptionFilter()
        {
            return _trackerReportingRepository.GetCABDescriptionFilter();
        }
        public List<DropdownOutputValues> GetIndustryPracticeFilter()
        {
            return _trackerReportingRepository.GetIndustryPracticeFilter();
        }
        public List<DropdownOutputValues> GetIndustryPracticeDetailFilter()
        {
            return _trackerReportingRepository.GetIndustryPracticeDetailFilter();
        }
        public List<DropdownOutputValues> GetIncumbentFilter()
        {
            return _trackerReportingRepository.GetIncumbentFilter();
        }
        public List<DropdownOutputValues> GetCRMCallTypeFilter()
        {
            return _trackerReportingRepository.GetCRMCallTypeFilter();
        }
        public List<DropdownOutputValues> GetCRMContactPreferenceFilter()
        {
            return _trackerReportingRepository.GetCRMContactPreferenceFilter();
        }
        public List<DropdownOutputValues> GetCRMEventTypeFilter()
        {
            return _trackerReportingRepository.GetCRMEventTypeFilter();
        }
      
        public List<DropdownOutputValues> GetCornerstoneValues()
        {
            return _trackerReportingRepository.GetCornerstoneValues();
        }
        public List<DropdownOutputValues> GetCRMProducerFilter()
        {
            return _trackerReportingRepository.GetCRMProducerFilter();
        }
        public List<DropdownOutputValues> GetCRMCompanyOwnerTypeFilter()
        {
            return _trackerReportingRepository.GetCRMCompanyOwnerTypeFilter();
        }
        public List<DropdownOutputValues> GetCRMStatusTypeFilter()
        {
            return _trackerReportingRepository.GetCRMStatusTypeFilter();
        }
        public List<DropdownOutputValues> GetCRMActivityTypeFilter()
        {
            return _trackerReportingRepository.GetCRMActivityTypeFilter();
        }
        public List<DropdownOutputValues> GetCRMContactTypeFilter()
        {
            return _trackerReportingRepository.GetCRMContactTypeFilter();
        }
        public List<DropdownOutputValues> GetCRMUserTypeFilter()
        {
            return _trackerReportingRepository.GetCRMUserTypeFilter();
        }

        public List<DropdownOutputValues> GetProducerStateFilter()
        {
            return _trackerReportingRepository.GetProducerStateFilter();
        }
        public List<DropdownOutputValues> GetProducerCityFilter()
        {
            return _trackerReportingRepository.GetProducerCityFilter();
        }
        public List<DropdownOutputValues> GetInsuredStateFilter()
        {
            return _trackerReportingRepository.GetInsuredStateFilter();
        }
        public List<DropdownOutputValues> GetInsuredCityFilter()
        {
            return _trackerReportingRepository.GetInsuredCityFilter();
        }
        public List<DropdownOutputValues> GetIndustryFilter()
        {
            return _trackerReportingRepository.GetIndustryFilter();
        }
        public List<DropdownOutputValues> GetRelationshipTypeFilter()
        {
            return _trackerReportingRepository.GetRelationshipTypeFilter();
        }
        public List<DropdownOutputValues> GetProductFilter()
        {
            return _trackerReportingRepository.GetProductFilter();
        }
        public List<DropdownOutputValues> GetUWBranchFilter(List<string> Region)
        {
            return _trackerReportingRepository.GetUWBranchFilter(Region);
        }

        public List<DropdownOutputValues> GetCurrencyFilter()
        {
            return _trackerReportingRepository.GetCurrencyFilter();
        }
        public List<DropdownOutputValues> GetCapacityFilter()
        {
            return _trackerReportingRepository.GetCapacityFilter();
        }
        public List<DropdownOutputValues> GetPGroupFilter()
        {
            return _trackerReportingRepository.GetPGroupFilter();
        }
        public List<DropdownOutputValues> GetCustomerGroupFilter()//TRKR-5701
        {
            return _trackerReportingRepository.GetCustomerGroupFilter();
        }
        public List<DropdownOutputValues> GetProducerBranchFilter(ProducerBranchFilterInputModel objProducerBranchFilterInputModel)
        {
            return _trackerReportingRepository.GetProducerBranchFilter(objProducerBranchFilterInputModel);
        }
        public List<DropdownOutputValues> GetProducerRegionFilter(ProducerRegionFilterInputModel objProducerRegionFilterInputModel)
        {
            return _trackerReportingRepository.GetProducerRegionFilter(objProducerRegionFilterInputModel);
        }
        public List<DropdownOutputValues> GetCRMRoleFilter()
        {
            return _trackerReportingRepository.GetCRMRoleFilter();
        }
        public List<DropdownOutputValues> GetCRMProductSpecializationFilter()
        {
            return _trackerReportingRepository.GetCRMProductSpecializationFilter();
        }
        public List<DropdownOutputValues> GetCRMIndustrySpecializationFilter()
        {
            return _trackerReportingRepository.GetCRMIndustrySpecializationFilter();
        }
        public List<DropdownOutputValues> GetCRMChubbBusinessUnitFilter()
        {
            return _trackerReportingRepository.GetCRMChubbBusinessUnitFilter();
        }
        public List<DropdownOutputValues> GetProducerGroupFilter()
        {
            return _trackerReportingRepository.GetProducerGroupFilter();
        }
        public List<DropdownOutputValues> GetTClassFilter()
        {
            return _trackerReportingRepository.GetTClassFilter();
        }
        public List<DropdownOutputValues> GetTScore()
        {
            return _trackerReportingRepository.GetTScore();
        }
        public List<DropdownOutputValues> GetTPAFilter()
        {
            return _trackerReportingRepository.GetTPAFilter();
        }
        public List<DropdownOutputValues> GetTerrorCoverageFilter()
        {
            return _trackerReportingRepository.GetTerrorCoverageFilter();
        }
        public DropdownOutputValues GetMaximumForecastAmount()
        {
            return _trackerReportingRepository.GetMaximumForecastAmount();
        }
        public List<DropdownOutputValues> GetUnderwriterFilter(string FilterName)
        {
            return _trackerReportingRepository.GetUnderwriterFilter(FilterName);
        }
        public List<DropdownOutputValues> GetCountryNameFilter()
        {
            return _trackerReportingRepository.GetCountryNameFilter();
        }
        public List<DropdownOutputValues> GetequityfirmFilter()
        {
            return _trackerReportingRepository.GetequityfirmFilter();
        }
        public List<DropdownOutputValues> GetEstPlacementFilter()
        {
            return _trackerReportingRepository.GetEstPlacementFilter();
        }
        public List<CustomerFilterOutputModel> GetCustomerFilter(CustomerFilterInputModel CustomerFilterInputModel)
        {
            return _trackerReportingRepository.GetCustomerFilter(CustomerFilterInputModel);
        }
        public List<ScorecardOverviewOutputModel> GetScorecardOverview(LoadReportInputModel loadReportInputModel)
        {
            return _trackerReportingRepository.GetScorecardOverview(loadReportInputModel);
        }

        public List<ScorecardAmountPerDivionOutputModel> GetScorecardAmountPerDivision(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetScorecardAmountPerDivision(trackingReportingCommonFilterInputModel);
        }
        public List<ScorecardAmountPerDivionOutputModel> GetNetScorecardAmountPerDivision(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetNetScorecardAmountPerDivision(trackingReportingCommonFilterInputModel);
        }
        public List<RegionalScorecardAmountPerRegionOutputModel> GetRegionalScorecardAmountPerRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetRegionalScorecardAmountPerRegion(trackingReportingCommonFilterInputModel);
        }
        public List<RegionalScorecardAmountPerRegionOutputModel> GetNetScorecardAmountPerRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetNetScorecardAmountPerRegion(trackingReportingCommonFilterInputModel);
        }
        public List<ForecastVariationOutputModel> GetForecastVariation(ForecastVariationInputModel forecastVariationInputModel)
        {
            return _trackerReportingRepository.GetForecastVariation(forecastVariationInputModel);
        }
        public List<UWPipelineDetails> GetUWPipelineDetailsTargets(LoadReportInputModel loadReportInputModel)
        {
            return _trackerReportingRepository.GetUWPipelineDetailsTargets(loadReportInputModel);
        }
        public List<UWPipelineDetails> GetUWPipelineDetailsRenewals(LoadReportInputModel loadReportInputModel)
        {
            return _trackerReportingRepository.GetUWPipelineDetailsRenewals(loadReportInputModel);
        }
        public List<UWPipelineDetails> GetUWPipelineDetailsNewBusiness(LoadReportInputModel loadReportInputModel)
        {
            return _trackerReportingRepository.GetUWPipelineDetailsNewBusiness(loadReportInputModel);
        }
        public List<ScorecardRenewalByStatusOutputModel> GetScorecardRenewalByStatus(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetScorecardRenewalByStatus(trackingReportingCommonFilterInputModel);
        }
        public List<RegionalScorecardRenewalByStatusOutputModel> GetRegionalScorecardRenewalByStatus(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetRegionalScorecardRenewalByStatus(trackingReportingCommonFilterInputModel);
        }
        public List<ScorecardByStatusOutputModel> GetScorecardNewBusinessByStatus(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetScorecardNewBusinessByStatus(trackingReportingCommonFilterInputModel);
        }
        public List<RegionalScorecardNewBusinessByStatusOutputModel> GetRegionalScorecardNewBusinessByStatus(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetRegionalScorecardNewBusinessByStatus(trackingReportingCommonFilterInputModel);
        }
        public List<UWSummaryPipelineDetails> GetUWSummaryPipelineDetails(LoadReportInputModel loadReportInputModel)
        {
            return _trackerReportingRepository.GetUWSummaryPipelineDetails(loadReportInputModel);
        }

        public List<UWSummaryNBLostAndDeclineOutputModel> GetUWSummaryNewBusinessLostAndDeclineDetails(LoadReportInputModel loadReportInputModel)
        {
            return _trackerReportingRepository.GetUWSummaryNewBusinessLostAndDeclineDetails(loadReportInputModel);
        }
        public List<ProducerLookupOutputModel> GetProducerLookupOverview(ProducerLookupInputModel producerlookupInput)
        {
            return _trackerReportingRepository.GetProducerLookupOverview(producerlookupInput);
        }
        public List<DetailReport> GetDetailReport(TrackingReportingCommonFilterInputModel loadReportInputModel)
        {
            return _trackerReportingRepository.GetDetailReport(loadReportInputModel);
        }
        public List<DetailReport> GetArchiveDetailReport(TrackingReportingCommonFilterInputModel loadReportInputModel)
        {
            return _trackerReportingRepository.GetArchiveDetailReport(loadReportInputModel);
        }
        public List<TargetReportOutputModel> GetTargetReport(TrackingReportingCommonFilterInputModel loadReportInputModel)
        {
            return _trackerReportingRepository.GetTargetReport(loadReportInputModel);
        }
        //public List<ForecastVariationOutputModel>  GetVariationReport(TrackingReportingCommonFilterInputModel loadReportInputModel)
        //{
        //    return _trackerReportingRepository.GetForecastVariation(loadReportInputModel);
        //}
        public InsuredReportOutputModel GetInsuredReport(InsuredSearchFilterInputModel loadReportInputModel)
        {
            return _trackerReportingRepository.GetInsuredReport(loadReportInputModel);
        }
        public InsuredReportOutputModel GetArchiveInsuredReport(InsuredSearchFilterInputModel loadReportInputModel)
        {
            return _trackerReportingRepository.GetArchiveInsuredReport(loadReportInputModel);
        }
        //public string GetDNBCountryCode(string CompanyName, string StateCode)
        //{
        //    return _trackerReportingRepository.GetDNBCountryCode(CompanyName, StateCode);
        //}
        public List<UWSummaryAtGlanceoutputModel> GetUWSummaryAtGlance(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel, int ProducerVisitsYTDCount)
        {
            return _trackerReportingRepository.GetUWSummaryAtGlance(trackingReportingCommonFilterInputModel, ProducerVisitsYTDCount);
        }
        public List<UWSummaryNewBusinessoutputModel> GetUWSummaryNewBusiness(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetUWSummaryNewBusiness(trackingReportingCommonFilterInputModel);
        }
        public List<UWSummaryNewBusinessoutputModel> GetUWSummaryNewBusinessTotal(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetUWSummaryNewBusinessTotal(trackingReportingCommonFilterInputModel);
        }
        public List<UWSummaryRenewaloutputModel> GetUWSummaryRenewal(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetUWSummaryRenewal(trackingReportingCommonFilterInputModel);
        }
        public List<UWSummaryRenewaloutputModel> GetUWSummaryRenewalTotal(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetUWSummaryRenewalTotal(trackingReportingCommonFilterInputModel);
        }
        public List<UWSummaryTotalforecasteoutputModel> GetUWSummaryTotalForecast(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetUWSummaryTotalForecast(trackingReportingCommonFilterInputModel);
        }
        public List<UWSummaryTotalforecasteoutputModel> GetUWSummaryTotalForecastTotal(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetUWSummaryTotalForecastTotal(trackingReportingCommonFilterInputModel);
        }
        public List<UWGoalsNewBusinessOutputModel> GetUWGoalsNewBusiness(LoadReportInputModel loadReportInputModel)
        {
            return _trackerReportingRepository.GetUWGoalsNewBusiness(loadReportInputModel);
        }
        public List<UWGoalsHitQuoteRatioOutputModel> GetUWGoalsHitRatio(LoadReportInputModel loadReportInputModel)
        {
            return _trackerReportingRepository.GetUWGoalsHitRatio(loadReportInputModel);
        }
        public UWGoalsHitQuoteRatioDetailsOutputModel GetUWGoalsHitRatioDetails(LoadReportInputModel loadReportInputModel)
        {
            return _trackerReportingRepository.GetUWGoalsHitRatioDetails(loadReportInputModel);
        }
        public TravelGoalsOutputModel GetTravelGoals(TravelGoalsInputModel goalsInputModel, int NoOfVisits)
        {
            return _trackerReportingRepository.GetTravelGoals(goalsInputModel, NoOfVisits);
        }
        public AccountingMonthClosedDatesOutputModel GetAccountingMonthClosedDates(TravelGoalsInputModel goalsInputModel)
        {
            return _trackerReportingRepository.GetAccountingMonthClosedDates(goalsInputModel);
        }

        public string GetEmailID(string UserID)
        {
            return _trackerReportingRepository.GetEmailID(UserID);
        }

        public UWGoalsHitQuoteRatioDetailsOutputModel GetUWGoalsQuoteRatioDetails(LoadReportInputModel loadReportInputModel)
        {
            return _trackerReportingRepository.GetUWGoalsQuoteRatioDetails(loadReportInputModel);
        }
        public HelpOutputValues GetHelpDetails(string UserID)
        {
            return _trackerReportingRepository.GetHelpDetails(UserID);
        }
        public List<ForecastByBusinessSegmentOutputModel> GetForecastSummary(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetForecastSummary(trackingReportingCommonFilterInputModel);
        }
        public List<ForecastByBusinessSegmentOutputModel> GetForecastSummaryTotal(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetForecastSummaryTotal(trackingReportingCommonFilterInputModel);
        }

        public List<ForecastRegionDataOutputModel> GetForecastRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetForecastRegion(trackingReportingCommonFilterInputModel);
        }
        public List<ForecastRegionDataOutputModel> GetForecastRegionTotal(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetForecastRegionTotal(trackingReportingCommonFilterInputModel);
        }
        public FilterDataOutputModel SaveFilterDetails(LoadFilterInputModel loadFilterInputModel)
        {
            return _trackerReportingRepository.SaveFilterDetails(loadFilterInputModel);

        }
        //public List<ForecastVariationOutputModel> GetForecastVariation(TrackingReportingCommonFilterInputModel variationInputModel)
        //{
        //    return _trackerReportingRepository.GetForecastVariation(variationInputModel);
        //}

        public List<GetFilterOutputModel> GetMySavedOrRecentViewReports(GetFilterInputModel getFilterInputModel)
        {
            return _trackerReportingRepository.GetMySavedOrRecentViewReports(getFilterInputModel);
        }

        public List<UWGoalsHitQuoteRatioOutputModel> GetUWGoalsQuoteRatio(LoadReportInputModel loadReportInputModel)
        {
            List<UWGoalsHitQuoteRatioOutputModel> goalsQuoteRatio = _trackerReportingRepository.GetUWGoalsQuoteRatio(loadReportInputModel);
            return goalsQuoteRatio;
        }

        public List<DropdownOutputValues> GetAccountingMonthFilter()
        {
            return _trackerReportingRepository.GetAccountingMonthFilter();
        }

        public List<DropdownOutputValues> GetAccountingYearFilter()
        {
            return _trackerReportingRepository.GetAccountingYearFilter();
        }

        public List<DropdownOutputValues> GetTargetTypeFilter()
        {
            return _trackerReportingRepository.GetTargetTypeFilter();
        }

        public List<DropdownOutputValues> GetTransactionTypeFilter()
        {
            return _trackerReportingRepository.GetTransactionTypeFilter();
        }

        public List<DropdownOutputValues> GetProgramFilter()
        {
            return _trackerReportingRepository.GetProgramFilter();
        }

        public List<DropdownOutputValues> GetMarketingManagerFilter()
        {
            return _trackerReportingRepository.GetMarketingManagerFilter();
        }

        public List<DropdownOutputValues> GetDataSourceFilter()
        {
            return _trackerReportingRepository.GetDataSourceFilter();
        }

        public List<DropdownOutputValues> GetChubbIndustryFilter()
        {
            return _trackerReportingRepository.GetChubbIndustryFilter();
        }

        public List<DropdownOutputValues> GetUWRegionFilter()
        {
            return _trackerReportingRepository.GetUWRegionFilter();
        }

        public List<Chubb5000DetailListOutputModel> GetChubb5000DetailListDetails(Chubb5000DetailListInputModel chubb5000DetailListInputModel)
        {
            List<Chubb5000DetailListOutputModel> chubb5000DetailList = _trackerReportingRepository.GetChubb5000DetailListDetails(chubb5000DetailListInputModel);
            return chubb5000DetailList;
        }
        public List<GetProducerGoalsOutputModel> GetProfilePlanGoalReport(string ProducerProfileName)
        {
            List<GetProducerGoalsOutputModel> producerGoalDetails = _trackerReportingRepository.GetProfilePlanGoalReport(ProducerProfileName);
            return producerGoalDetails;
        }
        public string SaveProfilePlanGoalReport(List<ProducerProfileGoalModel> getproducerProfileInputModel)
        {
            string producerGoalDetails = _trackerReportingRepository.SaveProfilePlanGoalReport(getproducerProfileInputModel);
            return producerGoalDetails;
        }
        public string AddProfilePlanGoalReport(List<AddProducerProfileGoalModel> getproducerProfileInputModel)
        {
            string producerGoalDetails = _trackerReportingRepository.AddProfilePlanGoalReport(getproducerProfileInputModel);
            return producerGoalDetails;
        }
        public GetProducerAtGlanceOutputModel GetProfileAtGlance(string ProducerProfileName)
        {
            GetProducerAtGlanceOutputModel producerGoalDetails = _trackerReportingRepository.GetProfileAtGlance(ProducerProfileName);
            return producerGoalDetails;
        }

        public List<ProducerFilterOutputModel> GetProducerFilter(ProducerFilterInputModel objProducerFilterInputModel)
        {
            return _trackerReportingRepository.GetProducerFilter(objProducerFilterInputModel);
        }

        public List<DropdownOutputValues> GetPASCodeFilter(PasCodeFilterInputModel objPasCodeFilterInputModel)
        {
            return _trackerReportingRepository.GetPASCodeFilter(objPasCodeFilterInputModel);
        }

        public List<TrackerQueueDetailsOutputModel> GetTrackerQueue(TrackerQueueInputModel trackerQueueInputModel)
        {
            return _trackerReportingRepository.GetTrackerQueue(trackerQueueInputModel);
        }

        public List<CoreElementsOutputModel> GetCoreElements(string userID)
        {
            return _trackerReportingRepository.GetCoreElements(userID);
        }

        public List<MultiNoncoreElementsOutputModel> GetMultiNoncoreElements(string userID)
        {
            return _trackerReportingRepository.GetMultiNoncoreElements(userID);
        }

        public List<NonCoreElementsOutputModel> GetNonCoreElements(string userID)
        {
            return _trackerReportingRepository.GetNonCoreElements(userID);
        }
        public StringBuilder ExportData(ExportInputModel exportInputModel)
        {
            StringBuilder dataTable = _trackerReportingRepository.ExportData(exportInputModel);

            return dataTable;


        }

        public byte[] ExportCustomerDocument(int ClientID)
        {

            StringBuilder CustomerDocument = _trackerReportingRepository.ExportCustomerDocument(ClientID);

            string strReportHeader = "Customer Profile Document";

            string finalcontent = CustomerDocument.ToString();

            return WinnovativeConverter(finalcontent, strReportHeader, true);

        }
        public List<CustomerProfileSummaryOutputModel> GetCustomerProfileSummary(CustomerPofileSummaryInputModel customerProfilesummaryInputModel)
        {
            List<CustomerProfileSummaryOutputModel> summary = _trackerReportingRepository.GetCustomerProfileSummary(customerProfilesummaryInputModel);
            return summary;
        }

        public string SaveOrUpdateRecords(TrackQueueInputPageInputModel trackQueueInputPageInputModel)
        {
            string Saveuserdetails = _trackerReportingRepository.SaveOrUpdateRecords(trackQueueInputPageInputModel);
            return Saveuserdetails;
        }
        public List<BrokerProfileOutputModel> GetBrokerProfile(BrokerProfileInputModel brokerProfileInputModel)
        {
            return _trackerReportingRepository.GetBrokerProfile(brokerProfileInputModel);
        }

        public string SaveSubmissionRouting(SubmissionRoutingModel objSubmissionRoutingInputModel)
        {

            string loginNo = _trackerReportingRepository.GetLogonNumber(objSubmissionRoutingInputModel.UserID);

            DataSet DSsubmissions = new DataSet();
            //Schedule & Output selection
            DataTable dtSchedule = new DataTable();
            dtSchedule.Columns.Add("Login_no", typeof(string));
            dtSchedule.Columns.Add("Schedule_ID", typeof(int));
            dtSchedule.Columns.Add("Schedule_Name", typeof(string));
            dtSchedule.Columns.Add("Created_Date", typeof(DateTime));
            dtSchedule.Columns.Add("Schedule", typeof(string));
            dtSchedule.Columns.Add("Next_Run_Date", typeof(DateTime));
            dtSchedule.Columns.Add("output", typeof(string));


            DataRow drSchedule = dtSchedule.NewRow();
            drSchedule["Login_no"] = loginNo;
            drSchedule["Schedule_ID"] = objSubmissionRoutingInputModel.ScheduleID;
            drSchedule["Schedule_Name"] = objSubmissionRoutingInputModel.ReportName;
            drSchedule["Created_Date"] = DateTime.Now.ToShortDateString();

            if (objSubmissionRoutingInputModel.Schedule.Equals("ToNight"))
            {
                drSchedule["Schedule"] = "Tonight";
                drSchedule["Next_Run_Date"] = System.DateTime.Today;
            }
            else if (objSubmissionRoutingInputModel.Schedule.Equals("Weekly"))
            {
                drSchedule["Schedule"] = "Weekly";
                DateTime firstSundayweek = System.DateTime.Today.AddDays(7);
                while (firstSundayweek.DayOfWeek != DayOfWeek.Sunday)
                {
                    firstSundayweek = firstSundayweek.AddDays(-1);
                }
                drSchedule["Next_Run_Date"] = firstSundayweek;
            }
            else if (objSubmissionRoutingInputModel.Schedule.Equals("BiWeekly"))
            {
                drSchedule["Schedule"] = "Bi-Weekly";
                DateTime firstSundayweek = System.DateTime.Today.AddDays(14);
                while (firstSundayweek.DayOfWeek != DayOfWeek.Sunday)
                {
                    firstSundayweek = firstSundayweek.AddDays(-1);
                }
                drSchedule["Next_Run_Date"] = firstSundayweek;
            }
            else if (objSubmissionRoutingInputModel.Schedule.Equals("Monthly"))
            {
                drSchedule["Schedule"] = "Monthly";
                DateTime firstSundayMonth = new DateTime(System.DateTime.Today.AddMonths(1).Year, System.DateTime.Today.AddMonths(1).Month, 7);
                while (firstSundayMonth.DayOfWeek != DayOfWeek.Sunday)
                {
                    firstSundayMonth = firstSundayMonth.AddDays(-1);
                }
                drSchedule["Next_Run_Date"] = firstSundayMonth;

            }
            else if (objSubmissionRoutingInputModel.Schedule.Equals("Quarterly"))
            {
                drSchedule["Schedule"] = "3Months";
                DateTime firstSundayQuater = System.DateTime.Now;
                if (System.DateTime.Today.Month == 1 || System.DateTime.Today.Month == 2 || System.DateTime.Today.Month == 3)
                {
                    firstSundayQuater = new DateTime(System.DateTime.Today.Year, 4, 7);
                }
                else if (System.DateTime.Today.Month == 4 || System.DateTime.Today.Month == 5 || System.DateTime.Today.Month == 6)
                {
                    firstSundayQuater = new DateTime(System.DateTime.Today.Year, 7, 7);
                }
                else if (System.DateTime.Today.Month == 7 || System.DateTime.Today.Month == 8 || System.DateTime.Today.Month == 9)
                {
                    firstSundayQuater = new DateTime(System.DateTime.Today.Year, 10, 7);
                }
                else if (System.DateTime.Today.Month == 10 || System.DateTime.Today.Month == 11 || System.DateTime.Today.Month == 6)
                {
                    firstSundayQuater = new DateTime(System.DateTime.Today.AddYears(1).Year, 1, 7);
                }
                while (firstSundayQuater.DayOfWeek != DayOfWeek.Sunday)
                {
                    firstSundayQuater = firstSundayQuater.AddDays(-1);
                }
                drSchedule["Next_Run_Date"] = firstSundayQuater;
            }
            else if (objSubmissionRoutingInputModel.Schedule.Equals("Annual"))
            {
                drSchedule["Schedule"] = "Yearly";
                DateTime firstSundayYear = new DateTime(System.DateTime.Today.AddYears(1).Year, 1, 7);
                while (firstSundayYear.DayOfWeek != DayOfWeek.Sunday)
                {
                    firstSundayYear = firstSundayYear.AddDays(-1);
                }
                drSchedule["Next_Run_Date"] = firstSundayYear;

            }
            string nxtDate = Convert.ToDateTime(drSchedule["Next_Run_Date"]).AddDays(1).ToShortDateString();
            string output = "";

            if (objSubmissionRoutingInputModel.ProducerInformation.Count > 0 && !objSubmissionRoutingInputModel.ProducerInformation[0].Equals(string.Empty))
                output += UtilityHelper.ListValueToCommaSeperatedProducerValue(objSubmissionRoutingInputModel.ProducerInformation, ",");

            if (objSubmissionRoutingInputModel.BusinessUnits.Count > 0 && !objSubmissionRoutingInputModel.BusinessUnits[0].Equals(string.Empty))
                output += UtilityHelper.ListValueToCommaSeperatedBusinessValue(objSubmissionRoutingInputModel.BusinessUnits, ",");

            if (objSubmissionRoutingInputModel.InsuredInformation.Count > 0 && !objSubmissionRoutingInputModel.InsuredInformation[0].Equals(string.Empty))
                output += UtilityHelper.ListValueToCommaSeperatedInsuredValue(objSubmissionRoutingInputModel.InsuredInformation, ",");

            if (objSubmissionRoutingInputModel.PolicyData.Count > 0 && !objSubmissionRoutingInputModel.PolicyData[0].Equals(string.Empty))
                output += UtilityHelper.ListValueToCommaSeperatedPolicyValue(objSubmissionRoutingInputModel.PolicyData, ",");

            if (objSubmissionRoutingInputModel.UWInformation.Count > 0 && !objSubmissionRoutingInputModel.UWInformation[0].Equals(string.Empty))
                output += UtilityHelper.ListValueToCommaSeperatedUWValue(objSubmissionRoutingInputModel.UWInformation, ",");

            if (output != "")
                output = output.Substring(0, output.Length - 1);

            drSchedule["output"] = "effective_dt,M.record_no as [Record No]," + output;

            dtSchedule.Rows.Add(drSchedule);

            //Constant filters
            DataTable dtConstant = new DataTable();
            dtConstant.Columns.Add("DateType", typeof(string));
            dtConstant.Columns.Add("NoofDays", typeof(Int32));
            dtConstant.Columns.Add("Efffrom", typeof(DateTime));
            dtConstant.Columns.Add("EffTo", typeof(DateTime));
            dtConstant.Columns.Add("Insured", typeof(string));
            dtConstant.Columns.Add("Type", typeof(string));
            dtConstant.Columns.Add("Status", typeof(string));
            dtConstant.Columns.Add("CrRegion", typeof(string));
            dtConstant.Columns.Add("BrRegion", typeof(string));
            dtConstant.Columns.Add("UwRegion", typeof(string));
            dtConstant.Columns.Add("Crbranch", typeof(string));
            dtConstant.Columns.Add("Broker", typeof(string));
            dtConstant.Columns.Add("brokerstprv", typeof(string));
            dtConstant.Columns.Add("brokercity", typeof(string));
            dtConstant.Columns.Add("brocode", typeof(string));
            dtConstant.Columns.Add("GlobalAccounts", typeof(string));
            dtConstant.Columns.Add("GCE", typeof(string));
            dtConstant.Columns.Add("UWBranch", typeof(string));
            dtConstant.Columns.Add("BrokerBranch", typeof(string));
            dtConstant.Columns.Add("RollingType", typeof(string));

            DataRow drConstant = dtConstant.NewRow();

            string valuebroker = " ";
            if (objSubmissionRoutingInputModel.Producer.Count > 0 && !objSubmissionRoutingInputModel.Producer[0].Equals(string.Empty))
                valuebroker += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Producer, ",");

            drConstant["Broker"] = valuebroker;

            string valueddlbrokerstprv = "";
            if (objSubmissionRoutingInputModel.ProducerStatePrv.Count > 0 && !objSubmissionRoutingInputModel.ProducerStatePrv[0].Equals(string.Empty))
                valueddlbrokerstprv += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.ProducerStatePrv, ",");

            drConstant["brokerstprv"] = valueddlbrokerstprv;

            string brocity = "";
            if (objSubmissionRoutingInputModel.ProducerCity.Count > 0 && !objSubmissionRoutingInputModel.ProducerCity[0].Equals(string.Empty))
                brocity += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.ProducerCity, ",");

            drConstant["brokercity"] = brocity;
            drConstant["brocode"] = objSubmissionRoutingInputModel.ProducerCode.ToString();
            drConstant["GlobalAccounts"] = "";
            drConstant["GCE"] = objSubmissionRoutingInputModel.GCE.ToString();

            string dateType = "";
            if (objSubmissionRoutingInputModel.ExpirationDate)
                dateType = "Expiration";
            if (objSubmissionRoutingInputModel.EffectiveDate)
                dateType = "Effective";
            if (objSubmissionRoutingInputModel.CreateDate)
                dateType = "Create";
            if (objSubmissionRoutingInputModel.Rolling)
                dateType = "Rolling";

            drConstant["DateType"] = dateType;
            drConstant["NoofDays"] = dateType == "Rolling" ? Int32.Parse(objSubmissionRoutingInputModel.NumberOfDays.Replace(",", "")) : 0;
            //TRKR-942
            drConstant["RollingType"] = objSubmissionRoutingInputModel.RollingType;
            //TRKR-942
            if (objSubmissionRoutingInputModel.EffectiveFrom != null)
                drConstant["Efffrom"] = objSubmissionRoutingInputModel.EffectiveFrom.ToString();
            else
                drConstant["Efffrom"] = Convert.ToDateTime("1900-01-01");

            if (objSubmissionRoutingInputModel.EffectiveTo != null)
                drConstant["EffTo"] = objSubmissionRoutingInputModel.EffectiveTo.ToString();
            else
                drConstant["EffTo"] = Convert.ToDateTime("1900-01-01");

            drConstant["Insured"] = Regex.Replace(objSubmissionRoutingInputModel.InsuredExclusion, @"'", @"''");

            string valueStatus = "";
            if (objSubmissionRoutingInputModel.Status.Count > 0 && !objSubmissionRoutingInputModel.Status[0].Equals(string.Empty))
                valueStatus += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Status, ",");

            drConstant["Status"] = valueStatus;

            string valueCrRegion = "";
            if (objSubmissionRoutingInputModel.CreditedRegion.Count > 0 && !objSubmissionRoutingInputModel.CreditedRegion[0].Equals(string.Empty))
                valueCrRegion += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.CreditedRegion, ",");

            drConstant["CrRegion"] = valueCrRegion;

            string valueBrRegion = "";
            if (objSubmissionRoutingInputModel.ProducerRegion.Count > 0 && !objSubmissionRoutingInputModel.ProducerRegion[0].Equals(string.Empty))
                valueBrRegion += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.ProducerRegion, ",");

            drConstant["BrRegion"] = valueBrRegion;

            string valueUwRegion = "";
            if (objSubmissionRoutingInputModel.UWRegion.Count > 0 && !objSubmissionRoutingInputModel.UWRegion[0].Equals(string.Empty))
                valueUwRegion += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.UWRegion, ",");

            drConstant["UwRegion"] = valueUwRegion;

            string valueCrbranch = "";
            if (objSubmissionRoutingInputModel.CreditedRegion.Count > 0 && !objSubmissionRoutingInputModel.CreditedRegion[0].Equals(string.Empty))
                valueCrbranch += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.CreditedRegion, ",");

            drConstant["Crbranch"] = valueCrbranch;

            string valueUWBranch = "";
            if (objSubmissionRoutingInputModel.UWBranch.Count > 0 && !objSubmissionRoutingInputModel.UWBranch[0].Equals(string.Empty))
                valueUWBranch += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.UWBranch, ",");

            drConstant["UWBranch"] = valueUWBranch;

            string valueBrokerBranch = "";
            if (objSubmissionRoutingInputModel.ProducerBranch.Count > 0 && !objSubmissionRoutingInputModel.ProducerBranch[0].Equals(string.Empty))
                valueBrokerBranch += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.ProducerBranch, ",");

            drConstant["BrokerBranch"] = valueBrokerBranch;
            dtConstant.Rows.Add(drConstant);


            DataTable dtVaraiable = new DataTable();
            dtVaraiable.Columns.Add("company", typeof(string));
            dtVaraiable.Columns.Add("division", typeof(string));
            dtVaraiable.Columns.Add("unit", typeof(string));
            dtVaraiable.Columns.Add("segment", typeof(string));
            dtVaraiable.Columns.Add("product", typeof(string));
            dtVaraiable.Columns.Add("ddlforecast", typeof(string));
            dtVaraiable.Columns.Add("forecast", typeof(Int64));
            dtVaraiable.Columns.Add("ddlrevenu", typeof(string));
            dtVaraiable.Columns.Add("revenu", typeof(Int64));
            dtVaraiable.Columns.Add("custseg", typeof(string));
            dtVaraiable.Columns.Add("rowID", typeof(string));
            dtVaraiable.Columns.Add("VaraiableQuery", typeof(string));
            dtVaraiable.Columns.Add("ACEIndustry", typeof(string));
            dtVaraiable.Columns.Add("SicCode", typeof(string));
            dtVaraiable.Columns.Add("PublicPrivate", typeof(string));

            DataRow drVaraiable = dtVaraiable.NewRow();
            string valuecompany = "";
            string VaraiableQuery = string.Empty;

            if (objSubmissionRoutingInputModel.Company.Count > 0 && !objSubmissionRoutingInputModel.Company[0].Equals(string.Empty))
                valuecompany += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Company, ",");

            if (valuecompany != "")
            {
                VaraiableQuery += " and M.Group_Name in(select distinct Group_name from forecaster_subgroup where Company_Name in(" + "''" + Regex.Replace(valuecompany, ",", @"'',''") + "''" + ")) ";
            }
            drVaraiable["company"] = valuecompany;

            string valuedivision = "";
            if (objSubmissionRoutingInputModel.Division.Count > 0 && !objSubmissionRoutingInputModel.Division[0].Equals(string.Empty))
                valuedivision += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Division, ",");

            if (valuedivision != "")
            {
                VaraiableQuery += " and M.Group_Name in(" + "''" + Regex.Replace(valuedivision, ",", @"'',''") + "''" + ")";
            }
            drVaraiable["division"] = valuedivision;

            string valueunit = "";
            if (objSubmissionRoutingInputModel.Unit.Count > 0 && !objSubmissionRoutingInputModel.Unit[0].Equals(string.Empty))
                valueunit += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Unit, ",");

            if (valueunit != "")
            {
                VaraiableQuery += " and M.Sub_Group in(" + "''" + Regex.Replace(valueunit, ",", @"'',''") + "''" + ")";
            }
            drVaraiable["unit"] = valueunit;

            string valuesegment = "";
            if (objSubmissionRoutingInputModel.Segment.Count > 0 && !objSubmissionRoutingInputModel.Segment[0].Equals(string.Empty))
                valuesegment += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Segment, ",");

            if (valuesegment != "")
            {
                VaraiableQuery += " and M.division in(" + "''" + Regex.Replace(valuesegment, ",", @"'',''") + "''" + ")";
            }
            drVaraiable["segment"] = valuesegment;

            string valueproduct = "";
            if (objSubmissionRoutingInputModel.Product.Count > 0 && !objSubmissionRoutingInputModel.Product[0].Equals(string.Empty))
                valueproduct += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Product, ",");

            if (valueproduct != "")
            {
                string valueproductq = valueproduct.Replace("'", "''''''''");
                VaraiableQuery += " and M.product in(" + "''" + Regex.Replace(valueproductq, ",", @"'',''") + "''" + ")";
            }
            drVaraiable["product"] = valueproduct;

            drVaraiable["ddlforecast"] = objSubmissionRoutingInputModel.ForecastSymbol;
            if (objSubmissionRoutingInputModel.Forecast != "")
                drVaraiable["forecast"] = Int64.Parse(objSubmissionRoutingInputModel.Forecast.Replace(",", ""));
            else
                drVaraiable["forecast"] = 0;
            if (objSubmissionRoutingInputModel.Forecast != "")
            {
                VaraiableQuery += " and M.forecast " + drVaraiable["ddlforecast"] + drVaraiable["forecast"];
            }

            drVaraiable["ddlrevenu"] = objSubmissionRoutingInputModel.RevenueSymbol;
            if (objSubmissionRoutingInputModel.Revenue != "")
                drVaraiable["revenu"] = Int64.Parse(objSubmissionRoutingInputModel.Revenue.Replace(",", ""));
            else
                drVaraiable["revenu"] = 0;
            if (objSubmissionRoutingInputModel.Revenue != "")
            {
                VaraiableQuery += " and M.RevenueAmount " + drVaraiable["ddlrevenu"] + drVaraiable["revenu"];
            }

            string valueIndustry0 = "";
            if (objSubmissionRoutingInputModel.Industry.Count > 0 && !objSubmissionRoutingInputModel.Industry[0].Equals(string.Empty))
                valueIndustry0 += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Industry, "|");

            if (valueIndustry0 != "")
            {
                drVaraiable["ACEIndustry"] = valueIndustry0;

                valueIndustry0 = valueIndustry0.Replace("'", "''''''''");
                valueIndustry0 = valueIndustry0.Replace("|", "'',''");

                VaraiableQuery += "and M.Industry in (" + "''" + valueIndustry0 + "''" + ") ";
            }
            string valueSicCode0 = objSubmissionRoutingInputModel.DNBSICCode.Replace("|", "\'\',\'\'");
            drVaraiable["SicCode"] = valueSicCode0;
            if (objSubmissionRoutingInputModel.DNBSICCode != "")
            {
                VaraiableQuery += " and M.DB_Sic_Code in (\'\'" + valueSicCode0 + "\'\')";
            }
            drVaraiable["PublicPrivate"] = objSubmissionRoutingInputModel.PublicPrivate;
            if (objSubmissionRoutingInputModel.PublicPrivate != "")
                VaraiableQuery += "and M.PublicPrivate =''" + objSubmissionRoutingInputModel.PublicPrivate.ToString() + "'' ";
            drVaraiable["rowID"] = "1";
            drVaraiable["VaraiableQuery"] = VaraiableQuery;
            dtVaraiable.Rows.Add(drVaraiable);

            //1st row-- checked.
            if (objSubmissionRoutingInputModel.VariableCheck1)
            {
                VaraiableQuery = "";
                drVaraiable = dtVaraiable.NewRow();
                valuecompany = "";

                if (objSubmissionRoutingInputModel.Company1.Count > 0 && !objSubmissionRoutingInputModel.Company1[0].Equals(string.Empty))
                    valuecompany += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Company1, ",");

                if (valuecompany != "")
                {
                    VaraiableQuery += " and M.Group_Name in(select distinct Group_name from forecaster_subgroup where Company_Name in(" + "'" + Regex.Replace(valuecompany, ",", @"','") + "'" + ")) ";
                }
                drVaraiable["company"] = valuecompany;

                valuedivision = "";
                if (objSubmissionRoutingInputModel.Division1.Count > 0 && !objSubmissionRoutingInputModel.Division1[0].Equals(string.Empty))
                    valuedivision += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Division1, ",");

                if (valuedivision != "")
                {
                    VaraiableQuery += " and M.Group_Name in(" + "'" + Regex.Replace(valuedivision, ",", @"','") + "'" + ")";
                }
                drVaraiable["division"] = valuedivision;

                valueunit = "";
                if (objSubmissionRoutingInputModel.Unit1.Count > 0 && !objSubmissionRoutingInputModel.Unit1[0].Equals(string.Empty))
                    valueunit += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Unit1, ",");

                if (valueunit != "")
                {
                    valueunit = valueunit.Substring(0, valueunit.Length - 1);
                    VaraiableQuery += " and M.Sub_Group in(" + "'" + Regex.Replace(valueunit, ",", @"','") + "'" + ")";
                }
                drVaraiable["unit"] = valueunit;

                valuesegment = "";
                if (objSubmissionRoutingInputModel.Segment1.Count > 0 && !objSubmissionRoutingInputModel.Segment1[0].Equals(string.Empty))
                    valuesegment += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Segment1, ",");

                if (valuesegment != "")
                {
                    VaraiableQuery += " and M.division in(" + "'" + Regex.Replace(valuesegment, ",", @"','") + "'" + ")";
                }
                drVaraiable["segment"] = valuesegment;

                valueproduct = "";
                if (objSubmissionRoutingInputModel.Product1.Count > 0 && !objSubmissionRoutingInputModel.Product1[0].Equals(string.Empty))
                    valueproduct += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Product1, ",");

                if (valueproduct != "")
                {
                    string valueproductq = valueproduct.Replace("'", "''''''''");
                    VaraiableQuery += " and M.product in(" + "'" + Regex.Replace(valueproductq, ",", @"','") + "'" + ")";
                }
                drVaraiable["product"] = valueproduct;

                drVaraiable["ddlforecast"] = objSubmissionRoutingInputModel.ForecastSymbol1;
                if (objSubmissionRoutingInputModel.Forecast1 != "")
                    drVaraiable["forecast"] = Int64.Parse(objSubmissionRoutingInputModel.Forecast1.Replace(",", ""));
                else
                    drVaraiable["forecast"] = 0;
                if (objSubmissionRoutingInputModel.Forecast1 != "")
                {
                    VaraiableQuery += " and M.forecast " + drVaraiable["ddlforecast"] + drVaraiable["forecast"];
                }

                drVaraiable["ddlrevenu"] = objSubmissionRoutingInputModel.RevenueSymbol1;
                if (objSubmissionRoutingInputModel.Revenue1 != "")
                    drVaraiable["revenu"] = Int64.Parse(objSubmissionRoutingInputModel.Revenue1.Replace(",", ""));
                else
                    drVaraiable["revenu"] = 0;
                if (objSubmissionRoutingInputModel.Revenue1 != "")
                {
                    VaraiableQuery += " and M.RevenueAmount " + drVaraiable["ddlrevenu"] + drVaraiable["revenu"];
                }

                string valueIndustry1 = "";
                if (objSubmissionRoutingInputModel.Industry1.Count > 0 && !objSubmissionRoutingInputModel.Industry1[0].Equals(string.Empty))
                    valueIndustry1 += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Industry1, ",");

                if (valueIndustry1 != "")
                {
                    drVaraiable["ACEIndustry"] = valueIndustry1;
                    valueIndustry1 = valueIndustry1.Replace("'", "''''''''");
                    valueIndustry1 = valueIndustry1.Replace("|", "'',''");

                    VaraiableQuery += "and M.Industry in (" + "''" + valueIndustry1 + "''" + ") ";
                }
                string valueSicCode1 = objSubmissionRoutingInputModel.DNBSICCode1.Replace("|", "\'\',\'\'");
                drVaraiable["SicCode"] = valueSicCode1;
                if (objSubmissionRoutingInputModel.DNBSICCode1 != "")
                {
                    VaraiableQuery += " and M.DB_Sic_Code in (\'\'" + valueSicCode1 + "\'\')";
                }
                drVaraiable["PublicPrivate"] = objSubmissionRoutingInputModel.PublicPrivate1;
                if (objSubmissionRoutingInputModel.PublicPrivate1 != "")
                    VaraiableQuery += "and M.PublicPrivate =''" + objSubmissionRoutingInputModel.PublicPrivate1.ToString() + "'' ";

                drVaraiable["rowID"] = "2";
                drVaraiable["VaraiableQuery"] = VaraiableQuery;
                dtVaraiable.Rows.Add(drVaraiable);
            }

            //2nd row-- checked.
            if (objSubmissionRoutingInputModel.VariableCheck2)
            {
                VaraiableQuery = string.Empty;
                drVaraiable = dtVaraiable.NewRow();
                valuecompany = "";

                if (objSubmissionRoutingInputModel.Company2.Count > 0 && !objSubmissionRoutingInputModel.Company2[0].Equals(string.Empty))
                    valuecompany += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Company2, ",");

                if (valuecompany != "")
                {
                    VaraiableQuery += " and M.Group_Name in(select distinct Group_name from forecaster_subgroup where Company_Name in(" + "'" + Regex.Replace(valuecompany, ",", @"','") + "'" + ")) ";
                }
                drVaraiable["company"] = valuecompany;

                valuedivision = "";
                if (objSubmissionRoutingInputModel.Division2.Count > 0 && !objSubmissionRoutingInputModel.Division2[0].Equals(string.Empty))
                    valuedivision += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Division2, ",");

                if (valuedivision != "")
                {
                    VaraiableQuery += " and M.Group_Name in(" + "'" + Regex.Replace(valuedivision, ",", @"','") + "'" + ")";
                }
                drVaraiable["division"] = valuedivision;

                valueunit = "";
                if (objSubmissionRoutingInputModel.Unit2.Count > 0 && !objSubmissionRoutingInputModel.Unit2[0].Equals(string.Empty))
                    valueunit += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Unit2, ",");

                if (valueunit != "")
                {
                    VaraiableQuery += " and M.Sub_Group in(" + "'" + Regex.Replace(valueunit, ",", @"','") + "'" + ")";
                }
                drVaraiable["unit"] = valueunit;

                valuesegment = "";
                if (objSubmissionRoutingInputModel.Segment2.Count > 0 && !objSubmissionRoutingInputModel.Segment2[0].Equals(string.Empty))
                    valuesegment += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Segment2, ",");

                if (valuesegment != "")
                {
                    VaraiableQuery += " and M.division in(" + "'" + Regex.Replace(valuesegment, ",", @"','") + "'" + ")";
                }
                drVaraiable["segment"] = valuesegment;

                valueproduct = "";
                if (objSubmissionRoutingInputModel.Product2.Count > 0 && !objSubmissionRoutingInputModel.Product2[0].Equals(string.Empty))
                    valueproduct += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Product2, ",");

                if (valueproduct != "")
                {
                    string valueproductq = valueproduct.Replace("'", "''''''''");
                    VaraiableQuery += " and M.product in(" + "'" + Regex.Replace(valueproductq, ",", @"','") + "'" + ")";
                }
                drVaraiable["product"] = valueproduct;

                drVaraiable["ddlforecast"] = objSubmissionRoutingInputModel.ForecastSymbol2;
                if (objSubmissionRoutingInputModel.Forecast2 != "")
                    drVaraiable["forecast"] = Int64.Parse(objSubmissionRoutingInputModel.Forecast2.Replace(",", ""));
                else
                    drVaraiable["forecast"] = 0;
                if (objSubmissionRoutingInputModel.Forecast2 != "")
                {
                    VaraiableQuery += " and M.forecast " + drVaraiable["ddlforecast"] + drVaraiable["forecast"];
                }

                drVaraiable["ddlrevenu"] = objSubmissionRoutingInputModel.RevenueSymbol2;
                if (objSubmissionRoutingInputModel.Revenue2 != "")
                    drVaraiable["revenu"] = Int64.Parse(objSubmissionRoutingInputModel.Revenue2.Replace(",", ""));
                else
                    drVaraiable["revenu"] = 0;
                if (objSubmissionRoutingInputModel.Revenue2 != "")
                {
                    VaraiableQuery += " and M.RevenueAmount " + drVaraiable["ddlrevenu"] + drVaraiable["revenu"];
                }

                string valueIndustry2 = "";
                if (objSubmissionRoutingInputModel.Industry2.Count > 0 && !objSubmissionRoutingInputModel.Industry2[0].Equals(string.Empty))
                    valueIndustry2 += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Industry2, ",");

                if (valueIndustry2 != "")
                {
                    drVaraiable["ACEIndustry"] = valueIndustry2;
                    valueIndustry2 = valueIndustry2.Replace("'", "''''''''");
                    valueIndustry2 = valueIndustry2.Replace("|", "'',''");

                    VaraiableQuery += "and M.Industry in (" + "''" + valueIndustry2 + "''" + ") ";
                }
                string valueSicCode2 = objSubmissionRoutingInputModel.DNBSICCode2.Replace("|", "\'\',\'\'");
                drVaraiable["SicCode"] = valueSicCode2;
                if (objSubmissionRoutingInputModel.DNBSICCode2 != "")
                {
                    VaraiableQuery += " and M.DB_Sic_Code in (\'\'" + valueSicCode2 + "\'\')";
                }
                drVaraiable["PublicPrivate"] = objSubmissionRoutingInputModel.PublicPrivate2;
                if (objSubmissionRoutingInputModel.PublicPrivate2 != "")
                    VaraiableQuery += "and M.PublicPrivate =''" + objSubmissionRoutingInputModel.PublicPrivate2.ToString() + "'' ";

                drVaraiable["rowID"] = "3";
                drVaraiable["VaraiableQuery"] = VaraiableQuery;
                dtVaraiable.Rows.Add(drVaraiable);
            }

            //3rd row-- checked.
            if (objSubmissionRoutingInputModel.VariableCheck3)
            {
                VaraiableQuery = string.Empty;
                drVaraiable = dtVaraiable.NewRow();
                valuecompany = "";

                if (objSubmissionRoutingInputModel.Company3.Count > 0 && !objSubmissionRoutingInputModel.Company3[0].Equals(string.Empty))
                    valuecompany += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Company3, ",");

                if (valuecompany != "")
                {
                    VaraiableQuery += " and M.Group_Name in(select distinct Group_name from forecaster_subgroup where Company_Name in(" + "'" + Regex.Replace(valuecompany, ",", @"','") + "'" + ")) ";
                }
                drVaraiable["company"] = valuecompany;

                valuedivision = "";
                if (objSubmissionRoutingInputModel.Division3.Count > 0 && !objSubmissionRoutingInputModel.Division3[0].Equals(string.Empty))
                    valuedivision += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Division3, ",");

                if (valuedivision != "")
                {
                    VaraiableQuery += " and M.Group_Name in(" + "'" + Regex.Replace(valuedivision, ",", @"','") + "'" + ")";
                }
                drVaraiable["division"] = valuedivision;

                valueunit = "";
                if (objSubmissionRoutingInputModel.Unit3.Count > 0 && !objSubmissionRoutingInputModel.Unit3[0].Equals(string.Empty))
                    valueunit += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Unit3, ",");

                if (valueunit != "")
                {
                    VaraiableQuery += " and M.Sub_Group in(" + "'" + Regex.Replace(valueunit, ",", @"','") + "'" + ")";
                }
                drVaraiable["unit"] = valueunit;

                valuesegment = "";
                if (objSubmissionRoutingInputModel.Segment3.Count > 0 && !objSubmissionRoutingInputModel.Segment3[0].Equals(string.Empty))
                    valuesegment += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Segment3, ",");

                if (valuesegment != "")
                {
                    VaraiableQuery += " and M.division in(" + "'" + Regex.Replace(valuesegment, ",", @"','") + "'" + ")";
                }
                drVaraiable["segment"] = valuesegment;

                valueproduct = "";
                if (objSubmissionRoutingInputModel.Product3.Count > 0 && !objSubmissionRoutingInputModel.Product3[0].Equals(string.Empty))
                    valueproduct += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Product3, ",");

                if (valueproduct != "")
                {
                    string valueproductq = valueproduct.Replace("'", "''''''''");
                    VaraiableQuery += " and M.product in(" + "'" + Regex.Replace(valueproductq, ",", @"','") + "'" + ")";
                }
                drVaraiable["product"] = valueproduct;

                drVaraiable["ddlforecast"] = objSubmissionRoutingInputModel.ForecastSymbol3;
                if (objSubmissionRoutingInputModel.Forecast3 != "")
                    drVaraiable["forecast"] = Int64.Parse(objSubmissionRoutingInputModel.Forecast3.Replace(",", ""));
                else
                    drVaraiable["forecast"] = 0;
                if (objSubmissionRoutingInputModel.Forecast3 != "")
                {
                    VaraiableQuery += " and M.forecast " + drVaraiable["ddlforecast"] + drVaraiable["forecast"];
                }

                drVaraiable["ddlrevenu"] = objSubmissionRoutingInputModel.RevenueSymbol3;
                if (objSubmissionRoutingInputModel.Revenue3 != "")
                    drVaraiable["revenu"] = Int64.Parse(objSubmissionRoutingInputModel.Revenue3.Replace(",", ""));
                else
                    drVaraiable["revenu"] = 0;
                if (objSubmissionRoutingInputModel.Revenue3 != "")
                {
                    VaraiableQuery += " and M.RevenueAmount " + drVaraiable["ddlrevenu"] + drVaraiable["revenu"];
                }

                string valueIndustry3 = "";
                if (objSubmissionRoutingInputModel.Industry3.Count > 0 && !objSubmissionRoutingInputModel.Industry3[0].Equals(string.Empty))
                    valueIndustry3 += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Industry3, ",");

                if (valueIndustry3 != "")
                {
                    drVaraiable["ACEIndustry"] = valueIndustry3;
                    valueIndustry3 = valueIndustry3.Replace("'", "''''''''");
                    valueIndustry3 = valueIndustry3.Replace("|", "'',''");

                    VaraiableQuery += "and M.Industry in (" + "''" + valueIndustry3 + "''" + ") ";
                }
                string valueSicCode3 = objSubmissionRoutingInputModel.DNBSICCode3.Replace("|", "\'\',\'\'");
                drVaraiable["SicCode"] = valueSicCode3;
                if (objSubmissionRoutingInputModel.DNBSICCode3 != "")
                {
                    VaraiableQuery += " and M.DB_Sic_Code in (\'\'" + valueSicCode3 + "\'\')";
                }
                drVaraiable["PublicPrivate"] = objSubmissionRoutingInputModel.PublicPrivate3;
                if (objSubmissionRoutingInputModel.PublicPrivate3 != "")
                    VaraiableQuery += "and M.PublicPrivate =''" + objSubmissionRoutingInputModel.PublicPrivate3.ToString() + "'' ";

                drVaraiable["rowID"] = "4";
                drVaraiable["VaraiableQuery"] = VaraiableQuery;
                dtVaraiable.Rows.Add(drVaraiable);
            }

            //4th row-- checked.
            if (objSubmissionRoutingInputModel.VariableCheck4)
            {
                VaraiableQuery = string.Empty;
                drVaraiable = dtVaraiable.NewRow();
                valuecompany = "";

                if (objSubmissionRoutingInputModel.Company4.Count > 0 && !objSubmissionRoutingInputModel.Company4[0].Equals(string.Empty))
                    valuecompany += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Company4, ",");

                if (valuecompany != "")
                {
                    VaraiableQuery += " and M.Group_Name in(select distinct Group_name from forecaster_subgroup where Company_Name in(" + "'" + Regex.Replace(valuecompany, ",", @"','") + "'" + ")) ";
                }
                drVaraiable["company"] = valuecompany;

                valuedivision = "";
                if (objSubmissionRoutingInputModel.Division4.Count > 0 && !objSubmissionRoutingInputModel.Division4[0].Equals(string.Empty))
                    valuedivision += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Division4, ",");

                if (valuedivision != "")
                {
                    VaraiableQuery += " and M.Group_Name in(" + "'" + Regex.Replace(valuedivision, ",", @"','") + "'" + ")";
                }
                drVaraiable["division"] = valuedivision;

                valueunit = "";
                if (objSubmissionRoutingInputModel.Unit4.Count > 0 && !objSubmissionRoutingInputModel.Unit4[0].Equals(string.Empty))
                    valueunit += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Unit4, ",");

                if (valueunit != "")
                {
                    VaraiableQuery += " and M.Sub_Group in(" + "'" + Regex.Replace(valueunit, ",", @"','") + "'" + ")";
                }
                drVaraiable["unit"] = valueunit;

                valuesegment = "";
                if (objSubmissionRoutingInputModel.Segment4.Count > 0 && !objSubmissionRoutingInputModel.Segment4[0].Equals(string.Empty))
                    valuesegment += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Segment4, ",");

                if (valuesegment != "")
                {
                    VaraiableQuery += " and M.division in(" + "'" + Regex.Replace(valuesegment, ",", @"','") + "'" + ")";
                }
                drVaraiable["segment"] = valuesegment;

                valueproduct = "";
                if (objSubmissionRoutingInputModel.Product4.Count > 0 && !objSubmissionRoutingInputModel.Product4[0].Equals(string.Empty))
                    valueproduct += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Product4, ",");

                if (valueproduct != "")
                {
                    string valueproductq = valueproduct.Replace("'", "''''''''");
                    VaraiableQuery += " and M.product in(" + "'" + Regex.Replace(valueproductq, ",", @"','") + "'" + ")";
                }
                drVaraiable["product"] = valueproduct;

                drVaraiable["ddlforecast"] = objSubmissionRoutingInputModel.ForecastSymbol4;
                if (objSubmissionRoutingInputModel.Forecast4 != "")
                    drVaraiable["forecast"] = Int64.Parse(objSubmissionRoutingInputModel.Forecast4.Replace(",", ""));
                else
                    drVaraiable["forecast"] = 0;
                if (objSubmissionRoutingInputModel.Forecast4 != "")
                {
                    VaraiableQuery += " and M.forecast " + drVaraiable["ddlforecast"] + drVaraiable["forecast"];
                }

                drVaraiable["ddlrevenu"] = objSubmissionRoutingInputModel.RevenueSymbol4;
                if (objSubmissionRoutingInputModel.Revenue4 != "")
                    drVaraiable["revenu"] = Int64.Parse(objSubmissionRoutingInputModel.Revenue4.Replace(",", ""));
                else
                    drVaraiable["revenu"] = 0;
                if (objSubmissionRoutingInputModel.Revenue4 != "")
                {
                    VaraiableQuery += " and M.RevenueAmount " + drVaraiable["ddlrevenu"] + drVaraiable["revenu"];
                }

                string valueIndustry4 = "";
                if (objSubmissionRoutingInputModel.Industry4.Count > 0 && !objSubmissionRoutingInputModel.Industry4[0].Equals(string.Empty))
                    valueIndustry4 += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Industry4, ",");

                if (valueIndustry4 != "")
                {
                    drVaraiable["ACEIndustry"] = valueIndustry4;
                    valueIndustry4 = valueIndustry4.Replace("'", "''''''''");
                    valueIndustry4 = valueIndustry4.Replace("|", "'',''");

                    VaraiableQuery += "and M.Industry in (" + "''" + valueIndustry4 + "''" + ") ";
                }
                string valueSicCode4 = objSubmissionRoutingInputModel.DNBSICCode4.Replace("|", "\'\',\'\'");
                drVaraiable["SicCode"] = valueSicCode4;
                if (objSubmissionRoutingInputModel.DNBSICCode4 != "")
                {
                    VaraiableQuery += " and M.DB_Sic_Code in (\'\'" + valueSicCode4 + "\'\')";
                }
                drVaraiable["PublicPrivate"] = objSubmissionRoutingInputModel.PublicPrivate4;
                if (objSubmissionRoutingInputModel.PublicPrivate4 != "")
                    VaraiableQuery += "and M.PublicPrivate =''" + objSubmissionRoutingInputModel.PublicPrivate4.ToString() + "'' ";

                drVaraiable["rowID"] = "5";
                drVaraiable["VaraiableQuery"] = VaraiableQuery;
                dtVaraiable.Rows.Add(drVaraiable);
            }

            //5th row-- checked.
            if (objSubmissionRoutingInputModel.VariableCheck5)
            {
                VaraiableQuery = string.Empty;
                drVaraiable = dtVaraiable.NewRow();
                valuecompany = "";

                if (objSubmissionRoutingInputModel.Company5.Count > 0 && !objSubmissionRoutingInputModel.Company5[0].Equals(string.Empty))
                    valuecompany += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Company5, ",");

                if (valuecompany != "")
                {
                    VaraiableQuery += " and M.Group_Name in(select distinct Group_name from forecaster_subgroup where Company_Name in(" + "'" + Regex.Replace(valuecompany, ",", @"','") + "'" + ")) ";
                }
                drVaraiable["company"] = valuecompany;

                valuedivision = "";
                if (objSubmissionRoutingInputModel.Division5.Count > 0 && !objSubmissionRoutingInputModel.Division5[0].Equals(string.Empty))
                    valuedivision += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Division5, ",");

                if (valuedivision != "")
                {
                    VaraiableQuery += " and M.Group_Name in(" + "'" + Regex.Replace(valuedivision, ",", @"','") + "'" + ")";
                }
                drVaraiable["division"] = valuedivision;

                valueunit = "";
                if (objSubmissionRoutingInputModel.Unit5.Count > 0 && !objSubmissionRoutingInputModel.Unit5[0].Equals(string.Empty))
                    valueunit += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Unit5, ",");

                if (valueunit != "")
                {
                    VaraiableQuery += " and M.Sub_Group in(" + "'" + Regex.Replace(valueunit, ",", @"','") + "'" + ")";
                }
                drVaraiable["unit"] = valueunit;

                valuesegment = "";
                if (objSubmissionRoutingInputModel.Segment5.Count > 0 && !objSubmissionRoutingInputModel.Segment5[0].Equals(string.Empty))
                    valuesegment += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Segment5, ",");

                if (valuesegment != "")
                {
                    VaraiableQuery += " and M.division in(" + "'" + Regex.Replace(valuesegment, ",", @"','") + "'" + ")";
                }
                drVaraiable["segment"] = valuesegment;

                valueproduct = "";
                if (objSubmissionRoutingInputModel.Product5.Count > 0 && !objSubmissionRoutingInputModel.Product5[0].Equals(string.Empty))
                    valueproduct += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Product5, ",");

                if (valueproduct != "")
                {
                    string valueproductq = valueproduct.Replace("'", "''''''''");
                    VaraiableQuery += " and M.product in(" + "'" + Regex.Replace(valueproductq, ",", @"','") + "'" + ")";
                }
                drVaraiable["product"] = valueproduct;

                drVaraiable["ddlforecast"] = objSubmissionRoutingInputModel.ForecastSymbol5;
                if (objSubmissionRoutingInputModel.Forecast5 != "")
                    drVaraiable["forecast"] = Int64.Parse(objSubmissionRoutingInputModel.Forecast5.Replace(",", ""));
                else
                    drVaraiable["forecast"] = 0;
                if (objSubmissionRoutingInputModel.Forecast5 != "")
                {
                    VaraiableQuery += " and M.forecast " + drVaraiable["ddlforecast"] + drVaraiable["forecast"];
                }

                drVaraiable["ddlrevenu"] = objSubmissionRoutingInputModel.RevenueSymbol5;
                if (objSubmissionRoutingInputModel.Revenue5 != "")
                    drVaraiable["revenu"] = Int64.Parse(objSubmissionRoutingInputModel.Revenue5.Replace(",", ""));
                else
                    drVaraiable["revenu"] = 0;
                if (objSubmissionRoutingInputModel.Revenue5 != "")
                {
                    VaraiableQuery += " and M.RevenueAmount " + drVaraiable["ddlrevenu"] + drVaraiable["revenu"];
                }

                string valueIndustry5 = "";
                if (objSubmissionRoutingInputModel.Industry5.Count > 0 && !objSubmissionRoutingInputModel.Industry5[0].Equals(string.Empty))
                    valueIndustry5 += UtilityHelper.ListValueToCommaSeperatedValue(objSubmissionRoutingInputModel.Industry5, ",");

                if (valueIndustry5 != "")
                {
                    drVaraiable["ACEIndustry"] = valueIndustry5;
                    valueIndustry5 = valueIndustry5.Replace("'", "''''''''");
                    valueIndustry5 = valueIndustry5.Replace("|", "'',''");

                    VaraiableQuery += "and M.Industry in (" + "''" + valueIndustry5 + "''" + ") ";
                }
                string valueSicCode5 = objSubmissionRoutingInputModel.DNBSICCode5.Replace("|", "\'\',\'\'");
                drVaraiable["SicCode"] = valueSicCode5;
                if (objSubmissionRoutingInputModel.DNBSICCode5 != "")
                {
                    VaraiableQuery += " and M.DB_Sic_Code in (\'\'" + valueSicCode5 + "\'\')";
                }
                drVaraiable["PublicPrivate"] = objSubmissionRoutingInputModel.PublicPrivate5;
                if (objSubmissionRoutingInputModel.PublicPrivate5 != "")
                    VaraiableQuery += "and M.PublicPrivate =''" + objSubmissionRoutingInputModel.PublicPrivate5.ToString() + "'' ";

                drVaraiable["rowID"] = "6";
                drVaraiable["VaraiableQuery"] = VaraiableQuery;
                dtVaraiable.Rows.Add(drVaraiable);
            }

            DSsubmissions.Tables.Add(dtSchedule);
            DSsubmissions.Tables.Add(dtConstant);
            DSsubmissions.Tables.Add(dtVaraiable);

            string saveSubmissionRouting = _trackerReportingRepository.SaveSubmissionRouting(nxtDate, objSubmissionRoutingInputModel.UserID, DSsubmissions.GetXml().ToString());

            return saveSubmissionRouting;
        }
        public List<DropdownOutputValues> GetOwnerRegionFilter()
        {
            List<DropdownOutputValues> region = _trackerReportingRepository.GetOwnerRegionFilter();
            return region;
        }
        public List<DropdownOutputValues> GetTopCarrierFilter()
        {
            List<DropdownOutputValues> topcarrier = _trackerReportingRepository.GetTopCarrierFilter();
            return topcarrier;
        }
        public CurrentAccountingYearMonthOutputModel GetCurrentAccountingYearMonth()
        {
            CurrentAccountingYearMonthOutputModel yrmonth = _trackerReportingRepository.GetCurrentAccountingYearMonth();
            return yrmonth;
        }
        public List<DropdownOutputValues> GetCustomerProfileOwnerFilter()
        {
            List<DropdownOutputValues> customerProfileOwner = _trackerReportingRepository.GetCustomerProfileOwnerFilter();
            return customerProfileOwner;
        }
        public List<DropdownOutputValues> GetProducerProductBrokeredFilter(int brokerId, int BrokerOfficeId)
        {
            List<DropdownOutputValues> producerbrokered = _trackerReportingRepository.GetProducerProductBrokeredFilter(brokerId, BrokerOfficeId);
            return producerbrokered;
        }

        public List<DropdownOutputValues> GetProducerProfileOwnerFilter()
        {
            List<DropdownOutputValues> producerProfileOwner = _trackerReportingRepository.GetProducerProfileOwnerFilter();
            return producerProfileOwner;
        }
        public List<GetSubmissionRouting> GetSubmissionRoutingData(string UserID)
        {
            List<GetSubmissionRouting> getSubmissionRoutingData = _trackerReportingRepository.GetSubmissionRoutingData(UserID);
            return getSubmissionRoutingData;
        }

        public string DeleteSubmissionRoutingData(string ScheduleID)
        {
            string getSubmissionRoutingData = _trackerReportingRepository.DeleteSubmissionRoutingData(ScheduleID);
            return getSubmissionRoutingData;
        }
        public string DeleteSavedFilterData(List<string> FilterID)
        {
            string getDeleteSavedFilterData = _trackerReportingRepository.DeleteSavedFilterData(FilterID);
            return getDeleteSavedFilterData;
        }
        public SubmissionRoutingModel UpdateSubmissionRoutingData(string ScheduleID)
        {
            SubmissionRoutingModel getSubmissionRoutingData = _trackerReportingRepository.UpdateSubmissionRoutingData(ScheduleID);
            return getSubmissionRoutingData;
        }
        public List<ProducerReportOuputModel> GetProducerReport(ProducerReportInputModel objProducerDetailsInputModel)
        {
            List<ProducerReportOuputModel> producerReport = _trackerReportingRepository.GetProducerReport(objProducerDetailsInputModel);
            return producerReport;
        }
        public List<ProducerKeyProfileOuputModel> GetProducerKeyProfile(ProducerKeyprofileInputModel objProducerDetailsInputModel)
        {
            List<ProducerKeyProfileOuputModel> producerReport = _trackerReportingRepository.GetProducerKeyProfile(objProducerDetailsInputModel);
            return producerReport;
        }

        public List<ProducerScorecardFilterOutputModel> GetProducerScorecardvalue(TrackingReportingCommonFilterInputModel producerscorecardinputModel)
        {
            List<ProducerScorecardFilterOutputModel> producerscore = _trackerReportingRepository.GetProducerScorecardvalue(producerscorecardinputModel);
            return producerscore;
        }

        public ReportingGoalsFilterOutputModel GetReportingGoalsFilter(TrackingReportingCommonFilterInputModel reportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetReportingGoalsFilter(reportingCommonFilterInputModel);
        }
        public List<LostandDeclinedBusinessOutputModel> GetInsuredLostandDeclinedBusiness(LostandDeclinedInsuredInputModel lostAndDeclinedCompanyName)
        {
            //int clientId = _trackerReportingRepository.GetInsuredClientID(lostAndDeclinedCompanyName.CompanyName);
            List<LostandDeclinedBusinessOutputModel> lostAndDeclinedBussiness = _trackerReportingRepository.GetInsuredLostandDeclinedBusiness(lostAndDeclinedCompanyName);
            return lostAndDeclinedBussiness;
        }
        public List<DynamicPipelinesOutputModel> GetDynamicsPipelinesDetails(DynamicPipelinesInputModel objDynamicPipelinesInputModel)
        {
            List<DynamicPipelinesOutputModel> GetDynamicsPipelinesDetails = _trackerReportingRepository.GetDynamicsPipelinesDetails(objDynamicPipelinesInputModel);
            return GetDynamicsPipelinesDetails;
        }

        public string SavedProfileCoreElements(SavedProfileCoreElementInputModel savedProfileCoreElementInputModel)
        {
            string CoreElements = _trackerReportingRepository.SavedProfileCoreElements(savedProfileCoreElementInputModel);
            return CoreElements;
        }
        public string GetUWSaveGoalsNewBusiness(string UserID, long GoalAmount)
        {
            string saveGoals = _trackerReportingRepository.GetUWSaveGoalsNewBusiness(UserID, GoalAmount);
            return saveGoals;
        }
        public string GetTravelSaveGoals(string UserID, long GoalAmount, string VisitType)
        {
            string travelsaveGoals = _trackerReportingRepository.GetTravelSaveGoals(UserID, GoalAmount, VisitType);
            return travelsaveGoals;
        }
        public string SavedProfileNonCoreElements(SavedProfileNonCoreElementInputModel savedProfileNonCoreElementInputModel)
        {
            string CoreElements = _trackerReportingRepository.SavedProfileNonCoreElements(savedProfileNonCoreElementInputModel);
            return CoreElements;
        }
        public string SavedProfileMultiNonCoreElements(SavedProfileMultiNonCoreElementInputModel savedProfileMultiNonCoreElementInputModel)
        {
            string CoreElements = _trackerReportingRepository.SavedProfileMultiNonCoreElements(savedProfileMultiNonCoreElementInputModel);
            return CoreElements;
        }

        public string SaveUnderwritting(UnderwrittingInputModel objUnderwrittingInputModel)
        {
            string saveUnderwritting = _trackerReportingRepository.SaveUnderwritting(objUnderwrittingInputModel);
            return saveUnderwritting;
        }

        public string SaveClaimsHandling(ClaimsHandlingInputModel objClaimsHandlingInputModel)
        {
            string saveClaimsHandling = _trackerReportingRepository.SaveClaimsHandling(objClaimsHandlingInputModel);
            return saveClaimsHandling;
        }
        public string SaveRelationShip(RelationShipInputModel objRelationShipInputModel)
        {
            string saveRelationShip = _trackerReportingRepository.SaveRelationShip(objRelationShipInputModel);
            return saveRelationShip;
        }
        public string SaveCarrierThreat(CarrierThreatsInputModel objCarrierThreatsInputModel)
        {
            string saveCarrierThreat = _trackerReportingRepository.SaveCarrierThreat(objCarrierThreatsInputModel);
            return saveCarrierThreat;
        }
        public string SaveProducerRecordThreat(ProducerRecordThreatsInputModel objSaveProducerRecordThreatInputModel)
        {
            string saveProducerRecordThreat = _trackerReportingRepository.SaveProducerRecordThreat(objSaveProducerRecordThreatInputModel);
            return saveProducerRecordThreat;
        }

        public List<UnderwrittingOutputModel> GetUnderwritting(string clientName)
        {
            List<UnderwrittingOutputModel> getUnderwritting = _trackerReportingRepository.GetUnderwritting(clientName);
            return getUnderwritting;
        }

        public List<ClaimsHandlingOutputModel> GetClaimsHandling(string clientName)
        {
            List<ClaimsHandlingOutputModel> getClaimsHandling = _trackerReportingRepository.GetClaimsHandling(clientName);
            return getClaimsHandling;
        }
        public List<RelationShipOutputModel> GetRelationship(string clientName)
        {
            List<RelationShipOutputModel> getRelationship = _trackerReportingRepository.GetRelationship(clientName);
            return getRelationship;
        }
        public List<CarrierThreatsOutputModel> GetCarrierThreats(string clientName)
        {
            List<CarrierThreatsOutputModel> getCarrierThreat = _trackerReportingRepository.GetCarrierThreats(clientName);
            return getCarrierThreat;
        }
        public List<ProducerRecordThreatsOutputModel> GetProducerRecordThreats(string clientName)
        {
            List<ProducerRecordThreatsOutputModel> getProducerRecordThreat = _trackerReportingRepository.GetProducerRecordThreats(clientName);
            return getProducerRecordThreat;
        }
        public string SaveLossNote(LossNoteInputModel objLossNoteInputModel)
        {
            string saveLossNote = _trackerReportingRepository.SaveLossNote(objLossNoteInputModel);
            return saveLossNote;
        }
        public List<LossNoteOutputModel> GetLossNotes(string clientName)
        {
            List<LossNoteOutputModel> lossNotes = _trackerReportingRepository.GetLossNotes(clientName);
            return lossNotes;
        }
        public string SaveAccountMarketed(AccountMarketedInputModel objAccountMarketedInputModel)
        {
            string saveAccountMarketed = _trackerReportingRepository.SaveAccountMarketed(objAccountMarketedInputModel);
            return saveAccountMarketed;
        }
        public List<AccountMarketedOuputModel> GetAccountMarketed(string clientName)
        {
            List<AccountMarketedOuputModel> accountMarketed = _trackerReportingRepository.GetAccountMarketed(clientName);
            return accountMarketed;
        }

        public string SaveRenewalStrategy(RenewalStrategyInputModel objRenewalStrategyInputModel)
        {
            string renewalStrategy = _trackerReportingRepository.SaveRenewalStrategy(objRenewalStrategyInputModel);
            return renewalStrategy;
        }
        public string SaveRiskEngineeringService(RiskEngineeringServiceInputModel objRiskEngineeringServiceInputModel)
        {
            string riskEngineeringService = _trackerReportingRepository.SaveRiskEngineeringService(objRiskEngineeringServiceInputModel);
            return riskEngineeringService;
        }
        public string SaveClaimServices(ClaimServicesInputModel objClaimServicesInputModel)
        {
            string claimServices = _trackerReportingRepository.SaveClaimServices(objClaimServicesInputModel);
            return claimServices;
        }
        public List<RenewalStrategyOutputModel> GetRenewalStrategy(string clientName)
        {
            List<RenewalStrategyOutputModel> strategy = _trackerReportingRepository.GetRenewalStrategy(clientName);
            return strategy;
        }

        public List<RiskEngineeringServiceOutputModel> GetRiskengineeringService(string clientName)
        {
            List<RiskEngineeringServiceOutputModel> riskEngineering = _trackerReportingRepository.GetRiskengineeringService(clientName);
            return riskEngineering;
        }
        public List<ClaimServicesOutputModel> GetClaimServices(string clientName)
        {
            List<ClaimServicesOutputModel> claimServices = _trackerReportingRepository.GetClaimServices(clientName);
            return claimServices;
        }
        public List<DropdownOutputValues> GetPageDropdownDetails(ScreenDropdownInputModel screenDropdownModel)
        {
            List<DropdownOutputValues> listDetails = _trackerReportingRepository.GetPageDropdownDetails(screenDropdownModel);
            return listDetails;
        }

        public List<StewardshipCoverageOutputModel> GetStewardshipCoverage(string clientName)
        {
            List<StewardshipCoverageOutputModel> coverage = _trackerReportingRepository.GetStewardshipCoverage(clientName);
            return coverage;
        }

        public List<StewardshipLineOfBusinessOutputModel> GetStewardshipLineOfBusiness(string clientName)
        {
            List<StewardshipLineOfBusinessOutputModel> business = _trackerReportingRepository.GetStewardshipLineOfBusiness(clientName);
            return business;
        }

        public string SaveStewardshipLineOfBusinessComment(StewardshipBusinessCommentInputModel objBusinessCommentInputModel)
        {
            string lineOfBusinessComment = _trackerReportingRepository.SaveStewardshipLineOfBusinessComment(objBusinessCommentInputModel);
            return lineOfBusinessComment;
        }

        public List<AccountOutputModel> GetAccount(string clientName, int noOfVisits)
        {
            List<AccountOutputModel> account = _trackerReportingRepository.GetAccount(clientName, noOfVisits);
            return account;
        }

        public Guid? GetGuidByClientName(string clientName)
        {
            Guid? guid = _trackerReportingRepository.GetGuidByClientName(clientName);
            return guid;
        }
        public List<InsuredGlanceOutputModel> GetInsuredGlanceDetails(int ClientID)
        {
            List<InsuredGlanceOutputModel> InsuredGlanceDetails = _trackerReportingRepository.GetInsuredGlanceDetails(ClientID);
            return InsuredGlanceDetails;
        }

        public List<InsuredHistoricalForecastOutputModel> GetInsuredHistoricalForecastDetails(int ClientID)
        {
            List<InsuredHistoricalForecastOutputModel> InsuredHistoricalForecastDetails = _trackerReportingRepository.GetInsuredHistoricalForecastDetails(ClientID);
            return InsuredHistoricalForecastDetails;
        }

        public List<InsuredInformationOutputModel> GetInsuredInformationDetails(int ClientID)
        {
            List<InsuredInformationOutputModel> InsuredInformationDetails = _trackerReportingRepository.GetInsuredInformationDetails(ClientID);
            return InsuredInformationDetails;
        }
        public List<StewardshipRententionOuputModel> GetStewardshipRentention(string clientName)
        {
            List<StewardshipRententionOuputModel> rentention = _trackerReportingRepository.GetStewardshipRentention(clientName);
            return rentention;
        }
        public List<InsuredSummaryOutputModel> GetInsuredCurrentInforceSummary(LostandDeclinedInsuredInputModel objLostandDeclinedInsuredInputModel)
        {
            List<InsuredSummaryOutputModel> InsuredCurrentInforceSummary = _trackerReportingRepository.GetInsuredCurrentInforceSummary(objLostandDeclinedInsuredInputModel);
            return InsuredCurrentInforceSummary;
        }

        public List<InsuredSummaryOutputModel> GetInsuredTargetSummary(LostandDeclinedInsuredInputModel objLostandDeclinedInsuredInputModel)
        {
            List<InsuredSummaryOutputModel> InsuredTargetSummary = _trackerReportingRepository.GetInsuredTargetSummary(objLostandDeclinedInsuredInputModel);
            return InsuredTargetSummary;
        }
        public string DeleteInsuredSummaryDetails(int ClientID, int ProductNo)
        {
            string deleteinsuredsummarydtls = _trackerReportingRepository.DeleteInsuredSummaryDetails(ClientID, ProductNo);
            return deleteinsuredsummarydtls;
        }

        public List<PoliciesTargetsOutputModel> GetPoliciesTarget(string UserID)
        {
            return _trackerReportingRepository.GetPoliciesTarget(UserID);
        }

        public string ExcludeInsuredSummaryDetails(InsuredSummaryExludeAccountsInputModel objInsuredSummaryExludeAccountsInputModel)
        {
            string excludeinsuredsummarydtls = _trackerReportingRepository.ExcludeInsuredSummaryDetails(objInsuredSummaryExludeAccountsInputModel);
            return excludeinsuredsummarydtls;
        }

        public string IncludeInsuredSummaryDetails(string ClientID, List<string> RecordNo)
        {
            string includeinsuredsummarydtls = _trackerReportingRepository.IncludeInsuredSummaryDetails(ClientID, RecordNo);
            return includeinsuredsummarydtls;
        }
        public List<InsuredDNBSearchOutputModel> GetInsuredDNBDetails(string ClientID)
        {
            return _trackerReportingRepository.GetInsuredDNBDetails(ClientID);
        }

        public List<DNBHierarchySearchOutputModel> GetInsuredDNBHierarchySearch(string DunsNo)
        {
            return _trackerReportingRepository.GetInsuredDNBHierarchySearch(DunsNo);
        }

        public string UpdateInsuredInformation(UpdateInsuredInputModel objUpdateInsuredInputModel)
        {
            string updateinsuredsummarydtls = _trackerReportingRepository.UpdateInsuredInformation(objUpdateInsuredInputModel);
            return updateinsuredsummarydtls;
        }
        public List<InsuredCurrentInforceMappingOutputModel> GetExcludeCurrentBusinessAccounts(int ClientID)
        {
            return _trackerReportingRepository.GetExcludeCurrentBusinessAccounts(ClientID);
        }
        public List<InsuredCurrentInforceMappingOutputModel> GetExcludeLostDeclinedBusinessAccounts(int ClientID)
        {
            return _trackerReportingRepository.GetExcludeLostDeclinedBusinessAccounts(ClientID);
        }
        public List<PoliciesTargetDetailsOutputModel> GetPoliciesTargetdetails(string RecordGUID)
        {
            return _trackerReportingRepository.GetPoliciesTargetdetails(RecordGUID);
        }
        public List<DropdownOutputValues> GetInsuredAccountType()
        {
            return _trackerReportingRepository.GetInsuredAccountType();
        }
        public List<DropdownOutputValues> GetInsuredDunsNumber(InsuredDunsNumberInputModel InsuredDunsNumberInputModel)
        {
            return _trackerReportingRepository.GetInsuredDunsNumber(InsuredDunsNumberInputModel);
        }

        public StringBuilder GetForecastSummaryTotalDownload(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            StringBuilder strHTML = new StringBuilder();
            if (trackingReportingCommonFilterInputModel.ReportName == "Scorecard")
            {
                List<ScorecardByStatusOutputModel> ScorecardNewBusinessByStatus = new List<ScorecardByStatusOutputModel>();
                List<ScorecardRenewalByStatusOutputModel> ScorecardRenewalByStatus = new List<ScorecardRenewalByStatusOutputModel>();
                List<ScorecardAmountPerDivionOutputModel> ScorecardAmountPerDivision = new List<ScorecardAmountPerDivionOutputModel>();
                ScorecardAmountPerDivision = _trackerReportingRepository.GetScorecardAmountPerDivision(trackingReportingCommonFilterInputModel);
                ScorecardNewBusinessByStatus = _trackerReportingRepository.GetScorecardNewBusinessByStatus(trackingReportingCommonFilterInputModel);
                ScorecardRenewalByStatus = _trackerReportingRepository.GetScorecardRenewalByStatus(trackingReportingCommonFilterInputModel);
                AssignDateValueByFlag(trackingReportingCommonFilterInputModel);
                strHTML.Append(SpreadSheetXLSXGeneratorForScoreCard(ScorecardAmountPerDivision, ScorecardNewBusinessByStatus, ScorecardRenewalByStatus, trackingReportingCommonFilterInputModel));
                //AssignNullForObject(ScorecardNewBusinessByStatus);
                //AssignNullForObject(ScorecardRenewalByStatus);
                //AssignNullForObject(ScorecardAmountPerDivision);
            }
            else if (trackingReportingCommonFilterInputModel.ReportName == "Forecast Division")
            {
                List<ForecastByBusinessSegmentOutputModel> forecastByBusinessSegmentOutputModel = new List<ForecastByBusinessSegmentOutputModel>();
                forecastByBusinessSegmentOutputModel = _trackerReportingRepository.GetForecastSummaryTotal(trackingReportingCommonFilterInputModel);
                AssignDateValueByFlag(trackingReportingCommonFilterInputModel);
                strHTML.Append(SpreadSheetXLSXGenerartorForecastDivision(forecastByBusinessSegmentOutputModel, trackingReportingCommonFilterInputModel));
                //AssignNullForObject(forecastByBusinessSegmentOutputModel);
            }
            else if (trackingReportingCommonFilterInputModel.ReportName == "Forecast Region")
            {
                StringBuilder sb2 = new StringBuilder();
                List<ForecastRegionDataOutputModel> lGetForecastRegionTotal = new List<ForecastRegionDataOutputModel>();
                sb2.Append(trackingReportingCommonFilterInputModel.CreateDateEnd);
                lGetForecastRegionTotal = _trackerReportingRepository.GetForecastRegionTotal(trackingReportingCommonFilterInputModel);
                AssignDateValueByFlag(trackingReportingCommonFilterInputModel);
                strHTML.Append(SpreadSheetXLSXGenerartorForecastRegion(lGetForecastRegionTotal, trackingReportingCommonFilterInputModel));
                //AssignNullForObject(lGetForecastRegionTotal);
            }
            else if (trackingReportingCommonFilterInputModel.ReportName == "Regional Scorecard")
            {
                strHTML.Append(GetRegionalScorecardExportToXcel(trackingReportingCommonFilterInputModel));
            }
            else if (trackingReportingCommonFilterInputModel.ReportName == "Net Scorecard")
            {
                strHTML.Append(GetNetScorecardExportToXcel(trackingReportingCommonFilterInputModel));
            }
            else if (trackingReportingCommonFilterInputModel.ReportName == "Producer Scorecard")
            {
                strHTML.Append(GetProducerScorecardExportToXcel(trackingReportingCommonFilterInputModel));
            }
            else if (trackingReportingCommonFilterInputModel.ReportName == "Surety Scorecard")
            {
                strHTML.Append(GetSuretyScorecardExportToXcel(trackingReportingCommonFilterInputModel));
            }
            else if (trackingReportingCommonFilterInputModel.ReportName == "Regional Margin")
            {
                strHTML.Append(GetRegionalMarginExportToXcel(trackingReportingCommonFilterInputModel));
            }
            else if (trackingReportingCommonFilterInputModel.ReportName == "Growth & Mix Margin")
            {
                strHTML.Append(GetGrowthMixMarginExportToXcel(trackingReportingCommonFilterInputModel));
            }
            else if (trackingReportingCommonFilterInputModel.ReportName == "Home Office Margin")
            {
                strHTML.Append(GetHomeOfficeMarginExportToXcel(trackingReportingCommonFilterInputModel));
            }
            else if (trackingReportingCommonFilterInputModel.ReportName == "ERC Detailed")
            {
                strHTML.Append(GetERCDetailedExportToXcel(trackingReportingCommonFilterInputModel));
            }
            else if (trackingReportingCommonFilterInputModel.ReportName == "ERC Summary")
            {
                strHTML.Append(GetERCSummaryExportToXcel(trackingReportingCommonFilterInputModel));
            }
            else if (trackingReportingCommonFilterInputModel.ReportName == "Target Progression")
            {
                //trackingReportingCommonFilterInputModel.GroupBy = "Branch";
                //var targetProgressionByBranch = GetTargetProgressionByBranch(trackingReportingCommonFilterInputModel);

                //trackingReportingCommonFilterInputModel.GroupBy = "Region";
                //var targetProgressionByRegion = GetTargetProgressionByRegion(trackingReportingCommonFilterInputModel);
                //// var targetProgressionByLob = GetTargetProgression(trackingReportingCommonFilterInputModel);

                List<TargetProgressionByBranchOutputModel> GetTargetProgressionByBranch = new List<TargetProgressionByBranchOutputModel>();
                List<TargetProgressionByRegionOutputModel> GetTargetProgressionByRegion = new List<TargetProgressionByRegionOutputModel>();
                TargetProgressionByLobOutputModel GetTargetProgressionByLOB = new TargetProgressionByLobOutputModel();
                GetTargetProgressionByBranch = _trackerReportingRepository.GetTargetProgressionReportsByBranch(trackingReportingCommonFilterInputModel);
                GetTargetProgressionByRegion = _trackerReportingRepository.GetTargetProgressionReportsByRegion(trackingReportingCommonFilterInputModel);
                GetTargetProgressionByLOB = _trackerReportingRepository.GetTargetProgressionReportsByLOB(trackingReportingCommonFilterInputModel);
                AssignDateValueByFlag(trackingReportingCommonFilterInputModel);
                strHTML.Append(SpreadSheetXLSXGeneratorForTargetProgression(GetTargetProgressionByRegion, GetTargetProgressionByBranch, GetTargetProgressionByLOB.LobByCompany, GetTargetProgressionByLOB.LobByDivision, GetTargetProgressionByLOB.LobByUnit, GetTargetProgressionByLOB.LobBySegment, trackingReportingCommonFilterInputModel));
            }
            //else if (trackingReportingCommonFilterInputModel.ReportName == "Forecast Variation")
            //{
            //    strHTML.Append(GetVariationReportExportToXcel(trackingReportingCommonFilterInputModel));
            //}
            return strHTML;

            
        }

        // FIXME this function does nothing in it's current state:
        private void AssignNullForObject(Object obj)
        {
            obj = null;
        }

        private void AssignDateValueByFlag(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            DateTime? effectiveDateStart = trackingReportingCommonFilterInputModel.EffectiveDateStart;
            DateTime? effectiveDateEnd = trackingReportingCommonFilterInputModel.EffectiveDateEnd;
            DateTime? expirationDateStart = trackingReportingCommonFilterInputModel.ExpirationDateStart;
            DateTime? expirationDateEnd = trackingReportingCommonFilterInputModel.ExpirationDateEnd;
            DateTime? createDateStart = trackingReportingCommonFilterInputModel.CreateDateStart;
            DateTime? createDateEnd = trackingReportingCommonFilterInputModel.CreateDateEnd;


            int flag = 0;
            if (effectiveDateStart.HasValue)
            {
                flag = 1;
            }
            else if (effectiveDateEnd.HasValue)
            {
                flag = 1;
            }
            else if (expirationDateStart.HasValue)
            {
                flag = 1;
            }
            else if (expirationDateEnd.HasValue)
            {
                flag = 1;
            }
            else if (createDateStart.HasValue)
            {
                flag = 1;
            }
            else if (createDateEnd.HasValue)
            {
                flag = 1;
            }

            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.EffectiveDateStart = effectiveDateStart;
            }
            else
            {
                trackingReportingCommonFilterInputModel.EffectiveDateStart = null;
            }
            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.EffectiveDateEnd = effectiveDateEnd;
            }
            else
            {
                trackingReportingCommonFilterInputModel.EffectiveDateEnd = null;
            }
            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.ExpirationDateStart = expirationDateStart;
            }
            else
            {
                trackingReportingCommonFilterInputModel.ExpirationDateStart = null;
            }
            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.ExpirationDateEnd = expirationDateEnd;
            }
            else
            {
                trackingReportingCommonFilterInputModel.ExpirationDateEnd = null;
            }
            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.CreateDateStart = createDateStart;
            }
            else
            {
                trackingReportingCommonFilterInputModel.CreateDateStart = null;
            }
            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.CreateDateEnd = createDateEnd;
            }
            else
            {
                trackingReportingCommonFilterInputModel.CreateDateEnd = null;
            }
        }


        public string GetQuickXcelExport(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                string reportName = trackingReportingCommonFilterInputModel.ReportName;
                switch (reportName)
                {
                    case "Target Detail":
                        List<TargetReportOutputModel> targetReportOutputModels = GetTargetReport(trackingReportingCommonFilterInputModel);
                        outputFilePath = ExcelCommon.ExcelCommon.ExportToXcel(trackingReportingCommonFilterInputModel, targetReportOutputModels.ToDataTable());
                        break;
                    //case "Forecast Variation":
                    //    List<ForecastVariationOutputModel> forecastVariation = GetVariationReport(trackingReportingCommonFilterInputModel);
                    //    outputFilePath = ExcelCommon.ExcelCommon.ExportToXcel(trackingReportingCommonFilterInputModel, forecastVariation.ToDataTable());
                    //    break;
                    default:
                        outputFilePath = GetForecastSummaryTotalDownload(trackingReportingCommonFilterInputModel).ToString();
                        break;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outputFilePath;
        }


        private string GetRegionalScorecardExportToXcel(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                List<RegionalScorecardAmountPerRegionOutputModel> regionalScorecardAmountPerRegion = new List<RegionalScorecardAmountPerRegionOutputModel>();
                List<RegionalScorecardNewBusinessByStatusOutputModel> regionalScorecardNewBusinessByStatus = new List<RegionalScorecardNewBusinessByStatusOutputModel>();
                List<RegionalScorecardRenewalByStatusOutputModel> regionalScorecardRenewalByStatus = new List<RegionalScorecardRenewalByStatusOutputModel>();

                regionalScorecardAmountPerRegion = _trackerReportingRepository.GetRegionalScorecardAmountPerRegion(trackingReportingCommonFilterInputModel);
                regionalScorecardNewBusinessByStatus = _trackerReportingRepository.GetRegionalScorecardNewBusinessByStatus(trackingReportingCommonFilterInputModel);
                regionalScorecardRenewalByStatus = _trackerReportingRepository.GetRegionalScorecardRenewalByStatus(trackingReportingCommonFilterInputModel);

                outputFilePath = SpreadSheetXLSXGeneratorForRegionalScoreCard(regionalScorecardAmountPerRegion, regionalScorecardNewBusinessByStatus, regionalScorecardRenewalByStatus, trackingReportingCommonFilterInputModel);

                AssignNullForObject(regionalScorecardAmountPerRegion);
                AssignNullForObject(regionalScorecardNewBusinessByStatus);
                AssignNullForObject(regionalScorecardRenewalByStatus);

            }
            catch (Exception ex)
            {
                outputFilePath = string.Empty;
            }
            return outputFilePath;
        }

        private string GetNetScorecardExportToXcel(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                List<ScorecardAmountPerDivionOutputModel> netScorecardAmountPerDivion = new List<ScorecardAmountPerDivionOutputModel>();
                List<RegionalScorecardAmountPerRegionOutputModel> netScorecardAmountPerRegion = new List<RegionalScorecardAmountPerRegionOutputModel>();

                netScorecardAmountPerDivion = _trackerReportingRepository.GetNetScorecardAmountPerDivision(trackingReportingCommonFilterInputModel);
                trackingReportingCommonFilterInputModel.DisplayResultBy = trackingReportingCommonFilterInputModel.DisplayResultBy == "Segment" ? "Credited Region and Branch" : "Credited Region";
                netScorecardAmountPerRegion = _trackerReportingRepository.GetNetScorecardAmountPerRegion(trackingReportingCommonFilterInputModel);

                outputFilePath = SpreadSheetXLSXGeneratorForNetScoreCard(netScorecardAmountPerDivion, netScorecardAmountPerRegion, trackingReportingCommonFilterInputModel);

                AssignNullForObject(netScorecardAmountPerRegion);
                AssignNullForObject(netScorecardAmountPerDivion);
            }
            catch (Exception ex)
            {
                outputFilePath = string.Empty;
            }
            return outputFilePath;
        }

        private string GetProducerScorecardExportToXcel(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                List<ProducerScorecardFilterOutputModel> producerScorecard = new List<ProducerScorecardFilterOutputModel>();


                producerScorecard = _trackerReportingRepository.GetProducerScorecardvalue(trackingReportingCommonFilterInputModel);


                outputFilePath = SpreadSheetXLSXGeneratorForProducerScoreCard(producerScorecard, trackingReportingCommonFilterInputModel);

                AssignNullForObject(producerScorecard);

            }
            catch (Exception ex)
            {
                outputFilePath = string.Empty;
            }
            return outputFilePath;
        }
        //private string GetVariationReportExportToXcel(ForecastVariationInputModel forecastVariationInputModel)
        //{
        //    string outputFilePath = string.Empty;
        //    try
        //    {
        //        List<ForecastVariationOutputModel> forecastVariation = new List<ForecastVariationOutputModel>();


        //        forecastVariation = _trackerReportingRepository.GetForecastVariation(forecastVariationInputModel);


        //        outputFilePath = SpreadSheetXLSXGeneratorForVariationReport(forecastVariation, forecastVariationInputModel);

        //        AssignNullForObject(forecastVariation);

        //    }
        //    catch (Exception ex)
        //    {
        //        outputFilePath = string.Empty;
        //    }
        //    return outputFilePath;
        //}
        #region Excel method
        private StringBuilder SpreadSheetXMLGeneratorDivision(List<ScorecardAmountPerDivionOutputModel> ScorecardAmountPerDivision, TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            StringBuilder strHTML = new StringBuilder();
            strHTML.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            strHTML.AppendLine("<?mso-application progid=\"Excel.Sheet\"?>");
            strHTML.AppendLine("<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:x=\"urn:schemas-microsoft-com:office:excel\" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:html=\"https://www.w3.org/TR/html401/\">");
            strHTML.AppendLine("<ss:Styles>");
            strHTML.AppendLine("<Style ss:ID=\"Default\" ss:Name=\"Normal\">");
            strHTML.AppendLine("<Alignment ss:Vertical=\"Bottom\"/>");
            strHTML.AppendLine("<Borders/>");
            strHTML.AppendLine("<Font ss:FontName=\"Calibri\" x:Family=\"Swiss\" ss:Size=\"11\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Interior/>");
            strHTML.AppendLine("<NumberFormat/>");
            strHTML.AppendLine("<Protection/>");
            strHTML.AppendLine("</Style>");
            strHTML.AppendLine("<Style ss:ID=\"s62\">");
            strHTML.AppendLine("<Alignment ss:Vertical=\"Bottom\"/>");
            strHTML.AppendLine("<Borders/>");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" ss:Bold=\"1\"/>");
            strHTML.AppendLine("<Interior/>");
            strHTML.AppendLine("<NumberFormat/>");
            strHTML.AppendLine("<Protection/>");
            strHTML.AppendLine("</Style>");
            strHTML.AppendLine("<Style ss:ID=\"s63\">");
            strHTML.AppendLine("<Alignment ss:Vertical=\"Bottom\"/>");
            strHTML.AppendLine("<Borders/>");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#FFFFFF\" ss:Bold=\"1\"/>");
            strHTML.AppendLine("<Interior ss:Color=\"#000000\" ss:Pattern=\"Solid\"/>");
            strHTML.AppendLine("<NumberFormat/>");
            strHTML.AppendLine("<Protection/>");
            strHTML.AppendLine("</Style>");


            //----------------
            strHTML.AppendLine("<Style ss:ID=\"s70\">");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#000000\" ss:FontColor=\"black\" ss:Bold=\"1\"/>");/*Archana*/
            strHTML.AppendLine("<Interior ss:Color=\"#8c8c8c\" ss:Pattern=\"Solid\"/>");/*Archana*/
            strHTML.AppendLine("<Alignment ss:Vertical=\"Top\" />");
            strHTML.AppendLine("<Borders>");
            strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("</Borders>");
            strHTML.AppendLine("</Style>");

            strHTML.AppendLine("<Style ss:ID=\"s80\">");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#000000\" ss:Bold=\"1\"/>");/*Archana*/
            strHTML.AppendLine("<Interior ss:Color=\"#FFFFFF\" ss:Pattern=\"Solid\"/>");/*Archana*/
            strHTML.AppendLine("<Alignment ss:Vertical=\"Top\" />");
            strHTML.AppendLine("<Borders>");
            strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("</Borders>");
            strHTML.AppendLine("</Style>");

            strHTML.AppendLine("<Style ss:ID=\"s76\">");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#000000\" ss:Bold=\"1\"/>");/*Archana*/
            strHTML.AppendLine("<Interior ss:Color=\"#CCCCCC\" ss:Pattern=\"Solid\"/>");/*Archana*/
            strHTML.AppendLine("<Alignment ss:Vertical=\"Top\" />");
            strHTML.AppendLine("<Borders>");
            strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("</Borders>");
            strHTML.AppendLine("</Style>");

            strHTML.AppendLine("<Style ss:ID=\"s82\">");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#000000\" ss:Bold=\"1\"/>");/*Archana*/
            strHTML.AppendLine("<Interior ss:Color=\"#A6A6A6\" ss:Pattern=\"Solid\"/>");/*Archana*/
            strHTML.AppendLine("<Alignment ss:Vertical=\"Top\" />");
            strHTML.AppendLine("<Borders>");
            strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("</Borders>");
            strHTML.AppendLine("</Style>");

            strHTML.AppendLine("<Style ss:ID=\"s84\">");
            strHTML.AppendLine("<Borders>");
            strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            strHTML.AppendLine("</Borders>");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" ss:Size=\"10\" ss:Color=\"#0000FF\"/>");
            strHTML.AppendLine("</Style>");

            strHTML.AppendLine("<Style ss:ID=\"s79\">");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" ss:Size=\"10\" ss:Color=\"#000000\" ss:Bold=\"1\"/>");
            strHTML.AppendLine("</Style>");

            //-------------------------

            strHTML.AppendLine("<Style ss:ID=\"s65\">");
            strHTML.AppendLine("<Borders>");
            strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            strHTML.AppendLine("</Borders>");
            strHTML.AppendLine("</Style>");
            strHTML.AppendLine("</ss:Styles>");

            strHTML.AppendLine("<Worksheet ss:Name=\"ScorecardReport\">");
            strHTML.AppendLine("<Table>");
            strHTML.AppendLine("<Column ss:Index=\"1\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"2\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"3\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"4\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"5\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"6\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"7\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"8\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"9\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"10\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"11\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"12\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"13\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"14\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"15\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Row ss:StyleID=\"s62\">");
            strHTML.AppendLine("<Cell><Data ss:Type=\"String\">Scorecard Report</Data></Cell>");
            strHTML.AppendLine("</Row>");

            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s79\"><Data ss:Type=\"String\">All the figures listed below are in (USD)</Data></Cell>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");

            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Business Segment</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">New Business Prior Forecast</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">New Business Year Forecast</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">New Business Plan</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Renewal PriorForecast</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Renewal YearForecast</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Renewal Plan</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Other Prior Forecast</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Other Business Forecast</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Other Plan</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Total Bound Prior Forecast</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Total Bound Year Forecast</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Total Bound Plan</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Forecast Percentage Prior</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Forecast Percentage Plan</Data></Cell>");
            strHTML.AppendLine("</Row>");

            var UwSummaryTotal = ScorecardAmountPerDivision.GroupBy(s => new { s.Company });

            foreach (var item in UwSummaryTotal)
            {
                if (item.Key.Company != null)
                {

                    //strHTML.AppendLine("<tr>");
                    //strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item.Key.Company + "</font></td>");
                    strHTML.AppendLine("<Row>");
                    strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + item.Key.Company + "</Data></Cell>");
                    int ii = 1;
                    foreach (var item44 in item)
                    {

                        if (ii == 1)
                        {

                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.NewBusinessPriorForecast) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.NewBusinessYearForecast) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.NewBusinessPlan) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.RenewalPriorForecast) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.RenewalYearForecast) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.RenewalPlan) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.OtherPriorForecast) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.OtherYearForecast) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.OtherPlan) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.TotalBoundPriorForecast) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.TotalBoundYearForecast) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.TotalBoundPlan) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item44.ForecastPercentagePrior) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item44.ForecastPercentagePlan) + "</Data></Cell>");
                            strHTML.AppendLine("</Row>");
                            ii++;



                        }
                    }

                }
                var ss = item.GroupBy(c => new { c.Division }).ToList();

                foreach (var item1 in ss)
                {
                    if (item1.Key.Division != null)
                    {
                        //strHTML.AppendLine("<tr>");
                        //strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item1.Key.Division + "</font></td>");
                        strHTML.AppendLine("<Row>");
                        strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + item1.Key.Division + "</Data></Cell>");
                        int kk = 1;
                        foreach (var item55 in item1)
                        {

                            if (kk == 1)
                            {

                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.NewBusinessPriorForecast) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.NewBusinessYearForecast) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.NewBusinessPlan) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.RenewalPriorForecast) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.RenewalYearForecast) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.RenewalPlan) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.OtherPriorForecast) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.OtherYearForecast) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.OtherPlan) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.TotalBoundPriorForecast) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.TotalBoundYearForecast) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.TotalBoundPlan) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item55.ForecastPercentagePrior) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item55.ForecastPercentagePlan) + "</Data></Cell>");
                                strHTML.AppendLine("</Row>");
                                kk++;


                            }
                        }

                    }
                    var ss1 = item1.GroupBy(c => new { c.Unit }).ToList();

                    foreach (var item2 in ss1)

                    {
                        if (item2.Key.Unit != null)
                        {
                            //strHTML.AppendLine("<tr>");
                            //strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item2.Key.Unit + "</font></td>");
                            strHTML.AppendLine("<Row>");
                            strHTML.AppendLine("<Cell><Data ss:Type=\"String\">" + item2.Key.Unit + "</Data></Cell>");
                            int nn = 1;
                            foreach (var item66 in item2)
                            {


                                if (nn == 1)
                                {

                                    strHTML.AppendLine("<Cell  ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.NewBusinessPriorForecast) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell  ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.NewBusinessYearForecast) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.NewBusinessPlan) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.RenewalPriorForecast) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.RenewalYearForecast) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.RenewalPlan) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.OtherPriorForecast) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.OtherYearForecast) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.OtherPlan) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell  ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.TotalBoundPriorForecast) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell  ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.TotalBoundYearForecast) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell  ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.TotalBoundPlan) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item66.ForecastPercentagePrior) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item66.ForecastPercentagePlan) + "</Data></Cell>");
                                    strHTML.AppendLine("</Row>");
                                    nn++;
                                }
                            }

                        }
                        var ss2 = item2.GroupBy(c => new { c.Segment }).ToList();
                        foreach (var item5 in ss2)
                        {
                            if (item5.Key.Segment != null)
                            {
                                //strHTML.AppendLine("<tr>");

                                // strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item5.Key.Segment + "</font></td>");
                                strHTML.AppendLine("<Row>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + item5.Key.Segment + "</Data></Cell>");
                                int jj = 1;
                                foreach (var item77 in item5)
                                {

                                    if (jj == 1)
                                    {

                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.NewBusinessPriorForecast) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.NewBusinessYearForecast) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.NewBusinessPlan) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.RenewalPriorForecast) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.RenewalYearForecast) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.RenewalPlan) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.OtherPriorForecast) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.OtherYearForecast) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.OtherPlan) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.TotalBoundPriorForecast) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.TotalBoundYearForecast) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.TotalBoundPlan) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item77.ForecastPercentagePrior) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item77.ForecastPercentagePlan) + "</Data></Cell>");
                                        strHTML.AppendLine("</Row>");
                                        jj++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">Selected Search Criteria</Data></Cell>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            int ICount = 0;
            foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
            {
                List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                {
                    if (!info.PropertyType.Name.Contains("List"))
                    {
                        var value = info.GetValue(trackingReportingCommonFilterInputModel, null);
                        var filter = info.Name + ":" + value + ";";
                        if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "PageNumber" && info.Name != "PageSize")
                        {
                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                strHTML.AppendLine("</Row>");
                                strHTML.AppendLine("<Row>");
                            }
                            strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                        }

                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(listValue))
                        {
                            var filter = info.Name + ":" + listValue + ";";

                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                strHTML.AppendLine("</Row>");
                                strHTML.AppendLine("<Row>");
                            }

                            //strHTML.AppendLine("<td colspan=1><font color='#0000FF' >" + filter + "</font></td>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");


                        }
                    }

                }
            }
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("</Table><WorksheetOptions xmlns=\"urn:schemas-microsoft-com:office:excel\"><DoNotDisplayGridlines/></WorksheetOptions></Worksheet>");//</Workbook>");

            return strHTML;
        }

        private string SpreadSheetXLSXGeneratorForNetScoreCard(
            List<ScorecardAmountPerDivionOutputModel> netScorecardAmountPerDivion,
            List<RegionalScorecardAmountPerRegionOutputModel> netScorecardAmountPerRegion,
            TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                ExcelCreationInputModel excelCreationInputModel = new ExcelCreationInputModel();
                outputFilePath = ExcelEngine.GetXLOutputPath(trackingReportingCommonFilterInputModel.ReportName, trackingReportingCommonFilterInputModel.UserID);

                using (SpreadsheetDocument xlDocument = SpreadsheetDocument.Create(outputFilePath, SpreadsheetDocumentType.Workbook))
                {
                    WorkbookPart xlWorkbookPart = xlDocument.AddWorkbookPart();
                    OpenXMLStyleHelper.SaveCustomStylesheet(xlWorkbookPart);
                    Workbook xlWorkbook = new Workbook();
                    xlWorkbookPart.Workbook = new Workbook();
                    xlWorkbook = xlWorkbookPart.Workbook;
                    Sheets xlSheets = xlWorkbook.AppendChild<Sheets>(new Sheets());
                    WorksheetPart xlWorksheetPart = null;
                    //Common value 
                    excelCreationInputModel.SearchCriteriaName = "Selected Search Criteria";
                    excelCreationInputModel.ReportName = "NetScorecardAmountPerDivision";
                    excelCreationInputModel.ReportHeaderName = "Net Scorecard - Amount Per Division Report: All the figures listed below are in (USD)";
                    excelCreationInputModel.SheetName = "Amount Per Division";
                    excelCreationInputModel.SheeIdValue = 1;
                    ExcelCommon.ExcelCommon.CreateCustomXcelSheet(excelCreationInputModel, trackingReportingCommonFilterInputModel, xlDocument, xlWorksheetPart, xlWorkbookPart, xlSheets, netScorecardAmountPerDivion.ToDataTable(), 5);

                    excelCreationInputModel.ReportName = "RegionalScoreCardAmountPerRegion";
                    excelCreationInputModel.ReportHeaderName = "Net Scorecard - Amount Per Region Report: All the figures listed below are in (USD)";
                    excelCreationInputModel.SheetName = "Amount Per Region";
                    excelCreationInputModel.SheeIdValue = 2;
                    ExcelCommon.ExcelCommon.CreateCustomXcelSheet(excelCreationInputModel, trackingReportingCommonFilterInputModel, xlDocument, xlWorksheetPart, xlWorkbookPart, xlSheets, netScorecardAmountPerRegion.ToDataTable(), 2);
                    //Create XL Workbook Part.
                    ExcelEngine.CreateXLWorkbookPart(xlDocument);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outputFilePath;
        }

        private string SpreadSheetXLSXGeneratorForRegionalScoreCard(
            List<RegionalScorecardAmountPerRegionOutputModel> regionalScorecardAmountPerRegion,
            List<RegionalScorecardNewBusinessByStatusOutputModel> regionalScorecardNewBusinessByStatus,
            List<RegionalScorecardRenewalByStatusOutputModel> regionalScorecardRenewalByStatus,
            TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                ExcelCreationInputModel excelCreationInputModel = new ExcelCreationInputModel();
                outputFilePath = ExcelEngine.GetXLOutputPath(trackingReportingCommonFilterInputModel.ReportName, trackingReportingCommonFilterInputModel.UserID);

                using (SpreadsheetDocument xlDocument = SpreadsheetDocument.Create(outputFilePath, SpreadsheetDocumentType.Workbook))
                {
                    WorkbookPart xlWorkbookPart = xlDocument.AddWorkbookPart();
                    OpenXMLStyleHelper.SaveCustomStylesheet(xlWorkbookPart);
                    Workbook xlWorkbook = new Workbook();
                    xlWorkbookPart.Workbook = new Workbook();
                    xlWorkbook = xlWorkbookPart.Workbook;
                    Sheets xlSheets = xlWorkbook.AppendChild<Sheets>(new Sheets());
                    WorksheetPart xlWorksheetPart = null;
                    //Common value 
                    excelCreationInputModel.SearchCriteriaName = "Selected Search Criteria";
                    //Create Worksheet for Regional Scorecard Report
                    excelCreationInputModel.ReportName = "RegionalScoreCardAmountPerRegion";
                    excelCreationInputModel.ReportHeaderName = "Regional ScoreCard - Amount Per Region Report: All the figures listed below are in (USD)";
                    excelCreationInputModel.SheetName = "Amount Per Region";
                    excelCreationInputModel.SheeIdValue = 1;
                    ExcelCommon.ExcelCommon.CreateCustomXcelSheet(excelCreationInputModel, trackingReportingCommonFilterInputModel, xlDocument, xlWorksheetPart, xlWorkbookPart, xlSheets, regionalScorecardAmountPerRegion.ToDataTable(), 2);
                    excelCreationInputModel.ReportName = "RegionalScorecardNewBusinessByStatus";
                    excelCreationInputModel.ReportHeaderName = "Regional ScoreCard - New Business By Status: All the figures listed below are in (USD)";
                    excelCreationInputModel.SheetName = "NewBusiness By Status";
                    excelCreationInputModel.SheeIdValue = 2;
                    ExcelCommon.ExcelCommon.CreateCustomXcelSheet(excelCreationInputModel, trackingReportingCommonFilterInputModel, xlDocument, xlWorksheetPart, xlWorkbookPart, xlSheets, regionalScorecardNewBusinessByStatus.ToDataTable(), 2);
                    excelCreationInputModel.ReportName = "RegionalScorecardRenewalByStatus";
                    excelCreationInputModel.ReportHeaderName = "Regional ScoreCard - Renewal By Status: All the figures listed below are in (USD)";
                    excelCreationInputModel.SheetName = "Renewal By Status";
                    excelCreationInputModel.SheeIdValue = 3;
                    ExcelCommon.ExcelCommon.CreateCustomXcelSheet(excelCreationInputModel, trackingReportingCommonFilterInputModel, xlDocument, xlWorksheetPart, xlWorkbookPart, xlSheets, regionalScorecardRenewalByStatus.ToDataTable(), 2);
                    //Create XL Workbook Part.
                    ExcelEngine.CreateXLWorkbookPart(xlDocument);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outputFilePath;
        }

        private string SpreadSheetXLSXGeneratorForProducerScoreCard(
           List<ProducerScorecardFilterOutputModel> producerScorecard,
           TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                ExcelCreationInputModel excelCreationInputModel = new ExcelCreationInputModel();
                outputFilePath = ExcelEngine.GetXLOutputPath(trackingReportingCommonFilterInputModel.ReportName, trackingReportingCommonFilterInputModel.UserID);

                using (SpreadsheetDocument xlDocument = SpreadsheetDocument.Create(outputFilePath, SpreadsheetDocumentType.Workbook))
                {
                    WorkbookPart xlWorkbookPart = xlDocument.AddWorkbookPart();
                    OpenXMLStyleHelper.SaveCustomStylesheet(xlWorkbookPart);
                    Workbook xlWorkbook = new Workbook();
                    xlWorkbookPart.Workbook = new Workbook();
                    xlWorkbook = xlWorkbookPart.Workbook;
                    Sheets xlSheets = xlWorkbook.AppendChild<Sheets>(new Sheets());
                    WorksheetPart xlWorksheetPart = null;
                    //Common value 
                    excelCreationInputModel.SearchCriteriaName = "Selected Search Criteria";
                    //Create Worksheet for proucer Scorecard Report
                    excelCreationInputModel.ReportName = "Producer Scorecard";
                    excelCreationInputModel.ReportHeaderName = "Producer Scorecard : All the figures listed below are in (USD)";
                    excelCreationInputModel.SheetName = "Producer Scorecard";
                    excelCreationInputModel.SheeIdValue = 1;
                    ExcelCommon.ExcelCommon.CreateCustomXcelSheet(excelCreationInputModel, trackingReportingCommonFilterInputModel, xlDocument, xlWorksheetPart, xlWorkbookPart, xlSheets, producerScorecard.ToDataTable(), 1);

                    ExcelEngine.CreateXLWorkbookPart(xlDocument);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outputFilePath;
        }
        private string SpreadSheetXLSXGeneratorForVariationReport(
       List<ForecastVariationOutputModel> forecastVariation,
       TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                ExcelCreationInputModel excelCreationInputModel = new ExcelCreationInputModel();
                outputFilePath = ExcelEngine.GetXLOutputPath(trackingReportingCommonFilterInputModel.ReportName, trackingReportingCommonFilterInputModel.UserID);

                using (SpreadsheetDocument xlDocument = SpreadsheetDocument.Create(outputFilePath, SpreadsheetDocumentType.Workbook))
                {
                    WorkbookPart xlWorkbookPart = xlDocument.AddWorkbookPart();
                    OpenXMLStyleHelper.SaveCustomStylesheet(xlWorkbookPart);
                    Workbook xlWorkbook = new Workbook();
                    xlWorkbookPart.Workbook = new Workbook();
                    xlWorkbook = xlWorkbookPart.Workbook;
                    Sheets xlSheets = xlWorkbook.AppendChild<Sheets>(new Sheets());
                    WorksheetPart xlWorksheetPart = null;
                    //Common value 
                    excelCreationInputModel.SearchCriteriaName = "Selected Search Criteria";
                    //Create Worksheet for proucer Scorecard Report
                    excelCreationInputModel.ReportName = "Variation Report";
                    excelCreationInputModel.ReportHeaderName = "Variation Report : All the figures listed below are in (USD)";
                    excelCreationInputModel.SheetName = "Variation Report";
                    excelCreationInputModel.SheeIdValue = 1;
                    ExcelCommon.ExcelCommon.CreateCustomXcelSheet(excelCreationInputModel, trackingReportingCommonFilterInputModel, xlDocument, xlWorksheetPart, xlWorkbookPart, xlSheets, forecastVariation.ToDataTable(), 1);

                    ExcelEngine.CreateXLWorkbookPart(xlDocument);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outputFilePath;
        }

        private string SpreadSheetXLSXGeneratorForScoreCard(List<ScorecardAmountPerDivionOutputModel> ScorecardAmountPerDivision,
            List<ScorecardByStatusOutputModel> ScorecardNewBusinessByStatus,
            List<ScorecardRenewalByStatusOutputModel> ScorecardRenewalByStatus,
            TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                outputFilePath = ExcelEngine.GetXLOutputPath("Scorecard", trackingReportingCommonFilterInputModel.UserID);
                using (SpreadsheetDocument xlDocument = SpreadsheetDocument.Create(outputFilePath, SpreadsheetDocumentType.Workbook))
                {
                    WorkbookPart xlWorkbookPart = xlDocument.AddWorkbookPart();
                    OpenXMLStyleHelper.SaveCustomStylesheet(xlWorkbookPart);
                    Workbook xlWorkbook = new Workbook();
                    xlWorkbookPart.Workbook = new Workbook();
                    xlWorkbook = xlWorkbookPart.Workbook;
                    Sheets xlSheets = xlWorkbook.AppendChild<Sheets>(new Sheets());
                    WorksheetPart xlWorksheetPart = null;
                    Sheet xlSheet = null;

                    //Create Worksheet for Scorecard Report - Begin
                    CreateSheetForAmountPerDivision(ScorecardAmountPerDivision, trackingReportingCommonFilterInputModel,
                        xlWorksheetPart, xlWorkbookPart, xlSheets, xlSheet);
                    //Create Worksheet for Scorecard Report - End

                    //Create Worksheet for Scorecard New Business Report - Begin
                    CreateSheetForNewBusinessByStatus(ScorecardNewBusinessByStatus, trackingReportingCommonFilterInputModel,
                        xlWorksheetPart, xlWorkbookPart, xlSheets, xlSheet);
                    //Create Worksheet for Scorecard  New Business Report - End

                    //Create Worksheet for Scorecard Renewal Report - Begin
                    CreateSheetForRenewalByStatus(ScorecardRenewalByStatus, trackingReportingCommonFilterInputModel,
                        xlWorksheetPart, xlWorkbookPart, xlSheets, xlSheet);
                    //Create Worksheet for Scorecard Renewal Report - End

                    //Create XL Workbook Part.
                    ExcelEngine.CreateXLWorkbookPart(xlDocument);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outputFilePath;
        }

        private string SpreadSheetXLSXGeneratorForTargetProgression(List<TargetProgressionByRegionOutputModel> targetProgressionByRegion, List<TargetProgressionByBranchOutputModel> targetProgressionByBranch,
            List<TargetProgressionByCompany> targetProgressionByCompany, List<TargetProgressionByDivision> targetProgressionByDivision,
            List<TargetProgressionByUnit> targetProgressionByUnit, List<TargetProgressionBySegment> targetProgressionBySegment,
            TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                outputFilePath = ExcelEngine.GetXLOutputPath("TargetProgression", trackingReportingCommonFilterInputModel.UserID);
                using (SpreadsheetDocument xlDocument = SpreadsheetDocument.Create(outputFilePath, SpreadsheetDocumentType.Workbook))
                {
                    WorkbookPart xlWorkbookPart = xlDocument.AddWorkbookPart();
                    OpenXMLStyleHelper.SaveCustomStylesheet(xlWorkbookPart);
                    Workbook xlWorkbook = new Workbook();
                    xlWorkbookPart.Workbook = new Workbook();
                    xlWorkbook = xlWorkbookPart.Workbook;
                    Sheets xlSheets = xlWorkbook.AppendChild(new Sheets());
                    WorksheetPart xlWorksheetPart = null;
                    Sheet xlSheet = null;

                    UInt32Value sheetId = 1;
                    CreateSheetForTargetProgressionByRegion(targetProgressionByRegion, trackingReportingCommonFilterInputModel,
                        xlWorksheetPart, xlWorkbookPart, xlSheets, xlSheet);

                    CreateSheetForTargetProgressionByBranch(targetProgressionByBranch, trackingReportingCommonFilterInputModel,
                        xlWorksheetPart, xlWorkbookPart, xlSheets, xlSheet);                   

                    CreateSheetForTargetProgressionByCompanyLOB(targetProgressionByCompany, trackingReportingCommonFilterInputModel,
                        xlWorksheetPart, xlWorkbookPart, xlSheets, xlSheet);

                    CreateSheetForTargetProgressionByDivisionLOB(targetProgressionByDivision, trackingReportingCommonFilterInputModel,
                     xlWorksheetPart, xlWorkbookPart, xlSheets, xlSheet);

                    CreateSheetForTargetProgressionByUnitLOB(targetProgressionByUnit, trackingReportingCommonFilterInputModel,
                     xlWorksheetPart, xlWorkbookPart, xlSheets, xlSheet);

                    CreateSheetForTargetProgressionBySegmentLOB(targetProgressionBySegment, trackingReportingCommonFilterInputModel,
                     xlWorksheetPart, xlWorkbookPart, xlSheets, xlSheet);

                    ExcelEngine.CreateXLWorkbookPart(xlDocument);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outputFilePath;
        }

        private void CreateSheetForAmountPerDivision(List<ScorecardAmountPerDivionOutputModel> ScorecardAmountPerDivision,
            TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel,
            WorksheetPart xlWorksheetPart, WorkbookPart xlWorkbookPart, Sheets xlSheets, Sheet xlSheet)
        {
            string[] xlWidthCollection = { "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30" };
            int xlRowStartIndex = 1;
            UInt32Value sheeIdValue = 1;
            try
            {
                xlWorksheetPart = xlWorkbookPart.AddNewPart<WorksheetPart>();
                xlSheet = new Sheet()
                {
                    Id = xlWorkbookPart.GetIdOfPart(xlWorksheetPart),
                    SheetId = sheeIdValue,
                    Name = "Amount Per Division"
                };
                xlSheets.Append(xlSheet);
                using (var xlWriter = OpenXmlWriter.Create(xlWorksheetPart))
                {
                    List<OpenXmlAttribute> xmlAttribute = null;
                    xlWriter.WriteStartElement(new Worksheet());
                    //Freeze header of report
                    ExcelEngine.SetHeaderRowFrozen(xlWriter, trackingReportingCommonFilterInputModel.ReportName);
                    //Set Column Width 
                    ExcelEngine.SetXLColumnWidth(xmlAttribute, xlWriter, xlWidthCollection);
                    xlWriter.WriteStartElement(new SheetData());

                    //For Download Report Header Row XML Attribute
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, xlRowStartIndex.ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    //Download Report Header - Write XL Header Text
                    ExcelEngine.WriteDataToExcel(xlWriter, "Amount Per Division Report: All the figures listed below are in (USD)", "string", 5);
                    //For Download Report Header Value End Element
                    xlWriter.WriteEndElement();

                    //To Write Blank Row.
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //For XL Header XML Attribute
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, "Division", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Bound Prior Forecast", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Bound Year Forecast", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Bound Plan", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "New Business Prior Forecast", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "New Business Year Forecast", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "New Business Plan", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Renewal PriorForecast", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Renewal YearForecast", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Renewal Plan", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Other Prior Forecast", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Other Business Forecast", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Other Plan", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Forecast Percentage Prior", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Forecast Percentage Plan", "string", 1);
                    //ForHeader Value End Element
                    xlWriter.WriteEndElement();

                    var UwSummaryTotal = ScorecardAmountPerDivision.GroupBy(s => new { s.Company });

                    foreach (var item in UwSummaryTotal)
                    {
                        if (item.Key.Company != null)
                        {
                            xmlAttribute = new List<OpenXmlAttribute>();
                            xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                            xlWriter.WriteStartElement(new Row(), xmlAttribute);
                            xlRowStartIndex++;
                            ExcelEngine.WriteDataToExcel(xlWriter, item.Key.Company, "string", 8);
                            int ii = 1;
                            foreach (var item44 in item)
                            {
                                if (ii == 1)
                                {
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.TotalBoundPriorForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.TotalBoundYearForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.TotalBoundPlan), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.NewBusinessPriorForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.NewBusinessYearForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.NewBusinessPlan), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.RenewalPriorForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.RenewalYearForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.RenewalPlan), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.OtherPriorForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.OtherYearForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.OtherPlan), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.ForecastPercentagePrior), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.ForecastPercentagePlan), "number", 9);
                                    //ForHeader Value End Element
                                    xlWriter.WriteEndElement();
                                    ii++;
                                    break;
                                }
                            }
                        }
                        var ss = item.GroupBy(c => new { c.Division }).ToList();

                        foreach (var item1 in ss)
                        {
                            if (item1.Key.Division != null)
                            {
                                xmlAttribute = new List<OpenXmlAttribute>();
                                xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                                xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                xlRowStartIndex++;
                                ExcelEngine.WriteDataToExcel(xlWriter, item1.Key.Division, "string", 13);
                                int kk = 1;
                                foreach (var item55 in item1)
                                {
                                    if (kk == 1)
                                    {
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.TotalBoundPriorForecast), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.TotalBoundYearForecast), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.TotalBoundPlan), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.NewBusinessPriorForecast), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.NewBusinessYearForecast), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.NewBusinessPlan), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.RenewalPriorForecast), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.RenewalYearForecast), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.RenewalPlan), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.OtherPriorForecast), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.OtherYearForecast), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.OtherPlan), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.ForecastPercentagePrior), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.ForecastPercentagePlan), "number", 10);
                                        xlWriter.WriteEndElement();
                                        kk++;
                                        break;

                                    }
                                }
                            }
                            var ss1 = item1.GroupBy(c => new { c.Unit }).ToList();

                            foreach (var item2 in ss1)
                            {
                                if (item2.Key.Unit != null)
                                {
                                    xmlAttribute = new List<OpenXmlAttribute>();
                                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                    xlRowStartIndex++;
                                    ExcelEngine.WriteDataToExcel(xlWriter, item2.Key.Unit, "string", 14);
                                    int nn = 1;
                                    foreach (var item66 in item2)
                                    {
                                        if (nn == 1)
                                        {
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.TotalBoundPriorForecast), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.TotalBoundYearForecast), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.TotalBoundPlan), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.NewBusinessPriorForecast), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.NewBusinessYearForecast), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.NewBusinessPlan), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.RenewalPriorForecast), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.RenewalYearForecast), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.RenewalPlan), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.OtherPriorForecast), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.OtherYearForecast), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.OtherPlan), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.ForecastPercentagePrior), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.ForecastPercentagePlan), "number", 11);
                                            xlWriter.WriteEndElement();
                                            nn++;
                                            break;
                                        }
                                    }

                                }
                                var ss2 = item2.GroupBy(c => new { c.Segment }).ToList();
                                foreach (var item5 in ss2)
                                {
                                    if (item5.Key.Segment != null)
                                    {
                                        xmlAttribute = new List<OpenXmlAttribute>();
                                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                        xlRowStartIndex++;
                                        ExcelEngine.WriteDataToExcel(xlWriter, item5.Key.Segment, "string", 15);
                                        int jj = 1;
                                        foreach (var item77 in item5)
                                        {
                                            if (jj == 1)
                                            {
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.TotalBoundPriorForecast), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.TotalBoundYearForecast), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.TotalBoundPlan), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.NewBusinessPriorForecast), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.NewBusinessYearForecast), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.NewBusinessPlan), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.RenewalPriorForecast), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.RenewalYearForecast), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.RenewalPlan), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.OtherPriorForecast), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.OtherYearForecast), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.OtherPlan), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.ForecastPercentagePrior), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.ForecastPercentagePlan), "number", 12);
                                                xlWriter.WriteEndElement();
                                                jj++;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    //To Write Blank Row.
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //To Write Filter Rows header
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, "Selected Search Criteria", "string", 7);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //To Write Filter Rows
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;

                    foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
                    {
                        List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                        string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                        if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                        {
                            if (!info.PropertyType.Name.Contains("List"))
                            {
                                var value = info.GetValue(trackingReportingCommonFilterInputModel, null);
                                var filter = info.Name + ":" + value + ";";
                                if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "PageNumber" && info.Name != "PageSize")
                                {
                                    //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                                    ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                }
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(listValue))
                                {
                                    var filter = info.Name + ":" + listValue + ";";
                                    //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                                    ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                }
                            }
                        }
                    }
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //For final end element
                    xlWriter.WriteStartElement(new Workbook());
                    xlWriter.WriteStartElement(new Worksheet());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void CreateSheetForNewBusinessByStatus(List<ScorecardByStatusOutputModel> ScorecardNewBusinessByStatus,
           TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel,
           WorksheetPart xlWorksheetPart, WorkbookPart xlWorkbookPart, Sheets xlSheets, Sheet xlSheet)
        {
            string[] xlWidthCollection = { "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30" };
            int xlRowStartIndex = 1;
            UInt32Value sheeIdValue = 2;
            try
            {
                xlWorksheetPart = xlWorkbookPart.AddNewPart<WorksheetPart>();
                xlSheet = new Sheet()
                {
                    Id = xlWorkbookPart.GetIdOfPart(xlWorksheetPart),
                    SheetId = sheeIdValue,
                    Name = "New Business By Status"
                };
                xlSheets.Append(xlSheet);
                using (var xlWriter = OpenXmlWriter.Create(xlWorksheetPart))
                {
                    List<OpenXmlAttribute> xmlAttribute = null;
                    xlWriter.WriteStartElement(new Worksheet());
                    //Freeze header of report
                    ExcelEngine.SetHeaderRowFrozen(xlWriter, trackingReportingCommonFilterInputModel.ReportName);
                    //Set Column Width 
                    ExcelEngine.SetXLColumnWidth(xmlAttribute, xlWriter, xlWidthCollection);
                    xlWriter.WriteStartElement(new SheetData());

                    //For Download Report Header Row XML Attribute
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, xlRowStartIndex.ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    //Download Report Header - Write XL Header Text
                    ExcelEngine.WriteDataToExcel(xlWriter, "New Business By Status: All the figures listed below are in (USD)", "string", 5);
                    //For Download Report Header Value End Element
                    xlWriter.WriteEndElement();

                    //To Write Blank Row.
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //For XL Header XML Attribute
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, "Division", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "New Business Prior Forecast (USD)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "New Business Year Forecast (USD)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "New Business Plan (USD)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Forecast Percentage Prior", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Forecast Percentage Plan", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submission Count Prior", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submission Count Total", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Quote Count Prior", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Quote Count Total", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Quoteto Submission Ratio", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Bound Count Prior", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Bound Count Total", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "BoundToQuote Ratio", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "BoundToSubmission Ratio", "string", 1);
                    //ForHeader Value End Element
                    xlWriter.WriteEndElement();

                    var q = ScorecardNewBusinessByStatus.GroupBy(s => new { s.Company });

                    foreach (var item in q)
                    {
                        if (item.Key.Company != null)
                        {
                            xmlAttribute = new List<OpenXmlAttribute>();
                            xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                            xlWriter.WriteStartElement(new Row(), xmlAttribute);
                            xlRowStartIndex++;
                            ExcelEngine.WriteDataToExcel(xlWriter, item.Key.Company, "string", 8);
                            //strHTML.AppendLine("<Row>");
                            //strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + item.Key.Company + "</Data></Cell>");
                            int ii = 1;
                            foreach (var item44 in item)
                            {
                                if (ii == 1)
                                {
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.NewBusinessPriorForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.NewBusinessYearForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.NewBusinessPlan), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.ForecastPercentagePrior), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.ForecastPercentagePlan), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.SubmissionCountPrior), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.SubmissionCountTotal), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.QuoteCountPrior), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.QuoteCountTotal), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.QuotetoSubmissionRatio), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.BoundCountPrior), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.BoundCountTotal), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.BoundtoQuoteRatio), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.BoundtoSubmissionRatio), "number", 9);
                                    //strHTML.AppendLine("</Row>");
                                    xlWriter.WriteEndElement();
                                    ii++;
                                }
                            }
                        }
                        var ss = item.GroupBy(c => new { c.Division }).ToList();

                        foreach (var item1 in ss)
                        {
                            if (item1.Key.Division != null)
                            {
                                xmlAttribute = new List<OpenXmlAttribute>();
                                xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                                xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                xlRowStartIndex++;
                                ExcelEngine.WriteDataToExcel(xlWriter, item1.Key.Division, "string", 13);
                                //strHTML.AppendLine("<Row>");
                                //strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + item1.Key.Division + "</Data></Cell>");
                                int kk = 1;
                                foreach (var item55 in item1)
                                {
                                    if (kk == 1)
                                    {
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.NewBusinessPriorForecast), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.NewBusinessYearForecast), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.NewBusinessPlan), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.ForecastPercentagePrior), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.ForecastPercentagePlan), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.SubmissionCountPrior), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.SubmissionCountTotal), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.QuoteCountPrior), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.QuoteCountTotal), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.QuotetoSubmissionRatio), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.BoundCountPrior), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.BoundCountTotal), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.BoundtoQuoteRatio), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.BoundtoSubmissionRatio), "number", 10);
                                        //strHTML.AppendLine("</Row>");
                                        xlWriter.WriteEndElement();
                                        kk++;
                                    }
                                }
                            }
                            var ss1 = item1.GroupBy(c => new { c.Unit }).ToList();

                            foreach (var item2 in ss1)
                            {
                                if (item2.Key.Unit != null)
                                {
                                    xmlAttribute = new List<OpenXmlAttribute>();
                                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                    xlRowStartIndex++;
                                    ExcelEngine.WriteDataToExcel(xlWriter, item2.Key.Unit, "string", 14);
                                    //strHTML.AppendLine("<Row>");
                                    //strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + item2.Key.Unit + "</Data></Cell>");
                                    int nn = 1;
                                    foreach (var item66 in item2)
                                    {
                                        if (nn == 1)
                                        {
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.NewBusinessPriorForecast), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.NewBusinessYearForecast), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.NewBusinessPlan), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.ForecastPercentagePrior), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.ForecastPercentagePlan), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.SubmissionCountPrior), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.SubmissionCountTotal), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.QuoteCountPrior), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.QuoteCountTotal), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.QuotetoSubmissionRatio), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.BoundCountPrior), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.BoundCountTotal), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.BoundtoQuoteRatio), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.BoundtoSubmissionRatio), "number", 11);
                                            //strHTML.AppendLine("</Row>");
                                            xlWriter.WriteEndElement();
                                            nn++;
                                        }
                                    }
                                }
                                var ss2 = item2.GroupBy(c => new { c.Segment }).ToList();
                                foreach (var item5 in ss2)
                                {
                                    if (item5.Key.Segment != null)
                                    {
                                        xmlAttribute = new List<OpenXmlAttribute>();
                                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                        xlRowStartIndex++;
                                        ExcelEngine.WriteDataToExcel(xlWriter, item5.Key.Segment, "string", 15);
                                        //strHTML.AppendLine("<Row>");
                                        //strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + item5.Key.Segment + "</Data></Cell>");
                                        int jj = 1;
                                        foreach (var item77 in item5)
                                        {
                                            if (jj == 1)
                                            {
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.NewBusinessPriorForecast), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.NewBusinessYearForecast), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.NewBusinessPlan), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.ForecastPercentagePrior), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.ForecastPercentagePlan), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.SubmissionCountPrior), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.SubmissionCountTotal), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.QuoteCountPrior), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.QuoteCountTotal), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.QuotetoSubmissionRatio), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.BoundCountPrior), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.BoundCountTotal), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.BoundtoQuoteRatio), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.BoundtoSubmissionRatio), "number", 12);
                                                //strHTML.AppendLine("</Row>");
                                                xlWriter.WriteEndElement();
                                                jj++;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    //To Write Blank Row.
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //To Write Filter Rows header
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, "Selected Search Criteria", "string", 7);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //To Write Filter Rows
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;

                    foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
                    {
                        List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                        string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                        if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                        {
                            if (!info.PropertyType.Name.Contains("List"))
                            {
                                var value = info.GetValue(trackingReportingCommonFilterInputModel, null);
                                var filter = info.Name + ":" + value + ";";
                                if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "PageNumber" && info.Name != "PageSize")
                                {
                                    ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                                }
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(listValue))
                                {
                                    var filter = info.Name + ":" + listValue + ";";
                                    ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                                }
                            }
                        }
                    }

                    //For row value end element
                    xlWriter.WriteEndElement();

                    //For final end element
                    xlWriter.WriteStartElement(new Workbook());
                    xlWriter.WriteStartElement(new Worksheet());
                }
                sheeIdValue++;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void CreateSheetForRenewalByStatus(List<ScorecardRenewalByStatusOutputModel> ScorecardRenewalByStatus,
          TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel,
          WorksheetPart xlWorksheetPart, WorkbookPart xlWorkbookPart, Sheets xlSheets, Sheet xlSheet)
        {
            string[] xlWidthCollection = { "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30" };
            int xlRowStartIndex = 1;
            UInt32Value sheeIdValue = 3;
            try
            {
                xlWorksheetPart = xlWorkbookPart.AddNewPart<WorksheetPart>();
                xlSheet = new Sheet()
                {
                    Id = xlWorkbookPart.GetIdOfPart(xlWorksheetPart),
                    SheetId = sheeIdValue,
                    Name = "Renewal By Status"
                };
                xlSheets.Append(xlSheet);
                using (var xlWriter = OpenXmlWriter.Create(xlWorksheetPart))
                {
                    List<OpenXmlAttribute> xmlAttribute = null;
                    xlWriter.WriteStartElement(new Worksheet());
                    //Freeze header of report
                    ExcelEngine.SetHeaderRowFrozen(xlWriter, trackingReportingCommonFilterInputModel.ReportName);
                    //Set Column Width 
                    ExcelEngine.SetXLColumnWidth(xmlAttribute, xlWriter, xlWidthCollection);
                    xlWriter.WriteStartElement(new SheetData());

                    //For Download Report Header Row XML Attribute
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, xlRowStartIndex.ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    //Download Report Header - Write XL Header Text
                    ExcelEngine.WriteDataToExcel(xlWriter, "Renewal By Status: All the figures listed below are in (USD)", "string", 5);
                    //For Download Report Header Value End Element
                    xlWriter.WriteEndElement();

                    //To Write Blank Row.
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //For XL Header XML Attribute
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, "Division", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Renewal Prior Forecast (USD)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Renewal Year Forecast (USD)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Renewal Plan (USD)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Forecast Percentage Prior", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Forecast Percentage Plan", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submission Count Prior", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submission Count Total", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Quote Count Prior", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Quote Count Total", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Quoteto Submission Ratio", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Bound Count Prior", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Bound Count Total", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "BoundToQuote Ratio", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "BoundToSubmission Ratio", "string", 1);
                    //ForHeader Value End Element
                    xlWriter.WriteEndElement();

                    var qq = ScorecardRenewalByStatus.GroupBy(s => new { s.Company });

                    foreach (var item in qq)
                    {
                        if (item.Key.Company != null)
                        {
                            xmlAttribute = new List<OpenXmlAttribute>();
                            xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                            xlWriter.WriteStartElement(new Row(), xmlAttribute);
                            xlRowStartIndex++;
                            ExcelEngine.WriteDataToExcel(xlWriter, item.Key.Company, "string", 8);
                            //strHTML.AppendLine("<Row>");
                            //strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + item.Key.Company + "</Data></Cell>");
                            int ii = 1;
                            foreach (var item44 in item)
                            {
                                if (ii == 1)
                                {
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.RenewalPriorForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.RenewalYearForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.RenewalPlan), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.ForecastPercentagePrior), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.ForecastPercentagePlan), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.SubmissionCountPrior), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.SubmissionCountTotal), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.QuoteCountPrior), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.QuoteCountTotal), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.QuotetoSubmissionRatio), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.BoundCountPrior), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.BoundCountTotal), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.BoundtoQuoteRatio), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.BoundtoSubmissionRatio), "number", 9);
                                    //strHTML.AppendLine("</Row>");
                                    xlWriter.WriteEndElement();
                                    ii++;
                                }
                            }
                        }
                        var ss = item.GroupBy(c => new { c.Division }).ToList();

                        foreach (var item1 in ss)
                        {
                            if (item1.Key.Division != null)
                            {
                                xmlAttribute = new List<OpenXmlAttribute>();
                                xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                                xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                xlRowStartIndex++;
                                ExcelEngine.WriteDataToExcel(xlWriter, item1.Key.Division, "string", 13);
                                //strHTML.AppendLine("<Row>");
                                //strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + item1.Key.Division + "</Data></Cell>");
                                int kk = 1;
                                foreach (var item55 in item1)
                                {
                                    if (kk == 1)
                                    {
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.RenewalPriorForecast), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.RenewalYearForecast), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.RenewalPlan), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.ForecastPercentagePrior), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.ForecastPercentagePlan), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.SubmissionCountPrior), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.SubmissionCountTotal), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.QuoteCountPrior), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.QuoteCountTotal), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.QuotetoSubmissionRatio), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.BoundCountPrior), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.BoundCountTotal), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.BoundtoQuoteRatio), "number", 10);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.BoundtoSubmissionRatio), "number", 10);
                                        //strHTML.AppendLine("</Row>");
                                        xlWriter.WriteEndElement();
                                        kk++;
                                    }
                                }
                            }
                            var ss1 = item1.GroupBy(c => new { c.Unit }).ToList();

                            foreach (var item2 in ss1)
                            {
                                if (item2.Key.Unit != null)
                                {
                                    xmlAttribute = new List<OpenXmlAttribute>();
                                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                    xlRowStartIndex++;
                                    ExcelEngine.WriteDataToExcel(xlWriter, item2.Key.Unit, "string", 14);
                                    //strHTML.AppendLine("<Row>");
                                    //strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + item2.Key.Unit + "</Data></Cell>");
                                    int nn = 1;
                                    foreach (var item66 in item2)
                                    {
                                        if (nn == 1)
                                        {
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.RenewalPriorForecast), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.RenewalYearForecast), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.RenewalPlan), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.ForecastPercentagePrior), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.ForecastPercentagePlan), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.SubmissionCountPrior), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.SubmissionCountTotal), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.QuoteCountPrior), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.QuoteCountTotal), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.QuotetoSubmissionRatio), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.BoundCountPrior), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.BoundCountTotal), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.BoundtoQuoteRatio), "number", 11);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.BoundtoSubmissionRatio), "number", 11);
                                            //strHTML.AppendLine("</Row>");
                                            xlWriter.WriteEndElement();
                                            nn++;
                                        }
                                    }
                                }
                                var ss2 = item2.GroupBy(c => new { c.Segment }).ToList();
                                foreach (var item5 in ss2)
                                {
                                    if (item5.Key.Segment != null)
                                    {
                                        xmlAttribute = new List<OpenXmlAttribute>();
                                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                        xlRowStartIndex++;
                                        ExcelEngine.WriteDataToExcel(xlWriter, item5.Key.Segment, "string", 15);
                                        //strHTML.AppendLine("<Row>");
                                        //strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + item5.Key.Segment + "</Data></Cell>");
                                        int jj = 1;
                                        foreach (var item77 in item5)
                                        {
                                            if (jj == 1)
                                            {
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.RenewalPriorForecast), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.RenewalYearForecast), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.RenewalPlan), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.ForecastPercentagePrior), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.ForecastPercentagePlan), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.SubmissionCountPrior), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.SubmissionCountTotal), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.QuoteCountPrior), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.QuoteCountTotal), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.QuotetoSubmissionRatio), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.BoundCountPrior), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.BoundCountTotal), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.BoundtoQuoteRatio), "number", 12);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.BoundtoSubmissionRatio), "number", 12);
                                                //strHTML.AppendLine("</Row>");
                                                xlWriter.WriteEndElement();
                                                jj++;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    //To Write Blank Row.
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //To Write Filter Rows header
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, "Selected Search Criteria", "string", 7);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //To Write Filter Rows
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;

                    foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
                    {
                        List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                        string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                        if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                        {
                            if (!info.PropertyType.Name.Contains("List"))
                            {
                                var value = info.GetValue(trackingReportingCommonFilterInputModel, null);
                                var filter = info.Name + ":" + value + ";";
                                if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "PageNumber" && info.Name != "PageSize")
                                {
                                    ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                                }
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(listValue))
                                {
                                    var filter = info.Name + ":" + listValue + ";";
                                    ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                                }
                            }
                        }
                    }
                    //For row value end element
                    xlWriter.WriteEndElement();


                    //For final end element
                    xlWriter.WriteStartElement(new Workbook());
                    xlWriter.WriteStartElement(new Worksheet());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void CreateSheetForTargetProgressionByRegion(List<TargetProgressionByRegionOutputModel> targetProgressionByRegion,
         TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel, WorksheetPart xlWorksheetPart,
         WorkbookPart xlWorkbookPart, Sheets xlSheets, Sheet xlSheet)
        {
            //CreateSheetForTargetProgression(targetProgressionData, trackingReportingCommonFilterInputModel, xlWorksheetPart,
            //    xlWorkbookPart, xlSheets, xlSheet, "By Region", 2);
            string[] xlWidthCollection = { "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30" };
            int xlRowStartIndex = 1;
            UInt32Value sheeIdValue = 1;
            try
            {
                xlWorksheetPart = xlWorkbookPart.AddNewPart<WorksheetPart>();
                xlSheet = new Sheet()
                {
                    Id = xlWorkbookPart.GetIdOfPart(xlWorksheetPart),
                    SheetId = sheeIdValue,
                    Name = "TargetProgression By Region"
                };
                xlSheets.Append(xlSheet);

                using (var xlWriter = OpenXmlWriter.Create(xlWorksheetPart))
                {
                    List<OpenXmlAttribute> xmlAttribute = null;
                    xlWriter.WriteStartElement(new Worksheet());
                    //Freeze header of report
                    ExcelEngine.SetHeaderRowFrozen(xlWriter, trackingReportingCommonFilterInputModel.ReportName);
                    //Set Column Width 
                    ExcelEngine.SetXLColumnWidth(xmlAttribute, xlWriter, xlWidthCollection);
                    xlWriter.WriteStartElement(new SheetData());

                    //For Download Report Header Row XML Attribute
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, xlRowStartIndex.ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    //Download Report Header - Write XL Header Text
                    ExcelEngine.WriteDataToExcel(xlWriter, "TargetProgression By Region: All the figures listed below are in (USD)", "string", 5);
                    //For Download Report Header Value End Element
                    xlWriter.WriteEndElement();

                    //To Write Blank Row.
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //For XL Header XML Attribute
                    xmlAttribute = new List<OpenXmlAttribute>
                    {
                        new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString())
                    };
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, "Credited Region", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Targets", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Outstanding (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Outstanding (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Outstanding (Forecast $)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Closed (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Closed (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Targets Rolled (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Targets Rolled (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received Quotes #", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received Bound #", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Bound (Forecast $)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Unbound RF (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Unbound RF (%)", "string", 1);

                    xlWriter.WriteEndElement();

                    var TargetByRegion = targetProgressionByRegion.GroupBy(s => new { s.CreditedRegion });
                    foreach (var item in TargetByRegion)
                    {
                        if (item.Key.CreditedRegion != null)
                        {

                            xmlAttribute = new List<OpenXmlAttribute>();
                            xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                            xlWriter.WriteStartElement(new Row(), xmlAttribute);
                            xlRowStartIndex++;
                            ExcelEngine.WriteDataToExcel(xlWriter, item.Key.CreditedRegion, "string", 8);
                            int ii = 1;
                            foreach (var item22 in item)
                            {
                                if (ii == 1)
                                {
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TotalTargets), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsOutStandingCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsOutStandingPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsOutStandingForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsClosedCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsClosedPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetRolledForwardCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetRolledForwardPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedSubmissionCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedSubmissionPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedQuotes), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedBound), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedBoundForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.UnBoundRFCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.UnBoundRFPercentage), "number", 9);
                                    xlWriter.WriteEndElement();
                                    ii++;
                                    break;
                                }
                            }
                        }
                        var ss = item.GroupBy(c => new { c.TargetConfidence }).ToList();
                        foreach (var item1 in ss)
                        {
                            if (item1.Key.TargetConfidence != null)
                            {

                                xmlAttribute = new List<OpenXmlAttribute>();
                                xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                                xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                xlRowStartIndex++;
                                ExcelEngine.WriteDataToExcel(xlWriter, item1.Key.TargetConfidence, "string", 8);
                                int kk = 1;
                                foreach (var item33 in item1)
                                {
                                    if (kk == 1)
                                    {
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TotalTargets), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsOutStandingCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsOutStandingPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsOutStandingForecast), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsClosedCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsClosedPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetRolledForwardCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetRolledForwardPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedSubmissionCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedSubmissionPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedQuotes), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedBound), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedBoundForecast), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.UnBoundRFCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.UnBoundRFPercentage), "number", 9);
                                        xlWriter.WriteEndElement();
                                        kk++;
                                        break;
                                    }
                                }
                            }
                        }
                    }

                    //To Write Blank Row.
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //To Write Filter Rows header
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, "Selected Search Criteria", "string", 7);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //To Write Filter Rows
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;

                    foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
                    {
                        List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                        string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                        if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                        {
                            if (!info.PropertyType.Name.Contains("List"))
                            {
                                var value = info.GetValue(trackingReportingCommonFilterInputModel, null);
                                var filter = info.Name + ":" + value + ";";
                                if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "PageNumber" && info.Name != "PageSize")
                                {
                                    ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                                }
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(listValue))
                                {
                                    var filter = info.Name + ":" + listValue + ";";
                                    ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                                }
                            }
                        }
                    }
                    //For row value end element
                    xlWriter.WriteEndElement();


                    //For final end element
                    xlWriter.WriteStartElement(new Workbook());
                    xlWriter.WriteStartElement(new Worksheet());
                }
                sheeIdValue++;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private void CreateSheetForTargetProgressionByBranch(List<TargetProgressionByBranchOutputModel> targetProgressionByBranch,
          TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel, WorksheetPart xlWorksheetPart,
          WorkbookPart xlWorkbookPart, Sheets xlSheets, Sheet xlSheet)
        {
            string[] xlWidthCollection = { "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30" };
            int xlRowStartIndex = 1;
            UInt32Value sheeIdValue = 2;
            try
            {
                xlWorksheetPart = xlWorkbookPart.AddNewPart<WorksheetPart>();
                xlSheet = new Sheet()
                {
                    Id = xlWorkbookPart.GetIdOfPart(xlWorksheetPart),
                    SheetId = sheeIdValue,
                    Name = "TargetProgression By Branch"
                };
                xlSheets.Append(xlSheet);

                using (var xlWriter = OpenXmlWriter.Create(xlWorksheetPart))
                {
                    List<OpenXmlAttribute> xmlAttribute = null;
                    xlWriter.WriteStartElement(new Worksheet());
                    //Freeze header of report
                    ExcelEngine.SetHeaderRowFrozen(xlWriter, trackingReportingCommonFilterInputModel.ReportName);
                    //Set Column Width 
                    ExcelEngine.SetXLColumnWidth(xmlAttribute, xlWriter, xlWidthCollection);
                    xlWriter.WriteStartElement(new SheetData());

                    //For Download Report Header Row XML Attribute
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, xlRowStartIndex.ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    //Download Report Header - Write XL Header Text
                    ExcelEngine.WriteDataToExcel(xlWriter, "TargetProgression By Branch: All the figures listed below are in (USD)", "string", 5);
                    //For Download Report Header Value End Element
                    xlWriter.WriteEndElement();

                    //To Write Blank Row.
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //For XL Header XML Attribute
                    xmlAttribute = new List<OpenXmlAttribute>
                    {
                        new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString())
                    };
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, "Credited Branch", "string", 1);
                    //ExcelEngine.WriteDataToExcel(xlWriter, "Target Confidence", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Targets", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Outstanding (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Outstanding (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Outstanding (Forecast $)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Closed (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Closed (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Targets Rolled (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Targets Rolled (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received Quotes #", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received Bound #", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Bound (Forecast $)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Unbound RF (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Unbound RF (%)", "string", 1);

                    xlWriter.WriteEndElement();

                    var TargetByBranch = targetProgressionByBranch.GroupBy(s => new { s.CreditedBranch });
                    foreach (var item in TargetByBranch)
                    {
                        if (item.Key.CreditedBranch != null)
                        {
                            xmlAttribute = new List<OpenXmlAttribute>();
                            xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                            xlWriter.WriteStartElement(new Row(), xmlAttribute);
                            xlRowStartIndex++;
                            ExcelEngine.WriteDataToExcel(xlWriter, item.Key.CreditedBranch, "string", 8);
                            int ii = 1;
                            foreach (var item22 in item)
                            {
                                if (ii == 1)
                                {
                                    //ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(value.TargetConfidence), "string", 8);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TotalTargets), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsOutStandingCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsOutStandingPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsOutStandingForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsClosedCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsClosedPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetRolledForwardCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetRolledForwardPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedSubmissionCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedSubmissionPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedQuotes), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedBound), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedBoundForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.UnBoundRFCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.UnBoundRFPercentage), "number", 9);

                                    xlWriter.WriteEndElement();
                                    ii++;
                                    break;
                                }

                            }
                        }

                        var ss = item.GroupBy(c => new { c.TargetConfidence }).ToList();
                        foreach (var item1 in ss)
                        {
                            if (item1.Key.TargetConfidence != null)
                            {
                                xmlAttribute = new List<OpenXmlAttribute>();
                                xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                                xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                xlRowStartIndex++;
                                ExcelEngine.WriteDataToExcel(xlWriter, item1.Key.TargetConfidence, "string", 8);
                                int kk = 1;
                                foreach (var item33 in item1)
                                {
                                    if (kk == 1)
                                    {
                                        //ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(value.TargetConfidence), "string", 8);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TotalTargets), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsOutStandingCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsOutStandingPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsOutStandingForecast), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsClosedCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsClosedPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetRolledForwardCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetRolledForwardPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedSubmissionCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedSubmissionPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedQuotes), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedBound), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedBoundForecast), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.UnBoundRFCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.UnBoundRFPercentage), "number", 9);

                                        xlWriter.WriteEndElement();
                                        kk++;
                                        break;
                                    }

                                }
                            }
                        }
                        }

                    //To Write Blank Row.
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //To Write Filter Rows header
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, "Selected Search Criteria", "string", 7);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //To Write Filter Rows
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;

                    foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
                    {
                        List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                        string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                        if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                        {
                            if (!info.PropertyType.Name.Contains("List"))
                            {
                                var value = info.GetValue(trackingReportingCommonFilterInputModel, null);
                                var filter = info.Name + ":" + value + ";";
                                if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "PageNumber" && info.Name != "PageSize")
                                {
                                    ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                                }
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(listValue))
                                {
                                    var filter = info.Name + ":" + listValue + ";";
                                    ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                                }
                            }
                        }
                    }
                    //For row value end element
                    xlWriter.WriteEndElement();


                    //For final end element
                    xlWriter.WriteStartElement(new Workbook());
                    xlWriter.WriteStartElement(new Worksheet());
                }
                sheeIdValue++;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        private void CreateSheetForTargetProgressionByCompanyLOB(List<TargetProgressionByCompany> targetProgressionByCompany,
         TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel, WorksheetPart xlWorksheetPart,
         WorkbookPart xlWorkbookPart, Sheets xlSheets, Sheet xlSheet)
        {
            //CreateSheetForTargetProgression(targetProgressionData, trackingReportingCommonFilterInputModel, xlWorksheetPart,
            //    xlWorkbookPart, xlSheets, xlSheet, "By Region", 2);
            string[] xlWidthCollection = { "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30" };
            int xlRowStartIndex = 1;
            UInt32Value sheeIdValue = 3;
            try
            {
                xlWorksheetPart = xlWorkbookPart.AddNewPart<WorksheetPart>();
                xlSheet = new Sheet()
                {
                    Id = xlWorkbookPart.GetIdOfPart(xlWorksheetPart),
                    SheetId = sheeIdValue,
                    Name = "TargetProgression By Company"
                };
                xlSheets.Append(xlSheet);

                using (var xlWriter = OpenXmlWriter.Create(xlWorksheetPart))
                {
                    List<OpenXmlAttribute> xmlAttribute = null;
                    xlWriter.WriteStartElement(new Worksheet());
                    //Freeze header of report
                    ExcelEngine.SetHeaderRowFrozen(xlWriter, trackingReportingCommonFilterInputModel.ReportName);
                    //Set Column Width 
                    ExcelEngine.SetXLColumnWidth(xmlAttribute, xlWriter, xlWidthCollection);
                    xlWriter.WriteStartElement(new SheetData());

                    //For Download Report Header Row XML Attribute
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, xlRowStartIndex.ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    //Download Report Header - Write XL Header Text
                    ExcelEngine.WriteDataToExcel(xlWriter, "TargetProgression By LOB: All the figures listed below are in (USD)", "string", 5);
                    //For Download Report Header Value End Element
                    xlWriter.WriteEndElement();

                    //To Write Blank Row.
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //For XL Header XML Attribute
                    xmlAttribute = new List<OpenXmlAttribute>
                    {
                        new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString())
                    };
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, "Company Name", "string", 1);                
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Targets", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Outstanding (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Outstanding (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Outstanding (Forecast $)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Closed (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Closed (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Targets Rolled (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Targets Rolled (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received Quotes #", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received Bound #", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Bound (Forecast $)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Unbound RF (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Unbound RF (%)", "string", 1);

                    xlWriter.WriteEndElement();

                    var TargetByCompany = targetProgressionByCompany.GroupBy(s => new { s.CompanyName });

                    foreach (var item in TargetByCompany)
                    {
                        if (item.Key.CompanyName != null)
                        {
                            xmlAttribute = new List<OpenXmlAttribute>();
                            xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                            xlWriter.WriteStartElement(new Row(), xmlAttribute);
                            
                            xlRowStartIndex++;
                            ExcelEngine.WriteDataToExcel(xlWriter, item.Key.CompanyName, "string", 8);
                            int ii = 1;
                            foreach (var item22 in item)
                            {
                                if (ii == 1)
                                {
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TotalTargets), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsOutStandingCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsOutStandingPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsOutStandingForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsClosedCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsClosedPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetRolledForwardCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetRolledForwardPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedSubmissionCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedSubmissionPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedQuotes), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedBound), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedBoundForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.UnBoundRFCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.UnBoundRFPercentage), "number", 9);

                                    xlWriter.WriteEndElement();
                                    ii++;
                                    break;
                                }
                            }
                        }
                        var ss = item.GroupBy(c => new { c.TargetConfidence }).ToList();
                        foreach (var item1 in ss)
                        {
                            if (item1.Key.TargetConfidence != null)
                            {

                                xmlAttribute = new List<OpenXmlAttribute>();
                                xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                                xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                xlRowStartIndex++;
                                ExcelEngine.WriteDataToExcel(xlWriter, item1.Key.TargetConfidence, "string", 8);
                                int kk = 1;
                                foreach (var item33 in item1)
                                {
                                    if (kk == 1)
                                    {
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TotalTargets), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsOutStandingCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsOutStandingPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsOutStandingForecast), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsClosedCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsClosedPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetRolledForwardCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetRolledForwardPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedSubmissionCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedSubmissionPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedQuotes), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedBound), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedBoundForecast), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.UnBoundRFCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.UnBoundRFPercentage), "number", 9);
                                        xlWriter.WriteEndElement();
                                        kk++;
                                        break;
                                    }
                                }
                            }
                        }

                    }

                    //To Write Blank Row.
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //To Write Filter Rows header
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, "Selected Search Criteria", "string", 7);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //To Write Filter Rows
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;

                    foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
                    {
                        List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                        string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                        if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                        {
                            if (!info.PropertyType.Name.Contains("List"))
                            {
                                var value = info.GetValue(trackingReportingCommonFilterInputModel, null);
                                var filter = info.Name + ":" + value + ";";
                                if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "PageNumber" && info.Name != "PageSize")
                                {
                                    ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                                }
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(listValue))
                                {
                                    var filter = info.Name + ":" + listValue + ";";
                                    ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                                }
                            }
                        }
                    }
                    //For row value end element
                    xlWriter.WriteEndElement();


                    //For final end element
                    xlWriter.WriteStartElement(new Workbook());
                    xlWriter.WriteStartElement(new Worksheet());
                }
                sheeIdValue++;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private void CreateSheetForTargetProgressionByDivisionLOB(List<TargetProgressionByDivision> targetProgressionByDivision,
        TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel, WorksheetPart xlWorksheetPart,
        WorkbookPart xlWorkbookPart, Sheets xlSheets, Sheet xlSheet)
        {
            //CreateSheetForTargetProgression(targetProgressionData, trackingReportingCommonFilterInputModel, xlWorksheetPart,
            //    xlWorkbookPart, xlSheets, xlSheet, "By Region", 2);
            string[] xlWidthCollection = { "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30" };
            int xlRowStartIndex = 1;
            UInt32Value sheeIdValue = 4;
            try
            {
                xlWorksheetPart = xlWorkbookPart.AddNewPart<WorksheetPart>();
                xlSheet = new Sheet()
                {
                    Id = xlWorkbookPart.GetIdOfPart(xlWorksheetPart),
                    SheetId = sheeIdValue,
                    Name = "TargetProgression By Division"
                };
                xlSheets.Append(xlSheet);

                using (var xlWriter = OpenXmlWriter.Create(xlWorksheetPart))
                {
                    List<OpenXmlAttribute> xmlAttribute = null;
                    xlWriter.WriteStartElement(new Worksheet());
                    //Freeze header of report
                    ExcelEngine.SetHeaderRowFrozen(xlWriter, trackingReportingCommonFilterInputModel.ReportName);
                    //Set Column Width 
                    ExcelEngine.SetXLColumnWidth(xmlAttribute, xlWriter, xlWidthCollection);
                    xlWriter.WriteStartElement(new SheetData());

                    //For Download Report Header Row XML Attribute
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, xlRowStartIndex.ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    //Download Report Header - Write XL Header Text
                    ExcelEngine.WriteDataToExcel(xlWriter, "TargetProgression By LOB: All the figures listed below are in (USD)", "string", 5);
                    //For Download Report Header Value End Element
                    xlWriter.WriteEndElement();

                    //To Write Blank Row.
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //For XL Header XML Attribute
                    xmlAttribute = new List<OpenXmlAttribute>
                    {
                        new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString())
                    };
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, "Division", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Targets", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Outstanding (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Outstanding (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Outstanding (Forecast $)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Closed (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Closed (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Targets Rolled (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Targets Rolled (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received Quotes #", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received Bound #", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Bound (Forecast $)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Unbound RF (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Unbound RF (%)", "string", 1);

                    xlWriter.WriteEndElement();

                    var TargetByDivision = targetProgressionByDivision.GroupBy(s => new { s.Division });

                    foreach (var item in TargetByDivision)
                    {
                        if (item.Key.Division != null)
                        {
                            xmlAttribute = new List<OpenXmlAttribute>();
                            xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                            xlWriter.WriteStartElement(new Row(), xmlAttribute);

                            xlRowStartIndex++;
                            ExcelEngine.WriteDataToExcel(xlWriter, item.Key.Division, "string", 8);
                            int ii = 1;
                            foreach (var item22 in item)
                            {
                                if (ii == 1)
                                {                                                      
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TotalTargets), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsOutStandingCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsOutStandingPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsOutStandingForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsClosedCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsClosedPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetRolledForwardCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetRolledForwardPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedSubmissionCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedSubmissionPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedQuotes), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedBound), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedBoundForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.UnBoundRFCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.UnBoundRFPercentage), "number", 9);

                                    xlWriter.WriteEndElement();
                                    ii++;
                                    break;
                                }
                            }
                        }
                        var ss = item.GroupBy(c => new { c.TargetConfidence }).ToList();
                        foreach (var item1 in ss)
                        {
                            if (item1.Key.TargetConfidence != null)
                            {

                                xmlAttribute = new List<OpenXmlAttribute>();
                                xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                                xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                xlRowStartIndex++;
                                ExcelEngine.WriteDataToExcel(xlWriter, item1.Key.TargetConfidence, "string", 8);
                                int kk = 1;
                                foreach (var item33 in item1)
                                {
                                    if (kk == 1)
                                    {
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TotalTargets), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsOutStandingCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsOutStandingPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsOutStandingForecast), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsClosedCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsClosedPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetRolledForwardCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetRolledForwardPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedSubmissionCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedSubmissionPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedQuotes), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedBound), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedBoundForecast), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.UnBoundRFCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.UnBoundRFPercentage), "number", 9);
                                        xlWriter.WriteEndElement();
                                        kk++;
                                        break;
                                    }
                                }
                            }
                        }

                    }

                    //To Write Blank Row.
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //To Write Filter Rows header
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, "Selected Search Criteria", "string", 7);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //To Write Filter Rows
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;

                    foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
                    {
                        List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                        string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                        if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                        {
                            if (!info.PropertyType.Name.Contains("List"))
                            {
                                var value = info.GetValue(trackingReportingCommonFilterInputModel, null);
                                var filter = info.Name + ":" + value + ";";
                                if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "PageNumber" && info.Name != "PageSize")
                                {
                                    ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                                }
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(listValue))
                                {
                                    var filter = info.Name + ":" + listValue + ";";
                                    ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                                }
                            }
                        }
                    }
                    //For row value end element
                    xlWriter.WriteEndElement();


                    //For final end element
                    xlWriter.WriteStartElement(new Workbook());
                    xlWriter.WriteStartElement(new Worksheet());
                }
                sheeIdValue++;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private void CreateSheetForTargetProgressionByUnitLOB(List<TargetProgressionByUnit> targetProgressionByUnit,
        TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel, WorksheetPart xlWorksheetPart,
        WorkbookPart xlWorkbookPart, Sheets xlSheets, Sheet xlSheet)
        {
            //CreateSheetForTargetProgression(targetProgressionData, trackingReportingCommonFilterInputModel, xlWorksheetPart,
            //    xlWorkbookPart, xlSheets, xlSheet, "By Region", 2);
            string[] xlWidthCollection = { "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30" };
            int xlRowStartIndex = 1;
            UInt32Value sheeIdValue = 5;
            try
            {
                xlWorksheetPart = xlWorkbookPart.AddNewPart<WorksheetPart>();
                xlSheet = new Sheet()
                {
                    Id = xlWorkbookPart.GetIdOfPart(xlWorksheetPart),
                    SheetId = sheeIdValue,
                    Name = "TargetProgression By Unit"
                };
                xlSheets.Append(xlSheet);

                using (var xlWriter = OpenXmlWriter.Create(xlWorksheetPart))
                {
                    List<OpenXmlAttribute> xmlAttribute = null;
                    xlWriter.WriteStartElement(new Worksheet());
                    //Freeze header of report
                    ExcelEngine.SetHeaderRowFrozen(xlWriter, trackingReportingCommonFilterInputModel.ReportName);
                    //Set Column Width 
                    ExcelEngine.SetXLColumnWidth(xmlAttribute, xlWriter, xlWidthCollection);
                    xlWriter.WriteStartElement(new SheetData());

                    //For Download Report Header Row XML Attribute
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, xlRowStartIndex.ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    //Download Report Header - Write XL Header Text
                    ExcelEngine.WriteDataToExcel(xlWriter, "TargetProgression By LOB: All the figures listed below are in (USD)", "string", 5);
                    //For Download Report Header Value End Element
                    xlWriter.WriteEndElement();

                    //To Write Blank Row.
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //For XL Header XML Attribute
                    xmlAttribute = new List<OpenXmlAttribute>
                    {
                        new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString())
                    };
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, "Unit", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Targets", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Outstanding (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Outstanding (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Outstanding (Forecast $)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Closed (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Closed (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Targets Rolled (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Targets Rolled (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received Quotes #", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received Bound #", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Bound (Forecast $)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Unbound RF (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Unbound RF (%)", "string", 1);

                    xlWriter.WriteEndElement();

                    var TargetByUnit = targetProgressionByUnit.GroupBy(s => new { s.Unit });

                    foreach (var item in TargetByUnit)
                    {
                        if (item.Key.Unit != null)
                        {
                            xmlAttribute = new List<OpenXmlAttribute>();
                            xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                            xlWriter.WriteStartElement(new Row(), xmlAttribute);

                            xlRowStartIndex++;
                            ExcelEngine.WriteDataToExcel(xlWriter, item.Key.Unit, "string", 8);
                            int ii = 1;
                            foreach (var item22 in item)
                            {
                                if (ii == 1)
                                {                    
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TotalTargets), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsOutStandingCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsOutStandingPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsOutStandingForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsClosedCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsClosedPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetRolledForwardCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetRolledForwardPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedSubmissionCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedSubmissionPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedQuotes), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedBound), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedBoundForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.UnBoundRFCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.UnBoundRFPercentage), "number", 9);

                                    xlWriter.WriteEndElement();
                                    ii++;
                                    break;
                                }
                            }
                        }
                        var ss = item.GroupBy(c => new { c.TargetConfidence }).ToList();
                        foreach (var item1 in ss)
                        {
                            if (item1.Key.TargetConfidence != null)
                            {

                                xmlAttribute = new List<OpenXmlAttribute>();
                                xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                                xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                xlRowStartIndex++;
                                ExcelEngine.WriteDataToExcel(xlWriter, item1.Key.TargetConfidence, "string", 8);
                                int kk = 1;
                                foreach (var item33 in item1)
                                {
                                    if (kk == 1)
                                    {
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TotalTargets), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsOutStandingCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsOutStandingPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsOutStandingForecast), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsClosedCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsClosedPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetRolledForwardCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetRolledForwardPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedSubmissionCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedSubmissionPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedQuotes), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedBound), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedBoundForecast), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.UnBoundRFCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.UnBoundRFPercentage), "number", 9);
                                        xlWriter.WriteEndElement();
                                        kk++;
                                        break;
                                    }
                                }
                            }
                        }

                    }

                    //To Write Blank Row.
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //To Write Filter Rows header
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, "Selected Search Criteria", "string", 7);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //To Write Filter Rows
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;

                    foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
                    {
                        List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                        string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                        if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                        {
                            if (!info.PropertyType.Name.Contains("List"))
                            {
                                var value = info.GetValue(trackingReportingCommonFilterInputModel, null);
                                var filter = info.Name + ":" + value + ";";
                                if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "PageNumber" && info.Name != "PageSize")
                                {
                                    ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                                }
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(listValue))
                                {
                                    var filter = info.Name + ":" + listValue + ";";
                                    ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                                }
                            }
                        }
                    }
                    //For row value end element
                    xlWriter.WriteEndElement();


                    //For final end element
                    xlWriter.WriteStartElement(new Workbook());
                    xlWriter.WriteStartElement(new Worksheet());
                }
                sheeIdValue++;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private void CreateSheetForTargetProgressionBySegmentLOB (List<TargetProgressionBySegment> targetProgressionBySegment,
        TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel, WorksheetPart xlWorksheetPart,
        WorkbookPart xlWorkbookPart, Sheets xlSheets, Sheet xlSheet)
        {
            string[] xlWidthCollection = { "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30" };
            int xlRowStartIndex = 1;
            UInt32Value sheeIdValue = 6;
            try
            {
                xlWorksheetPart = xlWorkbookPart.AddNewPart<WorksheetPart>();
                xlSheet = new Sheet()
                {
                    Id = xlWorkbookPart.GetIdOfPart(xlWorksheetPart),
                    SheetId = sheeIdValue,
                    Name = "TargetProgression By Segment"
                };
                xlSheets.Append(xlSheet);

                using (var xlWriter = OpenXmlWriter.Create(xlWorksheetPart))
                {
                    List<OpenXmlAttribute> xmlAttribute = null;
                    xlWriter.WriteStartElement(new Worksheet());
                    //Freeze header of report
                    ExcelEngine.SetHeaderRowFrozen(xlWriter, trackingReportingCommonFilterInputModel.ReportName);
                    //Set Column Width 
                    ExcelEngine.SetXLColumnWidth(xmlAttribute, xlWriter, xlWidthCollection);
                    xlWriter.WriteStartElement(new SheetData());

                    //For Download Report Header Row XML Attribute
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, xlRowStartIndex.ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    //Download Report Header - Write XL Header Text
                    ExcelEngine.WriteDataToExcel(xlWriter, "TargetProgression By LOB: All the figures listed below are in (USD)", "string", 5);
                    //For Download Report Header Value End Element
                    xlWriter.WriteEndElement();

                    //To Write Blank Row.
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //For XL Header XML Attribute
                    xmlAttribute = new List<OpenXmlAttribute>
                    {
                        new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString())
                    };
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, "Segment", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Targets", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Outstanding (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Outstanding (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Outstanding (Forecast $)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Closed (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Total Closed (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Targets Rolled (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Targets Rolled (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received (%)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received Quotes #", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Submissions Received Bound #", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Bound (Forecast $)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Unbound RF (Count)", "string", 1);
                    ExcelEngine.WriteDataToExcel(xlWriter, "Unbound RF (%)", "string", 1);

                    xlWriter.WriteEndElement();

                    var TargetBySegment = targetProgressionBySegment.GroupBy(s => new { s.Segment });

                    foreach (var item in TargetBySegment)
                    {
                        if (item.Key.Segment != null)
                        {
                            xmlAttribute = new List<OpenXmlAttribute>();
                            xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                            xlWriter.WriteStartElement(new Row(), xmlAttribute);

                            xlRowStartIndex++;
                            ExcelEngine.WriteDataToExcel(xlWriter, item.Key.Segment, "string", 8);
                            int ii = 1;
                            foreach (var item22 in item)
                            {
                                if (ii == 1)
                                {                     
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TotalTargets), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsOutStandingCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsOutStandingPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsOutStandingForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsClosedCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetsClosedPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetRolledForwardCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.TargetRolledForwardPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedSubmissionCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedSubmissionPercentage), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedQuotes), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedBound), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.SubmissionReceivedBoundForecast), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.UnBoundRFCount), "number", 9);
                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item22.UnBoundRFPercentage), "number", 9);
                                    xlWriter.WriteEndElement();
                                    ii++;
                                    break;
                                }
                            }
                        }
                        var ss = item.GroupBy(c => new { c.TargetConfidence }).ToList();
                        foreach (var item1 in ss)
                        {
                            if (item1.Key.TargetConfidence != null)
                            {

                                xmlAttribute = new List<OpenXmlAttribute>();
                                xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                                xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                xlRowStartIndex++;
                                ExcelEngine.WriteDataToExcel(xlWriter, item1.Key.TargetConfidence, "string", 8);
                                int kk = 1;
                                foreach (var item33 in item1)
                                {
                                    if (kk == 1)
                                    {
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TotalTargets), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsOutStandingCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsOutStandingPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsOutStandingForecast), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsClosedCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetsClosedPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetRolledForwardCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.TargetRolledForwardPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedSubmissionCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedSubmissionPercentage), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedQuotes), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedBound), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.SubmissionReceivedBoundForecast), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.UnBoundRFCount), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item33.UnBoundRFPercentage), "number", 9);
                                        xlWriter.WriteEndElement();
                                        kk++;
                                        break;
                                    }
                                }
                            }
                        }

                    }

                    //To Write Blank Row.
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //To Write Filter Rows header
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;
                    ExcelEngine.WriteDataToExcel(xlWriter, "Selected Search Criteria", "string", 7);
                    //For row value end element
                    xlWriter.WriteEndElement();

                    //To Write Filter Rows
                    xmlAttribute = new List<OpenXmlAttribute>();
                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                    xlRowStartIndex++;

                    foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
                    {
                        List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                        string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                        if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                        {
                            if (!info.PropertyType.Name.Contains("List"))
                            {
                                var value = info.GetValue(trackingReportingCommonFilterInputModel, null);
                                var filter = info.Name + ":" + value + ";";
                                if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "PageNumber" && info.Name != "PageSize")
                                {
                                    ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                                }
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(listValue))
                                {
                                    var filter = info.Name + ":" + listValue + ";";
                                    ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                                }
                            }
                        }
                    }
                    //For row value end element
                    xlWriter.WriteEndElement();


                    //For final end element
                    xlWriter.WriteStartElement(new Workbook());
                    xlWriter.WriteStartElement(new Worksheet());
                }
               
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        /*private void CreateSheetForTargetProgressionByLob(List<TargetProgressionOutputModel> targetProgressionData,
          TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel, WorksheetPart xlWorksheetPart,
          WorkbookPart xlWorkbookPart, Sheets xlSheets, Sheet xlSheet, string lobTarget)
        {
            Func<TargetProgressionOutputModel, string> keySelector;
            switch (lobTarget)
            {
                case "Division":
                    keySelector = d => d.Division;
                    break;

                case "Unit":
                    keySelector = d => d.Unit;
                    break;

                case "Segment":
                default:
                    keySelector = d => d.Segment;
                    break;
            }
            CreateSheetForTargetProgression(targetProgressionData, trackingReportingCommonFilterInputModel, xlWorksheetPart,
                xlWorkbookPart, xlSheets, xlSheet, "By LoB", 3, keySelector);
        }*/

        //private void CreateSheetForTargetProgression<T>(List<T> targetProgressionData,
        //  TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel, WorksheetPart xlWorksheetPart,
        //  WorkbookPart xlWorkbookPart, Sheets xlSheets, Sheet xlSheet, string sheetName, UInt32Value sheetId)
        //{
        //    string[] xlWidthCollection = { "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30", "30" };
        //    int xlRowStartIndex = 1;
        //    try
        //    {
        //        xlWorksheetPart = xlWorkbookPart.AddNewPart<WorksheetPart>();
        //        xlSheet = new Sheet()
        //        {
        //            Id = xlWorkbookPart.GetIdOfPart(xlWorksheetPart),
        //            SheetId = sheetId,
        //            Name = sheetName
        //        };
        //        xlSheets.Append(xlSheet);

        //        using (var xlWriter = OpenXmlWriter.Create(xlWorksheetPart))
        //        {
        //            List<OpenXmlAttribute> xmlAttribute = null;
        //            xlWriter.WriteStartElement(new Worksheet());
        //            //Freeze header of report
        //            ExcelEngine.SetHeaderRowFrozen(xlWriter, trackingReportingCommonFilterInputModel.ReportName);
        //            //Set Column Width 
        //            ExcelEngine.SetXLColumnWidth(xmlAttribute, xlWriter, xlWidthCollection);
        //            xlWriter.WriteStartElement(new SheetData());

        //            //For Download Report Header Row XML Attribute
        //            xmlAttribute = new List<OpenXmlAttribute>();
        //            xmlAttribute.Add(new OpenXmlAttribute("r", null, xlRowStartIndex.ToString()));
        //            xlWriter.WriteStartElement(new Row(), xmlAttribute);
        //            xlRowStartIndex++;
        //            //Download Report Header - Write XL Header Text
        //            ExcelEngine.WriteDataToExcel(xlWriter, "Renewal By Status: All the figures listed below are in (USD)", "string", 5);
        //            //For Download Report Header Value End Element
        //            xlWriter.WriteEndElement();

        //            //To Write Blank Row.
        //            xmlAttribute = new List<OpenXmlAttribute>();
        //            xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
        //            xlWriter.WriteStartElement(new Row(), xmlAttribute);
        //            xlRowStartIndex++;
        //            ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
        //            //For row value end element
        //            xlWriter.WriteEndElement();

        //            //For XL Header XML Attribute
        //            xmlAttribute = new List<OpenXmlAttribute>
        //            {
        //                new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString())
        //            };
        //            xlWriter.WriteStartElement(new Row(), xmlAttribute);
        //            xlRowStartIndex++;
        //            ExcelEngine.WriteDataToExcel(xlWriter, "Count", "string", 1);
        //            ExcelEngine.WriteDataToExcel(xlWriter, "Total Outstanding (Count)", "string", 1);
        //            ExcelEngine.WriteDataToExcel(xlWriter, "Total Outstanding (%)", "string", 1);
        //            ExcelEngine.WriteDataToExcel(xlWriter, "Total Outstanding (Forecat $)", "string", 1);
        //            ExcelEngine.WriteDataToExcel(xlWriter, "Total Closed (Count)", "string", 1);
        //            ExcelEngine.WriteDataToExcel(xlWriter, "Total Closed (%)", "string", 1);
        //            ExcelEngine.WriteDataToExcel(xlWriter, "Targets Rolled (Count)", "string", 1);
        //            ExcelEngine.WriteDataToExcel(xlWriter, "Targets Rolled (%)", "string", 1);
        //            ExcelEngine.WriteDataToExcel(xlWriter, "Submissions (Count)", "string", 1);
        //            ExcelEngine.WriteDataToExcel(xlWriter, "Submissions (%)", "string", 1);
        //            ExcelEngine.WriteDataToExcel(xlWriter, "Quoted #", "string", 1);
        //            ExcelEngine.WriteDataToExcel(xlWriter, "Bound #", "string", 1);
        //            ExcelEngine.WriteDataToExcel(xlWriter, "Bound (Forecast $)", "string", 1);
        //            ExcelEngine.WriteDataToExcel(xlWriter, "Unbound Submissions (Count)", "string", 1);
        //            ExcelEngine.WriteDataToExcel(xlWriter, "Unbound Submissions (%)", "string", 1);

        //            xlWriter.WriteEndElement();

        //            /*foreach (var value in targetProgressionData)
        //            {
        //                xmlAttribute = new List<OpenXmlAttribute>();
        //                xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
        //                xlWriter.WriteStartElement(new Row(), xmlAttribute);
        //                xlRowStartIndex++;
        //                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(value.TotalTargets), "number", 9);
        //                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(value.TotalOutStandingTargets), "number", 9);
        //                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(value.OutStandingTargetsPercentage), "number", 9);
        //                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(value.TotalForecast), "number", 9);
        //                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(value.TotalClosed), "number", 9);
        //                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(value.TotalClosedPercentage), "number", 9);
        //                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(value.TargetsRolledForward), "number", 9);
        //                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(value.TargetsRolledForwardPercentage), "number", 9);
        //                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(value.Submissions), "number", 9);
        //                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(value.SubmissionsPercentage), "number", 9);
        //                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(value.Quoted), "number", 9);
        //                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(value.Bound), "number", 9);
        //                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(value.BoundForecast), "number", 9);
        //                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(value.UnboundSubmissions), "number", 9);
        //                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(value.UnboundSubmissionsPercentage), "number", 9);

        //                xlWriter.WriteEndElement();
        //            }*/

        //            //To Write Blank Row.
        //            xmlAttribute = new List<OpenXmlAttribute>();
        //            xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
        //            xlWriter.WriteStartElement(new Row(), xmlAttribute);
        //            xlRowStartIndex++;
        //            ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
        //            //For row value end element
        //            xlWriter.WriteEndElement();

        //            //To Write Filter Rows header
        //            xmlAttribute = new List<OpenXmlAttribute>();
        //            xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
        //            xlWriter.WriteStartElement(new Row(), xmlAttribute);
        //            xlRowStartIndex++;
        //            ExcelEngine.WriteDataToExcel(xlWriter, "Selected Search Criteria", "string", 7);
        //            //For row value end element
        //            xlWriter.WriteEndElement();

        //            //To Write Filter Rows
        //            xmlAttribute = new List<OpenXmlAttribute>();
        //            xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
        //            xlWriter.WriteStartElement(new Row(), xmlAttribute);
        //            xlRowStartIndex++;

        //            foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
        //            {
        //                List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
        //                string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
        //                if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
        //                {
        //                    if (!info.PropertyType.Name.Contains("List"))
        //                    {
        //                        var value = info.GetValue(trackingReportingCommonFilterInputModel, null);
        //                        var filter = info.Name + ":" + value + ";";
        //                        if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "PageNumber" && info.Name != "PageSize")
        //                        {
        //                            ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
        //                            //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
        //                        }
        //                    }
        //                    else
        //                    {
        //                        if (!string.IsNullOrEmpty(listValue))
        //                        {
        //                            var filter = info.Name + ":" + listValue + ";";
        //                            ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
        //                            //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
        //                        }
        //                    }
        //                }
        //            }
        //            //For row value end element
        //            xlWriter.WriteEndElement();


        //            //For final end element
        //            xlWriter.WriteStartElement(new Workbook());
        //            xlWriter.WriteStartElement(new Worksheet());
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        private StringBuilder SpreadSheetXMLGeneratorNewBusiness(List<ScorecardByStatusOutputModel> ScorecardNewBusinessByStatus, TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {

            StringBuilder strHTML = new StringBuilder();
            //strHTML.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            //strHTML.AppendLine("<?mso-application progid=\"Excel.Sheet\"?>");
            //strHTML.AppendLine("<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:x=\"urn:schemas-microsoft-com:office:excel\" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:html=\"https://www.w3.org/TR/html401/\">");
            //strHTML.AppendLine("<ss:Styles>");
            //strHTML.AppendLine("<Style ss:ID=\"Default\" ss:Name=\"Normal\">");
            //strHTML.AppendLine("<Alignment ss:Vertical=\"Bottom\"/>");
            //strHTML.AppendLine("<Borders/>");
            //strHTML.AppendLine("<Font ss:FontName=\"Calibri\" x:Family=\"Swiss\" ss:Size=\"11\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Interior/>");
            //strHTML.AppendLine("<NumberFormat/>");
            //strHTML.AppendLine("<Protection/>");
            //strHTML.AppendLine("</Style>");
            //strHTML.AppendLine("<Style ss:ID=\"s62\">");
            //strHTML.AppendLine("<Alignment ss:Vertical=\"Bottom\"/>");
            //strHTML.AppendLine("<Borders/>");
            //strHTML.AppendLine("<Font ss:FontName=\"Arial\" ss:Bold=\"1\"/>");
            //strHTML.AppendLine("<Interior/>");
            //strHTML.AppendLine("<NumberFormat/>");
            //strHTML.AppendLine("<Protection/>");
            //strHTML.AppendLine("</Style>");
            //strHTML.AppendLine("<Style ss:ID=\"s63\">");
            //strHTML.AppendLine("<Alignment ss:Vertical=\"Bottom\"/>");
            //strHTML.AppendLine("<Borders/>");
            //strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#FFFFFF\" ss:Bold=\"1\"/>");
            //strHTML.AppendLine("<Interior ss:Color=\"#000000\" ss:Pattern=\"Solid\"/>");
            //strHTML.AppendLine("<NumberFormat/>");
            //strHTML.AppendLine("<Protection/>");
            //strHTML.AppendLine("</Style>");
            //strHTML.AppendLine("<Style ss:ID=\"s70\">");
            //strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#000000\" ss:FontColor=\"black\"/>");
            //strHTML.AppendLine("<Interior ss:Color=\"#FF8000\" ss:Pattern=\"Solid\"/>");
            //strHTML.AppendLine("<Alignment ss:Vertical=\"Top\" />");
            //strHTML.AppendLine("<Borders>");
            //strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("</Borders>");
            //strHTML.AppendLine("</Style>");
            //strHTML.AppendLine("<Style ss:ID=\"s65\">");
            //strHTML.AppendLine("<Borders>");
            //strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            //strHTML.AppendLine("</Borders>");
            //strHTML.AppendLine("</Style>");
            //strHTML.AppendLine("</ss:Styles>");
            //----------------
            //----------------
            //strHTML.AppendLine("<Style ss:ID=\"s79\">");
            //strHTML.AppendLine("<Font ss:FontName=\"Arial\" ss:Size=\"10\" ss:Color=\"#000000\" ss:Bold=\"1\"/>");
            //strHTML.AppendLine("</Style>");

            //strHTML.AppendLine("<Style ss:ID=\"s70\">");
            //strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#000000\" ss:FontColor=\"black\" ss:Bold=\"1\"/>");/*Archana*/
            //strHTML.AppendLine("<Interior ss:Color=\"#8c8c8c\" ss:Pattern=\"Solid\"/>");/*Archana*/
            //strHTML.AppendLine("<Alignment ss:Vertical=\"Top\" />");
            //strHTML.AppendLine("<Borders>");
            //strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("</Borders>");
            //strHTML.AppendLine("</Style>");

            //strHTML.AppendLine("<Style ss:ID=\"s80\">");
            //strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#000000\" ss:Bold=\"1\"/>");/*Archana*/
            //strHTML.AppendLine("<Interior ss:Color=\"#FFFFFF\" ss:Pattern=\"Solid\"/>");/*Archana*/
            //strHTML.AppendLine("<Alignment ss:Vertical=\"Top\" />");
            //strHTML.AppendLine("<Borders>");
            //strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("</Borders>");
            //strHTML.AppendLine("</Style>");

            //strHTML.AppendLine("<Style ss:ID=\"s76\">");
            //strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#000000\" ss:Bold=\"1\"/>");/*Archana*/
            //strHTML.AppendLine("<Interior ss:Color=\"#CCCCCC\" ss:Pattern=\"Solid\"/>");/*Archana*/
            //strHTML.AppendLine("<Alignment ss:Vertical=\"Top\" />");
            //strHTML.AppendLine("<Borders>");
            //strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("</Borders>");
            //strHTML.AppendLine("</Style>");

            //strHTML.AppendLine("<Style ss:ID=\"s82\">");
            //strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#000000\" ss:Bold=\"1\"/>");/*Archana*/
            //strHTML.AppendLine("<Interior ss:Color=\"#A6A6A6\" ss:Pattern=\"Solid\"/>");/*Archana*/
            //strHTML.AppendLine("<Alignment ss:Vertical=\"Top\" />");
            //strHTML.AppendLine("<Borders>");
            //strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("</Borders>");
            //strHTML.AppendLine("</Style>");

            //strHTML.AppendLine("<Style ss:ID=\"s84\">");
            //strHTML.AppendLine("<Borders>");
            //strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            //strHTML.AppendLine("</Borders>");
            //strHTML.AppendLine("<Font ss:FontName=\"Arial\" ss:Size=\"10\" ss:Color=\"#0000FF\"/>");
            //strHTML.AppendLine("</Style>");

            //-------------------------
            strHTML.AppendLine("<Worksheet ss:Name=\"ScorecardNewBusinessReport\">");
            strHTML.AppendLine("<Table>");
            strHTML.AppendLine("<Column ss:Index=\"1\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"2\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"3\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"4\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"5\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"6\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"7\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"8\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"9\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"10\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"11\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"12\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"13\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"14\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"15\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Row ss:StyleID=\"s62\">");
            strHTML.AppendLine("<Cell><Data ss:Type=\"String\">Scorecard New Business Status Report</Data></Cell>");
            strHTML.AppendLine("</Row>");

            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s79\"><Data ss:Type=\"String\">All the figures listed below are in (USD)</Data></Cell>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");

            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Business Segment</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">New Business Prior Forecast (USD)</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">New Business Year Forecast (USD)</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">New Business Plan (USD)</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Forecast Percentage Prior</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Forecast Percentage Plan</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Submission Count Prior</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Submission Count Total</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Quote Count Prior</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Quote Count Total</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Quoteto Submission Ratio</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Bound Count Prior</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Bound Count Total</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">BoundToSubmission Ratio</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">BoundToQuote Ratio</Data></Cell>");
            strHTML.AppendLine("</Row>");


            var q = ScorecardNewBusinessByStatus.GroupBy(s => new { s.Company });

            foreach (var item in q)
            {
                if (item.Key.Company != null)
                {

                    //strHTML.AppendLine("<tr>");
                    //strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item.Key.Company + "</font></td>");
                    strHTML.AppendLine("<Row>");
                    strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + item.Key.Company + "</Data></Cell>");
                    int ii = 1;
                    foreach (var item44 in item)
                    {

                        if (ii == 1)
                        {


                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.NewBusinessPriorForecast) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.NewBusinessYearForecast) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.NewBusinessPlan) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.ForecastPercentagePrior) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.ForecastPercentagePlan) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.SubmissionCountPrior) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.SubmissionCountTotal) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.QuoteCountPrior) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.QuoteCountTotal) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.QuotetoSubmissionRatio) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.BoundCountPrior) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.BoundCountTotal) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item44.BoundtoSubmissionRatio) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item44.BoundtoQuoteRatio) + "</Data></Cell>");
                            strHTML.AppendLine("</Row>");
                            ii++;


                        }
                    }

                }
                var ss = item.GroupBy(c => new { c.Division }).ToList();

                foreach (var item1 in ss)
                {
                    if (item1.Key.Division != null)
                    {
                        //strHTML.AppendLine("<tr>");
                        //strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item1.Key.Division + "</font></td>");
                        strHTML.AppendLine("<Row>");
                        strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + item1.Key.Division + "</Data></Cell>");
                        int kk = 1;
                        foreach (var item55 in item1)
                        {

                            if (kk == 1)
                            {

                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.NewBusinessPriorForecast) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.NewBusinessYearForecast) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.NewBusinessPlan) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.ForecastPercentagePrior) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.ForecastPercentagePlan) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.SubmissionCountPrior) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.SubmissionCountTotal) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.QuoteCountPrior) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.QuoteCountTotal) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.QuotetoSubmissionRatio) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.BoundCountPrior) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.BoundCountTotal) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item55.BoundtoSubmissionRatio) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item55.BoundtoQuoteRatio) + "</Data></Cell>");
                                strHTML.AppendLine("</Row>");
                                kk++;


                            }
                        }

                    }
                    var ss1 = item1.GroupBy(c => new { c.Unit }).ToList();

                    foreach (var item2 in ss1)

                    {
                        if (item2.Key.Unit != null)
                        {
                            //strHTML.AppendLine("<tr>");
                            //strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item2.Key.Unit + "</font></td>");
                            strHTML.AppendLine("<Row>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + item2.Key.Unit + "</Data></Cell>");
                            int nn = 1;
                            foreach (var item66 in item2)
                            {


                                if (nn == 1)
                                {

                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.NewBusinessPriorForecast) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.NewBusinessYearForecast) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.NewBusinessPlan) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.ForecastPercentagePrior) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.ForecastPercentagePlan) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.SubmissionCountPrior) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.SubmissionCountTotal) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.QuoteCountPrior) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.QuoteCountTotal) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.QuotetoSubmissionRatio) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.BoundCountPrior) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.BoundCountTotal) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item66.BoundtoSubmissionRatio) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item66.BoundtoQuoteRatio) + "</Data></Cell>");
                                    strHTML.AppendLine("</Row>");
                                    nn++;
                                }
                            }

                        }
                        var ss2 = item2.GroupBy(c => new { c.Segment }).ToList();
                        foreach (var item5 in ss2)
                        {
                            if (item5.Key.Segment != null)
                            {
                                //strHTML.AppendLine("<tr>");

                                //strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item5.Key.Segment + "</font></td>");
                                strHTML.AppendLine("<Row>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + item5.Key.Segment + "</Data></Cell>");
                                int jj = 1;
                                foreach (var item77 in item5)
                                {

                                    if (jj == 1)
                                    {

                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.NewBusinessPriorForecast) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.NewBusinessYearForecast) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.NewBusinessPlan) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.ForecastPercentagePrior) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.ForecastPercentagePlan) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.SubmissionCountPrior) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.SubmissionCountTotal) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.QuoteCountPrior) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.QuoteCountTotal) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.QuotetoSubmissionRatio) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.BoundCountPrior) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.BoundCountTotal) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item77.BoundtoSubmissionRatio) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item77.BoundtoQuoteRatio) + "</Data></Cell>");
                                        strHTML.AppendLine("</Row>");
                                        jj++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">Selected Search Criteria</Data></Cell>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            int ICount = 0;
            foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
            {
                List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                {
                    if (!info.PropertyType.Name.Contains("List"))
                    {
                        var value = info.GetValue(trackingReportingCommonFilterInputModel, null);
                        var filter = info.Name + ":" + value + ";";
                        if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "PageNumber" && info.Name != "PageSize")
                        {
                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                strHTML.AppendLine("</Row>");
                                strHTML.AppendLine("<Row>");
                            }
                            strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                        }

                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(listValue))
                        {
                            var filter = info.Name + ":" + listValue + ";";

                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                strHTML.AppendLine("</Row>");
                                strHTML.AppendLine("<Row>");
                            }

                            //strHTML.AppendLine("<td colspan=1><font color='#0000FF' >" + filter + "</font></td>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");


                        }
                    }

                }

            }
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("</Table><WorksheetOptions xmlns=\"urn:schemas-microsoft-com:office:excel\"><DoNotDisplayGridlines/></WorksheetOptions></Worksheet>");//</Workbook>");
            return strHTML;
        }

        private StringBuilder SpreadSheetXMLGeneratorRenewal(List<ScorecardRenewalByStatusOutputModel> ScorecardRenewalByStatus, TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            StringBuilder strHTML = new StringBuilder();
            //strHTML.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            //strHTML.AppendLine("<?mso-application progid=\"Excel.Sheet\"?>");
            //strHTML.AppendLine("<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:x=\"urn:schemas-microsoft-com:office:excel\" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:html=\"https://www.w3.org/TR/html401/\">");
            //strHTML.AppendLine("<ss:Styles>");
            //strHTML.AppendLine("<Style ss:ID=\"Default\" ss:Name=\"Normal\">");
            //strHTML.AppendLine("<Alignment ss:Vertical=\"Bottom\"/>");
            //strHTML.AppendLine("<Borders/>");
            //strHTML.AppendLine("<Font ss:FontName=\"Calibri\" x:Family=\"Swiss\" ss:Size=\"11\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Interior/>");
            //strHTML.AppendLine("<NumberFormat/>");
            //strHTML.AppendLine("<Protection/>");
            //strHTML.AppendLine("</Style>");
            //strHTML.AppendLine("<Style ss:ID=\"s62\">");
            //strHTML.AppendLine("<Alignment ss:Vertical=\"Bottom\"/>");
            //strHTML.AppendLine("<Borders/>");
            //strHTML.AppendLine("<Font ss:FontName=\"Arial\" ss:Bold=\"1\"/>");
            //strHTML.AppendLine("<Interior/>");
            //strHTML.AppendLine("<NumberFormat/>");
            //strHTML.AppendLine("<Protection/>");
            //strHTML.AppendLine("</Style>");
            //strHTML.AppendLine("<Style ss:ID=\"s63\">");
            //strHTML.AppendLine("<Alignment ss:Vertical=\"Bottom\"/>");
            //strHTML.AppendLine("<Borders/>");
            //strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#FFFFFF\" ss:Bold=\"1\"/>");
            //strHTML.AppendLine("<Interior ss:Color=\"#000000\" ss:Pattern=\"Solid\"/>");
            //strHTML.AppendLine("<NumberFormat/>");
            //strHTML.AppendLine("<Protection/>");
            //strHTML.AppendLine("</Style>");
            //strHTML.AppendLine("<Style ss:ID=\"s70\">");
            //strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#000000\" ss:FontColor=\"black\"/>");
            //strHTML.AppendLine("<Interior ss:Color=\"#FF8000\" ss:Pattern=\"Solid\"/>");
            //strHTML.AppendLine("<Alignment ss:Vertical=\"Top\" />");
            //strHTML.AppendLine("<Borders>");
            //strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("</Borders>");
            //strHTML.AppendLine("</Style>");
            //strHTML.AppendLine("<Style ss:ID=\"s65\">");
            //strHTML.AppendLine("<Borders>");
            //strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            //strHTML.AppendLine("</Borders>");
            //strHTML.AppendLine("</Style>");
            //strHTML.AppendLine("</ss:Styles>");
            //----------------
            //strHTML.AppendLine("<Style ss:ID=\"s70\">");
            //strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#000000\" ss:FontColor=\"black\" ss:Bold=\"1\"/>");/*Archana*/
            //strHTML.AppendLine("<Interior ss:Color=\"#8c8c8c\" ss:Pattern=\"Solid\"/>");/*Archana*/
            //strHTML.AppendLine("<Alignment ss:Vertical=\"Top\" />");
            //strHTML.AppendLine("<Borders>");
            //strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("</Borders>");
            //strHTML.AppendLine("</Style>");

            //strHTML.AppendLine("<Style ss:ID=\"s80\">");
            //strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#000000\" ss:Bold=\"1\"/>");/*Archana*/
            //strHTML.AppendLine("<Interior ss:Color=\"#FFFFFF\" ss:Pattern=\"Solid\"/>");/*Archana*/
            //strHTML.AppendLine("<Alignment ss:Vertical=\"Top\" />");
            //strHTML.AppendLine("<Borders>");
            //strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("</Borders>");
            //strHTML.AppendLine("</Style>");

            //strHTML.AppendLine("<Style ss:ID=\"s76\">");
            //strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#000000\" ss:Bold=\"1\"/>");/*Archana*/
            //strHTML.AppendLine("<Interior ss:Color=\"#CCCCCC\" ss:Pattern=\"Solid\"/>");/*Archana*/
            //strHTML.AppendLine("<Alignment ss:Vertical=\"Top\" />");
            //strHTML.AppendLine("<Borders>");
            //strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("</Borders>");
            //strHTML.AppendLine("</Style>");

            //strHTML.AppendLine("<Style ss:ID=\"s82\">");
            //strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#000000\" ss:Bold=\"1\"/>");/*Archana*/
            //strHTML.AppendLine("<Interior ss:Color=\"#A6A6A6\" ss:Pattern=\"Solid\"/>");/*Archana*/
            //strHTML.AppendLine("<Alignment ss:Vertical=\"Top\" />");
            //strHTML.AppendLine("<Borders>");
            //strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            //strHTML.AppendLine("</Borders>");
            //strHTML.AppendLine("</Style>");

            //strHTML.AppendLine("<Style ss:ID=\"s84\">");
            //strHTML.AppendLine("<Borders>");
            //strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            //strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            //strHTML.AppendLine("</Borders>");
            //strHTML.AppendLine("<Font ss:FontName=\"Arial\" ss:Size=\"10\" ss:Color=\"#0000FF\"/>");
            //strHTML.AppendLine("</Style>");

            //strHTML.AppendLine("<Style ss:ID=\"s79\">");
            //strHTML.AppendLine("<Font ss:FontName=\"Arial\" ss:Size=\"10\" ss:Color=\"#000000\" ss:Bold=\"1\"/>");
            //strHTML.AppendLine("</Style>");

            //-------------------------
            strHTML.AppendLine("<Worksheet ss:Name=\"ScorecardRenewalReport\">");
            strHTML.AppendLine("<Table>");
            strHTML.AppendLine("<Column ss:Index=\"1\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"2\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"3\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"4\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"5\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"6\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"7\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"8\" ss:AutoFitWidth=\"1\" ss:Width=\"100\"/>");
            strHTML.AppendLine("<Column ss:Index=\"9\" ss:AutoFitWidth=\"1\" ss:Width=\"100\"/>");
            strHTML.AppendLine("<Column ss:Index=\"10\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"11\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"12\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"13\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"14\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"15\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Row ss:StyleID=\"s62\">");
            strHTML.AppendLine("<Cell><Data ss:Type=\"String\">Scorecard Renewal Report</Data></Cell>");
            strHTML.AppendLine("</Row>");

            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s79\"><Data ss:Type=\"String\">All the figures listed below are in (USD)</Data></Cell>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");

            strHTML.AppendLine("<Row >");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Business Segment</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Renewal Prior Forecast (USD)</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Renewal Year Forecast (USD)</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Renewal Plan (USD)</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Forecast Percentage Prior</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Forecast Percentage Plan</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Submission Count Prior</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Submission Count Total</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Quote Count Prior</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Quote Count Total</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Quoteto Submission Ratio</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Bound Count Prior</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Bound Count Total</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">BoundToSubmission Ratio</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">BoundToQuote Ratio</Data></Cell>");
            strHTML.AppendLine("</Row>");


            var qq = ScorecardRenewalByStatus.GroupBy(s => new { s.Company });

            foreach (var item in qq)
            {
                if (item.Key.Company != null)
                {

                    //strHTML.AppendLine("<tr>");
                    //strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item.Key.Company + "</font></td>");
                    strHTML.AppendLine("<Row>");
                    strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + item.Key.Company + "</Data></Cell>");
                    int ii = 1;
                    foreach (var item44 in item)
                    {

                        if (ii == 1)
                        {

                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.RenewalPriorForecast) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.RenewalYearForecast) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.RenewalPlan) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.ForecastPercentagePrior) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.ForecastPercentagePlan) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.SubmissionCountPrior) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.SubmissionCountTotal) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.QuoteCountPrior) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.QuoteCountTotal) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.QuotetoSubmissionRatio) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.BoundCountPrior) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.BoundCountTotal) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item44.BoundtoSubmissionRatio) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item44.BoundtoQuoteRatio) + "</Data></Cell>");
                            strHTML.AppendLine("</Row>");
                            ii++;


                        }
                    }

                }
                var ss = item.GroupBy(c => new { c.Division }).ToList();

                foreach (var item1 in ss)
                {
                    if (item1.Key.Division != null)
                    {
                        //strHTML.AppendLine("<tr>");
                        //strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item1.Key.Division + "</font></td>");
                        strHTML.AppendLine("<Row>");
                        strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + item1.Key.Division + "</Data></Cell>");
                        int kk = 1;
                        foreach (var item55 in item1)
                        {

                            if (kk == 1)
                            {

                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.RenewalPriorForecast) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.RenewalYearForecast) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.RenewalPlan) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.ForecastPercentagePrior) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.ForecastPercentagePlan) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.SubmissionCountPrior) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.SubmissionCountTotal) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.QuoteCountPrior) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.QuoteCountTotal) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.QuotetoSubmissionRatio) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.BoundCountPrior) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.BoundCountTotal) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item55.BoundtoSubmissionRatio) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item55.BoundtoQuoteRatio) + "</Data></Cell>");
                                strHTML.AppendLine("</Row>");
                                kk++;

                            }
                        }

                    }
                    var ss1 = item1.GroupBy(c => new { c.Unit }).ToList();

                    foreach (var item2 in ss1)

                    {
                        if (item2.Key.Unit != null)
                        {
                            //strHTML.AppendLine("<tr>");
                            //strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item2.Key.Unit + "</font></td>");
                            strHTML.AppendLine("<Row>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + item2.Key.Unit + "</Data></Cell>");
                            int nn = 1;
                            foreach (var item66 in item2)
                            {


                                if (nn == 1)
                                {

                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.RenewalPriorForecast) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.RenewalYearForecast) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.RenewalPlan) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.ForecastPercentagePrior) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.ForecastPercentagePlan) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.SubmissionCountPrior) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.SubmissionCountTotal) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.QuoteCountPrior) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.QuoteCountTotal) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.QuotetoSubmissionRatio) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.BoundCountPrior) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.BoundCountTotal) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item66.BoundtoSubmissionRatio) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item66.BoundtoQuoteRatio) + "</Data></Cell>");
                                    strHTML.AppendLine("</Row>");
                                    nn++;
                                }
                            }

                        }
                        var ss2 = item2.GroupBy(c => new { c.Segment }).ToList();
                        foreach (var item5 in ss2)
                        {
                            if (item5.Key.Segment != null)
                            {
                                //strHTML.AppendLine("<tr>");

                                //strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item5.Key.Segment + "</font></td>");
                                strHTML.AppendLine("<Row>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + item5.Key.Segment + "</Data></Cell>");
                                int jj = 1;
                                foreach (var item77 in item5)
                                {

                                    if (jj == 1)
                                    {

                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.RenewalPriorForecast) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.RenewalYearForecast) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.RenewalPlan) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.ForecastPercentagePrior) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.ForecastPercentagePlan) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.SubmissionCountPrior) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.SubmissionCountTotal) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.QuoteCountPrior) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.QuoteCountTotal) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.QuotetoSubmissionRatio) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.BoundCountPrior) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.BoundCountTotal) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item77.BoundtoSubmissionRatio) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:0.0#}", item77.BoundtoQuoteRatio) + "</Data></Cell>");
                                        strHTML.AppendLine("</Row>");
                                        jj++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            int ICount = 0;
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">Selected Search Criteria</Data></Cell>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
            {
                List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                {
                    if (!info.PropertyType.Name.Contains("List"))
                    {
                        var value = info.GetValue(trackingReportingCommonFilterInputModel, null);
                        var filter = info.Name + ":" + value + ";";
                        if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "PageNumber" && info.Name != "PageSize")
                        {
                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                strHTML.AppendLine("</Row>");
                                strHTML.AppendLine("<Row>");
                            }
                            strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                        }

                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(listValue))
                        {
                            var filter = info.Name + ":" + listValue + ";";

                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                strHTML.AppendLine("</Row>");
                                strHTML.AppendLine("<Row>");
                            }

                            //strHTML.AppendLine("<td colspan=1><font color='#0000FF' >" + filter + "</font></td>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");


                        }
                    }

                }

            }
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("</Table><WorksheetOptions xmlns=\"urn:schemas-microsoft-com:office:excel\"><DoNotDisplayGridlines/></WorksheetOptions></Worksheet></Workbook>");
            return strHTML;
        }

        private string SpreadSheetXLSXGenerartorForecastDivision(List<ForecastByBusinessSegmentOutputModel> forecastByBusinessSegmentOutputModel, TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                string[] xlWidthCollection = { "30", "30", "30", "30", "30", "30", "30", "30", "30" };
                int xlRowStartIndex = 1;
                UInt32Value sheeIdValue = 1;
                outputFilePath = ExcelEngine.GetXLOutputPath("Forecast Division", trackingReportingCommonFilterInputModel.UserID);
                using (SpreadsheetDocument xlDocument = SpreadsheetDocument.Create(outputFilePath, SpreadsheetDocumentType.Workbook))
                {
                    //Create new xl worksheet part and new sheet
                    WorksheetPart xlWorksheetPart = ExcelEngine.CreateXLWorksheetPartAndSheets(xlDocument, sheeIdValue, "Forecast Division");

                    using (var xlWriter = OpenXmlWriter.Create(xlWorksheetPart))
                    {
                        List<OpenXmlAttribute> xmlAttribute = null;
                        xlWriter.WriteStartElement(new Worksheet());
                        //Freeze header of report
                        ExcelEngine.SetHeaderRowFrozen(xlWriter, trackingReportingCommonFilterInputModel.ReportName);
                        //Set Column Width 
                        ExcelEngine.SetXLColumnWidth(xmlAttribute, xlWriter, xlWidthCollection);
                        xlWriter.WriteStartElement(new SheetData());

                        //For Download Report Header Row XML Attribute
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, xlRowStartIndex.ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        xlRowStartIndex++;
                        //Download Report Header - Write XL Header Text
                        ExcelEngine.WriteDataToExcel(xlWriter, "Forecast Division Report: All the figures listed below are in (USD)", "string", 5);
                        //For Download Report Header Value End Element
                        xlWriter.WriteEndElement();

                        //To Write Blank Row.
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        xlRowStartIndex++;
                        ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                        //For row value end element
                        xlWriter.WriteEndElement();

                        //For XL Header XML Attribute
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        xlRowStartIndex++;
                        ExcelEngine.WriteDataToExcel(xlWriter, "Division", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Renewal Base (USD)", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Renewal Forecast (USD)", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "New Forecast (USD)", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Other Forecast (USD)", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Total Forecast (USD)", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Plan (USD)", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Forecast vs Plan (USD)", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Forecast Vs Plan %", "string", 1);
                        //ForHeader Value End Element
                        xlWriter.WriteEndElement();

                        //To Write XL Rows
                        var q = forecastByBusinessSegmentOutputModel.GroupBy(s => new { s.Company });
                        foreach (var item in q)
                        {
                            if (item.Key.Company != null)
                            {
                                xmlAttribute = new List<OpenXmlAttribute>();
                                xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                                xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                xlRowStartIndex++;
                                ExcelEngine.WriteDataToExcel(xlWriter, item.Key.Company, "string", 8);
                                //strHTML.AppendLine("<Row>");
                                //strHTML.AppendLine("<Cell  ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + item.Key.Company + "</Data></Cell>");
                                int ii = 1;
                                foreach (var item44 in item)
                                {
                                    if (ii == 1)
                                    {
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.RenewalBase), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.RenewalForecast), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.NewForecast), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.OtherForecast), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.TotalForecast), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.Plan), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.ForecastvsPlanUSD), "number", 9);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.ForecastvsPlanPercentage), "number", 9);
                                        //ForHeader Value End Element
                                        xlWriter.WriteEndElement();
                                        //strHTML.AppendLine("</Row>");
                                        ii++;
                                        break;
                                    }
                                }
                            }
                            var ss = item.GroupBy(c => new { c.Division }).ToList();

                            foreach (var item1 in ss)
                            {
                                if (item1.Key.Division != null)
                                {
                                    xmlAttribute = new List<OpenXmlAttribute>();
                                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                    xlRowStartIndex++;
                                    ExcelEngine.WriteDataToExcel(xlWriter, item1.Key.Division, "string", 13);
                                    //strHTML.AppendLine("<Row>");
                                    //strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + item1.Key.Division + "</Data></Cell>");
                                    int kk = 1;
                                    foreach (var item55 in item1)
                                    {
                                        if (kk == 1)
                                        {
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.RenewalBase), "number", 10);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.RenewalForecast), "number", 10);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.NewForecast), "number", 10);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.OtherForecast), "number", 10);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.TotalForecast), "number", 10);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.Plan), "number", 10);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.ForecastvsPlanUSD), "number", 10);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.ForecastvsPlanPercentage), "number", 10);
                                            //ForHeader Value End Element
                                            xlWriter.WriteEndElement();
                                            //strHTML.AppendLine("</Row>");
                                            kk++;
                                        }
                                    }
                                }
                                var ss1 = item1.GroupBy(c => new { c.Unit }).ToList();

                                foreach (var item2 in ss1)
                                {
                                    if (item2.Key.Unit != null)
                                    {
                                        xmlAttribute = new List<OpenXmlAttribute>();
                                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                        xlRowStartIndex++;
                                        ExcelEngine.WriteDataToExcel(xlWriter, item2.Key.Unit, "string", 14);
                                        //strHTML.AppendLine("<Row>");
                                        //strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + item2.Key.Unit + "</Data></Cell>");
                                        int nn = 1;
                                        foreach (var item66 in item2)
                                        {
                                            if (nn == 1)
                                            {
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.RenewalBase), "number", 11);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.RenewalForecast), "number", 11);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.NewForecast), "number", 11);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.OtherForecast), "number", 11);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.TotalForecast), "number", 11);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.Plan), "number", 11);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.ForecastvsPlanUSD), "number", 11);
                                                ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item66.ForecastvsPlanPercentage), "number", 11);
                                                //ForHeader Value End Element
                                                xlWriter.WriteEndElement();
                                                //strHTML.AppendLine("</Row>");
                                                nn++;
                                            }
                                        }
                                    }
                                    var ss2 = item2.GroupBy(c => new { c.Segment }).ToList();
                                    foreach (var item5 in ss2)
                                    {
                                        if (item5.Key.Segment != null)
                                        {
                                            xmlAttribute = new List<OpenXmlAttribute>();
                                            xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                                            xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                            xlRowStartIndex++;
                                            ExcelEngine.WriteDataToExcel(xlWriter, item5.Key.Segment, "string", 15);
                                            //strHTML.AppendLine("<Row>");
                                            //strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + item5.Key.Segment + "</Data></Cell>");
                                            int jj = 1;
                                            foreach (var item77 in item5)
                                            {
                                                if (jj == 1)
                                                {
                                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.RenewalBase), "number", 12);
                                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.RenewalForecast), "number", 12);
                                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.NewForecast), "number", 12);
                                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.OtherForecast), "number", 12);
                                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.TotalForecast), "number", 12);
                                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.Plan), "number", 12);
                                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.ForecastvsPlanUSD), "number", 12);
                                                    ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item77.ForecastvsPlanPercentage), "number", 12);
                                                    //ForHeader Value End Element
                                                    xlWriter.WriteEndElement();
                                                    //strHTML.AppendLine("</Row>");
                                                    jj++;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        //To Write Blank Row.
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        xlRowStartIndex++;
                        ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                        //For row value end element
                        xlWriter.WriteEndElement();

                        //To Write Filter Rows header
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        xlRowStartIndex++;
                        ExcelEngine.WriteDataToExcel(xlWriter, "Selected Search Criteria", "string", 7);
                        //For row value end element
                        xlWriter.WriteEndElement();

                        //To Write Filter Rows
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        xlRowStartIndex++;

                        foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
                        {
                            List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                            string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                            if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                            {
                                if (!info.PropertyType.Name.Contains("List"))
                                {
                                    var value = info.GetValue(trackingReportingCommonFilterInputModel, null);
                                    var filter = info.Name + ":" + value + ";";
                                    if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "PageNumber" && info.Name != "PageSize")
                                    {
                                        ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                        //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                                    }
                                }
                                else
                                {
                                    if (!string.IsNullOrEmpty(listValue))
                                    {
                                        var filter = info.Name + ":" + listValue + ";";
                                        ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                        //strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                                    }
                                }
                            }
                        }
                        //For row value end element
                        xlWriter.WriteEndElement();

                        //For final end element
                        xlWriter.WriteStartElement(new Workbook());
                        xlWriter.WriteStartElement(new Worksheet());
                    }

                    //Create XL Workbook Part.
                    ExcelEngine.CreateXLWorkbookPart(xlDocument);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outputFilePath;
        }

        private StringBuilder SpreadSheetXMLGenerartorForecastDivision(List<ForecastByBusinessSegmentOutputModel> forecastByBusinessSegmentOutputModel, TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            StringBuilder strHTML = new StringBuilder();
            strHTML.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            strHTML.AppendLine("<?mso-application progid=\"Excel.Sheet\"?>");
            strHTML.AppendLine("<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:x=\"urn:schemas-microsoft-com:office:excel\" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:html=\"https://www.w3.org/TR/html401/\">");
            strHTML.AppendLine("<ss:Styles>");
            strHTML.AppendLine("<Style ss:ID=\"Default\" ss:Name=\"Normal\">");
            strHTML.AppendLine("<Alignment ss:Vertical=\"Bottom\"/>");
            strHTML.AppendLine("<Borders/>");
            strHTML.AppendLine("<Font ss:FontName=\"Calibri\" x:Family=\"Swiss\" ss:Size=\"11\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Interior/>");
            strHTML.AppendLine("<NumberFormat/>");
            strHTML.AppendLine("<Protection/>");
            strHTML.AppendLine("</Style>");
            strHTML.AppendLine("<Style ss:ID=\"s62\">");
            strHTML.AppendLine("<Alignment ss:Vertical=\"Bottom\"/>");
            strHTML.AppendLine("<Borders/>");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" ss:Bold=\"1\"/>");
            strHTML.AppendLine("<Interior/>");
            strHTML.AppendLine("<NumberFormat/>");
            strHTML.AppendLine("<Protection/>");
            strHTML.AppendLine("</Style>");
            strHTML.AppendLine("<Style ss:ID=\"s63\">");
            strHTML.AppendLine("<Alignment ss:Vertical=\"Bottom\"/>");
            strHTML.AppendLine("<Borders/>");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#FFFFFF\" ss:Bold=\"1\"/>");
            strHTML.AppendLine("<Interior ss:Color=\"#3980c6\" ss:Pattern=\"Solid\"/>"); /*Archana*/
            strHTML.AppendLine("<NumberFormat/>");
            strHTML.AppendLine("<Protection/>");
            strHTML.AppendLine("</Style>");
            strHTML.AppendLine("<Style ss:ID=\"s70\">");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#000000\" ss:FontColor=\"black\" ss:Bold=\"1\"/>");/*Archana*/
            strHTML.AppendLine("<Interior ss:Color=\"#8c8c8c\" ss:Pattern=\"Solid\"/>");/*Archana*/
            strHTML.AppendLine("<Alignment ss:Vertical=\"Top\" />");
            strHTML.AppendLine("<Borders>");
            strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("</Borders>");
            strHTML.AppendLine("</Style>");

            //----------------
            strHTML.AppendLine("<Style ss:ID=\"s77\">");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" ss:Bold=\"1\"/>");
            strHTML.AppendLine("</Style>");

            strHTML.AppendLine("<Style ss:ID=\"s78\">");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" ss:Size=\"10\" ss:Color=\"#0000FF\"/>");
            strHTML.AppendLine("</Style>");

            strHTML.AppendLine("<Style ss:ID=\"s79\">");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" ss:Size=\"10\" ss:Color=\"#000000\" ss:Bold=\"1\"/>");
            strHTML.AppendLine("</Style>");

            strHTML.AppendLine("<Style ss:ID=\"s80\">");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#000000\" ss:Bold=\"1\"/>");/*Archana*/
            strHTML.AppendLine("<Interior ss:Color=\"#FFFFFF\" ss:Pattern=\"Solid\"/>");/*Archana*/
            strHTML.AppendLine("<Alignment ss:Vertical=\"Top\" />");
            strHTML.AppendLine("<Borders>");
            strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("</Borders>");
            strHTML.AppendLine("</Style>");

            strHTML.AppendLine("<Style ss:ID=\"s76\">");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#000000\" ss:Bold=\"1\"/>");/*Archana*/
            strHTML.AppendLine("<Interior ss:Color=\"#CCCCCC\" ss:Pattern=\"Solid\"/>");/*Archana*/
            strHTML.AppendLine("<Alignment ss:Vertical=\"Top\" />");
            strHTML.AppendLine("<Borders>");
            strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("</Borders>");
            strHTML.AppendLine("</Style>");

            strHTML.AppendLine("<Style ss:ID=\"s82\">");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#000000\" ss:Bold=\"1\"/>");/*Archana*/
            strHTML.AppendLine("<Interior ss:Color=\"#A6A6A6\" ss:Pattern=\"Solid\"/>");/*Archana*/
            strHTML.AppendLine("<Alignment ss:Vertical=\"Top\" />");
            strHTML.AppendLine("<Borders>");
            strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("</Borders>");
            strHTML.AppendLine("</Style>");

            strHTML.AppendLine("<Style ss:ID=\"s84\">");
            strHTML.AppendLine("<Borders>");
            strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            strHTML.AppendLine("</Borders>");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" ss:Size=\"10\" ss:Color=\"#0000FF\"/>");
            strHTML.AppendLine("</Style>");

            //-------------------------
            strHTML.AppendLine("<Style ss:ID=\"s65\">");
            strHTML.AppendLine("<Borders>");
            strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            strHTML.AppendLine("</Borders>");
            strHTML.AppendLine("</Style>");
            strHTML.AppendLine("</ss:Styles>");
            strHTML.AppendLine("<Worksheet ss:Name=\"ForecastDivisionReport\">");
            strHTML.AppendLine("<Table>");
            strHTML.AppendLine("<Column ss:Index=\"1\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"2\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"3\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"4\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"5\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"6\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"7\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"8\" ss:AutoFitWidth=\"1\" ss:Width=\"100\"/>");
            strHTML.AppendLine("<Column ss:Index=\"9\" ss:AutoFitWidth=\"1\" ss:Width=\"100\"/>");
            strHTML.AppendLine("<Row ss:StyleID=\"s62\">");
            strHTML.AppendLine("<Cell><Data ss:Type=\"String\">Forecast Division Report</Data></Cell>");
            strHTML.AppendLine("</Row>");

            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s79\"><Data ss:Type=\"String\">All the figures listed below are in (USD)</Data></Cell>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");


            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Division</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Renewal Base (USD)</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Renewal Forecast (USD)</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">New Forecast (USD)</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Other Forecast (USD)</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Total Forecast (USD)</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Plan (USD)</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Forecast vs Plan (USD)</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Forecast Vs Plan %</Data></Cell>");
            strHTML.AppendLine("</Row>");


            var q = forecastByBusinessSegmentOutputModel.GroupBy(s => new { s.Company });

            foreach (var item in q)
            {
                if (item.Key.Company != null)
                {

                    //strHTML.AppendLine("<tr>");
                    //strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item.Key.Company + "</font></td>");
                    strHTML.AppendLine("<Row>");
                    strHTML.AppendLine("<Cell  ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + item.Key.Company + "</Data></Cell>");
                    int ii = 1;
                    foreach (var item44 in item)
                    {

                        if (ii == 1)
                        {

                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.RenewalBase) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.RenewalForecast) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.NewForecast) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.OtherForecast) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.TotalForecast) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.Plan) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.ForecastvsPlanUSD) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.ForecastvsPlanPercentage) + "</Data></Cell>");
                            strHTML.AppendLine("</Row>");
                            ii++;


                        }
                    }

                }
                var ss = item.GroupBy(c => new { c.Division }).ToList();

                foreach (var item1 in ss)
                {
                    if (item1.Key.Division != null)
                    {
                        //strHTML.AppendLine("<tr>");
                        //strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item1.Key.Division + "</font></td>");
                        strHTML.AppendLine("<Row>");
                        strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + item1.Key.Division + "</Data></Cell>");
                        int kk = 1;
                        foreach (var item55 in item1)
                        {

                            if (kk == 1)
                            {

                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.RenewalBase) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.RenewalForecast) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.NewForecast) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.OtherForecast) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.TotalForecast) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.Plan) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.ForecastvsPlanUSD) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.ForecastvsPlanPercentage) + "</Data></Cell>");
                                strHTML.AppendLine("</Row>");
                                kk++;

                            }
                        }

                    }
                    var ss1 = item1.GroupBy(c => new { c.Unit }).ToList();

                    foreach (var item2 in ss1)

                    {
                        if (item2.Key.Unit != null)
                        {
                            //strHTML.AppendLine("<tr>");
                            //strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item2.Key.Unit + "</font></td>");
                            strHTML.AppendLine("<Row>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + item2.Key.Unit + "</Data></Cell>");
                            int nn = 1;
                            foreach (var item66 in item2)
                            {
                                if (nn == 1)
                                {
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.RenewalBase) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.RenewalForecast) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.NewForecast) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.OtherForecast) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.TotalForecast) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.Plan) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.ForecastvsPlanUSD) + "</Data></Cell>");
                                    strHTML.AppendLine("<Cell ss:StyleID=\"s76\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item66.ForecastvsPlanPercentage) + "</Data></Cell>");
                                    strHTML.AppendLine("</Row>");
                                    nn++;
                                }
                            }

                        }
                        var ss2 = item2.GroupBy(c => new { c.Segment }).ToList();
                        foreach (var item5 in ss2)
                        {
                            if (item5.Key.Segment != null)
                            {
                                //strHTML.AppendLine("<tr>");

                                //strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item5.Key.Segment + "</font></td>");
                                strHTML.AppendLine("<Row>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + item5.Key.Segment + "</Data></Cell>");
                                int jj = 1;
                                foreach (var item77 in item5)
                                {

                                    if (jj == 1)
                                    {

                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.RenewalBase) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.RenewalForecast) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.NewForecast) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.OtherForecast) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.TotalForecast) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.Plan) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.ForecastvsPlanUSD) + "</Data></Cell>");
                                        strHTML.AppendLine("<Cell ss:StyleID=\"s80\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item77.ForecastvsPlanPercentage) + "</Data></Cell>");
                                        strHTML.AppendLine("</Row>");
                                        jj++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            int ICount = 0;
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">Selected Search Criteria</Data></Cell>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
            {
                List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                {
                    if (!info.PropertyType.Name.Contains("List"))
                    {
                        var value = info.GetValue(trackingReportingCommonFilterInputModel, null);
                        var filter = info.Name + ":" + value + ";";
                        if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "PageNumber" && info.Name != "PageSize")
                        {
                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                strHTML.AppendLine("</Row>");
                                strHTML.AppendLine("<Row>");
                            }
                            strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                        }

                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(listValue))
                        {
                            var filter = info.Name + ":" + listValue + ";";

                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                strHTML.AppendLine("</Row>");
                                strHTML.AppendLine("<Row>");
                            }

                            //strHTML.AppendLine("<td colspan=1><font color='#0000FF' >" + filter + "</font></td>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");


                        }
                    }

                }

            }
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("</Table><WorksheetOptions xmlns=\"urn:schemas-microsoft-com:office:excel\"><DoNotDisplayGridlines/></WorksheetOptions></Worksheet></Workbook>");
            return strHTML;
        }

        private string SpreadSheetXLSXGenerartorForecastRegion(List<ForecastRegionDataOutputModel> lGetForecastRegionTotal, TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                string[] xlWidthCollection = { "30", "30", "30", "30", "30", "30", "30", "30", "30" };
                int xlRowStartIndex = 1;
                UInt32Value sheeIdValue = 1;
                outputFilePath = ExcelEngine.GetXLOutputPath("Forecast Region", trackingReportingCommonFilterInputModel.UserID);
                using (SpreadsheetDocument xlDocument = SpreadsheetDocument.Create(outputFilePath, SpreadsheetDocumentType.Workbook))
                {
                    //Create new xl worksheet part and new sheet
                    WorksheetPart xlWorksheetPart = ExcelEngine.CreateXLWorksheetPartAndSheets(xlDocument, sheeIdValue, "Forecast Region");

                    using (var xlWriter = OpenXmlWriter.Create(xlWorksheetPart))
                    {
                        List<OpenXmlAttribute> xmlAttribute = null;
                        xlWriter.WriteStartElement(new Worksheet());
                        //Set Column Width 
                        //Freeze header of report
                        ExcelEngine.SetHeaderRowFrozen(xlWriter, trackingReportingCommonFilterInputModel.ReportName);
                        ExcelEngine.SetXLColumnWidth(xmlAttribute, xlWriter, xlWidthCollection);
                        xlWriter.WriteStartElement(new SheetData());

                        //For Download Report Header Row XML Attribute
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, xlRowStartIndex.ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        xlRowStartIndex++;
                        //Download Report Header - Write XL Header Text
                        ExcelEngine.WriteDataToExcel(xlWriter, "Forecast Region Report: All the figures listed below are in (USD)", "string", 5);
                        //For Download Report Header Value End Element
                        xlWriter.WriteEndElement();

                        //To Write Blank Row.
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        xlRowStartIndex++;
                        ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                        //For row value end element
                        xlWriter.WriteEndElement();

                        //For XL Header XML Attribute
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        xlRowStartIndex++;
                        ExcelEngine.WriteDataToExcel(xlWriter, "Credited Branch/Region", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Renewal Base (USD)", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Renewal Forecast (USD)", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "New Forecast (USD)", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Other Forecast (USD)", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Total Forecast (USD)", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Plan (USD)", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Forecast vs Plan (USD)", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Forecast Vs Plan %", "string", 1);
                        //ForHeader Value End Element
                        xlWriter.WriteEndElement();

                        //To Write XL Rows
                        var q = lGetForecastRegionTotal.GroupBy(s => new { s.CreditedRegion });

                        foreach (var item in q)
                        {
                            if (item.Key.CreditedRegion != null)
                            {
                                xmlAttribute = new List<OpenXmlAttribute>();
                                xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                                xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                xlRowStartIndex++;
                                ExcelEngine.WriteDataToExcel(xlWriter, item.Key.CreditedRegion, "string", 14);
                                int ii = 1;
                                foreach (var item44 in item)
                                {

                                    if (ii == 1)
                                    {
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.RenewalBase), "number", 11);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.RenewalForecast), "number", 11);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.NewForecast), "number", 11);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.OtherForecast), "number", 11);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.TotalForecast), "number", 11);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.Plan), "number", 11);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.ForecastvsPlanUSD), "number", 11);
                                        ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item44.ForecastvsPlanPercentage), "number", 11);
                                        //ForHeader Value End Element
                                        xlWriter.WriteEndElement();
                                        ii++;
                                        break;
                                    }
                                }

                            }
                            var ss = item.GroupBy(c => new { c.CreditedBranch }).ToList();

                            foreach (var item1 in ss)
                            {
                                if (item1.Key.CreditedBranch != null)
                                {
                                    xmlAttribute = new List<OpenXmlAttribute>();
                                    xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                                    xlWriter.WriteStartElement(new Row(), xmlAttribute);
                                    xlRowStartIndex++;
                                    ExcelEngine.WriteDataToExcel(xlWriter, item1.Key.CreditedBranch, "string", 15);
                                    int kk = 1;
                                    foreach (var item55 in item1)
                                    {

                                        if (kk == 1)
                                        {
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.RenewalBase), "number", 12);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.RenewalForecast), "number", 12);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.NewForecast), "number", 12);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.OtherForecast), "number", 12);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.TotalForecast), "number", 12);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.Plan), "number", 12);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.ForecastvsPlanUSD), "number", 12);
                                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item55.ForecastvsPlanPercentage), "number", 12);
                                            //ForHeader Value End Element
                                            xlWriter.WriteEndElement();
                                            kk++;
                                            break;
                                        }
                                    }
                                }
                            }
                        }


                        //To Write Blank Row.
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        xlRowStartIndex++;
                        ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                        //For row value end element
                        xlWriter.WriteEndElement();

                        //To Write Filter Rows header
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        xlRowStartIndex++;
                        ExcelEngine.WriteDataToExcel(xlWriter, "Selected Search Criteria", "string", 7);
                        //For row value end element
                        xlWriter.WriteEndElement();

                        //To Write Filter Rows
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        xlRowStartIndex++;
                        foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
                        {
                            List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                            string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                            if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                            {
                                if (!info.PropertyType.Name.Contains("List"))
                                {
                                    var value = info.GetValue(trackingReportingCommonFilterInputModel, null);
                                    var filter = info.Name + ":" + value + ";";
                                    if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "PageNumber" && info.Name != "PageSize")
                                    {
                                        ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    }
                                }
                                else
                                {
                                    if (!string.IsNullOrEmpty(listValue))
                                    {
                                        var filter = info.Name + ":" + listValue + ";";
                                        ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    }
                                }
                            }
                        }
                        //For row value end element
                        xlWriter.WriteEndElement();

                        //For final end element
                        xlWriter.WriteStartElement(new Workbook());
                        xlWriter.WriteStartElement(new Worksheet());
                    }

                    //Create XL Workbook Part.
                    ExcelEngine.CreateXLWorkbookPart(xlDocument);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outputFilePath;
        }

        private StringBuilder SpreadSheetXMLGenerartorForecastRegion(List<ForecastRegionDataOutputModel> lGetForecastRegionTotal, TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            StringBuilder strHTML = new StringBuilder();
            strHTML.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            strHTML.AppendLine("<?mso-application progid=\"Excel.Sheet\"?>");
            strHTML.AppendLine("<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:x=\"urn:schemas-microsoft-com:office:excel\" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:html=\"https://www.w3.org/TR/html401/\">");
            strHTML.AppendLine("<ss:Styles>");
            strHTML.AppendLine("<Style ss:ID=\"Default\" ss:Name=\"Normal\">");
            strHTML.AppendLine("<Alignment ss:Vertical=\"Bottom\"/>");
            strHTML.AppendLine("<Borders/>");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Size=\"9\" ss:Color=\"#000000\"/>");  /*Archana*/
            strHTML.AppendLine("<Interior/>");
            strHTML.AppendLine("<NumberFormat/>");
            strHTML.AppendLine("<Protection/>");
            strHTML.AppendLine("</Style>");
            strHTML.AppendLine("<Style ss:ID=\"s62\">");
            strHTML.AppendLine("<Alignment ss:Vertical=\"Bottom\"/>");
            strHTML.AppendLine("<Borders/>");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" ss:Bold=\"1\"/>");
            strHTML.AppendLine("<Interior/>");
            strHTML.AppendLine("<NumberFormat/>");
            strHTML.AppendLine("<Protection/>");
            strHTML.AppendLine("</Style>");
            strHTML.AppendLine("<Style ss:ID=\"s63\">");
            strHTML.AppendLine("<Alignment ss:Vertical=\"Bottom\"/>");
            strHTML.AppendLine("<Borders/>");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#FFFFFF\" ss:Bold=\"1\"/>");
            strHTML.AppendLine("<Interior ss:Color=\"#3980c6\" ss:Pattern=\"Solid\"/>"); /*Archana*/
            strHTML.AppendLine("<NumberFormat/>");
            strHTML.AppendLine("<Protection/>");
            strHTML.AppendLine("</Style>");
            //------------
            strHTML.AppendLine("<Style ss:ID=\"s70\">");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#000000\" ss:FontColor=\"black\" ss:Bold=\"1\"/>");/*Archana*/
            strHTML.AppendLine("<Interior ss:Color=\"#8c8c8c\" ss:Pattern=\"Solid\"/>");/*Archana*/
            strHTML.AppendLine("<Alignment ss:Vertical=\"Top\" />");
            strHTML.AppendLine("<Borders>");
            strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("</Borders>");
            strHTML.AppendLine("</Style>");
            //----------------
            strHTML.AppendLine("<Style ss:ID=\"s77\">");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" ss:Bold=\"1\"/>");
            strHTML.AppendLine("</Style>");

            strHTML.AppendLine("<Style ss:ID=\"s78\">");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" ss:Size=\"10\" ss:Color=\"#0000FF\"/>");
            strHTML.AppendLine("</Style>");

            strHTML.AppendLine("<Style ss:ID=\"s79\">");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" ss:Size=\"10\" ss:Color=\"#000000\" ss:Bold=\"1\"/>");
            strHTML.AppendLine("</Style>");

            strHTML.AppendLine("<Style ss:ID=\"s84\">");
            strHTML.AppendLine("<Borders>");
            strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            strHTML.AppendLine("</Borders>");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" ss:Size=\"10\" ss:Color=\"#0000FF\"/>");
            strHTML.AppendLine("</Style>");


            strHTML.AppendLine("<Style ss:ID=\"s82\">");

            strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#000000\" ss:FontColor=\"black\" ss:Bold=\"1\"/>");/*Archana*/
            strHTML.AppendLine("<Interior ss:Color=\"#CCCCCC\" ss:Pattern=\"Solid\"/>");/*Archana*/

            strHTML.AppendLine("<Borders>");
            strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("</Borders>");
            strHTML.AppendLine("</Style>");



            //-------------------------
            strHTML.AppendLine("<Style ss:ID=\"s65\">");
            strHTML.AppendLine("<Borders>");
            strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            strHTML.AppendLine("</Borders>");
            strHTML.AppendLine("</Style>");
            strHTML.AppendLine("</ss:Styles>");
            strHTML.AppendLine("<Worksheet ss:Name=\"ForecastRegionReport\">");
            strHTML.AppendLine("<Table>");
            strHTML.AppendLine("<Column ss:Index=\"1\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"2\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"3\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"4\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"5\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"6\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"7\" ss:AutoFitWidth=\"1\" ss:Width=\"150\"/>");
            strHTML.AppendLine("<Column ss:Index=\"8\" ss:AutoFitWidth=\"1\" ss:Width=\"100\"/>");
            strHTML.AppendLine("<Column ss:Index=\"9\" ss:AutoFitWidth=\"1\" ss:Width=\"100\"/>");
            strHTML.AppendLine("<Row ss:StyleID=\"s62\">");
            strHTML.AppendLine("<Cell><Data ss:Type=\"String\">Forecast Region Report</Data></Cell>");
            strHTML.AppendLine("</Row>");

            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s79\"><Data ss:Type=\"String\">All the figures listed below are in (USD)</Data></Cell>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");

            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Credited Branch/Region</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Renewal Base (USD)</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Renewal Forecast (USD)</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">New Forecast (USD)</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Other Forecast (USD)</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Total Forecast (USD)</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Plan (USD)</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Forecast vs Plan (USD)</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Forecast Vs Plan %</Data></Cell>");
            strHTML.AppendLine("</Row>");


            var q = lGetForecastRegionTotal.GroupBy(s => new { s.CreditedRegion });

            foreach (var item in q)
            {
                if (item.Key.CreditedRegion != null)
                {
                    strHTML.AppendLine("<Row>");
                    strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + item.Key.CreditedRegion + "</Data></Cell>");
                    int ii = 1;
                    foreach (var item44 in item)
                    {

                        if (ii == 1)
                        {
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.RenewalBase) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.RenewalForecast) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.NewForecast) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.OtherForecast) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.TotalForecast) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.Plan) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.ForecastvsPlanUSD) + "</Data></Cell>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s70\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item44.ForecastvsPlanPercentage) + "</Data></Cell>");
                            strHTML.AppendLine("</Row>");
                            ii++;


                        }
                    }

                }
                var ss = item.GroupBy(c => new { c.CreditedBranch }).ToList();

                foreach (var item1 in ss)
                {
                    if (item1.Key.CreditedBranch != null)
                    {
                        strHTML.AppendLine("<Row>");
                        strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + item1.Key.CreditedBranch + "</Data></Cell>");
                        int kk = 1;
                        foreach (var item55 in item1)
                        {

                            if (kk == 1)
                            {
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.RenewalBase) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.RenewalForecast) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.NewForecast) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.OtherForecast) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.TotalForecast) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.Plan) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.ForecastvsPlanUSD) + "</Data></Cell>");
                                strHTML.AppendLine("<Cell ss:StyleID=\"s82\"><Data ss:Type=\"String\">" + String.Format("{0:n0}", item55.ForecastvsPlanPercentage) + "</Data></Cell>");
                                strHTML.AppendLine("</Row>");
                                kk++;

                            }
                        }

                    }
                }
            }


            int ICount = 0;
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">Selected Search Criteria</Data></Cell>");
            strHTML.AppendLine("</Row>");

            strHTML.AppendLine("<Row>");
            foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
            {
                List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                {
                    if (!info.PropertyType.Name.Contains("List"))
                    {
                        var value = info.GetValue(trackingReportingCommonFilterInputModel, null);
                        var filter = info.Name + ":" + value + ";";
                        if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "PageNumber" && info.Name != "PageSize")
                        {
                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                strHTML.AppendLine("</Row>");
                                strHTML.AppendLine("<Row>");
                            }
                            strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                        }

                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(listValue))
                        {
                            var filter = info.Name + ":" + listValue + ";";

                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                strHTML.AppendLine("</Row>");
                                strHTML.AppendLine("<Row>");
                            }

                            //strHTML.AppendLine("<td colspan=1><font color='#0000FF' >" + filter + "</font></td>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");


                        }
                    }

                }

            }
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("</Table><WorksheetOptions xmlns=\"urn:schemas-microsoft-com:office:excel\"><DoNotDisplayGridlines/></WorksheetOptions></Worksheet></Workbook>");
            return strHTML;
        }
        #endregion

        public List<string> ProducerProfileDownload(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)

        {
            List<UWSummaryTotalforecasteoutputModel> UWSummaryTotalForecastTotal = new List<UWSummaryTotalforecasteoutputModel>();

            StringBuilder strHTML = new StringBuilder();
            StringBuilder strHTML1 = new StringBuilder();
            StringBuilder strHTML2 = new StringBuilder();

            List<UWSummaryNewBusinessoutputModel> forecastByBusinessSegmentOutputModel = new List<UWSummaryNewBusinessoutputModel>();
            List<ForecastRegionDataOutputModel> lGetForecastRegionTotal = new List<ForecastRegionDataOutputModel>();
            List<ProducerReportOuputModel> producerReport = new List<ProducerReportOuputModel>();
            List<DetailReport> detailReport = new List<DetailReport>();

            List<string> workingList = new List<string>();

            forecastByBusinessSegmentOutputModel = _trackerReportingRepository.GetUWSummaryNewBusinessTotal(trackingReportingCommonFilterInputModel);
            DataTable dt = new DataTable();
            strHTML.AppendLine("<center><span  style='font-family: Arial; font-size: 13.5pt;'>UWSummary NewBusinessTotal Report</b></span></center><br/><br/>");
            strHTML.AppendLine("<p align= 'left' style='font-family: Arial; font-size: 10pt; text-align:left'><b>All the figures listed below are in (USD)</b></p>");


            strHTML.AppendLine("<table border=1 ID='Table1'>");


            int i;
            for (i = 0; i < 1; i++)
            {
                strHTML.AppendLine("<tr>");

                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font  color='white'>" + "Division" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "CYTDTotalForecastNewBusiness" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "PYTDTotalForecastNewBusiness" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black'  valign=top><font color='white'>" + "CYTDTotalBound" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "CYTDTotalSubmission" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "PYTDTotalSubmission" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "CYTDTotalTargetNotSubmitted" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "CYTDTotalQuote" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "CYTDTotalQuoteRejects" + "</font></th>");
                strHTML.AppendLine("</tr>");

            }

            var q = forecastByBusinessSegmentOutputModel.GroupBy(s => new { s.Company });

            foreach (var item in q)
            {
                if (item.Key.Company != null)
                {

                    strHTML.AppendLine("<tr>");
                    strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item.Key.Company + "</font></td>");
                    int ii = 1;
                    foreach (var item44 in item)
                    {

                        if (ii == 1)
                        {

                            strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.CYTDTotalForecastNewBusiness + "</font></td>");
                            strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.PYTDTotalForecastNewBusiness + "</font></td>");

                            strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.CYTDTotalBound + "</font></td>");
                            strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.CYTDTotalSubmission + "</font></td>");
                            strHTML.AppendLine("<td colspan=1  bgcolor='#ff8000'  valign=top><font color='black'>" + item44.PYTDTotalSubmission + "</font></td>");
                            strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.CYTDTotalTargetNotSubmitted + "</font></td>");
                            strHTML.AppendLine("<td colspan=1  bgcolor='#ff8000' valign=top><font color='black'>" + item44.CYTDTotalQuote + "</font></td>");
                            strHTML.AppendLine("<td colspan=1  bgcolor='#ff8000' valign=top><font color='black'>" + item44.CYTDTotalQuoteRejects + "</font></td>");
                            strHTML.AppendLine("</tr>");
                            ii++;
                        }
                    }

                }
                var ss = item.GroupBy(c => new { c.Division }).ToList();

                foreach (var item1 in ss)
                {
                    if (item1.Key.Division != null)
                    {
                        strHTML.AppendLine("<tr>");
                        strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item1.Key.Division + "</font></td>");
                        int kk = 1;
                        foreach (var item55 in item1)
                        {

                            if (kk == 1)
                            {
                                strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.CYTDTotalForecastNewBusiness + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.PYTDTotalForecastNewBusiness + "</font></td>");

                                strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.CYTDTotalBound + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.CYTDTotalSubmission + "</font></td>");
                                strHTML.AppendLine("<td colspan=1    valign=top><font color='black'>" + item55.PYTDTotalSubmission + "</font></td>");
                                strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item55.CYTDTotalTargetNotSubmitted + "</font></td>");
                                strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item55.CYTDTotalQuote + "</font></td>");
                                strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item55.CYTDTotalQuoteRejects + "</font></td>");
                                strHTML.AppendLine("</tr>");
                                kk++;
                            }
                        }

                    }
                    var ss1 = item1.GroupBy(c => new { c.Unit }).ToList();

                    foreach (var item2 in ss1)

                    {
                        if (item2.Key.Unit != null)
                        {
                            strHTML.AppendLine("<tr>");
                            strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item2.Key.Unit + "</font></td>");
                            int nn = 1;
                            foreach (var item66 in item2)
                            {


                                if (nn == 1)
                                {

                                    strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.CYTDTotalForecastNewBusiness + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.PYTDTotalForecastNewBusiness + "</font></td>");

                                    strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.CYTDTotalBound + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.CYTDTotalSubmission + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1    valign=top><font color='black'>" + item66.PYTDTotalSubmission + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item66.CYTDTotalTargetNotSubmitted + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item66.CYTDTotalQuote + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item66.CYTDTotalQuoteRejects + "</font></td>");
                                    strHTML.AppendLine("</tr>");
                                    nn++;
                                }
                            }

                        }
                        var ss2 = item2.GroupBy(c => new { c.Segment }).ToList();
                        foreach (var item5 in ss2)
                        {
                            if (item5.Key.Segment != null)
                            {
                                strHTML.AppendLine("<tr>");

                                strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item5.Key.Segment + "</font></td>");
                                int jj = 1;
                                foreach (var item77 in item5)
                                {

                                    if (jj == 1)
                                    {
                                        strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.CYTDTotalForecastNewBusiness + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.PYTDTotalForecastNewBusiness + "</font></td>");

                                        strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.CYTDTotalBound + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.CYTDTotalSubmission + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1    valign=top><font color='black'>" + item77.PYTDTotalSubmission + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item77.CYTDTotalTargetNotSubmitted + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item77.CYTDTotalQuote + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item77.CYTDTotalQuoteRejects + "</font></td>");
                                        strHTML.AppendLine("</tr>");
                                        jj++;
                                    }
                                }
                            }
                        }
                    }
                }
            }


            strHTML.AppendLine("</table>");




            strHTML.Append("<table cellspacing=1 cellpadding=1 border=1 ID='Table2'>");
            strHTML.AppendLine("<tr><td colspan=5 align=center><font color='#000000' size=3><b>Selected Search Criteria</b></font></td></tr>");
            strHTML.AppendLine("<tr>");
            int ICount = 0;

            foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
            {
                List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                {
                    if (!info.PropertyType.Name.Contains("List"))
                    {
                        var value = info.GetValue(trackingReportingCommonFilterInputModel, null);

                        var filter = info.Name + ":" + value + ";";
                        if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "FilterBy" && info.Name != "GroupBy" && info.Name != "PageNumber" && info.Name != "PageSize" && info.Name != "ScreenName")
                        {
                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                strHTML.AppendLine("</tr><tr>");
                            }
                            strHTML.AppendLine("<td colspan=1 valign=top><font color='#0000FF'>" + filter + "</font></td>");
                        }

                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(listValue))
                        {
                            var filter = info.Name + ":" + listValue + ";";

                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                strHTML.AppendLine("</tr><tr>");
                            }
                            strHTML.AppendLine("<td colspan=1 valign=top><font color='#0000FF'>" + filter + "</font></td>");
                        }
                    }

                }

            }

            if (ICount % 4 != 0)
            {
                strHTML.AppendLine("</tr");
            }
            strHTML.AppendLine("</table>");


            List<UWSummaryRenewaloutputModel> GetUWSummaryRenewalTotal = new List<UWSummaryRenewaloutputModel>();


            GetUWSummaryRenewalTotal = _trackerReportingRepository.GetUWSummaryRenewalTotal(trackingReportingCommonFilterInputModel);
            DataTable dtt = new DataTable();
            strHTML1.AppendLine("<center><span  style='font-family: Arial; font-size: 13.5pt;'>Forecast Division Report</b></span></center><br/><br/>");
            strHTML1.AppendLine("<p align= 'left' style='font-family: Arial; font-size: 10pt; text-align:left'><b>All the figures listed below are in (USD)</b></p>");


            strHTML1.AppendLine("<table border=1 ID='Table3'>");


            int iii;
            for (iii = 0; iii < 1; iii++)
            {
                strHTML1.AppendLine("<tr>");

                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font  color='white'>" + "Division" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "RenewalCYTD" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "RenewalYearOverYearChange" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black'  valign=top><font color='white'>" + "LostCYTD" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "PendingCYTD" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "PendingPYTD" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "QuotedCYTD" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "BoundCYTD" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "BoundPYTD" + "</font></th>");
                strHTML1.AppendLine("</tr>");

            }

            var qq = GetUWSummaryRenewalTotal.GroupBy(s => new { s.Company });

            foreach (var item in qq)
            {
                if (item.Key.Company != null)
                {

                    strHTML1.AppendLine("<tr>");
                    strHTML1.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item.Key.Company + "</font></td>");
                    int ii = 1;
                    foreach (var item44 in item)
                    {

                        if (ii == 1)
                        {

                            strHTML1.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.RenewalCYTD + "</font></td>");
                            strHTML1.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.RenewalYearOverYearChange + "</font></td>");

                            strHTML1.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.LostCYTD + "</font></td>");
                            strHTML1.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.PendingCYTD + "</font></td>");
                            strHTML1.AppendLine("<td colspan=1  bgcolor='#ff8000'  valign=top><font color='black'>" + item44.PendingPYTD + "</font></td>");
                            strHTML1.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.QuotedCYTD + "</font></td>");
                            strHTML1.AppendLine("<td colspan=1  bgcolor='#ff8000' valign=top><font color='black'>" + item44.BoundCYTD + "</font></td>");
                            strHTML1.AppendLine("<td colspan=1  bgcolor='#ff8000' valign=top><font color='black'>" + item44.BoundPYTD + "</font></td>");
                            strHTML1.AppendLine("</tr>");
                            ii++;
                        }
                    }

                }
                var ss = item.GroupBy(c => new { c.Division }).ToList();

                foreach (var item1 in ss)
                {
                    if (item1.Key.Division != null)
                    {
                        strHTML1.AppendLine("<tr>");
                        strHTML1.AppendLine("<td colspan=1 valign=top><font color='black'>" + item1.Key.Division + "</font></td>");
                        int kk = 1;
                        foreach (var item55 in item1)
                        {

                            if (kk == 1)
                            {
                                strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.RenewalCYTD + "</font></td>");
                                strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.RenewalYearOverYearChange + "</font></td>");

                                strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.LostCYTD + "</font></td>");
                                strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.PendingCYTD + "</font></td>");
                                strHTML1.AppendLine("<td colspan=1    valign=top><font color='black'>" + item55.PendingPYTD + "</font></td>");
                                strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item55.QuotedCYTD + "</font></td>");
                                strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item55.BoundCYTD + "</font></td>");
                                strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item55.BoundPYTD + "</font></td>");
                                strHTML1.AppendLine("</tr>");
                                kk++;
                            }
                        }

                    }
                    var ss1 = item1.GroupBy(c => new { c.Unit }).ToList();

                    foreach (var item2 in ss1)

                    {
                        if (item2.Key.Unit != null)
                        {
                            strHTML1.AppendLine("<tr>");
                            strHTML1.AppendLine("<td colspan=1 valign=top><font color='black'>" + item2.Key.Unit + "</font></td>");
                            int nn = 1;
                            foreach (var item66 in item2)
                            {


                                if (nn == 1)
                                {

                                    strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.RenewalCYTD + "</font></td>");
                                    strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.RenewalYearOverYearChange + "</font></td>");

                                    strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.LostCYTD + "</font></td>");
                                    strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.PendingCYTD + "</font></td>");
                                    strHTML1.AppendLine("<td colspan=1    valign=top><font color='black'>" + item66.PendingPYTD + "</font></td>");
                                    strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item66.QuotedCYTD + "</font></td>");
                                    strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item66.BoundCYTD + "</font></td>");
                                    strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item66.BoundPYTD + "</font></td>");
                                    strHTML1.AppendLine("</tr>");
                                    nn++;
                                }
                            }

                        }
                        var ss2 = item2.GroupBy(c => new { c.Segment }).ToList();
                        foreach (var item5 in ss2)
                        {
                            if (item5.Key.Segment != null)
                            {
                                strHTML1.AppendLine("<tr>");

                                strHTML1.AppendLine("<td colspan=1 valign=top><font color='black'>" + item5.Key.Segment + "</font></td>");
                                int jj = 1;
                                foreach (var item77 in item5)
                                {

                                    if (jj == 1)
                                    {
                                        strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.RenewalCYTD + "</font></td>");
                                        strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.RenewalYearOverYearChange + "</font></td>");

                                        strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.LostCYTD + "</font></td>");
                                        strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.PendingCYTD + "</font></td>");
                                        strHTML1.AppendLine("<td colspan=1    valign=top><font color='black'>" + item77.PendingPYTD + "</font></td>");
                                        strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item77.QuotedCYTD + "</font></td>");
                                        strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item77.BoundCYTD + "</font></td>");
                                        strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item77.BoundPYTD + "</font></td>");
                                        strHTML1.AppendLine("</tr>");
                                        jj++;
                                    }
                                }
                            }
                        }
                    }
                }
            }


            strHTML1.AppendLine("</table>");




            strHTML1.Append("<table cellspacing=1 cellpadding=1 border=1 ID='Table5'>");
            strHTML1.AppendLine("<tr><td colspan=5 align=center><font color='#000000' size=3><b>Selected Search Criteria</b></font></td></tr>");
            strHTML1.AppendLine("<tr>");
            int ICount1 = 0;

            foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
            {
                List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                {
                    if (!info.PropertyType.Name.Contains("List"))
                    {
                        var value = info.GetValue(trackingReportingCommonFilterInputModel, null);

                        var filter = info.Name + ":" + value + ";";
                        if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "FilterBy" && info.Name != "GroupBy" && info.Name != "PageNumber" && info.Name != "PageSize" && info.Name != "ScreenName")
                        {
                            if (ICount1 > 1 && ICount1 % 4 == 0)
                            {
                                strHTML1.AppendLine("</tr><tr>");
                            }
                            strHTML1.AppendLine("<td colspan=1 valign=top><font color='#0000FF'>" + filter + "</font></td>");
                        }

                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(listValue))
                        {
                            var filter = info.Name + ":" + listValue + ";";

                            if (ICount1 > 1 && ICount1 % 4 == 0)
                            {
                                strHTML1.AppendLine("</tr><tr>");
                            }
                            strHTML1.AppendLine("<td colspan=1 valign=top><font color='#0000FF'>" + filter + "</font></td>");
                        }
                    }

                }

            }

            if (ICount1 % 4 != 0)
            {
                strHTML1.AppendLine("</tr");
            }
            strHTML1.AppendLine("</table>");

            UWSummaryTotalForecastTotal = _trackerReportingRepository.GetUWSummaryTotalForecastTotal(trackingReportingCommonFilterInputModel);
            //GetUWSummaryRenewalTotal = _trackerReportingRepository.GetUWSummaryRenewalTotal(trackingReportingCommonFilterInputModel);
            // dtt = new DataTable();
            strHTML2.AppendLine("<center><span  style='font-family: Arial; font-size: 13.5pt;'>UWSummary Total ForecastTotal Report</b></span></center><br/><br/>");
            strHTML2.AppendLine("<p align= 'left' style='font-family: Arial; font-size: 10pt; text-align:left'><b>All the figures listed below are in (USD)</b></p>");


            strHTML2.AppendLine("<table border=1 ID='Table6'>");


            int columnCount;
            for (columnCount = 0; columnCount < 1; columnCount++)
            {
                strHTML2.AppendLine("<tr>");

                strHTML2.AppendLine("<th colspan=1 bgcolor='black' valign=top><font  color='white'>" + "Division" + "</font></th>");
                strHTML2.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "GWFCYTD" + "</font></th>");
                strHTML2.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "GWFPYTD" + "</font></th>");
                strHTML2.AppendLine("<th colspan=1 bgcolor='black'  valign=top><font color='white'>" + "GrowthCY" + "</font></th>");

                strHTML2.AppendLine("</tr>");

            }

            var UwSummaryTotal = UWSummaryTotalForecastTotal.GroupBy(s => new { s.Company });

            foreach (var item in UwSummaryTotal)
            {
                if (item.Key.Company != null)
                {

                    strHTML2.AppendLine("<tr>");
                    strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item.Key.Company + "</font></td>");
                    int ii = 1;
                    foreach (var item44 in item)
                    {

                        if (ii == 1)
                        {

                            strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.GWFCYTD + "</font></td>");
                            strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.GWFPYTD + "</font></td>");

                            strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.GrowthCY + "</font></td>");

                            strHTML2.AppendLine("</tr>");
                            ii++;
                        }
                    }

                }
                var ss = item.GroupBy(c => new { c.Division }).ToList();

                foreach (var item1 in ss)
                {
                    if (item1.Key.Division != null)
                    {
                        strHTML2.AppendLine("<tr>");
                        strHTML2.AppendLine("<td colspan=1 valign=top><font color='black'>" + item1.Key.Division + "</font></td>");
                        int kk = 1;
                        foreach (var item55 in item1)
                        {

                            if (kk == 1)
                            {
                                strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.GWFCYTD + "</font></td>");
                                strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.GWFPYTD + "</font></td>");

                                strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.GrowthCY + "</font></td>");

                                strHTML2.AppendLine("</tr>");
                                kk++;
                            }
                        }

                    }
                    var ss1 = item1.GroupBy(c => new { c.Unit }).ToList();

                    foreach (var item2 in ss1)

                    {
                        if (item2.Key.Unit != null)
                        {
                            strHTML2.AppendLine("<tr>");
                            strHTML2.AppendLine("<td colspan=1 valign=top><font color='black'>" + item2.Key.Unit + "</font></td>");
                            int nn = 1;
                            foreach (var item66 in item2)
                            {


                                if (nn == 1)
                                {

                                    strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.GWFCYTD + "</font></td>");
                                    strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.GWFPYTD + "</font></td>");

                                    strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.GrowthCY + "</font></td>");

                                    strHTML2.AppendLine("</tr>");
                                    nn++;
                                }
                            }

                        }
                        var ss2 = item2.GroupBy(c => new { c.Segment }).ToList();
                        foreach (var item5 in ss2)
                        {
                            if (item5.Key.Segment != null)
                            {
                                strHTML2.AppendLine("<tr>");

                                strHTML2.AppendLine("<td colspan=1 valign=top><font color='black'>" + item5.Key.Segment + "</font></td>");
                                int jj = 1;
                                foreach (var item77 in item5)
                                {

                                    if (jj == 1)
                                    {
                                        strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.GWFCYTD + "</font></td>");
                                        strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.GWFPYTD + "</font></td>");

                                        strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.GrowthCY + "</font></td>");

                                        strHTML2.AppendLine("</tr>");
                                        jj++;
                                    }
                                }
                            }
                        }
                    }
                }
            }


            strHTML2.AppendLine("</table>");




            strHTML2.Append("<table cellspacing=1 cellpadding=1 border=1 ID='Table7'>");
            strHTML2.AppendLine("<tr><td colspan=5 align=center><font color='#000000' size=3><b>Selected Search Criteria</b></font></td></tr>");
            strHTML2.AppendLine("<tr>");
            int ICount2 = 0;

            foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
            {
                List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                {
                    if (!info.PropertyType.Name.Contains("List"))
                    {
                        var value = info.GetValue(trackingReportingCommonFilterInputModel, null);

                        var filter = info.Name + ":" + value + ";";
                        if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "FilterBy" && info.Name != "GroupBy" && info.Name != "PageNumber" && info.Name != "PageSize" && info.Name != "ScreenName")
                        {
                            if (ICount2 > 1 && ICount2 % 4 == 0)
                            {
                                strHTML2.AppendLine("</tr><tr>");
                            }
                            strHTML2.AppendLine("<td colspan=1 valign=top><font color='#0000FF'>" + filter + "</font></td>");
                        }

                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(listValue))
                        {
                            var filter = info.Name + ":" + listValue + ";";

                            if (ICount2 > 1 && ICount2 % 4 == 0)
                            {
                                strHTML2.AppendLine("</tr><tr>");
                            }
                            strHTML2.AppendLine("<td colspan=1 valign=top><font color='#0000FF'>" + filter + "</font></td>");
                        }
                    }

                }

            }

            if (ICount2 % 4 != 0)
            {
                strHTML2.AppendLine("</tr");
            }

            workingList.Add(strHTML.ToString());
            workingList.Add(strHTML1.ToString());
            workingList.Add(strHTML2.ToString());



            return workingList;
        }



        public List<GetScorecardGrowthMixOutputModel> GetScorecardGrowthMix(GetScorecardGrowthMixInputModel GetScorecardGrowthMixInputModel)
        {
            return _trackerReportingRepository.GetScorecardGrowthMix(GetScorecardGrowthMixInputModel);
        }


        public StringBuilder GetUWSummaryNewBusinessTotalDownload(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<UWSummaryNewBusinessoutputModel> forecastByBusinessSegmentOutputModel = new List<UWSummaryNewBusinessoutputModel>();
            StringBuilder strHTML = new StringBuilder();
            List<UWSummaryTotalforecasteoutputModel> UWSummaryTotalForecastTotal = new List<UWSummaryTotalforecasteoutputModel>();
            forecastByBusinessSegmentOutputModel = _trackerReportingRepository.GetUWSummaryNewBusinessTotal(trackingReportingCommonFilterInputModel);
            DataTable dt = new DataTable();
            strHTML.AppendLine("<center><span  style='font-family: Arial; font-size: 13.5pt;'>UWSummary NewBusinessTotal Report</b></span></center><br/><br/>");
            strHTML.AppendLine("<p align= 'left' style='font-family: Arial; font-size: 10pt; text-align:left'><b>All the figures listed below are in (USD)</b></p>");


            strHTML.AppendLine("<table border=1 ID='Table1'>");


            int i;
            for (i = 0; i < 1; i++)
            {
                strHTML.AppendLine("<tr>");

                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font  color='white'>" + "Division" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "CYTDTotalForecastNewBusiness" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "PYTDTotalForecastNewBusiness" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black'  valign=top><font color='white'>" + "CYTDTotalBound" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "CYTDTotalSubmission" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "PYTDTotalSubmission" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "CYTDTotalTargetNotSubmitted" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "CYTDTotalQuote" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "CYTDTotalQuoteRejects" + "</font></th>");
                strHTML.AppendLine("</tr>");

            }

            var q = forecastByBusinessSegmentOutputModel.GroupBy(s => new { s.Company });

            foreach (var item in q)
            {
                if (item.Key.Company != null)
                {

                    strHTML.AppendLine("<tr>");
                    strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item.Key.Company + "</font></td>");
                    int ii = 1;
                    foreach (var item44 in item)
                    {

                        if (ii == 1)
                        {

                            strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.CYTDTotalForecastNewBusiness + "</font></td>");
                            strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.PYTDTotalForecastNewBusiness + "</font></td>");

                            strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.CYTDTotalBound + "</font></td>");
                            strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.CYTDTotalSubmission + "</font></td>");
                            strHTML.AppendLine("<td colspan=1  bgcolor='#ff8000'  valign=top><font color='black'>" + item44.PYTDTotalSubmission + "</font></td>");
                            strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.CYTDTotalTargetNotSubmitted + "</font></td>");
                            strHTML.AppendLine("<td colspan=1  bgcolor='#ff8000' valign=top><font color='black'>" + item44.CYTDTotalQuote + "</font></td>");
                            strHTML.AppendLine("<td colspan=1  bgcolor='#ff8000' valign=top><font color='black'>" + item44.CYTDTotalQuoteRejects + "</font></td>");
                            strHTML.AppendLine("</tr>");
                            ii++;
                        }
                    }

                }
                var ss = item.GroupBy(c => new { c.Division }).ToList();

                foreach (var item1 in ss)
                {
                    if (item1.Key.Division != null)
                    {
                        strHTML.AppendLine("<tr>");
                        strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item1.Key.Division + "</font></td>");
                        int kk = 1;
                        foreach (var item55 in item1)
                        {

                            if (kk == 1)
                            {
                                strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.CYTDTotalForecastNewBusiness + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.PYTDTotalForecastNewBusiness + "</font></td>");

                                strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.CYTDTotalBound + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.CYTDTotalSubmission + "</font></td>");
                                strHTML.AppendLine("<td colspan=1    valign=top><font color='black'>" + item55.PYTDTotalSubmission + "</font></td>");
                                strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item55.CYTDTotalTargetNotSubmitted + "</font></td>");
                                strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item55.CYTDTotalQuote + "</font></td>");
                                strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item55.CYTDTotalQuoteRejects + "</font></td>");
                                strHTML.AppendLine("</tr>");
                                kk++;
                            }
                        }

                    }
                    var ss1 = item1.GroupBy(c => new { c.Unit }).ToList();

                    foreach (var item2 in ss1)

                    {
                        if (item2.Key.Unit != null)
                        {
                            strHTML.AppendLine("<tr>");
                            strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item2.Key.Unit + "</font></td>");
                            int nn = 1;
                            foreach (var item66 in item2)
                            {


                                if (nn == 1)
                                {

                                    strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.CYTDTotalForecastNewBusiness + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.PYTDTotalForecastNewBusiness + "</font></td>");

                                    strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.CYTDTotalBound + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.CYTDTotalSubmission + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1    valign=top><font color='black'>" + item66.PYTDTotalSubmission + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item66.CYTDTotalTargetNotSubmitted + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item66.CYTDTotalQuote + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item66.CYTDTotalQuoteRejects + "</font></td>");
                                    strHTML.AppendLine("</tr>");
                                    nn++;
                                }
                            }

                        }
                        var ss2 = item2.GroupBy(c => new { c.Segment }).ToList();
                        foreach (var item5 in ss2)
                        {
                            if (item5.Key.Segment != null)
                            {
                                strHTML.AppendLine("<tr>");

                                strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item5.Key.Segment + "</font></td>");
                                int jj = 1;
                                foreach (var item77 in item5)
                                {

                                    if (jj == 1)
                                    {
                                        strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.CYTDTotalForecastNewBusiness + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.PYTDTotalForecastNewBusiness + "</font></td>");

                                        strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.CYTDTotalBound + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.CYTDTotalSubmission + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1    valign=top><font color='black'>" + item77.PYTDTotalSubmission + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item77.CYTDTotalTargetNotSubmitted + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item77.CYTDTotalQuote + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item77.CYTDTotalQuoteRejects + "</font></td>");
                                        strHTML.AppendLine("</tr>");
                                        jj++;
                                    }
                                }
                            }
                        }
                    }
                }
            }


            strHTML.AppendLine("</table>");




            strHTML.Append("<table cellspacing=1 cellpadding=1 border=1 ID='Table2'>");
            strHTML.AppendLine("<tr><td colspan=5 align=center><font color='#000000' size=3><b>Selected Search Criteria</b></font></td></tr>");
            strHTML.AppendLine("<tr>");
            int ICount = 0;

            foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
            {
                List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                {
                    if (!info.PropertyType.Name.Contains("List"))
                    {
                        var value = info.GetValue(trackingReportingCommonFilterInputModel, null);

                        var filter = info.Name + ":" + value + ";";
                        if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "FilterBy" && info.Name != "GroupBy" && info.Name != "PageNumber" && info.Name != "PageSize" && info.Name != "ScreenName")
                        {
                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                strHTML.AppendLine("</tr><tr>");
                            }
                            strHTML.AppendLine("<td colspan=1 valign=top><font color='#0000FF'>" + filter + "</font></td>");
                        }

                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(listValue))
                        {
                            var filter = info.Name + ":" + listValue + ";";

                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                strHTML.AppendLine("</tr><tr>");
                            }
                            strHTML.AppendLine("<td colspan=1 valign=top><font color='#0000FF'>" + filter + "</font></td>");
                        }
                    }

                }

            }

            if (ICount % 4 != 0)
            {
                strHTML.AppendLine("</tr");
            }
            strHTML.AppendLine("</table>");
            return strHTML;
        }

        public StringBuilder GetUWSummaryRenewalTotalDownload(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<UWSummaryRenewaloutputModel> GetUWSummaryRenewalTotal = new List<UWSummaryRenewaloutputModel>();

            StringBuilder strHTML1 = new StringBuilder();
            GetUWSummaryRenewalTotal = _trackerReportingRepository.GetUWSummaryRenewalTotal(trackingReportingCommonFilterInputModel);
            DataTable dtt = new DataTable();
            strHTML1.AppendLine("<center><span  style='font-family: Arial; font-size: 13.5pt;'>UWSummary RenewalTotal Report</b></span></center><br/><br/>");
            strHTML1.AppendLine("<p align= 'left' style='font-family: Arial; font-size: 10pt; text-align:left'><b>All the figures listed below are in (USD)</b></p>");


            strHTML1.AppendLine("<table border=1 ID='Table3'>");


            int iii;
            for (iii = 0; iii < 1; iii++)
            {
                strHTML1.AppendLine("<tr>");

                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font  color='white'>" + "Division" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "RenewalCYTD" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "RenewalYearOverYearChange" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black'  valign=top><font color='white'>" + "LostCYTD" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "PendingCYTD" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "PendingPYTD" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "QuotedCYTD" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "BoundCYTD" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "BoundPYTD" + "</font></th>");
                strHTML1.AppendLine("</tr>");

            }

            var qq = GetUWSummaryRenewalTotal.GroupBy(s => new { s.Company });

            foreach (var item in qq)
            {
                if (item.Key.Company != null)
                {

                    strHTML1.AppendLine("<tr>");
                    strHTML1.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item.Key.Company + "</font></td>");
                    int ii = 1;
                    foreach (var item44 in item)
                    {

                        if (ii == 1)
                        {

                            strHTML1.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.RenewalCYTD + "</font></td>");
                            strHTML1.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.RenewalYearOverYearChange + "</font></td>");

                            strHTML1.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.LostCYTD + "</font></td>");
                            strHTML1.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.PendingCYTD + "</font></td>");
                            strHTML1.AppendLine("<td colspan=1  bgcolor='#ff8000'  valign=top><font color='black'>" + item44.PendingPYTD + "</font></td>");
                            strHTML1.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.QuotedCYTD + "</font></td>");
                            strHTML1.AppendLine("<td colspan=1  bgcolor='#ff8000' valign=top><font color='black'>" + item44.BoundCYTD + "</font></td>");
                            strHTML1.AppendLine("<td colspan=1  bgcolor='#ff8000' valign=top><font color='black'>" + item44.BoundPYTD + "</font></td>");
                            strHTML1.AppendLine("</tr>");
                            ii++;
                        }
                    }

                }
                var ss = item.GroupBy(c => new { c.Division }).ToList();

                foreach (var item1 in ss)
                {
                    if (item1.Key.Division != null)
                    {
                        strHTML1.AppendLine("<tr>");
                        strHTML1.AppendLine("<td colspan=1 valign=top><font color='black'>" + item1.Key.Division + "</font></td>");
                        int kk = 1;
                        foreach (var item55 in item1)
                        {

                            if (kk == 1)
                            {
                                strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.RenewalCYTD + "</font></td>");
                                strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.RenewalYearOverYearChange + "</font></td>");

                                strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.LostCYTD + "</font></td>");
                                strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.PendingCYTD + "</font></td>");
                                strHTML1.AppendLine("<td colspan=1    valign=top><font color='black'>" + item55.PendingPYTD + "</font></td>");
                                strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item55.QuotedCYTD + "</font></td>");
                                strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item55.BoundCYTD + "</font></td>");
                                strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item55.BoundPYTD + "</font></td>");
                                strHTML1.AppendLine("</tr>");
                                kk++;
                            }
                        }

                    }
                    var ss1 = item1.GroupBy(c => new { c.Unit }).ToList();

                    foreach (var item2 in ss1)

                    {
                        if (item2.Key.Unit != null)
                        {
                            strHTML1.AppendLine("<tr>");
                            strHTML1.AppendLine("<td colspan=1 valign=top><font color='black'>" + item2.Key.Unit + "</font></td>");
                            int nn = 1;
                            foreach (var item66 in item2)
                            {


                                if (nn == 1)
                                {

                                    strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.RenewalCYTD + "</font></td>");
                                    strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.RenewalYearOverYearChange + "</font></td>");

                                    strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.LostCYTD + "</font></td>");
                                    strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.PendingCYTD + "</font></td>");
                                    strHTML1.AppendLine("<td colspan=1    valign=top><font color='black'>" + item66.PendingPYTD + "</font></td>");
                                    strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item66.QuotedCYTD + "</font></td>");
                                    strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item66.BoundCYTD + "</font></td>");
                                    strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item66.BoundPYTD + "</font></td>");
                                    strHTML1.AppendLine("</tr>");
                                    nn++;
                                }
                            }

                        }
                        var ss2 = item2.GroupBy(c => new { c.Segment }).ToList();
                        foreach (var item5 in ss2)
                        {
                            if (item5.Key.Segment != null)
                            {
                                strHTML1.AppendLine("<tr>");

                                strHTML1.AppendLine("<td colspan=1 valign=top><font color='black'>" + item5.Key.Segment + "</font></td>");
                                int jj = 1;
                                foreach (var item77 in item5)
                                {

                                    if (jj == 1)
                                    {
                                        strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.RenewalCYTD + "</font></td>");
                                        strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.RenewalYearOverYearChange + "</font></td>");

                                        strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.LostCYTD + "</font></td>");
                                        strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.PendingCYTD + "</font></td>");
                                        strHTML1.AppendLine("<td colspan=1    valign=top><font color='black'>" + item77.PendingPYTD + "</font></td>");
                                        strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item77.QuotedCYTD + "</font></td>");
                                        strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item77.BoundCYTD + "</font></td>");
                                        strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item77.BoundPYTD + "</font></td>");
                                        strHTML1.AppendLine("</tr>");
                                        jj++;
                                    }
                                }
                            }
                        }
                    }
                }
            }


            strHTML1.AppendLine("</table>");




            strHTML1.Append("<table cellspacing=1 cellpadding=1 border=1 ID='Table5'>");
            strHTML1.AppendLine("<tr><td colspan=5 align=center><font color='#000000' size=3><b>Selected Search Criteria</b></font></td></tr>");
            strHTML1.AppendLine("<tr>");
            int ICount1 = 0;

            foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
            {
                List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                {
                    if (!info.PropertyType.Name.Contains("List"))
                    {
                        var value = info.GetValue(trackingReportingCommonFilterInputModel, null);

                        var filter = info.Name + ":" + value + ";";
                        if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "FilterBy" && info.Name != "GroupBy" && info.Name != "PageNumber" && info.Name != "PageSize" && info.Name != "ScreenName")
                        {
                            if (ICount1 > 1 && ICount1 % 4 == 0)
                            {
                                strHTML1.AppendLine("</tr><tr>");
                            }
                            strHTML1.AppendLine("<td colspan=1 valign=top><font color='#0000FF'>" + filter + "</font></td>");
                        }

                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(listValue))
                        {
                            var filter = info.Name + ":" + listValue + ";";

                            if (ICount1 > 1 && ICount1 % 4 == 0)
                            {
                                strHTML1.AppendLine("</tr><tr>");
                            }
                            strHTML1.AppendLine("<td colspan=1 valign=top><font color='#0000FF'>" + filter + "</font></td>");
                        }
                    }

                }

            }

            if (ICount1 % 4 != 0)
            {
                strHTML1.AppendLine("</tr");
            }
            strHTML1.AppendLine("</table>");
            return strHTML1;
        }

        public StringBuilder GetUWSummaryTotalForecastTotalDownload(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            List<UWSummaryTotalforecasteoutputModel> UWSummaryTotalForecastTotal = new List<UWSummaryTotalforecasteoutputModel>();
            StringBuilder strHTML2 = new StringBuilder();
            UWSummaryTotalForecastTotal = _trackerReportingRepository.GetUWSummaryTotalForecastTotal(trackingReportingCommonFilterInputModel);

            strHTML2.AppendLine("<center><span  style='font-family: Arial; font-size: 13.5pt;'>UWSummary Total ForecastTotal Report</b></span></center><br/><br/>");
            strHTML2.AppendLine("<p align= 'left' style='font-family: Arial; font-size: 10pt; text-align:left'><b>All the figures listed below are in (USD)</b></p>");


            strHTML2.AppendLine("<table border=1 ID='Table6'>");


            int columnCount;
            for (columnCount = 0; columnCount < 1; columnCount++)
            {
                strHTML2.AppendLine("<tr>");

                strHTML2.AppendLine("<th colspan=1 bgcolor='black' valign=top><font  color='white'>" + "Division" + "</font></th>");
                strHTML2.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "GWFCYTD" + "</font></th>");
                strHTML2.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "GWFPYTD" + "</font></th>");
                strHTML2.AppendLine("<th colspan=1 bgcolor='black'  valign=top><font color='white'>" + "GrowthCY" + "</font></th>");

                strHTML2.AppendLine("</tr>");

            }

            var UwSummaryTotal = UWSummaryTotalForecastTotal.GroupBy(s => new { s.Company });

            foreach (var item in UwSummaryTotal)
            {
                if (item.Key.Company != null)
                {

                    strHTML2.AppendLine("<tr>");
                    strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item.Key.Company + "</font></td>");
                    int ii = 1;
                    foreach (var item44 in item)
                    {

                        if (ii == 1)
                        {

                            strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.GWFCYTD + "</font></td>");
                            strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.GWFPYTD + "</font></td>");

                            strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.GrowthCY + "</font></td>");

                            strHTML2.AppendLine("</tr>");
                            ii++;
                        }
                    }

                }
                var ss = item.GroupBy(c => new { c.Division }).ToList();

                foreach (var item1 in ss)
                {
                    if (item1.Key.Division != null)
                    {
                        strHTML2.AppendLine("<tr>");
                        strHTML2.AppendLine("<td colspan=1 valign=top><font color='black'>" + item1.Key.Division + "</font></td>");
                        int kk = 1;
                        foreach (var item55 in item1)
                        {

                            if (kk == 1)
                            {
                                strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.GWFCYTD + "</font></td>");
                                strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.GWFPYTD + "</font></td>");

                                strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.GrowthCY + "</font></td>");

                                strHTML2.AppendLine("</tr>");
                                kk++;
                            }
                        }

                    }
                    var ss1 = item1.GroupBy(c => new { c.Unit }).ToList();

                    foreach (var item2 in ss1)

                    {
                        if (item2.Key.Unit != null)
                        {
                            strHTML2.AppendLine("<tr>");
                            strHTML2.AppendLine("<td colspan=1 valign=top><font color='black'>" + item2.Key.Unit + "</font></td>");
                            int nn = 1;
                            foreach (var item66 in item2)
                            {


                                if (nn == 1)
                                {

                                    strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.GWFCYTD + "</font></td>");
                                    strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.GWFPYTD + "</font></td>");

                                    strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.GrowthCY + "</font></td>");

                                    strHTML2.AppendLine("</tr>");
                                    nn++;
                                }
                            }

                        }
                        var ss2 = item2.GroupBy(c => new { c.Segment }).ToList();
                        foreach (var item5 in ss2)
                        {
                            if (item5.Key.Segment != null)
                            {
                                strHTML2.AppendLine("<tr>");

                                strHTML2.AppendLine("<td colspan=1 valign=top><font color='black'>" + item5.Key.Segment + "</font></td>");
                                int jj = 1;
                                foreach (var item77 in item5)
                                {

                                    if (jj == 1)
                                    {
                                        strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.GWFCYTD + "</font></td>");
                                        strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.GWFPYTD + "</font></td>");

                                        strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.GrowthCY + "</font></td>");

                                        strHTML2.AppendLine("</tr>");
                                        jj++;
                                    }
                                }
                            }
                        }
                    }
                }
            }


            strHTML2.AppendLine("</table>");
            // }



            strHTML2.Append("<table cellspacing=1 cellpadding=1 border=1 ID='Table7'>");
            strHTML2.AppendLine("<tr><td colspan=5 align=center><font color='#000000' size=3><b>Selected Search Criteria</b></font></td></tr>");
            strHTML2.AppendLine("<tr>");
            int ICount2 = 0;

            foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
            {
                List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                {
                    if (!info.PropertyType.Name.Contains("List"))
                    {
                        var value = info.GetValue(trackingReportingCommonFilterInputModel, null);

                        var filter = info.Name + ":" + value + ";";
                        if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "FilterBy" && info.Name != "GroupBy" && info.Name != "PageNumber" && info.Name != "PageSize" && info.Name != "ScreenName")
                        {
                            if (ICount2 > 1 && ICount2 % 4 == 0)
                            {
                                strHTML2.AppendLine("</tr><tr>");
                            }
                            strHTML2.AppendLine("<td colspan=1 valign=top><font color='#0000FF'>" + filter + "</font></td>");
                        }

                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(listValue))
                        {
                            var filter = info.Name + ":" + listValue + ";";

                            if (ICount2 > 1 && ICount2 % 4 == 0)
                            {
                                strHTML2.AppendLine("</tr><tr>");
                            }
                            strHTML2.AppendLine("<td colspan=1 valign=top><font color='#0000FF'>" + filter + "</font></td>");
                        }
                    }

                }

            }

            if (ICount2 % 4 != 0)
            {
                strHTML2.AppendLine("</tr");
            }
            return strHTML2;
        }

        public string UpdateInsuredSummaryComments(int ClientID, String Comments, char CommentsFor)
        {
            string strResult = _trackerReportingRepository.UpdateInsuredSummaryComments(ClientID, Comments, CommentsFor);
            return strResult;
        }
       
        public List<GetCustomerProfileInformationDetailsOutputModel> GetCustomerProfileInformationDetails(GetCustomerProfileInformationDetailsInputModel GetCustomerProfileInformationDetailsInputModel)
        {
            return _trackerReportingRepository.GetCustomerProfileInformationDetails(GetCustomerProfileInformationDetailsInputModel);
        }
        public List<DropdownOutputValues> GetOwnerBranchFilter(List<string> Region)
        {
            List<DropdownOutputValues> listDetails = _trackerReportingRepository.GetOwnerBranchFilter(Region);
            return listDetails;
        }
        public List<CreditedRegionBranchOutputModel> GetOwnerRegionBranchFilters()
        {
            List<CreditedRegionBranchOutputModel> listDetails = _trackerReportingRepository.GetOwnerRegionBranchFilters();
            return listDetails;
        }
        public List<GetNetScorecardbyDivisionOutputModel> GetNetScorecardbyDivision(GetNetScorecardbyDivisionInputModel GetNetScorecardbyDivisionInputModel)
        {

            return _trackerReportingRepository.GetNetScorecardbyDivision(GetNetScorecardbyDivisionInputModel);
        }
        public List<GetNetScorecardbyRegionOutputModel> GetNetScorecardbyRegion(GetNetScorecardbyDivisionInputModel GetNetScorecardbyDivisionInputModel)
        {
            return _trackerReportingRepository.GetNetScorecardbyRegion(GetNetScorecardbyDivisionInputModel);
        }
        public List<GetHomeOfficeMarginbypercentageOutputModel> GetHomeOfficeMarginbypercentage(GetHomeOfficeMarginInputModel GetHomeOfficeMarginInputModel)
        {
            return _trackerReportingRepository.GetHomeOfficeMarginbypercentage(GetHomeOfficeMarginInputModel);
        }
        public List<GetHomeOfficeMarginbyCurrencyOutputModel> GetHomeOfficeMarginbyCurrency(GetHomeOfficeMarginInputModel GetHomeOfficeMarginInputModel)
        {
            return _trackerReportingRepository.GetHomeOfficeMarginbyCurrency(GetHomeOfficeMarginInputModel);
        }

        public byte[] GetForecastSummaryTotalDownloadPDF(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string strReportHeader;
            List<ForecastByBusinessSegmentOutputModel> forecastByBusinessSegmentOutputModel = new List<ForecastByBusinessSegmentOutputModel>();
            List<ForecastRegionDataOutputModel> lGetForecastRegionTotal = new List<ForecastRegionDataOutputModel>();
            List<ProducerReportOuputModel> producerReport = new List<ProducerReportOuputModel>();
            List<DetailReport> detailReport = new List<DetailReport>();

            List<ScorecardByStatusOutputModel> ScorecardNewBusinessByStatus = new List<ScorecardByStatusOutputModel>();
            List<ScorecardRenewalByStatusOutputModel> ScorecardRenewalByStatus = new List<ScorecardRenewalByStatusOutputModel>();
            List<ScorecardAmountPerDivionOutputModel> ScorecardAmountPerDivision = new List<ScorecardAmountPerDivionOutputModel>();

            List<TargetProgressionByBranchOutputModel> GetTargetProgressionByBranch = new List<TargetProgressionByBranchOutputModel>();
            List<TargetProgressionByRegionOutputModel> GetTargetProgressionByRegion = new List<TargetProgressionByRegionOutputModel>();
            TargetProgressionByLobOutputModel GetTargetProgressionByLOB = new TargetProgressionByLobOutputModel();

            StringBuilder sb2 = new StringBuilder();
            List<DateTime> list1 = new List<DateTime>();
            DateTime? effectiveDateStart = trackingReportingCommonFilterInputModel.EffectiveDateStart;
            DateTime? effectiveDateEnd = trackingReportingCommonFilterInputModel.EffectiveDateEnd;
            DateTime? expirationDateStart = trackingReportingCommonFilterInputModel.ExpirationDateStart;
            DateTime? expirationDateEnd = trackingReportingCommonFilterInputModel.ExpirationDateEnd;
            DateTime? createDateStart = trackingReportingCommonFilterInputModel.CreateDateStart;
            DateTime? createDateEnd = trackingReportingCommonFilterInputModel.CreateDateEnd;

            StringBuilder strHTML = new StringBuilder();
            strHTML.Append("<html>");
            strHTML.Append("<head>");

            //strHTML.Append("<style> table {border-collapse: collapse; } th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }</style>");
            strHTML.Append("<style>#Table2 {font-family: Trebuchet MS, Arial, Helvetica, sans-serif;border-collapse: collapse; width: 100%;} #Table2 td, #Table2 th { border: 1px solid #A9A9A9; padding: 8px;}}</style>");
            strHTML.Append("<style>#Legend {font-family: Trebuchet MS, Arial, Helvetica, sans-serif;border-collapse: collapse; width: 40%;} #Legend td, #Legend th { border: 1px solid #A9A9A9; padding: 8px;}}</style>");
            strHTML.Append("</head>");
            strHTML.Append("<body>");


            int flag = 0;
            if (effectiveDateStart.HasValue)
            {
                flag = 1;
            }
            else if (effectiveDateEnd.HasValue)
            {
                flag = 1;
            }
            else if (expirationDateStart.HasValue)
            {
                flag = 1;
            }
            else if (expirationDateEnd.HasValue)
            {
                flag = 1;
            }
            else if (createDateStart.HasValue)
            {
                flag = 1;
            }
            else if (createDateEnd.HasValue)
            {
                flag = 1;
            }

            //--------------------------------------Archana_start----------------------------------------------------------------------------------------------
            if (trackingReportingCommonFilterInputModel.ReportName == "Scorecard")
            {
                //------------------------------------Amount Per division--------------------------------------------
                ScorecardAmountPerDivision = _trackerReportingRepository.GetScorecardAmountPerDivision(trackingReportingCommonFilterInputModel);


                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = effectiveDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = effectiveDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = expirationDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = expirationDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = createDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = createDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = null;
                }
                DataTable dttt = new DataTable();
                strHTML.AppendLine("<center><span  style='font-family: Arial; font-size: 20pt;'>Scorecard Amount Per Division</b></span></center><br/><br/>");
                strHTML.AppendLine("<p align= 'left' style='font-family: Arial; font-size: 10pt; text-align:left'><b>All the figures listed below are in (USD)</b></p>");


                strHTML.AppendLine("<table ID='Table2'>");


                int columnCount;
                for (columnCount = 0; columnCount < 1; columnCount++)
                {
                    strHTML.AppendLine("<thead style='display: table-header-group'><tr>");

                    strHTML.AppendLine("<th colspan=1 style='width:25%'  bgcolor='#3980c6' valign=top><font  color='white'>" + "Division" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Bound PriorForecast" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6'  valign=top><font color='white'>" + "Total Bound YearForecast" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "TotalBound Plan" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "NewBusiness PriorForecast" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "NewBusiness YearForecast" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "NewBusiness Plan" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Renewal PriorForecast" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Renewal YearForecast" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Renewal Plan" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "OtherPrior Forecast" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "OtherBusiness Forecast" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Other Plan" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "ForecastPercentagePrior" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "ForecastPercentagePlan" + "</font></th>");
                    strHTML.AppendLine("</tr></thead>");

                }

                var UwSummaryTotal = ScorecardAmountPerDivision.GroupBy(s => new { s.Company });

                foreach (var item in UwSummaryTotal)
                {
                    if (item.Key.Company != null)
                    {

                        strHTML.AppendLine("<tr>");
                        strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#8c8c8c' valign=top><font color='black'>" + item.Key.Company + "</font></td>");
                        int ii = 1;
                        foreach (var item44 in item)
                        {

                            if (ii == 1)
                            {

                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.TotalBoundPriorForecast) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.TotalBoundYearForecast) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.TotalBoundPlan) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.NewBusinessPriorForecast) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.NewBusinessYearForecast) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.NewBusinessPlan) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.RenewalPriorForecast) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.RenewalYearForecast) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.RenewalPlan) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.OtherPriorForecast) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.OtherYearForecast) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.OtherPlan) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.ForecastPercentagePrior) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.ForecastPercentagePlan) + "</font></td>");

                                strHTML.AppendLine("</tr>");
                                ii++;




                            }
                        }

                    }
                    var ss = item.GroupBy(c => new { c.Division }).ToList();

                    foreach (var item1 in ss)
                    {
                        if (item1.Key.Division != null)
                        {
                            strHTML.AppendLine("<tr>");
                            strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item1.Key.Division + "</font></td>");
                            int kk = 1;
                            foreach (var item55 in item1)
                            {

                                if (kk == 1)
                                {
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item55.TotalBoundPriorForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item55.TotalBoundYearForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item55.TotalBoundPlan) + "</font></td>");

                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.NewBusinessPriorForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.NewBusinessYearForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.NewBusinessPlan) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.RenewalPriorForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.RenewalYearForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.RenewalPlan) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.OtherPriorForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.OtherYearForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.OtherPlan) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item55.ForecastPercentagePrior + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item55.ForecastPercentagePlan + "</font></td>");
                                    strHTML.AppendLine("</tr>");
                                    kk++;



                                }
                            }

                        }
                        var ss1 = item1.GroupBy(c => new { c.Unit }).ToList();

                        foreach (var item2 in ss1)

                        {
                            if (item2.Key.Unit != null)
                            {
                                strHTML.AppendLine("<tr>");
                                strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item2.Key.Unit + "</font></td>");
                                int nn = 1;
                                foreach (var item66 in item2)
                                {


                                    if (nn == 1)
                                    {
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item66.TotalBoundPriorForecast) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item66.TotalBoundYearForecast) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item66.TotalBoundPlan) + "</font></td>");

                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.NewBusinessPriorForecast) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.NewBusinessYearForecast) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.NewBusinessPlan) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.RenewalPriorForecast) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.RenewalYearForecast) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.RenewalPlan) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.OtherPriorForecast) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.OtherYearForecast) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.OtherPlan) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item66.ForecastPercentagePrior + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item66.ForecastPercentagePlan + "</font></td>");

                                        strHTML.AppendLine("</tr>");
                                        nn++;
                                    }
                                }

                            }
                            var ss2 = item2.GroupBy(c => new { c.Segment }).ToList();
                            foreach (var item5 in ss2)
                            {
                                if (item5.Key.Segment != null)
                                {
                                    strHTML.AppendLine("<tr>");

                                    strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item5.Key.Segment + "</font></td>");
                                    int jj = 1;
                                    foreach (var item77 in item5)
                                    {

                                        if (jj == 1)
                                        {
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item77.TotalBoundPriorForecast) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item77.TotalBoundYearForecast) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item77.TotalBoundPlan) + "</font></td>");

                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.NewBusinessPriorForecast) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.NewBusinessYearForecast) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.NewBusinessPlan) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.RenewalPriorForecast) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.RenewalYearForecast) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.RenewalPlan) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.OtherPriorForecast) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.OtherYearForecast) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.OtherPlan) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item77.ForecastPercentagePrior + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item77.ForecastPercentagePlan + "</font></td>");
                                            strHTML.AppendLine("</tr>");
                                            jj++;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }


                strHTML.AppendLine("</table>");
                //------------------------------end  amount per division-----------------------------------------------------
                ScorecardNewBusinessByStatus = _trackerReportingRepository.GetScorecardNewBusinessByStatus(trackingReportingCommonFilterInputModel);


                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = effectiveDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = effectiveDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = expirationDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = expirationDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = createDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = createDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = null;
                }
                DataTable dt = new DataTable();
                strHTML.AppendLine("<center><span  style='font-family: Arial; font-size: 20pt;'>Scorecard New Business By Status</b></span></center><br/><br/>");
                strHTML.AppendLine("<p align= 'left' style='font-family: Arial; font-size: 10pt; text-align:left'><b>All the figures listed below are in (USD)</b></p>");


                strHTML.AppendLine("<table border=1 ID='Table2'>");


                int i;
                for (i = 0; i < 1; i++)
                {

                    strHTML.AppendLine("<thead style='display: table-header-group'><tr>");
                    strHTML.AppendLine("<th colspan=1 style='width:25%'  bgcolor='#3980c6' valign=top><font  color='white'>" + "Division" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "NewBusiness PriorForecast (USD)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6'  valign=top><font color='white'>" + "NewBusiness YearForecast (USD)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "NewBusiness Plan (USD)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Forecast PercentagePrior" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Forecast PercentagePlan" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submission CountPrior" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submission CountTotal" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Quote CountPrior" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Quote CountTotal" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "QuotetoSubmissionRatio" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Bound CountPrior" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Bound CountTotal" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "BoundtoQuoteRatio" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "BoundtoSubmissionRatio" + "</font></th>");
                    strHTML.AppendLine("</tr></thead>");

                }

                var q = ScorecardNewBusinessByStatus.GroupBy(s => new { s.Company });

                foreach (var item in q)
                {
                    if (item.Key.Company != null)
                    {

                        strHTML.AppendLine("<tr>");
                        strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#8c8c8c' valign=top><font color='black'>" + item.Key.Company + "</font></td>");
                        int ii = 1;
                        foreach (var item44 in item)
                        {

                            if (ii == 1)
                            {

                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.NewBusinessPriorForecast) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.NewBusinessYearForecast) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.NewBusinessPlan) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.ForecastPercentagePrior) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.ForecastPercentagePlan) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.SubmissionCountPrior) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.SubmissionCountTotal) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.QuoteCountPrior) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.QuoteCountTotal) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.QuotetoSubmissionRatio) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.BoundCountPrior) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.BoundCountTotal) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.BoundtoQuoteRatio) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.BoundtoSubmissionRatio) + "</font></td>");
                                strHTML.AppendLine("</tr>");
                                ii++;
                            }
                        }

                    }
                    var ss = item.GroupBy(c => new { c.Division }).ToList();

                    foreach (var item1 in ss)
                    {
                        if (item1.Key.Division != null)
                        {
                            strHTML.AppendLine("<tr>");
                            strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item1.Key.Division + "</font></td>");
                            int kk = 1;
                            foreach (var item55 in item1)
                            {

                                if (kk == 1)
                                {
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item55.NewBusinessPriorForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item55.NewBusinessYearForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item55.NewBusinessPlan) + "</font></td>");

                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.ForecastPercentagePrior) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.ForecastPercentagePlan) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.SubmissionCountPrior) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.SubmissionCountTotal) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.QuoteCountPrior) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.QuoteCountTotal) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.QuotetoSubmissionRatio) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.BoundCountPrior) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.BoundCountTotal) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.BoundtoQuoteRatio) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.BoundtoSubmissionRatio) + "</font></td>");
                                    strHTML.AppendLine("</tr>");
                                    kk++;
                                }
                            }

                        }
                        var ss1 = item1.GroupBy(c => new { c.Unit }).ToList();

                        foreach (var item2 in ss1)

                        {
                            if (item2.Key.Unit != null)
                            {
                                strHTML.AppendLine("<tr>");
                                strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#e6e6e6' width='20%' valign=top><font color='black'>" + item2.Key.Unit + "</font></td>");
                                int nn = 1;
                                foreach (var item66 in item2)
                                {


                                    if (nn == 1)
                                    {
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item66.NewBusinessPriorForecast) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item66.NewBusinessYearForecast) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item66.NewBusinessPlan) + "</font></td>");

                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.ForecastPercentagePrior) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.ForecastPercentagePlan) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.SubmissionCountPrior) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.SubmissionCountTotal) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.QuoteCountPrior) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.QuoteCountTotal) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.QuotetoSubmissionRatio) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.BoundCountPrior) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.BoundCountTotal) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.BoundtoQuoteRatio) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.BoundtoSubmissionRatio) + "</font></td>");
                                        strHTML.AppendLine("</tr>");
                                        nn++;
                                    }
                                }

                            }
                            var ss2 = item2.GroupBy(c => new { c.Segment }).ToList();
                            foreach (var item5 in ss2)
                            {
                                if (item5.Key.Segment != null)
                                {
                                    strHTML.AppendLine("<tr>");

                                    strHTML.AppendLine("<td colspan=1 style='width:25%' valign=top><font color='black'>" + item5.Key.Segment + "</font></td>");

                                    int jj = 1;
                                    foreach (var item77 in item5)
                                    {

                                        if (jj == 1)
                                        {
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item77.NewBusinessPriorForecast) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item77.NewBusinessYearForecast) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item77.NewBusinessPlan) + "</font></td>");

                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.ForecastPercentagePrior) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.ForecastPercentagePlan) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.SubmissionCountPrior) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.SubmissionCountTotal) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.QuoteCountPrior) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.QuoteCountTotal) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.QuotetoSubmissionRatio) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.BoundCountPrior) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.BoundCountTotal) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.BoundtoQuoteRatio) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.BoundtoSubmissionRatio) + "</font></td>");
                                            strHTML.AppendLine("</tr>");
                                            jj++;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }


                strHTML.AppendLine("</table>");
                //-------------------------------------------Renewal by status-----------------------------
                ScorecardRenewalByStatus = _trackerReportingRepository.GetScorecardRenewalByStatus(trackingReportingCommonFilterInputModel);


                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = effectiveDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = effectiveDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = expirationDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = expirationDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = createDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = createDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = null;
                }
                DataTable dtt = new DataTable();
                strHTML.AppendLine("<center><span  style='font-family: Arial; font-size: 20pt;'>Scorecard Renewals By Status</b></span></center><br/><br/>");
                strHTML.AppendLine("<p align= 'left' style='font-family: Arial; font-size: 10pt; text-align:left'><b>All the figures listed below are in (USD)</b></p>");



                strHTML.AppendLine("<table border=1 ID='Table2'>");


                int i1;
                for (i1 = 0; i1 < 1; i1++)
                {
                    strHTML.AppendLine("<thead style='display: table-header-group'><tr>");
                    strHTML.AppendLine("<th colspan=1 style='width:25%'  bgcolor='#3980c6' valign=top><font  color='white'>" + "Division" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Renewal PriorForecast (USD)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6'  valign=top><font color='white'>" + "Renewal YearForecast (USD)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Renewal Plan (USD)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Forecast PercentagePrior" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Forecast PercentagePlan" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submission CountPrior" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submission CountTotal" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Quote CountPrior" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Quote CountTotal" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "QuotetoSubmissionRatio" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Bound CountPrior" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Bound CountTotal" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "BoundtoQuoteRatio" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "BoundtoSubmissionRatio" + "</font></th>");
                    strHTML.AppendLine("</tr></thead>");


                }

                var qq = ScorecardRenewalByStatus.GroupBy(s => new { s.Company });

                foreach (var item in qq)
                {
                    if (item.Key.Company != null)
                    {

                        strHTML.AppendLine("<tr>");
                        strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#8c8c8c' valign=top><font color='black'>" + item.Key.Company + "</font></td>");
                        int ii = 1;
                        foreach (var item44 in item)
                        {

                            if (ii == 1)
                            {

                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.RenewalPriorForecast) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.RenewalYearForecast) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.RenewalPlan) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.ForecastPercentagePrior) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.ForecastPercentagePlan) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.SubmissionCountPrior) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.SubmissionCountTotal) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.QuoteCountPrior) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.QuoteCountTotal) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.QuotetoSubmissionRatio) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.BoundCountPrior) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.BoundCountTotal) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.BoundtoQuoteRatio) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.BoundtoSubmissionRatio) + "</font></td>");
                                strHTML.AppendLine("</tr>");
                                ii++;



                            }
                        }

                    }
                    var ss = item.GroupBy(c => new { c.Division }).ToList();

                    foreach (var item1 in ss)
                    {
                        if (item1.Key.Division != null)
                        {
                            strHTML.AppendLine("<tr>");
                            strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item1.Key.Division + "</font></td>");
                            int kk = 1;
                            foreach (var item55 in item1)
                            {

                                if (kk == 1)
                                {
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item55.RenewalPriorForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item55.RenewalYearForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item55.RenewalPlan) + "</font></td>");

                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.ForecastPercentagePrior) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.ForecastPercentagePlan) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.SubmissionCountPrior) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.SubmissionCountTotal) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.QuoteCountPrior) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.QuoteCountTotal) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.QuotetoSubmissionRatio) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.BoundCountPrior) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.BoundCountTotal) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.BoundtoQuoteRatio) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.BoundtoSubmissionRatio) + "</font></td>");
                                    strHTML.AppendLine("</tr>");


                                    kk++;
                                }
                            }

                        }
                        var ss1 = item1.GroupBy(c => new { c.Unit }).ToList();

                        foreach (var item2 in ss1)

                        {
                            if (item2.Key.Unit != null)
                            {
                                strHTML.AppendLine("<tr>");
                                strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#e6e6e6' width='20%' valign=top><font color='black'>" + item2.Key.Unit + "</font></td>");
                                int nn = 1;
                                foreach (var item66 in item2)
                                {


                                    if (nn == 1)
                                    {
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item66.RenewalPriorForecast) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item66.RenewalYearForecast) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item66.RenewalPlan) + "</font></td>");

                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.ForecastPercentagePrior) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.ForecastPercentagePlan) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.SubmissionCountPrior) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.SubmissionCountTotal) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.QuoteCountPrior) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.QuoteCountTotal) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.QuotetoSubmissionRatio) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.BoundCountPrior) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.BoundCountTotal) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.BoundtoQuoteRatio) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.BoundtoSubmissionRatio) + "</font></td>");
                                        strHTML.AppendLine("</tr>");
                                        nn++;
                                    }
                                }

                            }
                            var ss2 = item2.GroupBy(c => new { c.Segment }).ToList();
                            foreach (var item5 in ss2)
                            {
                                if (item5.Key.Segment != null)
                                {
                                    strHTML.AppendLine("<tr>");

                                    strHTML.AppendLine("<td colspan=1 style='width:25%' valign=top><font color='black'>" + item5.Key.Segment + "</font></td>");

                                    int jj = 1;
                                    foreach (var item77 in item5)
                                    {

                                        if (jj == 1)
                                        {
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item77.RenewalPriorForecast) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item77.RenewalYearForecast) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item77.RenewalPlan) + "</font></td>");

                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.ForecastPercentagePrior) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.ForecastPercentagePlan) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.SubmissionCountPrior) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.SubmissionCountTotal) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.QuoteCountPrior) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.QuoteCountTotal) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.QuotetoSubmissionRatio) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.BoundCountPrior) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.BoundCountTotal) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.BoundtoQuoteRatio) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.BoundtoSubmissionRatio) + "</font></td>");
                                            strHTML.AppendLine("</tr>");
                                            jj++;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }


                strHTML.AppendLine("</table>");
                //------------------------------------RenewalBy status--------------------

            }

            //--------------------------------------------Archana_ENd------------------------------------------------------------------------------------
            //targetprogression start 
            if (trackingReportingCommonFilterInputModel.ReportName == "Target Progression")
            {
                #region GetTargetProgressionByRegion
                GetTargetProgressionByRegion = _trackerReportingRepository.GetTargetProgressionReportsByRegion(trackingReportingCommonFilterInputModel);
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = effectiveDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = effectiveDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = expirationDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = expirationDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = createDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = createDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = null;
                }
                DataTable dt = new DataTable();
                strHTML.AppendLine("<center><span  style='font-family: Arial; font-size: 20pt;'>TargetProgression By Region</b></span></center><br/><br/>");
                strHTML.AppendLine("<p align= 'left' style='font-family: Arial; font-size: 10pt; text-align:left'><b>All the figures listed below are in (USD)</b></p>");


                strHTML.AppendLine("<table border=1 ID='Table2'>");


                int i;
                for (i = 0; i < 1; i++)
                {
                    strHTML.AppendLine("<thead style='display: table-header-group'><tr>");

                    strHTML.AppendLine("<th colspan=1 style='width:25%'  bgcolor='#3980c6' valign=top><font  color='white'>" + "Credited Region" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Targets" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6'  valign=top><font color='white'>" + "Total Outstanding (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Outstanding (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Outstanding (Forecast $)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Closed (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Closed (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Targets Rolled (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Targets Rolled (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received Quotes #" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received Bound #" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Bound (Forecast $)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Unbound RF (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Unbound RF (%)" + "</font></th>");

                    strHTML.AppendLine("</tr></thead>");
                    var TargetByRegion = GetTargetProgressionByRegion.GroupBy(s => new { s.CreditedRegion });
                    foreach (var item in TargetByRegion)
                    {
                        if (item.Key.CreditedRegion != null)
                        {
                            strHTML.AppendLine("<tr>");
                            strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#8c8c8c' valign=top><font color='black'>" + item.Key.CreditedRegion + "</font></td>");
                            int ii = 1;
                            foreach (var item22 in item)
                            {
                                if (ii == 1)
                                {

                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TotalTargets) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsOutStandingCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsOutStandingPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsOutStandingForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsClosedCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsClosedPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetRolledForwardCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetRolledForwardPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedSubmissionCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedSubmissionPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedQuotes) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedBound) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedBoundForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.UnBoundRFCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.UnBoundRFPercentage) + "</font></td>");
                                    strHTML.AppendLine("</tr>");
                                    ii++;

                                }

                            }
                        }

                        var ss = item.GroupBy(c => new { c.TargetConfidence }).ToList();
                        foreach (var item1 in ss)
                        {
                            if (item1.Key.TargetConfidence != null)
                            {
                                strHTML.AppendLine("<tr>");
                                strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item1.Key.TargetConfidence + "</font></td>");
                                int kk = 1;
                                foreach (var item33 in item1)
                                {
                                    if (kk == 1)
                                    {

                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TotalTargets) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsOutStandingCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsOutStandingPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsOutStandingForecast) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsClosedCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsClosedPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetRolledForwardCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetRolledForwardPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedSubmissionCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedSubmissionPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedQuotes) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedBound) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item33.SubmissionReceivedBoundForecast + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item33.UnBoundRFCount + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item33.UnBoundRFPercentage + "</font></td>");
                                        strHTML.AppendLine("</tr>");
                                        kk++;
                                    }

                                }
                            }
                        }
                    }
                }
                strHTML.AppendLine("</table>");
                #endregion
                #region GetTargetProgressionByBranch
                //GetTargetProgressionByBranch start ---------------------------------
                GetTargetProgressionByBranch = _trackerReportingRepository.GetTargetProgressionReportsByBranch(trackingReportingCommonFilterInputModel);
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = effectiveDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = effectiveDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = expirationDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = expirationDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = createDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = createDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = null;
                }
                DataTable dttt = new DataTable();

                strHTML.AppendLine("<center><span  style='font-family: Arial; font-size: 20pt;'>TargetProgression By Branch</b></span></center><br/><br/>");
                strHTML.AppendLine("<p align= 'left' style='font-family: Arial; font-size: 10pt; text-align:left'><b>All the figures listed below are in (USD)</b></p>");


                strHTML.AppendLine("<table ID='Table2'>");

                int columnCount;
                for (columnCount = 0; columnCount < 1; columnCount++)
                {
                    strHTML.AppendLine("<thead style='display: table-header-group'><tr>");

                    strHTML.AppendLine("<th colspan=1 style='width:25%'  bgcolor='#3980c6' valign=top><font  color='white'>" + "Credited Branch" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Targets" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6'  valign=top><font color='white'>" + "Total Outstanding (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Outstanding (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Outstanding (Forecast $)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Closed (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Closed (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Targets Rolled (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Targets Rolled (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received Quotes #" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received Bound #" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Bound (Forecast $)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Unbound RF (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Unbound RF (%)" + "</font></th>");

                    strHTML.AppendLine("</tr></thead>");

                    
                    var TargetByBranch = GetTargetProgressionByBranch.GroupBy(s => new { s.CreditedBranch });
                    foreach (var item in TargetByBranch)
                    {
                        if (item.Key.CreditedBranch != null)
                        {
                            strHTML.AppendLine("<tr>");
                            strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#8c8c8c' valign=top><font color='black'>" + item.Key.CreditedBranch + "</font></td>");
                            int ii = 1;
                            foreach (var item22 in item)
                            {
                                if (ii == 1)
                                {                                  
                                   
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TotalTargets) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsOutStandingCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsOutStandingPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsOutStandingForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsClosedCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsClosedPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetRolledForwardCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetRolledForwardPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedSubmissionCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedSubmissionPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedQuotes) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedBound) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedBoundForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.UnBoundRFCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.UnBoundRFPercentage) + "</font></td>");
                                    strHTML.AppendLine("</tr>");
                                    ii++;

                                }

                            }
                        }

                        var ss = item.GroupBy(c => new { c.TargetConfidence }).ToList();
                        foreach (var item1 in ss)
                        {
                            if (item1.Key.TargetConfidence != null)
                            {
                                strHTML.AppendLine("<tr>");
                                strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item1.Key.TargetConfidence + "</font></td>");
                                int kk = 1;
                                foreach (var item33 in item1)
                                {
                                    if (kk == 1)
                                    {
                                        
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TotalTargets) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsOutStandingCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsOutStandingPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsOutStandingForecast) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsClosedCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsClosedPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetRolledForwardCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetRolledForwardPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedSubmissionCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedSubmissionPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedQuotes) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedBound) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item33.SubmissionReceivedBoundForecast + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item33.UnBoundRFCount + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item33.UnBoundRFPercentage + "</font></td>");
                                        strHTML.AppendLine("</tr>");
                                        kk++;
                                    }

                                }
                            }
                        }
                    }
                }
                strHTML.AppendLine("</table>");
                //GetTargetProgressionByBranch End---------
                #endregion              
                #region TargetProgression By LOB Company
                //TargetProgression By LOB Company
                GetTargetProgressionByLOB = _trackerReportingRepository.GetTargetProgressionReportsByLOB(trackingReportingCommonFilterInputModel);
                List<TargetProgressionByCompany> LobByCompany = new List<TargetProgressionByCompany>();
                LobByCompany = GetTargetProgressionByLOB.LobByCompany;
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = effectiveDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = effectiveDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = expirationDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = expirationDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = createDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = createDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = null;
                }
                DataTable dtt = new DataTable();
                strHTML.AppendLine("<center><span  style='font-family: Arial; font-size: 20pt;'>TargetProgression By Company</b></span></center><br/><br/>");
                strHTML.AppendLine("<p align= 'left' style='font-family: Arial; font-size: 10pt; text-align:left'><b>All the figures listed below are in (USD)</b></p>");
                strHTML.AppendLine("<table border=1 ID='Table2'>");

                int i1;
                for (i1 = 0; i1 < 1; i1++)
                {
                    strHTML.AppendLine("<thead style='display: table-header-group'><tr>");

                    strHTML.AppendLine("<th colspan=1 style='width:25%'  bgcolor='#3980c6' valign=top><font  color='white'>" + "Company Name" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Targets" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6'  valign=top><font color='white'>" + "Total Outstanding (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Outstanding (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Outstanding (Forecast $)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Closed (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Closed (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Targets Rolled (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Targets Rolled (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received Quotes #" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received Bound #" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Bound (Forecast $)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Unbound RF (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Unbound RF (%)" + "</font></th>");

                    strHTML.AppendLine("</tr></thead>");
                    var TargetByLOBCompany = LobByCompany.GroupBy(s => new { s.CompanyName });
                    foreach (var item in TargetByLOBCompany)
                    {
                        if (item.Key.CompanyName != null)
                        {
                            strHTML.AppendLine("<tr>");
                            strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#8c8c8c' valign=top><font color='black'>" + item.Key.CompanyName + "</font></td>");
                            int ii = 1;
                            foreach (var item22 in item)
                            {
                                if (ii == 1)
                                {

                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TotalTargets) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsOutStandingCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsOutStandingPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsOutStandingForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsClosedCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsClosedPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetRolledForwardCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetRolledForwardPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedSubmissionCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedSubmissionPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedQuotes) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedBound) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedBoundForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.UnBoundRFCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.UnBoundRFPercentage) + "</font></td>");
                                    strHTML.AppendLine("</tr>");
                                    ii++;

                                }

                            }
                        }

                        var ss = item.GroupBy(c => new { c.TargetConfidence }).ToList();
                        foreach (var item1 in ss)
                        {
                            if (item1.Key.TargetConfidence != null)
                            {
                                strHTML.AppendLine("<tr>");
                                strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item1.Key.TargetConfidence + "</font></td>");
                                int kk = 1;
                                foreach (var item33 in item1)
                                {
                                    if (kk == 1)
                                    {

                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TotalTargets) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsOutStandingCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsOutStandingPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsOutStandingForecast) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsClosedCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsClosedPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetRolledForwardCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetRolledForwardPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedSubmissionCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedSubmissionPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedQuotes) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedBound) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item33.SubmissionReceivedBoundForecast + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item33.UnBoundRFCount + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item33.UnBoundRFPercentage + "</font></td>");
                                        strHTML.AppendLine("</tr>");
                                        kk++;
                                    }

                                }
                            }
                        }
                    }
                }
                strHTML.AppendLine("</table>");
                #endregion
                #region TargetProgression By LOB Division
                //TargetProgression By LOB Division
                List<TargetProgressionByDivision> LobByDivision = new List<TargetProgressionByDivision>();
                LobByDivision = GetTargetProgressionByLOB.LobByDivision;
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = effectiveDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = effectiveDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = expirationDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = expirationDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = createDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = createDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = null;
                }
                DataTable dttd = new DataTable();
                strHTML.AppendLine("<center><span  style='font-family: Arial; font-size: 20pt;'>TargetProgression By Division</b></span></center><br/><br/>");
                strHTML.AppendLine("<p align= 'left' style='font-family: Arial; font-size: 10pt; text-align:left'><b>All the figures listed below are in (USD)</b></p>");
                strHTML.AppendLine("<table border=1 ID='Table2'>");

                int i2;
                for (i2 = 0; i2 < 1; i2++)
                {
                    strHTML.AppendLine("<thead style='display: table-header-group'><tr>");

                    strHTML.AppendLine("<th colspan=1 style='width:25%'  bgcolor='#3980c6' valign=top><font  color='white'>" + "Division" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Targets" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6'  valign=top><font color='white'>" + "Total Outstanding (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Outstanding (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Outstanding (Forecast $)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Closed (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Closed (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Targets Rolled (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Targets Rolled (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received Quotes #" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received Bound #" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Bound (Forecast $)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Unbound RF (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Unbound RF (%)" + "</font></th>");

                    strHTML.AppendLine("</tr></thead>");
                    var TargetByLOBDivision = LobByDivision.GroupBy(s => new { s.Division });
                    foreach (var item in TargetByLOBDivision)
                    {
                        if (item.Key.Division != null)
                        {
                            strHTML.AppendLine("<tr>");
                            strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#8c8c8c' valign=top><font color='black'>" + item.Key.Division + "</font></td>");
                            int ii = 1;
                            foreach (var item22 in item)
                            {
                                if (ii == 1)
                                {

                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TotalTargets) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsOutStandingCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsOutStandingPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsOutStandingForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsClosedCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsClosedPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetRolledForwardCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetRolledForwardPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedSubmissionCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedSubmissionPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedQuotes) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedBound) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedBoundForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.UnBoundRFCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.UnBoundRFPercentage) + "</font></td>");
                                    strHTML.AppendLine("</tr>");
                                    ii++;

                                }

                            }
                        }

                        var ss = item.GroupBy(c => new { c.TargetConfidence }).ToList();
                        foreach (var item1 in ss)
                        {
                            if (item1.Key.TargetConfidence != null)
                            {
                                strHTML.AppendLine("<tr>");
                                strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item1.Key.TargetConfidence + "</font></td>");
                                int kk = 1;
                                foreach (var item33 in item1)
                                {
                                    if (kk == 1)
                                    {

                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TotalTargets) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsOutStandingCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsOutStandingPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsOutStandingForecast) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsClosedCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsClosedPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetRolledForwardCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetRolledForwardPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedSubmissionCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedSubmissionPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedQuotes) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedBound) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item33.SubmissionReceivedBoundForecast + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item33.UnBoundRFCount + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item33.UnBoundRFPercentage + "</font></td>");
                                        strHTML.AppendLine("</tr>");
                                        kk++;
                                    }

                                }
                            }
                        }
                    }
                }
                strHTML.AppendLine("</table>");
                #endregion
                #region Target Progression By Unit
                //Target Progression By Unit
                List<TargetProgressionByUnit> LobByUnit = new List<TargetProgressionByUnit>();
                LobByUnit = GetTargetProgressionByLOB.LobByUnit;
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = effectiveDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = effectiveDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = expirationDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = expirationDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = createDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = createDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = null;
                }
                DataTable dttu = new DataTable();
                strHTML.AppendLine("<center><span  style='font-family: Arial; font-size: 20pt;'>TargetProgression By Unit</b></span></center><br/><br/>");
                strHTML.AppendLine("<p align= 'left' style='font-family: Arial; font-size: 10pt; text-align:left'><b>All the figures listed below are in (USD)</b></p>");
                strHTML.AppendLine("<table border=1 ID='Table2'>");

                int i3;
                for (i3 = 0; i3 < 1; i3++)
                {
                    strHTML.AppendLine("<thead style='display: table-header-group'><tr>");

                    strHTML.AppendLine("<th colspan=1 style='width:25%'  bgcolor='#3980c6' valign=top><font  color='white'>" + "Unit" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Targets" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6'  valign=top><font color='white'>" + "Total Outstanding (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Outstanding (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Outstanding (Forecast $)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Closed (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Closed (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Targets Rolled (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Targets Rolled (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received Quotes #" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received Bound #" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Bound (Forecast $)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Unbound RF (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Unbound RF (%)" + "</font></th>");

                    strHTML.AppendLine("</tr></thead>");
                    var TargetByLOBUnit = LobByUnit.GroupBy(s => new { s.Unit });
                    foreach (var item in TargetByLOBUnit)
                    {
                        if (item.Key.Unit != null)
                        {
                            strHTML.AppendLine("<tr>");
                            strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#8c8c8c' valign=top><font color='black'>" + item.Key.Unit + "</font></td>");
                            int ii = 1;
                            foreach (var item22 in item)
                            {
                                if (ii == 1)
                                {

                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TotalTargets) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsOutStandingCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsOutStandingPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsOutStandingForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsClosedCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsClosedPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetRolledForwardCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetRolledForwardPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedSubmissionCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedSubmissionPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedQuotes) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedBound) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedBoundForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.UnBoundRFCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.UnBoundRFPercentage) + "</font></td>");
                                    strHTML.AppendLine("</tr>");
                                    ii++;

                                }

                            }
                        }

                        var ss = item.GroupBy(c => new { c.TargetConfidence }).ToList();
                        foreach (var item1 in ss)
                        {
                            if (item1.Key.TargetConfidence != null)
                            {
                                strHTML.AppendLine("<tr>");
                                strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item1.Key.TargetConfidence + "</font></td>");
                                int kk = 1;
                                foreach (var item33 in item1)
                                {
                                    if (kk == 1)
                                    {

                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TotalTargets) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsOutStandingCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsOutStandingPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsOutStandingForecast) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsClosedCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsClosedPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetRolledForwardCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetRolledForwardPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedSubmissionCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedSubmissionPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedQuotes) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedBound) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item33.SubmissionReceivedBoundForecast + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item33.UnBoundRFCount + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item33.UnBoundRFPercentage + "</font></td>");
                                        strHTML.AppendLine("</tr>");
                                        kk++;
                                    }

                                }
                            }
                        }
                    }
                }
                strHTML.AppendLine("</table>");
                #endregion
                #region Target Progression By LOB Segment
                //Target Progression By LOB Segment
                List<TargetProgressionBySegment> LobBySegment = new List<TargetProgressionBySegment>();
                LobBySegment = GetTargetProgressionByLOB.LobBySegment;
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = effectiveDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = effectiveDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = expirationDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = expirationDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = createDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = createDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = null;
                }
                DataTable dtts = new DataTable();
                strHTML.AppendLine("<center><span  style='font-family: Arial; font-size: 20pt;'>TargetProgression By Segment</b></span></center><br/><br/>");
                strHTML.AppendLine("<p align= 'left' style='font-family: Arial; font-size: 10pt; text-align:left'><b>All the figures listed below are in (USD)</b></p>");
                strHTML.AppendLine("<table border=1 ID='Table2'>");

                int i4;
                for (i4 = 0; i4 < 1; i4++)
                {
                    strHTML.AppendLine("<thead style='display: table-header-group'><tr>");

                    strHTML.AppendLine("<th colspan=1 style='width:25%'  bgcolor='#3980c6' valign=top><font  color='white'>" + "Segment" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Targets" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6'  valign=top><font color='white'>" + "Total Outstanding (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Outstanding (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Outstanding (Forecast $)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Closed (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Closed (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Targets Rolled (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Targets Rolled (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received (%)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received Quotes #" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Submissions Received Bound #" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Bound (Forecast $)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Unbound RF (Count)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Unbound RF (%)" + "</font></th>");

                    strHTML.AppendLine("</tr></thead>");
                    var TargetByLOBSegment = LobBySegment.GroupBy(s => new { s.Segment });
                    foreach (var item in TargetByLOBSegment)
                    {
                        if (item.Key.Segment != null)
                        {
                            strHTML.AppendLine("<tr>");
                            strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#8c8c8c' valign=top><font color='black'>" + item.Key.Segment + "</font></td>");
                            int ii = 1;
                            foreach (var item22 in item)
                            {
                                if (ii == 1)
                                {

                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TotalTargets) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsOutStandingCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsOutStandingPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsOutStandingForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsClosedCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetsClosedPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetRolledForwardCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.TargetRolledForwardPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedSubmissionCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedSubmissionPercentage) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedQuotes) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedBound) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.SubmissionReceivedBoundForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.UnBoundRFCount) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item22.UnBoundRFPercentage) + "</font></td>");
                                    strHTML.AppendLine("</tr>");
                                    ii++;

                                }

                            }
                        }

                        var ss = item.GroupBy(c => new { c.TargetConfidence }).ToList();
                        foreach (var item1 in ss)
                        {
                            if (item1.Key.TargetConfidence != null)
                            {
                                strHTML.AppendLine("<tr>");
                                strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item1.Key.TargetConfidence + "</font></td>");
                                int kk = 1;
                                foreach (var item33 in item1)
                                {
                                    if (kk == 1)
                                    {

                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TotalTargets) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsOutStandingCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsOutStandingPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsOutStandingForecast) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsClosedCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetsClosedPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetRolledForwardCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.TargetRolledForwardPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedSubmissionCount) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedSubmissionPercentage) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedQuotes) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item33.SubmissionReceivedBound) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item33.SubmissionReceivedBoundForecast + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item33.UnBoundRFCount + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item33.UnBoundRFPercentage + "</font></td>");
                                        strHTML.AppendLine("</tr>");
                                        kk++;
                                    }

                                }
                            }
                        }
                    }
                }
                strHTML.AppendLine("</table>");
                #endregion
            }
            //targetprogression end 
            if (trackingReportingCommonFilterInputModel.ReportName == "Forecast Division")
            {
                forecastByBusinessSegmentOutputModel = _trackerReportingRepository.GetForecastSummaryTotal(trackingReportingCommonFilterInputModel);


                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = effectiveDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = effectiveDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = expirationDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = expirationDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = createDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = createDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = null;
                }
                DataTable dt = new DataTable();
                strHTML.AppendLine("<center><span  style='font-family: Arial; font-size: 20pt;'>Forecast Division Report</b></span></center><br/><br/>");
                strHTML.AppendLine("<p align= 'left' style='font-family: Arial; font-size: 10pt; text-align:left'><b>All the figures listed below are in (USD)</b></p>");


                strHTML.AppendLine("<table ID='Table2'>");


                int i;
                for (i = 0; i < 1; i++)
                {
                    strHTML.AppendLine("<thead style='display: table-header-group'><tr>");

                    strHTML.AppendLine("<th colspan=1 style='width:25%'  bgcolor='#3980c6' valign=top><font  color='white'>" + "Division" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Renewal Base (USD)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Renewal Forecast (USD)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6'  valign=top><font color='white'>" + "New Forecast (USD)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Other Forecast (USD)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Forecast (USD)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Plan (USD)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Forecast vs Plan (USD)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Forecast vs Plan %" + "</font></th>");
                    strHTML.AppendLine("</tr></thead>");

                }

                var q = forecastByBusinessSegmentOutputModel.GroupBy(s => new { s.Company });

                foreach (var item in q)
                {
                    if (item.Key.Company != null)
                    {

                        strHTML.AppendLine("<tr>");
                        strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#8c8c8c' valign=top><font color='black'>" + item.Key.Company + "</font></td>");
                        int ii = 1;
                        foreach (var item44 in item)
                        {

                            if (ii == 1)
                            {

                                strHTML.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.RenewalBase) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1 bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.RenewalForecast) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1 bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.NewForecast) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1 bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.OtherForecast) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1 bgcolor='#8c8c8c'   valign=top><font color='black'>" + String.Format("{0:n0}", item44.TotalForecast) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1 bgcolor='#8c8c8c'  valign=top><font color='black'>" + String.Format("{0:n0}", item44.Plan) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1 bgcolor='#8c8c8c'  valign=top><font color='black'>" + String.Format("{0:n0}", item44.ForecastvsPlanUSD) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1 bgcolor='#8c8c8c'  valign=top><font color='black'>" + item44.ForecastvsPlanPercentage + "</font></td>");
                                strHTML.AppendLine("</tr>");
                                ii++;
                            }
                        }

                    }
                    var ss = item.GroupBy(c => new { c.Division }).ToList();

                    foreach (var item1 in ss)
                    {
                        if (item1.Key.Division != null)
                        {
                            strHTML.AppendLine("<tr>");
                            strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item1.Key.Division + "</font></td>");
                            int kk = 1;
                            foreach (var item55 in item1)
                            {

                                if (kk == 1)
                                {
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item55.RenewalBase) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item55.RenewalForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", item55.NewForecast) + "</font></td>");

                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.OtherForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.TotalForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.Plan) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.ForecastvsPlanUSD) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + item55.ForecastvsPlanPercentage + "</font></td>");
                                    strHTML.AppendLine("</tr>");
                                    kk++;
                                }
                            }

                        }
                        var ss1 = item1.GroupBy(c => new { c.Unit }).ToList();

                        foreach (var item2 in ss1)

                        {
                            if (item2.Key.Unit != null)
                            {
                                strHTML.AppendLine("<tr>");
                                strHTML.AppendLine("<td colspan=1 style='width:25%' bgcolor='#e6e6e6' width='20%' valign=top><font color='black'>" + item2.Key.Unit + "</font></td>");
                                int nn = 1;
                                foreach (var item66 in item2)
                                {


                                    if (nn == 1)
                                    {

                                        strHTML.AppendLine("<td colspan=1 bgcolor='#e6e6e6' valign=top><font color='black'>" + String.Format("{0:n0}", item66.RenewalBase) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#e6e6e6' valign=top><font color='black'>" + String.Format("{0:n0}", item66.RenewalForecast) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#e6e6e6' valign=top><font color='black'>" + String.Format("{0:n0}", item66.NewForecast) + "</font></td>");

                                        strHTML.AppendLine("<td colspan=1 bgcolor='#e6e6e6' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.OtherForecast) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#e6e6e6'  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.TotalForecast) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#e6e6e6' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.Plan) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#e6e6e6' width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item66.ForecastvsPlanUSD) + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1 bgcolor='#e6e6e6' width='20%' valign=top><font color='black'>" + item66.ForecastvsPlanPercentage + "</font></td>");
                                        strHTML.AppendLine("</tr>");
                                        nn++;
                                    }
                                }

                            }
                            var ss2 = item2.GroupBy(c => new { c.Segment }).ToList();
                            foreach (var item5 in ss2)
                            {
                                if (item5.Key.Segment != null)
                                {
                                    strHTML.AppendLine("<tr>");

                                    strHTML.AppendLine("<td colspan=1 style='width:25%' valign=top><font color='black'>" + item5.Key.Segment + "</font></td>");
                                    int jj = 1;
                                    foreach (var item77 in item5)
                                    {

                                        if (jj == 1)
                                        {
                                            strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + String.Format("{0:n0}", item77.RenewalBase) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + String.Format("{0:n0}", item77.RenewalForecast) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + String.Format("{0:n0}", item77.NewForecast) + "</font></td>");

                                            strHTML.AppendLine("<td colspan=1 width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.OtherForecast) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.TotalForecast) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.Plan) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item77.ForecastvsPlanUSD) + "</font></td>");
                                            strHTML.AppendLine("<td colspan=1 width='20%' valign=top><font color='black'>" + item77.ForecastvsPlanPercentage + "</font></td>");
                                            strHTML.AppendLine("</tr>");
                                            jj++;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }


                strHTML.AppendLine("</table>");
            }

            //ForecastRegionTotal
            else if (trackingReportingCommonFilterInputModel.ReportName == "Forecast Region")
            {

                sb2.Append(trackingReportingCommonFilterInputModel.CreateDateEnd);
                lGetForecastRegionTotal = _trackerReportingRepository.GetForecastRegionTotal(trackingReportingCommonFilterInputModel);

                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = effectiveDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = effectiveDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.EffectiveDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = expirationDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = expirationDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.ExpirationDateEnd = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = createDateStart;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateStart = null;
                }
                if (flag == 1)
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = createDateEnd;
                }
                else
                {
                    trackingReportingCommonFilterInputModel.CreateDateEnd = null;
                }
                strHTML.AppendLine("<center><span  style='font-family: Arial; font-size: 20pt;'>Forecast Region Report</b></span></center><br/><br/>");
                strHTML.AppendLine("<p align= 'left' style='font-family: Arial; font-size: 10pt; text-align:left'><b>All the figures listed below are in (USD)</b></p>");
                strHTML.AppendLine("<table border=1 ID='Table2'>");
                int i;
                for (i = 0; i < 1; i++)
                {
                    strHTML.AppendLine("<thead style='display: table-header-group'><tr>");
                    strHTML.AppendLine("<th colspan=1 width='20%' bgcolor='#3980c6' valign=top><font  color='white'>" + "Credited Branch/Region" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Renewal Base (USD)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6'  valign=top><font color='white'>" + "Renewal Forecast (USD)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "New Forecast (USD)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Other Forecast (USD)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Total Forecast (USD)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Plan (USD)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Forecast vs Plan (USD)" + "</font></th>");
                    strHTML.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + "Forecast vs Plan %" + "</font></th>");
                    strHTML.AppendLine("</tr></thead>");


                }

                var q = lGetForecastRegionTotal.GroupBy(s => new { s.CreditedRegion });

                foreach (var item in q)
                {
                    if (item.Key.CreditedRegion != null)
                    {

                        strHTML.AppendLine("<tr>");
                        strHTML.AppendLine("<td colspan=1 width='20%' bgcolor='#8c8c8c' valign=top><font color='black'>" + item.Key.CreditedRegion + "</font></td>");
                        int ii = 1;
                        foreach (var item44 in item)
                        {

                            if (ii == 1)
                            {

                                strHTML.AppendLine("<td colspan=1 bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.RenewalBase) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1 bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.RenewalForecast) + "</font></td>");

                                strHTML.AppendLine("<td colspan=1 bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.NewForecast) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1 bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}", item44.OtherForecast) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1 bgcolor='#8c8c8c'   valign=top><font color='black'>" + String.Format("{0:n0}", item44.TotalForecast) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1 bgcolor='#8c8c8c'  valign=top><font color='black'>" + String.Format("{0:n0}", item44.Plan) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1 bgcolor='#8c8c8c'  valign=top><font color='black'>" + String.Format("{0:n0}", item44.ForecastvsPlanUSD) + "</font></td>");
                                strHTML.AppendLine("<td colspan=1 bgcolor='#8c8c8c'  valign=top><font color='black'>" + item44.ForecastvsPlanPercentage + "</font></td>");
                                strHTML.AppendLine("</tr>");
                                ii++;
                            }
                        }

                    }
                    var ss = item.GroupBy(c => new { c.CreditedBranch }).ToList();

                    foreach (var item1 in ss)
                    {
                        if (item1.Key.CreditedBranch != null)
                        {
                            strHTML.AppendLine("<tr>");
                            strHTML.AppendLine("<td colspan=1 width='20%' valign=top><font color='black'>" + item1.Key.CreditedBranch + "</font></td>");
                            int kk = 1;
                            foreach (var item55 in item1)
                            {
                                if (kk == 1)
                                {
                                    strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + String.Format("{0:n0}", item55.RenewalBase) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + String.Format("{0:n0}", item55.RenewalForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + String.Format("{0:n0}", item55.NewForecast) + "</font></td>");

                                    strHTML.AppendLine("<td colspan=1 width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.OtherForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.TotalForecast) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.Plan) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 width='20%' valign=top><font color='black'>" + String.Format("{0:n0}", item55.ForecastvsPlanUSD) + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1 width='20%' valign=top><font color='black'>" + item55.ForecastvsPlanPercentage + "</font></td>");
                                    strHTML.AppendLine("</tr>");
                                }
                            }

                        }

                    }
                }

                strHTML.AppendLine("</table>");

            }





            strHTML.Append("<br/><br/><br/><table ID='Legend'>");
            strHTML.AppendLine("<tr><td colspan=6 align=center bgcolor='#3980c6' valign=top><font color='white' size=5><b>Report Criteria</b></font></td></tr>");
            strHTML.AppendLine("<tr>");
            int ICount = 0;

            foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
            {
                List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, ";");
                if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                {
                    if (!info.PropertyType.Name.Contains("List"))
                    {
                        var value = info.GetValue(trackingReportingCommonFilterInputModel, null);


                        var filter = info.Name + ":" + value + ";";

                        if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "FilterBy" && info.Name != "GroupBy" && info.Name != "PageNumber" && info.Name != "PageSize" && info.Name != "ScreenName" && info.Name != "BrowseByValue" && info.Name != "BrowseByProducer" && info.Name != "BrowseByTitle" && info.Name != "DisableBrowseBy" && info.Name != "UserID")
                        {
                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                strHTML.AppendLine("</tr><tr>");
                            }

                            strHTML.AppendLine("<tr><td colspan=3 valign=top><font color='black'>" + info.Name + "</font></td><td colspan=3 valign=top><font color='black'>" + value + "</font></td></tr>");
                        }

                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(listValue))
                        {
                            var filter = info.Name + ":" + listValue + ";";

                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                strHTML.AppendLine("</tr><tr>");
                            }
                            strHTML.AppendLine("<tr><td colspan=3 valign=top><font color='black'>" + info.Name + "</font></td><td colspan=3 valign=top><font color='black'>" + listValue + "</font></td></tr>");
                        }
                    }

                }

            }

            if (ICount % 4 != 0)
            {
                strHTML.AppendLine("</tr");
            }
            strHTML.AppendLine("</table>");
            strHTML.AppendLine("</table>");


            strHTML.Append("</body>");
            strHTML.Append("</html>");


            String finalcontent = strHTML.ToString();

            //ForecastDivisionDetailsTotal
            if (trackingReportingCommonFilterInputModel.ReportName == "Forecast Division")
            {
                strReportHeader = "Forecast Division Report";
            }
            else
            {
                strReportHeader = "Forecast Region Report";
            }
            if (trackingReportingCommonFilterInputModel.ReportName == "Scorecard")
            {
                strReportHeader = "Scorecard Report";
            }


            return WinnovativeConverter(finalcontent, strReportHeader);
        }


        public List<string> GetScorecardDownload(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            StringBuilder strHTML = new StringBuilder();
            StringBuilder strHTML1 = new StringBuilder();
            StringBuilder strHTML2 = new StringBuilder();

            DateTime? effectiveDateStart = trackingReportingCommonFilterInputModel.EffectiveDateStart;
            DateTime? effectiveDateEnd = trackingReportingCommonFilterInputModel.EffectiveDateEnd;
            DateTime? expirationDateStart = trackingReportingCommonFilterInputModel.ExpirationDateStart;
            DateTime? expirationDateEnd = trackingReportingCommonFilterInputModel.ExpirationDateEnd;
            DateTime? createDateStart = trackingReportingCommonFilterInputModel.CreateDateStart;
            DateTime? createDateEnd = trackingReportingCommonFilterInputModel.CreateDateEnd;


            List<ScorecardByStatusOutputModel> ScorecardNewBusinessByStatus = new List<ScorecardByStatusOutputModel>();
            List<ScorecardRenewalByStatusOutputModel> ScorecardRenewalByStatus = new List<ScorecardRenewalByStatusOutputModel>();
            List<ScorecardAmountPerDivionOutputModel> ScorecardAmountPerDivision = new List<ScorecardAmountPerDivionOutputModel>();

            List<string> workingList = new List<string>();

            int flag = 0;
            if (effectiveDateStart.HasValue)
            {
                flag = 1;
            }
            else if (effectiveDateEnd.HasValue)
            {
                flag = 1;
            }
            else if (expirationDateStart.HasValue)
            {
                flag = 1;
            }
            else if (expirationDateEnd.HasValue)
            {
                flag = 1;
            }
            else if (createDateStart.HasValue)
            {
                flag = 1;
            }
            else if (createDateEnd.HasValue)
            {
                flag = 1;
            }
            ScorecardNewBusinessByStatus = _trackerReportingRepository.GetScorecardNewBusinessByStatus(trackingReportingCommonFilterInputModel);
            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.EffectiveDateStart = effectiveDateStart;
            }
            else
            {
                trackingReportingCommonFilterInputModel.EffectiveDateStart = null;
            }
            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.EffectiveDateEnd = effectiveDateEnd;
            }
            else
            {
                trackingReportingCommonFilterInputModel.EffectiveDateEnd = null;
            }
            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.ExpirationDateStart = expirationDateStart;
            }
            else
            {
                trackingReportingCommonFilterInputModel.ExpirationDateStart = null;
            }
            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.ExpirationDateEnd = expirationDateEnd;
            }
            else
            {
                trackingReportingCommonFilterInputModel.ExpirationDateEnd = null;
            }
            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.CreateDateStart = createDateStart;
            }
            else
            {
                trackingReportingCommonFilterInputModel.CreateDateStart = null;
            }
            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.CreateDateEnd = createDateEnd;
            }
            else
            {
                trackingReportingCommonFilterInputModel.CreateDateEnd = null;
            }

            DataTable dt = new DataTable();
            strHTML.AppendLine("<center><span  style='font-family: Arial; font-size: 13.5pt;'>Scorecard New Business Status Report</b></span></center><br/><br/>");
            strHTML.AppendLine("<p align= 'left' style='font-family: Arial; font-size: 10pt; text-align:left'><b>All the figures listed below are in (USD)</b></p>");


            strHTML.AppendLine("<table border=1 ID='Table1'>");


            int i;
            for (i = 0; i < 1; i++)
            {
                strHTML.AppendLine("<thead style='display: table-header-group'><tr>");

                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font  color='white'>" + "Division" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "SubmissionCountPrior" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "SubmissionCountTotal" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black'  valign=top><font color='white'>" + "QuoteCountPrior" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "QuoteCountTotal" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "QuotetoSubmissionRatio" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "BoundCountPrior" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "BoundCountTotal" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "BoundtoQuoteRatio" + "</font></th>");
                strHTML.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "BoundtoSubmissionRatio" + "</font></th>");
                strHTML.AppendLine("</tr></thead>");

            }

            var q = ScorecardNewBusinessByStatus.GroupBy(s => new { s.Company });

            foreach (var item in q)
            {
                if (item.Key.Company != null)
                {

                    strHTML.AppendLine("<tr>");
                    strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item.Key.Company + "</font></td>");
                    int ii = 1;
                    foreach (var item44 in item)
                    {

                        if (ii == 1)
                        {

                            strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.SubmissionCountPrior + "</font></td>");
                            strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.SubmissionCountTotal + "</font></td>");

                            strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.QuoteCountPrior + "</font></td>");
                            strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.QuoteCountTotal + "</font></td>");
                            strHTML.AppendLine("<td colspan=1  bgcolor='#ff8000'  valign=top><font color='black'>" + item44.QuotetoSubmissionRatio + "</font></td>");
                            strHTML.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.BoundCountPrior + "</font></td>");
                            strHTML.AppendLine("<td colspan=1  bgcolor='#ff8000' valign=top><font color='black'>" + item44.BoundCountTotal + "</font></td>");
                            strHTML.AppendLine("<td colspan=1  bgcolor='#ff8000' valign=top><font color='black'>" + item44.BoundtoQuoteRatio + "</font></td>");
                            strHTML.AppendLine("<td colspan=1  bgcolor='#ff8000' valign=top><font color='black'>" + item44.BoundtoSubmissionRatio + "</font></td>");
                            strHTML.AppendLine("</tr>");
                            ii++;
                        }
                    }

                }
                var ss = item.GroupBy(c => new { c.Division }).ToList();

                foreach (var item1 in ss)
                {
                    if (item1.Key.Division != null)
                    {
                        strHTML.AppendLine("<tr>");
                        strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item1.Key.Division + "</font></td>");
                        int kk = 1;
                        foreach (var item55 in item1)
                        {

                            if (kk == 1)
                            {
                                strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.SubmissionCountPrior + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.SubmissionCountTotal + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.QuoteCountPrior + "</font></td>");
                                strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.QuoteCountTotal + "</font></td>");
                                strHTML.AppendLine("<td colspan=1    valign=top><font color='black'>" + item55.QuotetoSubmissionRatio + "</font></td>");
                                strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item55.BoundCountPrior + "</font></td>");
                                strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item55.BoundCountTotal + "</font></td>");
                                strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item55.BoundtoQuoteRatio + "</font></td>");
                                strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item55.BoundtoSubmissionRatio + "</font></td>");
                                strHTML.AppendLine("</tr>");
                                kk++;
                            }
                        }

                    }
                    var ss1 = item1.GroupBy(c => new { c.Unit }).ToList();

                    foreach (var item2 in ss1)

                    {
                        if (item2.Key.Unit != null)
                        {
                            strHTML.AppendLine("<tr>");
                            strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item2.Key.Unit + "</font></td>");
                            int nn = 1;
                            foreach (var item66 in item2)
                            {


                                if (nn == 1)
                                {

                                    strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.SubmissionCountPrior + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.SubmissionCountTotal + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.QuoteCountPrior + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.QuoteCountTotal + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1    valign=top><font color='black'>" + item66.QuotetoSubmissionRatio + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item66.BoundCountPrior + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item66.BoundCountTotal + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item66.BoundtoQuoteRatio + "</font></td>");
                                    strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item66.BoundtoSubmissionRatio + "</font></td>");
                                    strHTML.AppendLine("</tr>");
                                    nn++;
                                }
                            }

                        }
                        var ss2 = item2.GroupBy(c => new { c.Segment }).ToList();
                        foreach (var item5 in ss2)
                        {
                            if (item5.Key.Segment != null)
                            {
                                strHTML.AppendLine("<tr>");

                                strHTML.AppendLine("<td colspan=1 valign=top><font color='black'>" + item5.Key.Segment + "</font></td>");
                                int jj = 1;
                                foreach (var item77 in item5)
                                {

                                    if (jj == 1)
                                    {
                                        strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.SubmissionCountPrior + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.SubmissionCountTotal + "</font></td>");

                                        strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.QuoteCountPrior + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.QuoteCountTotal + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1    valign=top><font color='black'>" + item77.QuotetoSubmissionRatio + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item77.BoundCountPrior + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item77.BoundCountTotal + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item77.BoundtoQuoteRatio + "</font></td>");
                                        strHTML.AppendLine("<td colspan=1   valign=top><font color='black'>" + item77.BoundtoSubmissionRatio + "</font></td>");
                                        strHTML.AppendLine("</tr>");
                                        jj++;
                                    }
                                }
                            }
                        }
                    }
                }
            }


            strHTML.AppendLine("</table>");




            strHTML.Append("<table cellspacing=1 cellpadding=1 border=1 ID='Table2'>");
            strHTML.AppendLine("<tr><td colspan=5 align=center><font color='#000000' size=3><b>Selected Search Criteria</b></font></td></tr>");
            strHTML.AppendLine("<tr>");
            int ICount = 0;

            foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
            {
                List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                {
                    if (!info.PropertyType.Name.Contains("List"))
                    {
                        var value = info.GetValue(trackingReportingCommonFilterInputModel, null);

                        var filter = info.Name + ":" + value + ";";
                        if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "FilterBy" && info.Name != "GroupBy" && info.Name != "PageNumber" && info.Name != "PageSize" && info.Name != "ScreenName" && info.Name != "BrowseByValue" && info.Name != "BrowseByProducer" && info.Name != "BrowseByTitle" && info.Name != "DisableBrowseBy")
                        {
                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                strHTML.AppendLine("</tr><tr>");
                            }
                            strHTML.AppendLine("<td colspan=1 valign=top><font color='#0000FF'>" + filter + "</font></td>");
                        }

                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(listValue))
                        {
                            var filter = info.Name + ":" + listValue + ";";

                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                strHTML.AppendLine("</tr><tr>");
                            }
                            strHTML.AppendLine("<td colspan=1 valign=top><font color='#0000FF'>" + filter + "</font></td>");
                        }
                    }

                }

            }

            if (ICount % 4 != 0)
            {
                strHTML.AppendLine("</tr");
            }
            strHTML.AppendLine("</table>");




            ScorecardRenewalByStatus = _trackerReportingRepository.GetScorecardRenewalByStatus(trackingReportingCommonFilterInputModel);

            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.EffectiveDateStart = effectiveDateStart;
            }
            else
            {
                trackingReportingCommonFilterInputModel.EffectiveDateStart = null;
            }
            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.EffectiveDateEnd = effectiveDateEnd;
            }
            else
            {
                trackingReportingCommonFilterInputModel.EffectiveDateEnd = null;
            }
            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.ExpirationDateStart = expirationDateStart;
            }
            else
            {
                trackingReportingCommonFilterInputModel.ExpirationDateStart = null;
            }
            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.ExpirationDateEnd = expirationDateEnd;
            }
            else
            {
                trackingReportingCommonFilterInputModel.ExpirationDateEnd = null;
            }
            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.CreateDateStart = createDateStart;
            }
            else
            {
                trackingReportingCommonFilterInputModel.CreateDateStart = null;
            }
            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.CreateDateEnd = createDateEnd;
            }
            else
            {
                trackingReportingCommonFilterInputModel.CreateDateEnd = null;
            }

            DataTable dtt = new DataTable();
            strHTML1.AppendLine("<center><span  style='font-family: Arial; font-size: 13.5pt;'>Scorecard Renewal Report</b></span></center><br/><br/>");
            strHTML1.AppendLine("<p align= 'left' style='font-family: Arial; font-size: 10pt; text-align:left'><b>All the figures listed below are in (USD)</b></p>");


            strHTML1.AppendLine("<table border=1 ID='Table3'>");


            int iii;
            for (iii = 0; iii < 1; iii++)
            {
                strHTML1.AppendLine("<tr>");

                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font  color='white'>" + "Division" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "SubmissionCountPrior" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "SubmissionCountTotal" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black'  valign=top><font color='white'>" + "QuoteCountPrior" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "QuoteCountTotal" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "QuotetoSubmissionRatio" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "BoundCountPrior" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "BoundCountTotal" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "BoundtoQuoteRatio" + "</font></th>");
                strHTML1.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "BoundtoSubmissionRatio" + "</font></th>");
                strHTML1.AppendLine("</tr>");

            }

            var qq = ScorecardRenewalByStatus.GroupBy(s => new { s.Company });

            foreach (var item in qq)
            {
                if (item.Key.Company != null)
                {

                    strHTML1.AppendLine("<tr>");
                    strHTML1.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item.Key.Company + "</font></td>");
                    int ii = 1;
                    foreach (var item44 in item)
                    {

                        if (ii == 1)
                        {
                            strHTML1.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.SubmissionCountPrior + "</font></td>");
                            strHTML1.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.SubmissionCountTotal + "</font></td>");
                            strHTML1.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.QuoteCountPrior + "</font></td>");
                            strHTML1.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.QuoteCountTotal + "</font></td>");
                            strHTML1.AppendLine("<td colspan=1  bgcolor='#ff8000'  valign=top><font color='black'>" + item44.QuotetoSubmissionRatio + "</font></td>");
                            strHTML1.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.BoundCountPrior + "</font></td>");
                            strHTML1.AppendLine("<td colspan=1  bgcolor='#ff8000' valign=top><font color='black'>" + item44.BoundCountTotal + "</font></td>");
                            strHTML1.AppendLine("<td colspan=1  bgcolor='#ff8000' valign=top><font color='black'>" + item44.BoundtoQuoteRatio + "</font></td>");
                            strHTML1.AppendLine("<td colspan=1  bgcolor='#ff8000' valign=top><font color='black'>" + item44.BoundtoSubmissionRatio + "</font></td>");
                            strHTML1.AppendLine("</tr>");
                            ii++;
                        }
                    }

                }
                var ss = item.GroupBy(c => new { c.Division }).ToList();

                foreach (var item1 in ss)
                {
                    if (item1.Key.Division != null)
                    {
                        strHTML1.AppendLine("<tr>");
                        strHTML1.AppendLine("<td colspan=1 valign=top><font color='black'>" + item1.Key.Division + "</font></td>");
                        int kk = 1;
                        foreach (var item55 in item1)
                        {

                            if (kk == 1)
                            {
                                strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.SubmissionCountPrior + "</font></td>");
                                strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.SubmissionCountTotal + "</font></td>");
                                strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.QuoteCountPrior + "</font></td>");
                                strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.QuoteCountTotal + "</font></td>");
                                strHTML1.AppendLine("<td colspan=1    valign=top><font color='black'>" + item55.QuotetoSubmissionRatio + "</font></td>");
                                strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item55.BoundCountPrior + "</font></td>");
                                strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item55.BoundCountTotal + "</font></td>");
                                strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item55.BoundtoQuoteRatio + "</font></td>");
                                strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item55.BoundtoSubmissionRatio + "</font></td>");
                                strHTML1.AppendLine("</tr>");
                                kk++;
                            }
                        }

                    }
                    var ss1 = item1.GroupBy(c => new { c.Unit }).ToList();

                    foreach (var item2 in ss1)

                    {
                        if (item2.Key.Unit != null)
                        {
                            strHTML1.AppendLine("<tr>");
                            strHTML1.AppendLine("<td colspan=1 valign=top><font color='black'>" + item2.Key.Unit + "</font></td>");
                            int nn = 1;
                            foreach (var item66 in item2)
                            {


                                if (nn == 1)
                                {

                                    strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.SubmissionCountPrior + "</font></td>");
                                    strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.SubmissionCountTotal + "</font></td>");
                                    strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.QuoteCountPrior + "</font></td>");
                                    strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.QuoteCountTotal + "</font></td>");
                                    strHTML1.AppendLine("<td colspan=1    valign=top><font color='black'>" + item66.QuotetoSubmissionRatio + "</font></td>");
                                    strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item66.BoundCountPrior + "</font></td>");
                                    strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item66.BoundCountTotal + "</font></td>");
                                    strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item66.BoundtoQuoteRatio + "</font></td>");
                                    strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item66.BoundtoSubmissionRatio + "</font></td>");
                                    strHTML1.AppendLine("</tr>");
                                    nn++;
                                }
                            }

                        }
                        var ss2 = item2.GroupBy(c => new { c.Segment }).ToList();
                        foreach (var item5 in ss2)
                        {
                            if (item5.Key.Segment != null)
                            {
                                strHTML1.AppendLine("<tr>");

                                strHTML1.AppendLine("<td colspan=1 valign=top><font color='black'>" + item5.Key.Segment + "</font></td>");
                                int jj = 1;
                                foreach (var item77 in item5)
                                {

                                    if (jj == 1)
                                    {
                                        strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.SubmissionCountPrior + "</font></td>");
                                        strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.SubmissionCountTotal + "</font></td>");
                                        strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.QuoteCountPrior + "</font></td>");
                                        strHTML1.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.QuoteCountTotal + "</font></td>");
                                        strHTML1.AppendLine("<td colspan=1    valign=top><font color='black'>" + item77.QuotetoSubmissionRatio + "</font></td>");
                                        strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item77.BoundCountPrior + "</font></td>");
                                        strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item77.BoundCountTotal + "</font></td>");
                                        strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item77.BoundtoQuoteRatio + "</font></td>");
                                        strHTML1.AppendLine("<td colspan=1   valign=top><font color='black'>" + item77.BoundtoSubmissionRatio + "</font></td>");
                                        strHTML1.AppendLine("</tr>");
                                        jj++;
                                    }
                                }
                            }
                        }
                    }
                }
            }


            strHTML1.AppendLine("</table>");




            strHTML1.Append("<table cellspacing=1 cellpadding=1 border=1 ID='Table5'>");
            strHTML1.AppendLine("<tr><td colspan=5 align=center><font color='#000000' size=3><b>Selected Search Criteria</b></font></td></tr>");
            strHTML1.AppendLine("<tr>");
            int ICount1 = 0;

            foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
            {
                List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                {
                    if (!info.PropertyType.Name.Contains("List"))
                    {
                        var value = info.GetValue(trackingReportingCommonFilterInputModel, null);

                        var filter = info.Name + ":" + value + ";";
                        if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "FilterBy" && info.Name != "GroupBy" && info.Name != "PageNumber" && info.Name != "PageSize" && info.Name != "ScreenName" && info.Name != "BrowseByValue" && info.Name != "BrowseByProducer" && info.Name != "BrowseByTitle" && info.Name != "DisableBrowseBy")
                        {
                            if (ICount1 > 1 && ICount1 % 4 == 0)
                            {
                                strHTML1.AppendLine("</tr><tr>");
                            }
                            strHTML1.AppendLine("<td colspan=1 valign=top><font color='#0000FF'>" + filter + "</font></td>");
                        }

                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(listValue))
                        {
                            var filter = info.Name + ":" + listValue + ";";

                            if (ICount1 > 1 && ICount1 % 4 == 0)
                            {
                                strHTML1.AppendLine("</tr><tr>");
                            }
                            strHTML1.AppendLine("<td colspan=1 valign=top><font color='#0000FF'>" + filter + "</font></td>");
                        }
                    }

                }

            }

            if (ICount1 % 4 != 0)
            {
                strHTML1.AppendLine("</tr");
            }
            strHTML1.AppendLine("</table>");

            ScorecardAmountPerDivision = _trackerReportingRepository.GetScorecardAmountPerDivision(trackingReportingCommonFilterInputModel);

            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.EffectiveDateStart = effectiveDateStart;
            }
            else
            {
                trackingReportingCommonFilterInputModel.EffectiveDateStart = null;
            }
            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.EffectiveDateEnd = effectiveDateEnd;
            }
            else
            {
                trackingReportingCommonFilterInputModel.EffectiveDateEnd = null;
            }
            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.ExpirationDateStart = expirationDateStart;
            }
            else
            {
                trackingReportingCommonFilterInputModel.ExpirationDateStart = null;
            }
            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.ExpirationDateEnd = expirationDateEnd;
            }
            else
            {
                trackingReportingCommonFilterInputModel.ExpirationDateEnd = null;
            }
            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.CreateDateStart = createDateStart;
            }
            else
            {
                trackingReportingCommonFilterInputModel.CreateDateStart = null;
            }
            if (flag == 1)
            {
                trackingReportingCommonFilterInputModel.CreateDateEnd = createDateEnd;
            }
            else
            {
                trackingReportingCommonFilterInputModel.CreateDateEnd = null;
            }

            strHTML2.AppendLine("<center><span  style='font-family: Arial; font-size: 13.5pt;'>Scorecard Amount Per Division Report</b></span></center><br/><br/>");
            strHTML2.AppendLine("<p align= 'left' style='font-family: Arial; font-size: 10pt; text-align:left'><b>All the figures listed below are in (USD)</b></p>");


            strHTML2.AppendLine("<table border=1 ID='Table6'>");


            int columnCount;
            for (columnCount = 0; columnCount < 1; columnCount++)
            {
                strHTML2.AppendLine("<tr>");

                strHTML2.AppendLine("<th colspan=1 bgcolor='black' valign=top><font  color='white'>" + "Division" + "</font></th>");
                strHTML2.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "TotalBoundPriorForecast" + "</font></th>");
                strHTML2.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "TotalBoundYearForecast" + "</font></th>");
                strHTML2.AppendLine("<th colspan=1 bgcolor='black'  valign=top><font color='white'>" + "TotalBoundPlan" + "</font></th>");
                strHTML2.AppendLine("<th colspan=1 bgcolor='black' valign=top><font  color='white'>" + "NewBusinessPriorForecast" + "</font></th>");
                strHTML2.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "NewBusinessYearForecast" + "</font></th>");
                strHTML2.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "NewBusinessPlan" + "</font></th>");
                strHTML2.AppendLine("<th colspan=1 bgcolor='black'  valign=top><font color='white'>" + "RenewalPriorForecast" + "</font></th>");
                strHTML2.AppendLine("<th colspan=1 bgcolor='black' valign=top><font  color='white'>" + "RenewalYearForecast" + "</font></th>");
                strHTML2.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "RenewalPlan" + "</font></th>");
                strHTML2.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "OtherPriorForecast" + "</font></th>");
                strHTML2.AppendLine("<th colspan=1 bgcolor='black'  valign=top><font color='white'>" + "OtherBusinessForecast" + "</font></th>");
                strHTML2.AppendLine("<th colspan=1 bgcolor='black' valign=top><font  color='white'>" + "OtherPlan" + "</font></th>");
                strHTML2.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "ForecastPercentagePrior" + "</font></th>");
                strHTML2.AppendLine("<th colspan=1 bgcolor='black' valign=top><font color='white'>" + "ForecastPercentagePlan" + "</font></th>");


                strHTML2.AppendLine("</tr>");

            }

            var UwSummaryTotal = ScorecardAmountPerDivision.GroupBy(s => new { s.Company });

            foreach (var item in UwSummaryTotal)
            {
                if (item.Key.Company != null)
                {

                    strHTML2.AppendLine("<tr>");
                    strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item.Key.Company + "</font></td>");
                    int ii = 1;
                    foreach (var item44 in item)
                    {

                        if (ii == 1)
                        {

                            strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.TotalBoundPriorForecast + "</font></td>");
                            strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.TotalBoundYearForecast + "</font></td>");
                            strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.TotalBoundPlan + "</font></td>");
                            strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.NewBusinessPriorForecast + "</font></td>");
                            strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.NewBusinessYearForecast + "</font></td>");
                            strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.NewBusinessPlan + "</font></td>");
                            strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.RenewalPriorForecast + "</font></td>");
                            strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.RenewalYearForecast + "</font></td>");
                            strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.RenewalPlan + "</font></td>");
                            strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.OtherPriorForecast + "</font></td>");
                            strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.OtherYearForecast + "</font></td>");
                            strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.OtherPlan + "</font></td>");
                            strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.ForecastPercentagePrior + "</font></td>");
                            strHTML2.AppendLine("<td colspan=1 bgcolor='#ff8000' valign=top><font color='black'>" + item44.ForecastPercentagePlan + "</font></td>");

                            strHTML2.AppendLine("</tr>");
                            ii++;
                        }
                    }

                }
                var ss = item.GroupBy(c => new { c.Division }).ToList();

                foreach (var item1 in ss)
                {
                    if (item1.Key.Division != null)
                    {
                        strHTML2.AppendLine("<tr>");
                        strHTML2.AppendLine("<td colspan=1 valign=top><font color='black'>" + item1.Key.Division + "</font></td>");
                        int kk = 1;
                        foreach (var item55 in item1)
                        {

                            if (kk == 1)
                            {
                                strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.TotalBoundPriorForecast + "</font></td>");
                                strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.TotalBoundYearForecast + "</font></td>");
                                strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.TotalBoundPlan + "</font></td>");
                                strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.NewBusinessPriorForecast + "</font></td>");
                                strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.NewBusinessYearForecast + "</font></td>");
                                strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.NewBusinessPlan + "</font></td>");
                                strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.RenewalPriorForecast + "</font></td>");
                                strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.RenewalYearForecast + "</font></td>");
                                strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.RenewalPlan + "</font></td>");
                                strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.OtherPriorForecast + "</font></td>");
                                strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.OtherYearForecast + "</font></td>");
                                strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.OtherPlan + "</font></td>");
                                strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.ForecastPercentagePrior + "</font></td>");
                                strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item55.ForecastPercentagePlan + "</font></td>");

                                strHTML2.AppendLine("</tr>");
                                kk++;
                            }
                        }

                    }
                    var ss1 = item1.GroupBy(c => new { c.Unit }).ToList();

                    foreach (var item2 in ss1)

                    {
                        if (item2.Key.Unit != null)
                        {
                            strHTML2.AppendLine("<tr>");
                            strHTML2.AppendLine("<td colspan=1 valign=top><font color='black'>" + item2.Key.Unit + "</font></td>");
                            int nn = 1;
                            foreach (var item66 in item2)
                            {
                                if (nn == 1)
                                {
                                    strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.TotalBoundPriorForecast + "</font></td>");
                                    strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.TotalBoundYearForecast + "</font></td>");
                                    strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.TotalBoundPlan + "</font></td>");
                                    strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.NewBusinessPriorForecast + "</font></td>");
                                    strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.NewBusinessYearForecast + "</font></td>");
                                    strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.NewBusinessPlan + "</font></td>");
                                    strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.RenewalPriorForecast + "</font></td>");
                                    strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.RenewalYearForecast + "</font></td>");
                                    strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.RenewalPlan + "</font></td>");
                                    strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.OtherPriorForecast + "</font></td>");
                                    strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.OtherYearForecast + "</font></td>");
                                    strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.OtherPlan + "</font></td>");
                                    strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.ForecastPercentagePrior + "</font></td>");
                                    strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item66.ForecastPercentagePlan + "</font></td>");

                                    strHTML2.AppendLine("</tr>");
                                    nn++;
                                }
                            }

                        }
                        var ss2 = item2.GroupBy(c => new { c.Segment }).ToList();
                        foreach (var item5 in ss2)
                        {
                            if (item5.Key.Segment != null)
                            {
                                strHTML2.AppendLine("<tr>");

                                strHTML2.AppendLine("<td colspan=1 valign=top><font color='black'>" + item5.Key.Segment + "</font></td>");
                                int jj = 1;
                                foreach (var item77 in item5)
                                {

                                    if (jj == 1)
                                    {
                                        strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.TotalBoundPriorForecast + "</font></td>");
                                        strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.TotalBoundYearForecast + "</font></td>");
                                        strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.TotalBoundPlan + "</font></td>");
                                        strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.NewBusinessPriorForecast + "</font></td>");
                                        strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.NewBusinessYearForecast + "</font></td>");
                                        strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.NewBusinessPlan + "</font></td>");
                                        strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.RenewalPriorForecast + "</font></td>");
                                        strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.RenewalYearForecast + "</font></td>");
                                        strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.RenewalPlan + "</font></td>");
                                        strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.OtherPriorForecast + "</font></td>");
                                        strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.OtherYearForecast + "</font></td>");
                                        strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.OtherPlan + "</font></td>");
                                        strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.ForecastPercentagePrior + "</font></td>");
                                        strHTML2.AppendLine("<td colspan=1  valign=top><font color='black'>" + item77.ForecastPercentagePlan + "</font></td>");

                                        strHTML2.AppendLine("</tr>");
                                        jj++;
                                    }
                                }
                            }
                        }
                    }
                }
            }


            strHTML2.AppendLine("</table>");




            strHTML2.Append("<table cellspacing=1 cellpadding=1 border=1 ID='Table7'>");
            strHTML2.AppendLine("<tr><td colspan=5 align=center><font color='#000000' size=3><b>Selected Search Criteria</b></font></td></tr>");
            strHTML2.AppendLine("<tr>");
            int ICount2 = 0;

            foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
            {
                List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                {
                    if (!info.PropertyType.Name.Contains("List"))
                    {
                        var value = info.GetValue(trackingReportingCommonFilterInputModel, null);

                        var filter = info.Name + ":" + value + ";";
                        if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "FilterBy" && info.Name != "GroupBy" && info.Name != "PageNumber" && info.Name != "PageSize" && info.Name != "ScreenName" && info.Name != "BrowseByValue" && info.Name != "BrowseByProducer" && info.Name != "BrowseByTitle" && info.Name != "DisableBrowseBy")
                        {
                            if (ICount2 > 1 && ICount2 % 4 == 0)
                            {
                                strHTML2.AppendLine("</tr><tr>");
                            }
                            strHTML2.AppendLine("<td colspan=1 valign=top><font color='#0000FF'>" + filter + "</font></td>");
                        }

                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(listValue))
                        {
                            var filter = info.Name + ":" + listValue + ";";

                            if (ICount2 > 1 && ICount2 % 4 == 0)
                            {
                                strHTML2.AppendLine("</tr><tr>");
                            }
                            strHTML2.AppendLine("<td colspan=1 valign=top><font color='#0000FF'>" + filter + "</font></td>");
                        }
                    }

                }

            }

            if (ICount2 % 4 != 0)
            {
                strHTML2.AppendLine("</tr");
            }

            workingList.Add(strHTML.ToString());
            workingList.Add(strHTML1.ToString());
            workingList.Add(strHTML2.ToString());



            return workingList;
        }

        public byte[] GetQuickPdfExport(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            byte[] outPdfBuffer = null;
            string reportHeaderName = trackingReportingCommonFilterInputModel.ReportName + " Report";
            string finalContent = string.Empty;
            StringBuilder htmlContent = new StringBuilder();
            htmlContent.Append("<html>");
            htmlContent.Append("<head>");

            htmlContent.Append("<style>#Table2 {font-family: Trebuchet MS, Arial, Helvetica, sans-serif;border-collapse: collapse; width: 100%;} #Table2 td, #Table2 th { border: 1px solid #A9A9A9; padding: 8px;}}</style>");
            htmlContent.Append("<style>#Legend {font-family: Trebuchet MS, Arial, Helvetica, sans-serif;border-collapse: collapse; width: 40%;} #Legend td, #Legend th { border: 1px solid #A9A9A9; padding: 8px;}}</style>");
            htmlContent.Append("</head>");
            htmlContent.Append("<body>");

            switch (trackingReportingCommonFilterInputModel.ReportName)
            {
                case "Regional Scorecard":

                    List<RegionalScorecardAmountPerRegionOutputModel> regionalScorecardAmountPerRegion = _trackerReportingRepository.GetRegionalScorecardAmountPerRegion(trackingReportingCommonFilterInputModel);
                    PDFCommon.PDFCommon.GenerateHtmlContentForHeader(htmlContent, regionalScorecardAmountPerRegion.ToDataTable(), 2, reportHeaderName, "RegionalScoreCardAmountPerRegion");
                    PDFCommon.PDFCommon.GenerateHtmlContentForRows(htmlContent, regionalScorecardAmountPerRegion.ToDataTable(), 2, "RegionalScoreCardAmountPerRegion");

                    List<RegionalScorecardNewBusinessByStatusOutputModel> regionalScorecardNewBusinessByStatus = _trackerReportingRepository.GetRegionalScorecardNewBusinessByStatus(trackingReportingCommonFilterInputModel);
                    PDFCommon.PDFCommon.GenerateHtmlContentForHeader(htmlContent, regionalScorecardNewBusinessByStatus.ToDataTable(), 2, reportHeaderName, "RegionalScorecardNewBusinessByStatus");
                    PDFCommon.PDFCommon.GenerateHtmlContentForRows(htmlContent, regionalScorecardNewBusinessByStatus.ToDataTable(), 2, "RegionalScorecardNewBusinessByStatus");

                    List<RegionalScorecardRenewalByStatusOutputModel> regionalScorecardRenewalByStatus = _trackerReportingRepository.GetRegionalScorecardRenewalByStatus(trackingReportingCommonFilterInputModel);
                    PDFCommon.PDFCommon.GenerateHtmlContentForHeader(htmlContent, regionalScorecardRenewalByStatus.ToDataTable(), 2, reportHeaderName, "RegionalScorecardRenewalByStatus");
                    PDFCommon.PDFCommon.GenerateHtmlContentForRows(htmlContent, regionalScorecardRenewalByStatus.ToDataTable(), 2, "RegionalScorecardRenewalByStatus");

                    PDFCommon.PDFCommon.GenerateHtmlContentForFilters(htmlContent, trackingReportingCommonFilterInputModel);

                    finalContent = htmlContent.ToString();
                    outPdfBuffer = WinnovativeConverter(finalContent, reportHeaderName);
                    break;
                case "Net Scorecard":

                    List<ScorecardAmountPerDivionOutputModel> netScorecardAmountPerDivion = _trackerReportingRepository.GetNetScorecardAmountPerDivision(trackingReportingCommonFilterInputModel);
                    PDFCommon.PDFCommon.GenerateHtmlContentForHeader(htmlContent, netScorecardAmountPerDivion.ToDataTable(), 5, reportHeaderName, "NetScorecardAmountPerDivision");
                    PDFCommon.PDFCommon.GenerateHtmlContentForRows(htmlContent, netScorecardAmountPerDivion.ToDataTable(), 5, "NetScorecardAmountPerDivision");

                    trackingReportingCommonFilterInputModel.DisplayResultBy = trackingReportingCommonFilterInputModel.DisplayResultBy == "Segment" ? "Credited Region and Branch" : "Credited Region";
                    List<RegionalScorecardAmountPerRegionOutputModel> netScorecardAmountPerRegion = _trackerReportingRepository.GetNetScorecardAmountPerRegion(trackingReportingCommonFilterInputModel);
                    PDFCommon.PDFCommon.GenerateHtmlContentForHeader(htmlContent, netScorecardAmountPerRegion.ToDataTable(), 2, reportHeaderName, "NetScorecardAmountPerRegion");
                    PDFCommon.PDFCommon.GenerateHtmlContentForRows(htmlContent, netScorecardAmountPerRegion.ToDataTable(), 2, "NetScorecardAmountPerRegion");

                    PDFCommon.PDFCommon.GenerateHtmlContentForFilters(htmlContent, trackingReportingCommonFilterInputModel);
                    finalContent = htmlContent.ToString();
                    outPdfBuffer = WinnovativeConverter(finalContent, reportHeaderName);
                    break;
                case "Producer Scorecard":

                    List<ProducerScorecardFilterOutputModel> producerScorecard = _trackerReportingRepository.GetProducerScorecardvalue(trackingReportingCommonFilterInputModel);
                    PDFCommon.PDFCommon.GenerateHtmlContentForHeader(htmlContent, producerScorecard.ToDataTable(), 1, reportHeaderName, "Producer Scorecard");
                    PDFCommon.PDFCommon.GenerateHtmlContentForRows(htmlContent, producerScorecard.ToDataTable(), 1, "Producer Scorecard");

                    PDFCommon.PDFCommon.GenerateHtmlContentForFilters(htmlContent, trackingReportingCommonFilterInputModel);

                    finalContent = htmlContent.ToString();
                    outPdfBuffer = WinnovativeConverter(finalContent, reportHeaderName);
                    break;
                case "Surety Scorecard":

                    List<SuretyScorecardByBondCategoryOutputModel> suretyScorecardByBondCategory = _trackerReportingRepository.GetSuretyScorecardByBondCategory(trackingReportingCommonFilterInputModel);
                    PDFCommon.PDFCommon.GenerateHtmlContentForHeader(htmlContent, suretyScorecardByBondCategory.ToDataTable(), 2, reportHeaderName, "SuretyScorecardByBondCategory");
                    PDFCommon.PDFCommon.GenerateHtmlContentForRows(htmlContent, suretyScorecardByBondCategory.ToDataTable(), 2, "SuretyScorecardByBondCategory");

                    List<SuretyScorecardByCreditedRegionOutputModel> suretyScorecardByCreditedRegion = _trackerReportingRepository.GetSuretyScorecardByCreditedRegion(trackingReportingCommonFilterInputModel);
                    PDFCommon.PDFCommon.GenerateHtmlContentForHeader(htmlContent, suretyScorecardByCreditedRegion.ToDataTable(), 2, reportHeaderName, "SuretyScorecardByCreditedRegion");

                    PDFCommon.PDFCommon.GenerateHtmlContentForRows(htmlContent, suretyScorecardByCreditedRegion.ToDataTable(), 2, "SuretyScorecardByCreditedRegion");
                    PDFCommon.PDFCommon.GenerateHtmlContentForFilters(htmlContent, trackingReportingCommonFilterInputModel);
                    finalContent = htmlContent.ToString();
                    outPdfBuffer = WinnovativeConverter(finalContent, reportHeaderName);
                    break;

                case "Regional Margin":

                    List<RegionalMarginOutputModel> regionalMargin = _trackerReportingRepository.GetRegionalMargin(trackingReportingCommonFilterInputModel);
                    PDFCommon.PDFCommon.GenerateHtmlContentForHeader(htmlContent, regionalMargin.ToDataTable(), 5, reportHeaderName, "RegionalMargin");
                    PDFCommon.PDFCommon.GenerateHtmlContentForRows(htmlContent, regionalMargin.ToDataTable(), 5, "RegionalMargin");
                    PDFCommon.PDFCommon.GenerateHtmlContentForFilters(htmlContent, trackingReportingCommonFilterInputModel);
                    finalContent = htmlContent.ToString();
                    outPdfBuffer = WinnovativeConverter(finalContent, reportHeaderName);
                    break;
                case "Growth & Mix Margin":
                    if (trackingReportingCommonFilterInputModel.DisplayResultBy != "Credited Region")
                    {
                        List<GrowthMixByBusinessOutputModel> growthMixByBusinesses = _trackerReportingRepository.GetGrowthMixMarginByBusiness(trackingReportingCommonFilterInputModel);
                        PDFCommon.PDFCommon.GenerateHtmlContentForHeader(htmlContent, growthMixByBusinesses.ToDataTable(), 5, reportHeaderName, "GrowthMixByBusiness");
                        PDFCommon.PDFCommon.GenerateHtmlContentForRows(htmlContent, growthMixByBusinesses.ToDataTable(), 5, "GrowthMixByBusiness");
                    }
                    else
                    {
                        List<GrowthMixByRegionOutputModel> growthMixByRegion = _trackerReportingRepository.GetGrowthMixMarginByRegion(trackingReportingCommonFilterInputModel);
                        PDFCommon.PDFCommon.GenerateHtmlContentForHeader(htmlContent, growthMixByRegion.ToDataTable(), 2, reportHeaderName, "GrowthMixByRegion");
                        PDFCommon.PDFCommon.GenerateHtmlContentForRows(htmlContent, growthMixByRegion.ToDataTable(), 2, "GrowthMixByRegion");
                    }
                    PDFCommon.PDFCommon.GenerateHtmlContentForFilters(htmlContent, trackingReportingCommonFilterInputModel);
                    finalContent = htmlContent.ToString();
                    outPdfBuffer = WinnovativeConverter(finalContent, reportHeaderName);
                    break;
                case "Home Office Margin":
                    if (trackingReportingCommonFilterInputModel.DisplayResultBy != "Credited Region")
                    {
                        List<HomeOfficeMarginByBusinessSegmentOutputModel> homeOfficeByBusiness = _trackerReportingRepository.GetHomeOfficeMarginByBusinessSegment(trackingReportingCommonFilterInputModel);
                        PDFCommon.PDFCommon.GenerateHtmlContentForHeader(htmlContent, homeOfficeByBusiness.ToDataTable(), 5, reportHeaderName, "HomeOfficeByBusinessSegment");
                        PDFCommon.PDFCommon.GenerateHtmlContentForRows(htmlContent, homeOfficeByBusiness.ToDataTable(), 5, "HomeOfficeByBusinessSegment");
                    }
                    else
                    { 
                    List<HomeOfficeMarginByCreditedRegionOutputModel> homeOfficeByRegion = _trackerReportingRepository.GetHomeOfficeMarginByCreditedRegion(trackingReportingCommonFilterInputModel);
                    PDFCommon.PDFCommon.GenerateHtmlContentForHeader(htmlContent, homeOfficeByRegion.ToDataTable(), 2, reportHeaderName, "HomeOfficeByRegion");
                    PDFCommon.PDFCommon.GenerateHtmlContentForRows(htmlContent, homeOfficeByRegion.ToDataTable(), 2, "HomeOfficeByRegion");
                    }
                    PDFCommon.PDFCommon.GenerateHtmlContentForFilters(htmlContent, trackingReportingCommonFilterInputModel);
                    finalContent = htmlContent.ToString();
                    outPdfBuffer = WinnovativeConverter(finalContent, reportHeaderName);
                    break;
                case "ERC Detailed":

                    List<ERCDetailOutputModel> ercDetailed = _trackerReportingRepository.GetERCDetails(trackingReportingCommonFilterInputModel);
                    DataTable ercdt = ercDetailed.ToDataTable();
                    ercdt.Columns.Remove("RecordNo");
                    ercdt.Columns.Remove("Subgroup");
                    PDFCommon.PDFCommon.GenerateHtmlContentForHeader(htmlContent, ercdt, 1, reportHeaderName, "ERC Detailed");
                    PDFCommon.PDFCommon.GenerateHtmlContentForRows(htmlContent, ercdt, 1, "ERC Detailed");
                    PDFCommon.PDFCommon.GenerateHtmlContentForFilters(htmlContent, trackingReportingCommonFilterInputModel);

                    finalContent = htmlContent.ToString();
                    outPdfBuffer = WinnovativeConverter(finalContent, reportHeaderName);
                    break;
                case "ERC Summary":
                    List<ERCSummaryOutputModel> ercSummary = _trackerReportingRepository.GetERCSummaryDetails(trackingReportingCommonFilterInputModel);
                    if (trackingReportingCommonFilterInputModel.DisplayResultBy == "Segment")
                    {
                        List<ERCSummarySegmentOutputModel> ercSummarySegment = ercSummary[0].ERCSummarySegment;
                        DataTable ercSegment = ercSummarySegment.ToDataTable();
                        ercSegment.Columns.Add("Portfolio Class", typeof(string)).SetOrdinal(4);
                        PDFCommon.PDFCommon.GenerateHtmlContentForHeader(htmlContent, ercSegment, 5, reportHeaderName, "ERCSummaryByBusinessSegment");
                        PDFCommon.PDFCommon.GenerateHtmlContentForRows(htmlContent, ercSegment, 5, "ERCSummaryByBusinessSegment");
                    }
                    else if (trackingReportingCommonFilterInputModel.DisplayResultBy == "PortFolio Class")
                    {                        
                        List<ERCSummaryPortfolioClassOutputModel> ercSummaryPortfolioClass = ercSummary[0].ERCSummaryPortfolioClass;
                        DataTable ercPortfolioClass = ercSummaryPortfolioClass.ToDataTable();
                        ercPortfolioClass.Columns.Add("Segment", typeof(string)).SetOrdinal(4);
                        PDFCommon.PDFCommon.GenerateHtmlContentForHeader(htmlContent, ercPortfolioClass, 5, reportHeaderName, "ERCSummaryByPortfolioClass");
                        PDFCommon.PDFCommon.GenerateHtmlContentForRows(htmlContent, ercPortfolioClass, 5, "ERCSummaryByPortfolioClass");
                    }
                    else if (trackingReportingCommonFilterInputModel.DisplayResultBy == "Credited Region")
                    {                       
                        List<ERCSummaryCreditedRegionOutputModel> ercSummaryRegion = ercSummary[0].ERCSummaryCreditedRegion;
                        PDFCommon.PDFCommon.GenerateHtmlContentForHeader(htmlContent, ercSummaryRegion.ToDataTable(), 2, reportHeaderName, "ERCSummaryByCreditedRegion");
                        PDFCommon.PDFCommon.GenerateHtmlContentForRows(htmlContent, ercSummaryRegion.ToDataTable(), 2, "ERCSummaryByCreditedRegion");
                    }
                    else if (trackingReportingCommonFilterInputModel.DisplayResultBy == "Time Frame")
                    {                       
                        List<ERCSummaryTimeFrameOutputModel> ercSummaryTimeFrame = ercSummary[0].ERCSummaryTimeFrame;
                        PDFCommon.PDFCommon.GenerateHtmlContentForHeader(htmlContent, ercSummaryTimeFrame.ToDataTable(), 1, reportHeaderName, "ERCSummaryByTimeFrame");
                        PDFCommon.PDFCommon.GenerateHtmlContentForRows(htmlContent, ercSummaryTimeFrame.ToDataTable(), 1, "ERCSummaryByTimeFrame");
                    }
                    PDFCommon.PDFCommon.GenerateHtmlContentForFilters(htmlContent, trackingReportingCommonFilterInputModel);
                    finalContent = htmlContent.ToString();
                    outPdfBuffer = WinnovativeConverter(finalContent, reportHeaderName);
                    break;
                default:
                    outPdfBuffer = GetForecastSummaryTotalDownloadPDF(trackingReportingCommonFilterInputModel);
                    break;
            }
            return outPdfBuffer;
        }

        public byte[] WinnovativeConverter(string pdf, string bg, bool customerDoc = false)
        {
            //Create a HTML to PDF converter object with default settings
            HtmlToPdfConverter htmlToPdfConverter = new HtmlToPdfConverter();

            //Set license key received after purchase to use the converter in licensed mode
            //Leave it not set to use the converter in demo mode
            htmlToPdfConverter.LicenseKey = "e/Xm9OX05ubj9OXg+uT05+X65eb67e3t7fTk";
            htmlToPdfConverter.PdfDocumentOptions.ShowHeader = true;
            if (bg == "Regional Margin Report" || bg == "Growth & Mix Margin Report" || bg == "Home Office Margin Report")
            {
                htmlToPdfConverter.PdfDocumentOptions.PdfPageOrientation = PdfPageOrientation.Landscape;
                DrawHeaderForMarginreports(htmlToPdfConverter, true, customerDoc);
                DrawFooterForMarginReports(htmlToPdfConverter, true, true, customerDoc);
            }
            else
            {
                DrawHeader(htmlToPdfConverter, true, customerDoc);
                DrawFooter(htmlToPdfConverter, true, true, customerDoc);
            }
            htmlToPdfConverter.PdfDocumentOptions.ShowFooter = true;
            if (!customerDoc)
            {
                htmlToPdfConverter.PdfDocumentOptions.LeftMargin = 50;
                htmlToPdfConverter.PdfDocumentOptions.RightMargin = 50;
            }
            else
            {
                htmlToPdfConverter.PdfDocumentOptions.LeftMargin = 50;
                htmlToPdfConverter.PdfDocumentOptions.RightMargin = 50;
            }

            // Convert the HTML page given by an URL to a PDF document in a memory buffer
            byte[] outPdfBuffer = htmlToPdfConverter.ConvertHtml(pdf, "");

            return outPdfBuffer;
        }

        private void DrawHeader(HtmlToPdfConverter htmlToPdfConverter, bool drawHeaderLine, bool customerDoc = false)
        {
            string imageurl = System.Web.Hosting.HostingEnvironment.MapPath("~/Images/ChubbLogo.png");
            StringBuilder htmlheader = new StringBuilder();
            htmlheader.Append("<html><head><title>HTML in Header</title></head><body><br /><br /><br /><table align='center'><tr><td>");
            htmlheader.Append("<img src = 'Imagepath'>");
            htmlheader.Append("</td ></tr></table></body></html>");
            htmlheader.Replace("Imagepath", imageurl);

            String headercontentfinal = htmlheader.ToString().Replace("\r\n", "");
            // Set the header height in points
            if (customerDoc)
            { htmlToPdfConverter.PdfHeaderOptions.HeaderHeight = 50; }
            else
            { htmlToPdfConverter.PdfHeaderOptions.HeaderHeight = 80; }

            // Set header background color
            htmlToPdfConverter.PdfHeaderOptions.HeaderBackColor = System.Drawing.Color.White;
            //htmlToPdfConverter.PdfDocumentOptions.LeftMargin
            // Create a HTML element to be added in header
            HtmlToPdfElement headerHtml = new HtmlToPdfElement(headercontentfinal, "");

            // Set the HTML element to fit the container height
            headerHtml.FitHeight = true;

            // Add HTML element to header
            htmlToPdfConverter.PdfHeaderOptions.AddElement(headerHtml);

            if (drawHeaderLine)
            {
                // Create a line element for the bottom of the header
                //LineElement headerLine = new LineElement(0, headerHeight - 1, headerWidth, headerHeight - 1);
                //    // Calculate the header width based on PDF page size and margins
                float headerWidth = htmlToPdfConverter.PdfDocumentOptions.PdfPageSize.Width -
                         htmlToPdfConverter.PdfDocumentOptions.LeftMargin - htmlToPdfConverter.PdfDocumentOptions.RightMargin;
                //    // Calculate header height
                float headerHeight = htmlToPdfConverter.PdfHeaderOptions.HeaderHeight;
                //    // Create a line element for the bottom of the header
                LineElement headerLine;
                if (customerDoc)
                {
                    headerLine = new LineElement(37, 45, 458, 45);
                }
                else
                {
                    headerLine = new LineElement(37, 75, 458, 75);
                }
                // Set line color
                headerLine.ForeColor = System.Drawing.Color.Black;
                // Add line element to the bottom of the header
                htmlToPdfConverter.PdfHeaderOptions.AddElement(headerLine);
            }
        }
        private void DrawHeaderForMarginreports(HtmlToPdfConverter htmlToPdfConverter, bool drawHeaderLine, bool customerDoc = false)
        {
            string imageurl = System.Web.Hosting.HostingEnvironment.MapPath("~/Images/ChubbLogo.png");
            StringBuilder htmlheader = new StringBuilder();
            htmlheader.Append("<html><head><title>HTML in Header</title></head><body><br /><br /><br /><table align='center'><tr><td>");
            htmlheader.Append("<img src = 'Imagepath'>");
            htmlheader.Append("</td ></tr></table></body></html>");
            htmlheader.Replace("Imagepath", imageurl);

            String headercontentfinal = htmlheader.ToString().Replace("\r\n", "");
            // Set the header height in points
            if (customerDoc)
            { htmlToPdfConverter.PdfHeaderOptions.HeaderHeight = 50; }
            else
            { htmlToPdfConverter.PdfHeaderOptions.HeaderHeight = 70; }

            // Set header background color
            htmlToPdfConverter.PdfHeaderOptions.HeaderBackColor = System.Drawing.Color.White;
            //htmlToPdfConverter.PdfDocumentOptions.LeftMargin
            // Create a HTML element to be added in header
            HtmlToPdfElement headerHtml = new HtmlToPdfElement(headercontentfinal, "");

            // Set the HTML element to fit the container height
            headerHtml.FitHeight = true;

            // Add HTML element to header
            htmlToPdfConverter.PdfHeaderOptions.AddElement(headerHtml);

            if (drawHeaderLine)
            {
                // Create a line element for the bottom of the header
                //LineElement headerLine = new LineElement(0, headerHeight - 1, headerWidth, headerHeight - 1);
                //    // Calculate the header width based on PDF page size and margins
                float headerWidth = htmlToPdfConverter.PdfDocumentOptions.PdfPageSize.Width -
                         htmlToPdfConverter.PdfDocumentOptions.LeftMargin - htmlToPdfConverter.PdfDocumentOptions.RightMargin;
                //    // Calculate header height
                float headerHeight = htmlToPdfConverter.PdfHeaderOptions.HeaderHeight;
                //    // Create a line element for the bottom of the header
                LineElement headerLine;
                if (customerDoc)
                {
                    headerLine = new LineElement(37, 45, 458, 45);
                }
                else
                {
                    headerLine = new LineElement(37, 55, 688, 55);
                }
                // Set line color
                headerLine.ForeColor = System.Drawing.Color.Black;
                // Add line element to the bottom of the header
                htmlToPdfConverter.PdfHeaderOptions.AddElement(headerLine);
            }
        }
        private void DrawFooter(HtmlToPdfConverter htmlToPdfConverter, bool drawFooterLine, bool addPageNumbers, bool customerDoc = false)
        {
            htmlToPdfConverter.PdfFooterOptions.FooterHeight = 60;

            if (drawFooterLine)
            {
                // Create a line element for the bottom of the header
                //LineElement headerLine = new LineElement(0, headerHeight - 1, headerWidth, headerHeight - 1);
                //    // Calculate the header width based on PDF page size and margins
                float footerWidth = htmlToPdfConverter.PdfDocumentOptions.PdfPageSize.Width -
                         htmlToPdfConverter.PdfDocumentOptions.LeftMargin - htmlToPdfConverter.PdfDocumentOptions.RightMargin;
                //    // Calculate header height
                float footerHeight = htmlToPdfConverter.PdfFooterOptions.FooterHeight;
                //    // Create a line element for the bottom of the header
                LineElement footerLine = new LineElement(0, 0, footerWidth, 0);
                // Set line color
                footerLine.ForeColor = System.Drawing.Color.Black;
                // Add line element to the bottom of the header
                htmlToPdfConverter.PdfFooterOptions.AddElement(footerLine);
            }

            StringBuilder htmlfooter = new StringBuilder();
            htmlfooter.Append("<html><head><title>HTML in Footer</title></head><body><br /><br /><br /><table align='left'><tr><td>");
            htmlfooter.Append("Report generated by Tracker system on " + DateTime.Now.ToString("MM/dd/yyyy h:mm tt"));
            htmlfooter.Append("</td ></tr></table></body></html>");

            // htmlToPdfConverter.PdfFooterOptions.PageNumberingStartIndex = 0;
            // htmlToPdfConverter.PdfFooterOptions.PageNumberingPageCountIncrement = 1;

            String footercontentfinal = htmlfooter.ToString().Replace("\r\n", "");

            // Create a HTML element to be added in footer
            HtmlToPdfElement footerHtml = new HtmlToPdfElement(footercontentfinal, "");

            // Add HTML element to header
            htmlToPdfConverter.PdfFooterOptions.AddElement(footerHtml);

            // Add page numbering
            if (addPageNumbers)
            {
                // Create a text element with page numbering place holders &p; and & P;
                TextElement footerText = new TextElement(0, 30, "Page &p; of &P;  ",
                    new System.Drawing.Font(new System.Drawing.FontFamily("Times New Roman"), 8, System.Drawing.GraphicsUnit.Point));

                // Align the text at the right of the footer
                footerText.TextAlign = HorizontalTextAlign.Right;

                // Set page numbering text color
                footerText.ForeColor = System.Drawing.Color.Black;

                // Embed the text element font in PDF
                footerText.EmbedSysFont = true;

                // Add the text element to footer
                htmlToPdfConverter.PdfFooterOptions.AddElement(footerText);
            }


        }
        private void DrawFooterForMarginReports(HtmlToPdfConverter htmlToPdfConverter, bool drawFooterLine, bool addPageNumbers, bool customerDoc = false)
        {
            htmlToPdfConverter.PdfFooterOptions.FooterHeight = 80;

            if (drawFooterLine)
            {
                // Create a line element for the bottom of the header
                //LineElement headerLine = new LineElement(0, headerHeight - 1, headerWidth, headerHeight - 1);
                //    // Calculate the header width based on PDF page size and margins
                // float footerWidth = htmlToPdfConverter.PdfDocumentOptions.PdfPageSize.Width -
                //   htmlToPdfConverter.PdfDocumentOptions.LeftMargin - htmlToPdfConverter.PdfDocumentOptions.RightMargin;
                //    // Calculate header height
                float footerHeight = htmlToPdfConverter.PdfFooterOptions.FooterHeight;
                //    // Create a line element for the bottom of the header
                LineElement footerLine = new LineElement(0, 0, 738, 0);
                // Set line color
                footerLine.ForeColor = System.Drawing.Color.Black;
                // Add line element to the bottom of the header
                htmlToPdfConverter.PdfFooterOptions.AddElement(footerLine);
            }

            StringBuilder htmlfooter = new StringBuilder();
            htmlfooter.Append("<html><head><title>HTML in Footer</title></head><body><br /><br /><br /><table align='left'><tr><td>");
            htmlfooter.Append("Report generated by Tracker system on " + DateTime.Now.ToString("MM/dd/yyyy h:mm tt"));
            htmlfooter.Append("</td ></tr></table></body></html>");

            // htmlToPdfConverter.PdfFooterOptions.PageNumberingStartIndex = 0;
            // htmlToPdfConverter.PdfFooterOptions.PageNumberingPageCountIncrement = 1;

            String footercontentfinal = htmlfooter.ToString().Replace("\r\n", "");

            // Create a HTML element to be added in footer
            HtmlToPdfElement footerHtml = new HtmlToPdfElement(footercontentfinal, "");

            // Add HTML element to header
            htmlToPdfConverter.PdfFooterOptions.AddElement(footerHtml);

            // Add page numbering
            if (addPageNumbers)
            {
                // Create a text element with page numbering place holders &p; and & P;
                TextElement footerText = new TextElement(0, 30, "Page &p; of &P;  ",
                    new System.Drawing.Font(new System.Drawing.FontFamily("Times New Roman"), 8, System.Drawing.GraphicsUnit.Point));

                // Align the text at the right of the footer
                footerText.TextAlign = HorizontalTextAlign.Right;

                // Set page numbering text color
                footerText.ForeColor = System.Drawing.Color.Black;

                // Embed the text element font in PDF
                footerText.EmbedSysFont = true;

                // Add the text element to footer
                htmlToPdfConverter.PdfFooterOptions.AddElement(footerText);
            }
        }
        public List<InsuredDNBDetailOutputModel> GetInsuredDetailByDBNumber(string DBNumber)
        {
            return _trackerReportingRepository.GetInsuredDetailByDBNumber(DBNumber);
        }

        public List<ProducerDetailOutputModel> GetProducerDetailsByCode(string ProducerCode)
        {
            return _trackerReportingRepository.GetProducerDetailsByCode(ProducerCode);
        }

        public List<BulkUpdateLoad> GetBulkUpdateLoad(BulkUpdateLoadInputModel bulkUpdateLoadInputModel)
        {
            return _trackerReportingRepository.GetBulkUpdateLoad(bulkUpdateLoadInputModel);
        }

        public int GetBulkUpdateSave(BulkUpdateSave bulkUpdateSave)
        {
            return _trackerReportingRepository.GetBulkUpdateSave(bulkUpdateSave);
        }

        public List<PostMortemUpdateInputModel> GetPostMortermDetails(int RecordNumber)
        {
            return _trackerReportingRepository.GetPostMotermDetails(RecordNumber);
        }

        public string GetHelpFilePath(int nFileID)
        {
            return _trackerReportingRepository.GetHelpFilePath(nFileID);
        }

        public List<InsuredSearchOutputModel> GetInsuredName(string strInsuredName)
        {
            return _trackerReportingRepository.GetInsuredName(strInsuredName);
        }
        public List<OptionsGroupItems> GetInsuredWildcardSearchResult(string filterValue)
        {
            return _trackerReportingRepository.GetInsuredWildcardSearchResult(filterValue);
        }
        public List<UnitSegmentDetailsOutputModel> GetUnitSegmentDetailsByUserID(string userID)
        {
            return _trackerReportingRepository.GetUnitSegmentDetailsByUserID(userID);
        }
        public List<SuretyScorecardByBondCategoryOutputModel> GetSuretyScorecardByBondCategory(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetSuretyScorecardByBondCategory(trackingReportingCommonFilterInputModel);
        }
        public List<SuretyScorecardByCreditedRegionOutputModel> GetSuretyScorecardByCreditedRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetSuretyScorecardByCreditedRegion(trackingReportingCommonFilterInputModel);
        }
        private string GetSuretyScorecardExportToXcel(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                List<SuretyScorecardByBondCategoryOutputModel> suretyScorecardByBondCategory = new List<SuretyScorecardByBondCategoryOutputModel>();
                List<SuretyScorecardByCreditedRegionOutputModel> suretyScorecardByCreditedRegion = new List<SuretyScorecardByCreditedRegionOutputModel>();

                suretyScorecardByBondCategory = _trackerReportingRepository.GetSuretyScorecardByBondCategory(trackingReportingCommonFilterInputModel);
                suretyScorecardByCreditedRegion = _trackerReportingRepository.GetSuretyScorecardByCreditedRegion(trackingReportingCommonFilterInputModel);
                
                outputFilePath = SpreadSheetXLSXGeneratorForSuretyScoreCard(suretyScorecardByBondCategory, suretyScorecardByCreditedRegion, trackingReportingCommonFilterInputModel);

                AssignNullForObject(suretyScorecardByBondCategory);
                AssignNullForObject(suretyScorecardByCreditedRegion);
            }
            catch (Exception ex)
            {
                outputFilePath = string.Empty;
            }
            return outputFilePath;
        }
        private string SpreadSheetXLSXGeneratorForSuretyScoreCard(
          List<SuretyScorecardByBondCategoryOutputModel> suretyScorecardByBondCategory,
          List<SuretyScorecardByCreditedRegionOutputModel> suretyScorecardByCreditedRegion,
          TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                ExcelCreationInputModel excelCreationInputModel = new ExcelCreationInputModel();
                outputFilePath = ExcelEngine.GetXLOutputPath(trackingReportingCommonFilterInputModel.ReportName, trackingReportingCommonFilterInputModel.UserID);

                using (SpreadsheetDocument xlDocument = SpreadsheetDocument.Create(outputFilePath, SpreadsheetDocumentType.Workbook))
                {
                    WorkbookPart xlWorkbookPart = xlDocument.AddWorkbookPart();
                    OpenXMLStyleHelper.SaveCustomStylesheet(xlWorkbookPart);
                    Workbook xlWorkbook = new Workbook();
                    xlWorkbookPart.Workbook = new Workbook();
                    xlWorkbook = xlWorkbookPart.Workbook;
                    Sheets xlSheets = xlWorkbook.AppendChild<Sheets>(new Sheets());
                    WorksheetPart xlWorksheetPart = null;
                    //Common value 
                    excelCreationInputModel.SearchCriteriaName = "Selected Search Criteria";
                    excelCreationInputModel.ReportName = "SuretyScorecardByBondCategory";
                    excelCreationInputModel.ReportHeaderName = "Surety Scorecard - Bond Category Report: All the figures listed below are in (USD)";
                    excelCreationInputModel.SheetName = "By Bond Category";
                    excelCreationInputModel.SheeIdValue = 1;
                    ExcelCommon.ExcelCommon.CreateCustomXcelSheet(excelCreationInputModel, trackingReportingCommonFilterInputModel, xlDocument, xlWorksheetPart, xlWorkbookPart, xlSheets, suretyScorecardByBondCategory.ToDataTable(), 2);

                    excelCreationInputModel.ReportName = "SuretyScorecardByCreditedRegion";
                    excelCreationInputModel.ReportHeaderName = "Surety Scorecard - Credited Region Report: All the figures listed below are in (USD)";
                    excelCreationInputModel.SheetName = "By Credited Region";
                    excelCreationInputModel.SheeIdValue = 2;
                    ExcelCommon.ExcelCommon.CreateCustomXcelSheet(excelCreationInputModel, trackingReportingCommonFilterInputModel, xlDocument, xlWorksheetPart, xlWorkbookPart, xlSheets, suretyScorecardByCreditedRegion.ToDataTable(), 2);
                    //Create XL Workbook Part.
                    ExcelEngine.CreateXLWorkbookPart(xlDocument);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outputFilePath;
        }
        public List<RegionalMarginOutputModel> GetRegionalMargin(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetRegionalMargin(trackingReportingCommonFilterInputModel);
        }
        private string GetRegionalMarginExportToXcel(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                List<RegionalMarginOutputModel> regionalMargin = new List<RegionalMarginOutputModel>();
                regionalMargin = _trackerReportingRepository.GetRegionalMargin(trackingReportingCommonFilterInputModel);
                outputFilePath = SpreadSheetXLSXGeneratorForRegionalMargin(regionalMargin, trackingReportingCommonFilterInputModel);
                AssignNullForObject(regionalMargin);
            }
            catch (Exception ex)
            {
                outputFilePath = string.Empty;
            }
            return outputFilePath;
        }
        private string SpreadSheetXLSXGeneratorForRegionalMargin(
          List<RegionalMarginOutputModel> regionalMargin,
          TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                ExcelCreationInputModel excelCreationInputModel = new ExcelCreationInputModel();
                outputFilePath = ExcelEngine.GetXLOutputPath(trackingReportingCommonFilterInputModel.ReportName, trackingReportingCommonFilterInputModel.UserID);

                using (SpreadsheetDocument xlDocument = SpreadsheetDocument.Create(outputFilePath, SpreadsheetDocumentType.Workbook))
                {
                    WorkbookPart xlWorkbookPart = xlDocument.AddWorkbookPart();
                    OpenXMLStyleHelper.SaveCustomStylesheet(xlWorkbookPart);
                    Workbook xlWorkbook = new Workbook();
                    xlWorkbookPart.Workbook = new Workbook();
                    xlWorkbook = xlWorkbookPart.Workbook;
                    Sheets xlSheets = xlWorkbook.AppendChild<Sheets>(new Sheets());
                    WorksheetPart xlWorksheetPart = null;
                    //WorksheetPart xlWorksheetPart = (WorksheetPart)xlDocument.WorkbookPart.GetPartById(xlSheets.First().Id);
                    //Common value 
                    excelCreationInputModel.SearchCriteriaName = "Selected Search Criteria";
                    excelCreationInputModel.ReportName = "RegionalMargin";
                    excelCreationInputModel.ReportHeaderName = trackingReportingCommonFilterInputModel.DisplayResultBy == "Segment" ? ("Regional Margin Report By Business Segment: All the figures listed below are in (USD)") : ("Regional Margin Report By Portfolio Class: All the figures listed below are in (USD)");                    
                    excelCreationInputModel.SheetName = trackingReportingCommonFilterInputModel.DisplayResultBy == "Segment" ? "By Segment" : "By Portfolio Class";
                    excelCreationInputModel.SheeIdValue = 1;
                    ExcelCommon.ExcelCommon.CreateCustomXcelSheet(excelCreationInputModel, trackingReportingCommonFilterInputModel, xlDocument, xlWorksheetPart, xlWorkbookPart, xlSheets, regionalMargin.ToDataTable(), 5);
                    //Create XL Workbook Part.
                    ExcelEngine.CreateXLWorkbookPart(xlDocument);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outputFilePath;
        }

        public bool GetRecordNavigation (int RecordNumber)
        {
            bool bCheckNavigation = false;
            try
            {
                bCheckNavigation = _trackerReportingRepository.GetRecordNavigation(RecordNumber);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return bCheckNavigation;


        }

        public List<GrowthMixByBusinessOutputModel> GetGrowthMixMarginByBusiness(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetGrowthMixMarginByBusiness(trackingReportingCommonFilterInputModel);
        }
        public List<GrowthMixByRegionOutputModel> GetGrowthMixMarginByRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetGrowthMixMarginByRegion(trackingReportingCommonFilterInputModel);
        }
        private string GetGrowthMixMarginExportToXcel(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                List<GrowthMixByBusinessOutputModel> growthMixByBusiness = new List<GrowthMixByBusinessOutputModel>();
                List<GrowthMixByRegionOutputModel> growthMixByRegion = new List<GrowthMixByRegionOutputModel>();

                if (trackingReportingCommonFilterInputModel.DisplayResultBy != "Credited Region")
                {
                    growthMixByBusiness = _trackerReportingRepository.GetGrowthMixMarginByBusiness(trackingReportingCommonFilterInputModel);
                }
                else
                {
                    growthMixByRegion = _trackerReportingRepository.GetGrowthMixMarginByRegion(trackingReportingCommonFilterInputModel);
                }
                outputFilePath = SpreadSheetXLSXGeneratorForGrowthMix(growthMixByBusiness, growthMixByRegion, trackingReportingCommonFilterInputModel);

                AssignNullForObject(growthMixByBusiness);
                AssignNullForObject(growthMixByRegion);
            }
            catch (Exception ex)
            {
                outputFilePath = string.Empty;
            }
            return outputFilePath;
        }
        private string SpreadSheetXLSXGeneratorForGrowthMix(
          List<GrowthMixByBusinessOutputModel> growthMixByBusiness,
          List<GrowthMixByRegionOutputModel> growthMixByRegion,
          TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                ExcelCreationInputModel excelCreationInputModel = new ExcelCreationInputModel();
                outputFilePath = ExcelEngine.GetXLOutputPath(trackingReportingCommonFilterInputModel.ReportName, trackingReportingCommonFilterInputModel.UserID);

                using (SpreadsheetDocument xlDocument = SpreadsheetDocument.Create(outputFilePath, SpreadsheetDocumentType.Workbook))
                {
                    WorkbookPart xlWorkbookPart = xlDocument.AddWorkbookPart();
                    OpenXMLStyleHelper.SaveCustomStylesheet(xlWorkbookPart);
                    Workbook xlWorkbook = new Workbook();
                    xlWorkbookPart.Workbook = new Workbook();
                    xlWorkbook = xlWorkbookPart.Workbook;
                    Sheets xlSheets = xlWorkbook.AppendChild<Sheets>(new Sheets());
                    WorksheetPart xlWorksheetPart = null;
                    //Common value 
                    excelCreationInputModel.SearchCriteriaName = "Selected Search Criteria";
                    if (growthMixByBusiness.Count != 0)
                    {
                        excelCreationInputModel.ReportName = "GrowthMixByBusiness";
                        excelCreationInputModel.ReportHeaderName = trackingReportingCommonFilterInputModel.DisplayResultBy == "Segment" ? ("Growth & Mix Margin Report By Business Segment: All the figures listed below are in (USD)") : ("Growth & Mix Margin Report By Portfolio Class: All the figures listed below are in (USD)");
                        excelCreationInputModel.SheetName = trackingReportingCommonFilterInputModel.DisplayResultBy == "Segment" ? "By Segment":"By Portfolio Class";
                        excelCreationInputModel.SheeIdValue = 1;
                        ExcelCommon.ExcelCommon.CreateCustomXcelSheet(excelCreationInputModel, trackingReportingCommonFilterInputModel, xlDocument, xlWorksheetPart, xlWorkbookPart, xlSheets, growthMixByBusiness.ToDataTable(), 5);
                    }
                    else
                    {
                        excelCreationInputModel.ReportName = "GrowthMixByRegion";
                        excelCreationInputModel.ReportHeaderName = "Growth Mix Margin Report By Credited Region: All the figures listed below are in (USD)";
                        excelCreationInputModel.SheetName = "By Credited Region";
                        excelCreationInputModel.SheeIdValue = 1;
                        ExcelCommon.ExcelCommon.CreateCustomXcelSheet(excelCreationInputModel, trackingReportingCommonFilterInputModel, xlDocument, xlWorksheetPart, xlWorkbookPart, xlSheets, growthMixByRegion.ToDataTable(), 2);
                    }
                     //Create XL Workbook Part.
                    ExcelEngine.CreateXLWorkbookPart(xlDocument);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outputFilePath;
        }

        public List<HomeOfficeMarginPercentByBusinessOutputModel> GetHomeOfficeMarginPercentByBusiness(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetHomeOfficeMarginPercentByBusiness(trackingReportingCommonFilterInputModel);
        }
        public List<HomeOfficeMarginPercentByCreditedRegionOutputModel> GetHomeOfficeMarginPercentByCreditedRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetHomeOfficeMarginPercentByCreditedRegion(trackingReportingCommonFilterInputModel);
        }
        public List<HomeOfficeMarginByBusinessSegmentOutputModel> GetHomeOfficeMarginByBusinessSegment(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetHomeOfficeMarginByBusinessSegment(trackingReportingCommonFilterInputModel);
        }
        public List<HomeOfficeMarginByCreditedRegionOutputModel> GetHomeOfficeMarginByCreditedRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetHomeOfficeMarginByCreditedRegion(trackingReportingCommonFilterInputModel);
        }
        public List<PassCodeDetailsOutputModel> GetPasCodeDetails(PassCodeDetailsInputModell passCodeDetailsInputModell)
        {
            return _trackerReportingRepository.GetPasCodeDetails(passCodeDetailsInputModell);
        }
        public List<ERCSummaryOutputModel> GetERCSummaryDetails(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetERCSummaryDetails(trackingReportingCommonFilterInputModel);
        }
        public List<EditProfileOutputModel> GetEditProfileDetails(EditProfileInputModel editProfileInputModel)
        {
            return _trackerReportingRepository.GetEditProfileDetails(editProfileInputModel);
        }
       
        public List<ERCDetailOutputModel> GetERCDetails(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetERCDetails(trackingReportingCommonFilterInputModel);
        }
       
        private string GetHomeOfficeMarginExportToXcel(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                List <HomeOfficeMarginByBusinessSegmentOutputModel> homeOfficeByBusiness = new List<HomeOfficeMarginByBusinessSegmentOutputModel>();
                List<HomeOfficeMarginByCreditedRegionOutputModel> homeOfficeByRegion = new List<HomeOfficeMarginByCreditedRegionOutputModel>();
                if (trackingReportingCommonFilterInputModel.DisplayResultBy != "Credited Region")
                {
                    homeOfficeByBusiness = _trackerReportingRepository.GetHomeOfficeMarginByBusinessSegment(trackingReportingCommonFilterInputModel);
                }
                else
                {
                    homeOfficeByRegion = _trackerReportingRepository.GetHomeOfficeMarginByCreditedRegion(trackingReportingCommonFilterInputModel);
                }
                outputFilePath = SpreadSheetXLSXGeneratorForHomeOffice( homeOfficeByBusiness, homeOfficeByRegion, trackingReportingCommonFilterInputModel);

                AssignNullForObject(homeOfficeByBusiness);
                AssignNullForObject(homeOfficeByRegion);
                
            }
            catch (Exception ex)
            {
                outputFilePath = string.Empty;
            }
            return outputFilePath;
        }
        private string SpreadSheetXLSXGeneratorForHomeOffice(
         
         List<HomeOfficeMarginByBusinessSegmentOutputModel> homeOfficeByBusiness,
         List<HomeOfficeMarginByCreditedRegionOutputModel> homeOfficeByRegion,
         TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                ExcelCreationInputModel excelCreationInputModel = new ExcelCreationInputModel();
                outputFilePath = ExcelEngine.GetXLOutputPath(trackingReportingCommonFilterInputModel.ReportName, trackingReportingCommonFilterInputModel.UserID);

                using (SpreadsheetDocument xlDocument = SpreadsheetDocument.Create(outputFilePath, SpreadsheetDocumentType.Workbook))
                {
                    WorkbookPart xlWorkbookPart = xlDocument.AddWorkbookPart();
                    OpenXMLStyleHelper.SaveCustomStylesheet(xlWorkbookPart);
                    Workbook xlWorkbook = new Workbook();
                    xlWorkbookPart.Workbook = new Workbook();
                    xlWorkbook = xlWorkbookPart.Workbook;
                    Sheets xlSheets = xlWorkbook.AppendChild<Sheets>(new Sheets());
                    WorksheetPart xlWorksheetPart = null;
                    excelCreationInputModel.SearchCriteriaName = "Selected Search Criteria";
                    if (homeOfficeByBusiness.Count != 0)
                    {
                        excelCreationInputModel.ReportName = "HomeOfficeByBusinessSegment";
                        excelCreationInputModel.ReportHeaderName = trackingReportingCommonFilterInputModel.DisplayResultBy == "Segment" ? ("Home Office Margin Report By Business Segment: All the figures listed below are in (USD)") : ("Home Office Margin Report By Portfolio Class: All the figures listed below are in (USD)");
                        excelCreationInputModel.SheetName = trackingReportingCommonFilterInputModel.DisplayResultBy == "Segment" ? "By Segment" : "By Portfolio Class";
                        excelCreationInputModel.SheeIdValue = 1;
                        ExcelCommon.ExcelCommon.CreateCustomXcelSheet(excelCreationInputModel, trackingReportingCommonFilterInputModel, xlDocument, xlWorksheetPart, xlWorkbookPart, xlSheets, homeOfficeByBusiness.ToDataTable(), 5);
                    }
                    else
                    {
                        excelCreationInputModel.ReportName = "HomeOfficeByRegion";
                        excelCreationInputModel.ReportHeaderName = "Home Office Margin Report By Credited Region: All the figures listed below are in (USD)";
                        excelCreationInputModel.SheetName = "By Credited Region";
                        excelCreationInputModel.SheeIdValue = 1;
                        ExcelCommon.ExcelCommon.CreateCustomXcelSheet(excelCreationInputModel, trackingReportingCommonFilterInputModel, xlDocument, xlWorksheetPart, xlWorkbookPart, xlSheets, homeOfficeByRegion.ToDataTable(), 2);
                    }
                    //Create XL Workbook Part.
                    ExcelEngine.CreateXLWorkbookPart(xlDocument);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outputFilePath;
        }
        private string GetERCDetailedExportToXcel(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                List<ERCDetailOutputModel> ercDetailed = new List<ERCDetailOutputModel>();
                ercDetailed = _trackerReportingRepository.GetERCDetails(trackingReportingCommonFilterInputModel);
                outputFilePath = SpreadSheetXLSXGeneratorForERCDetailed(ercDetailed, trackingReportingCommonFilterInputModel);
                AssignNullForObject(ercDetailed);

            }
            catch (Exception ex)
            {
                outputFilePath = string.Empty;
            }
            return outputFilePath;
        }
        private string SpreadSheetXLSXGeneratorForERCDetailed(
         List<ERCDetailOutputModel> ercDetailed,
         TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                ExcelCreationInputModel excelCreationInputModel = new ExcelCreationInputModel();
                outputFilePath = ExcelEngine.GetXLOutputPath(trackingReportingCommonFilterInputModel.ReportName, trackingReportingCommonFilterInputModel.UserID);

                using (SpreadsheetDocument xlDocument = SpreadsheetDocument.Create(outputFilePath, SpreadsheetDocumentType.Workbook))
                {
                    WorkbookPart xlWorkbookPart = xlDocument.AddWorkbookPart();
                    OpenXMLStyleHelper.SaveCustomStylesheet(xlWorkbookPart);
                    Workbook xlWorkbook = new Workbook();
                    xlWorkbookPart.Workbook = new Workbook();
                    xlWorkbook = xlWorkbookPart.Workbook;
                    Sheets xlSheets = xlWorkbook.AppendChild<Sheets>(new Sheets());
                    WorksheetPart xlWorksheetPart = null;
                    //Common value 
                    excelCreationInputModel.SearchCriteriaName = "Selected Search Criteria";
                    //Create Worksheet for ERC Detailed Report
                    excelCreationInputModel.ReportName = "ERC Detailed";
                    excelCreationInputModel.ReportHeaderName = "ERC Detailed : All the figures listed below are in (USD)";
                    excelCreationInputModel.SheetName = "ERC Detailed";
                    excelCreationInputModel.SheeIdValue = 1;
                    DataTable ercdt = ercDetailed.ToDataTable();
                    ercdt.Columns.Remove("RecordNo");
                    ercdt.Columns.Remove("Subgroup");
                    ExcelCommon.ExcelCommon.CreateCustomXcelSheet(excelCreationInputModel, trackingReportingCommonFilterInputModel, xlDocument, xlWorksheetPart, xlWorkbookPart, xlSheets, ercdt, 1);

                    ExcelEngine.CreateXLWorkbookPart(xlDocument);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outputFilePath;
        }
        private string GetERCSummaryExportToXcel(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                List<ERCSummaryOutputModel> ercSummary = _trackerReportingRepository.GetERCSummaryDetails(trackingReportingCommonFilterInputModel);
                List<ERCSummarySegmentOutputModel> ercSummarySegment = new List<ERCSummarySegmentOutputModel>();
                List<ERCSummaryPortfolioClassOutputModel> ercSummaryPortfolioClass = new List<ERCSummaryPortfolioClassOutputModel>();
                List<ERCSummaryCreditedRegionOutputModel> ercSummaryRegion = new List<ERCSummaryCreditedRegionOutputModel>();
                List<ERCSummaryTimeFrameOutputModel> ercSummaryTimeFrame = new List<ERCSummaryTimeFrameOutputModel>();
                if (trackingReportingCommonFilterInputModel.DisplayResultBy == "Segment")
                {
                    ercSummarySegment = ercSummary[0].ERCSummarySegment;
                }
                else if (trackingReportingCommonFilterInputModel.DisplayResultBy == "PortFolio Class")
                {                    
                    ercSummaryPortfolioClass = ercSummary[0].ERCSummaryPortfolioClass;
                }
                else if (trackingReportingCommonFilterInputModel.DisplayResultBy == "Credited Region")
                {                   
                    ercSummaryRegion = ercSummary[0].ERCSummaryCreditedRegion;
                }
                else if(trackingReportingCommonFilterInputModel.DisplayResultBy == "Time Frame")
                {                  
                    ercSummaryTimeFrame = ercSummary[0].ERCSummaryTimeFrame;
                }
                outputFilePath = SpreadSheetXLSXGeneratorForERCSummary(ercSummarySegment, ercSummaryPortfolioClass, ercSummaryRegion, ercSummaryTimeFrame, trackingReportingCommonFilterInputModel);
                AssignNullForObject(ercSummarySegment);
            }
            catch (Exception ex)
            {
                outputFilePath = string.Empty;
            }
            return outputFilePath;
        }
        private string SpreadSheetXLSXGeneratorForERCSummary(

         List<ERCSummarySegmentOutputModel> ercSummarySegment,
         List<ERCSummaryPortfolioClassOutputModel> ercSummaryPortfolioClass,
         List<ERCSummaryCreditedRegionOutputModel> ercSummaryRegion,
         List<ERCSummaryTimeFrameOutputModel> ercSummaryTimeFrame,
         TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string outputFilePath = string.Empty;
            try
            {
                ExcelCreationInputModel excelCreationInputModel = new ExcelCreationInputModel();
                outputFilePath = ExcelEngine.GetXLOutputPath(trackingReportingCommonFilterInputModel.ReportName, trackingReportingCommonFilterInputModel.UserID);

                using (SpreadsheetDocument xlDocument = SpreadsheetDocument.Create(outputFilePath, SpreadsheetDocumentType.Workbook))
                {
                    WorkbookPart xlWorkbookPart = xlDocument.AddWorkbookPart();
                    OpenXMLStyleHelper.SaveCustomStylesheet(xlWorkbookPart);
                    Workbook xlWorkbook = new Workbook();
                    xlWorkbookPart.Workbook = new Workbook();
                    xlWorkbook = xlWorkbookPart.Workbook;
                    Sheets xlSheets = xlWorkbook.AppendChild<Sheets>(new Sheets());
                    WorksheetPart xlWorksheetPart = null;

                    excelCreationInputModel.SearchCriteriaName = "Selected Search Criteria";
                    if (ercSummarySegment.Count != 0)
                    {
                        excelCreationInputModel.ReportName = "ERCSummaryByBusinessSegment";
                        excelCreationInputModel.ReportHeaderName = "ERC Summary Report By Business Segment: All the figures listed below are in (USD)";
                        excelCreationInputModel.SheetName = "By Business Segment";
                        excelCreationInputModel.SheeIdValue = 1;
                        DataTable ercSegment = ercSummarySegment.ToDataTable();
                        ercSegment.Columns.Add("Portfolio Class", typeof(string)).SetOrdinal(4);
                        ExcelCommon.ExcelCommon.CreateCustomXcelSheet(excelCreationInputModel, trackingReportingCommonFilterInputModel, xlDocument, xlWorksheetPart, xlWorkbookPart, xlSheets, ercSegment, 5);
                    }
                    else if (ercSummaryPortfolioClass.Count != 0)
                    {
                        excelCreationInputModel.ReportName = "ERCSummaryByPortfolioClass";
                        excelCreationInputModel.ReportHeaderName = "ERC Summary Report By Portfolio Class: All the figures listed below are in (USD)";
                        excelCreationInputModel.SheetName = "By Portfolio Class";
                        excelCreationInputModel.SheeIdValue = 1;
                        DataTable ercPortfolioClass = ercSummaryPortfolioClass.ToDataTable();
                        ercPortfolioClass.Columns.Add("Segment", typeof(string)).SetOrdinal(4);
                        ExcelCommon.ExcelCommon.CreateCustomXcelSheet(excelCreationInputModel, trackingReportingCommonFilterInputModel, xlDocument, xlWorksheetPart, xlWorkbookPart, xlSheets, ercPortfolioClass, 5);
                    }
                    else if (ercSummaryRegion.Count != 0)
                    {
                        excelCreationInputModel.ReportName = "ERCSummaryByCreditedRegion";
                        excelCreationInputModel.ReportHeaderName = "ERC Summary Report By Credited Region: All the figures listed below are in (USD)";
                        excelCreationInputModel.SheetName = "By Credited Region";
                        excelCreationInputModel.SheeIdValue = 1;
                        ExcelCommon.ExcelCommon.CreateCustomXcelSheet(excelCreationInputModel, trackingReportingCommonFilterInputModel, xlDocument, xlWorksheetPart, xlWorkbookPart, xlSheets, ercSummaryRegion.ToDataTable(), 2);
                    }
                    else if (ercSummaryTimeFrame.Count != 0)
                    {
                        excelCreationInputModel.ReportName = "ERCSummaryByTimeFrame";
                        excelCreationInputModel.ReportHeaderName = "ERC Summary Report By TimeFrame: All the figures listed below are in (USD)";
                        excelCreationInputModel.SheetName = "By Time Frame";
                        excelCreationInputModel.SheeIdValue = 1;
                        ExcelCommon.ExcelCommon.CreateCustomXcelSheet(excelCreationInputModel, trackingReportingCommonFilterInputModel, xlDocument, xlWorksheetPart, xlWorkbookPart, xlSheets, ercSummaryTimeFrame.ToDataTable(), 1);
                    }
                    //Create XL Workbook Part.
                    ExcelEngine.CreateXLWorkbookPart(xlDocument);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outputFilePath;
        }

        public List<SubmissionDetails> GetSubmissionDetails(int RecordNumber)
        {
            return _trackerReportingRepository.GetSubmissionDetails(RecordNumber);
        }
        public string GetEditProfileSave(EditProfileSaveInputModel editProfileSaveInputModel)
        {
            string saveProfile = _trackerReportingRepository.GetEditProfileSave(editProfileSaveInputModel);
            return saveProfile;
        }
        public string GetLinkedReport(string FileName)
        {
            return _trackerReportingRepository.GetLinkedReport(FileName);
        }

        public List<TargetProgressionByBranchOutputModel> GetTargetProgressionByBranch(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetTargetProgressionReportsByBranch(trackingReportingCommonFilterInputModel);
        }

        public List<TargetProgressionByRegionOutputModel> GetTargetProgressionByRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetTargetProgressionReportsByRegion(trackingReportingCommonFilterInputModel);
        }

        public TargetProgressionByLobOutputModel GetTargetProgressionByLob(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            return _trackerReportingRepository.GetTargetProgressionReportsByLOB(trackingReportingCommonFilterInputModel);
        }

        #region ForecastVariation Exprot
        public StringBuilder GetForecastVariationExcel(ForecastVariationInputModel forecastVariationInputModel)
        {
            StringBuilder strHTML = new StringBuilder();
            List<ForecastVariationOutputModel> forecastvariationReports = new List<ForecastVariationOutputModel>();
            forecastvariationReports = _trackerReportingRepository.GetForecastVariation(forecastVariationInputModel);
            strHTML = strHTML.Append(SpreadSheetXLSXGeneratorForecastVariationExport(forecastvariationReports, forecastVariationInputModel));
            return strHTML;
        }
       
        private string SpreadSheetXLSXGeneratorForecastVariationExport(List<ForecastVariationOutputModel> obj1, ForecastVariationInputModel obj2)
        {
            string outputFilePath = string.Empty;
            try
            {
                outputFilePath = ExcelEngine.GetXLOutputPath("ForecastVariationReport", obj2.UserID);
                int xlRowStartIndex = 1;
                UInt32Value sheeIdValue = 1;
                string[] xlWidthCollection = { "23", "23", "60", "23", "23", "23", "23", "23" };
                using (SpreadsheetDocument xlDocument = SpreadsheetDocument.Create(outputFilePath, SpreadsheetDocumentType.Workbook))
                {
                    //Create new xl worksheet part and new sheet
                    WorksheetPart xlWorksheetPart = ExcelEngine.CreateXLWorksheetPartAndSheets(xlDocument, sheeIdValue, "ForecastVariationReport");

                    using (var xlWriter = OpenXmlWriter.Create(xlWorksheetPart))
                    {
                        List<OpenXmlAttribute> xmlAttribute = null;
                        xlWriter.WriteStartElement(new Worksheet());
                        //Set Column Width 
                        ExcelEngine.SetXLColumnWidth(xmlAttribute, xlWriter, xlWidthCollection);
                        xlWriter.WriteStartElement(new SheetData());

                        //For Download Report Header Row XML Attribute
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, xlRowStartIndex.ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        //Download Report Header - Write XL Header Text
                        ExcelEngine.WriteDataToExcel(xlWriter, "Forecast Variation Report", "string", 5);
                        //For Download Report Header Value End Element
                        xlWriter.WriteEndElement();

                        //For XL Header XML Attribute
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex + 1).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Insured", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Segment", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Credited Region", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Forecast", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Forecast Change", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Change", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Date Time", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Accounting Month", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Accounting Year", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Change Type", "string", 1);

                        //ForHeader Value End Element
                        xlWriter.WriteEndElement();

                        //To Write XL Rows
                        int rowIndex = 0;
                        var cts = obj1;
                        foreach (var item in cts)
                        {
                            xmlAttribute = new List<OpenXmlAttribute>();
                            xmlAttribute.Add(new OpenXmlAttribute("r", null, (rowIndex + (xlRowStartIndex + 2)).ToString()));
                            xlWriter.WriteStartElement(new Row(), xmlAttribute);
                            ExcelEngine.WriteDataToExcel(xlWriter, item.Insured, "string", 4);
                            ExcelEngine.WriteDataToExcel(xlWriter, item.Segment, "string", 4);
                            ExcelEngine.WriteDataToExcel(xlWriter, item.CreditedRegion, "string", 4);
                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item.Forecast), "number", 6);
                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item.ForecastChange), "number", 3);
                            ExcelEngine.WriteDataToExcel(xlWriter, item.Change, "string", 3);
                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item.DateTime), "string", 3);
                            ExcelEngine.WriteDataToExcel(xlWriter, item.AccountingMonth, "string", 3);
                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item.AccountingYear), "string", 3);
                            ExcelEngine.WriteDataToExcel(xlWriter, item.ChangeType, "string", 3);

                            //ForHeader Value End Element
                            xlWriter.WriteEndElement();
                            rowIndex++;
                        }

                        //To Write Blank Row.
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (rowIndex + (xlRowStartIndex + 2)).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                        //For row value end element
                        xlWriter.WriteEndElement();
                        rowIndex++;

                        //To Write Filter Rows header
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (rowIndex + (xlRowStartIndex + 2)).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Selected Search Criteria", "string", 7);
                        //For row value end element
                        xlWriter.WriteEndElement();
                        rowIndex++;

                        //To Write Filter Rows
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (rowIndex + (xlRowStartIndex + 2)).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        foreach (PropertyInfo info in typeof(ForecastVariationInputModel).GetProperties())
                        {
                            List<string> oTheList = info.GetValue(obj2, null) as List<string>;
                            string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                            if (info.GetValue(obj2, null) != null && info.GetValue(obj2, null).ToString() != "0" && info.GetValue(obj2, null).ToString() != "")
                            {
                                if (!info.PropertyType.Name.Contains("List"))
                                {
                                    var value = info.GetValue(obj2, null);
                                    var filter = info.Name + ":" + value + ";";
                                    if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "PageNumber" && info.Name != "PageSize")
                                    {
                                        ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    }
                                }
                                else
                                {
                                    if (!string.IsNullOrEmpty(listValue))
                                    {
                                        var filter = info.Name + ":" + listValue + ";";
                                        ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    }
                                }
                            }
                        }
                        //For row value end element
                        xlWriter.WriteEndElement();

                        //For final end element
                        xlWriter.WriteStartElement(new Workbook());
                        xlWriter.WriteStartElement(new Worksheet());
                    }

                    //Create XL Workbook Part.
                    ExcelEngine.CreateXLWorkbookPart(xlDocument);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outputFilePath;
        }

        #endregion

        public List<DeeplinkAppFiltersResult> GetDeeplinkAppFiltersByID(string userID, int applicationID)
        {
            return _trackerReportingRepository.GetDeeplinkAppFiltersByID(userID, applicationID);
        }
        public List<string> GetPinnedReportsByID(string userID)
        {
            List<string> PinnedReports = _trackerReportingRepository.GetPinnedReportsByID(userID);
            return PinnedReports;
        }
        public string SavePinnedReportsByID(SavePinnedReportsInputModel savePinnedReportsInputModel)
        {
            return _trackerReportingRepository.SavePinnedReportsByID(savePinnedReportsInputModel);
        }
    }
}
