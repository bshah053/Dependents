﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Chubb.Tracker.EnterpriseIntegration.CRM.Model;
using Chubb.Tracker.TrackerReportingService.Business.Interfaces;
using Chubb.Tracker.EnterpriseIntegration.CRM.Contacts;
using Chubb.Tracker.TrackerReportingService.Data.Interfaces;
using Chubb.Tracker.Framework.Unity;
using Chubb.Tracker.EnterpriseIntegration.CRM.Activities;
using Chubb.Tracker.EnterpriseIntegration.DNB.Model;
using Chubb.Tracker.EnterpriseIntegration.DNB.Activity;
using Chubb.Tracker.ServiceModel.TrackingReporting;
using System.Text;
using System.Reflection;
using Chubb.Tracker.Framework.Helper;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using Chubb.Tracker.Framework.ExcelEngine;

namespace Chubb.Tracker.TrackerReportingService.Business.Implementation
{
    public class TrackerReportingEnterpriseIntegrationBO : ITrackerReportingEnterpriseIntegrationBO
    {
        private readonly ViewContacts objGetContacts = new ViewContacts();
        private readonly Activities objGetActivities = new Activities();
        private readonly DNBLookupDetails objGetDNBLookupDetails = new DNBLookupDetails();


        private readonly ITrackerReportingEnterpriseIntegrationRepository _trackerReportingEnterpriseIntegrationRepository = UnityManager.Resolve<ITrackerReportingEnterpriseIntegrationRepository>();

        public List<ContactOutputModel> GetContactbyCustomer(CustomerProfileInputModel objCustomerProfileInputModel)
        {
            List<CustomerInputGUIDModel> objViewCustomerContactOutputModel = _trackerReportingEnterpriseIntegrationRepository.GetCustomerGUID(objCustomerProfileInputModel);
            if (objViewCustomerContactOutputModel.Count > 0)
            {
                return objGetContacts.GetContactsbyCustomer(objViewCustomerContactOutputModel);
            }
            else
            {
                return new List<ContactOutputModel>();
            }
        }

        public List<ContactOutputModel> GetContactbyProducer(ProducerDetailsCRMInputModel objProducerDetailsInputModel)
        {
            List<ProducerInputGUIDModel> objContactOutputModel = _trackerReportingEnterpriseIntegrationRepository.GetCRMProducerGUID(objProducerDetailsInputModel);
            return objGetContacts.GetContactByProducer(objContactOutputModel);
        }

        //public List<MeetingDetailsOutputModel> GetMeetingbyCustomer(CustomerDetailsInputModel objViewCustomerMeetingInputModel)
        //{

        //    List<CustomerInputGUIDModel> objViewCustomerMeetingOutputModel = _trackerReportingEnterpriseIntegrationRepository.GetCustomerGUID(objViewCustomerMeetingInputModel);

        //    return objGetActivities.GetMeetingbyCustomer(objViewCustomerMeetingOutputModel, objViewCustomerMeetingInputModel);
        //}
        public List<ContactOutputModel> GetContactbyProdLocation(ContactDetailsInputModel objContactDetailsInputModel)
        {
            return objGetContacts.GetContactsbyProdLocation(objContactDetailsInputModel);
        }

        public List<MeetingDetailsInfoOutputModel> GetMeetingbyProducer(ProducerDetailsCRMInputModel objViewProducerMeetingInputModel)
        {

            List<ProducerInputGUIDModel> objViewProducerMeetingOutputModel = _trackerReportingEnterpriseIntegrationRepository.GetCRMProducerGUID(objViewProducerMeetingInputModel);

            return objGetActivities.GetMeetingbyProducer(objViewProducerMeetingOutputModel);
        }

        public List<AttachmentsDetailsOutputModel> GetAttachmentsbyProducer(ProducerDetailsCRMInputModel objViewProducerAttachmentsInputModel)
        {

            List<ProducerInputGUIDModel> objViewProducerAttachmentsOutputModel = _trackerReportingEnterpriseIntegrationRepository.GetCRMProducerGUID(objViewProducerAttachmentsInputModel);

            return objGetActivities.GetCRMAttachmentsbyProducer(objViewProducerAttachmentsOutputModel, objViewProducerAttachmentsInputModel);
        }
        public List<NotesDetailsOutputModel> GetNotesbyProducer(ProducerDetailsCRMInputModel objViewProducerNotesInputModel)
        {

            List<ProducerInputGUIDModel> objViewProducerNotesOutputModel = _trackerReportingEnterpriseIntegrationRepository.GetCRMProducerGUID(objViewProducerNotesInputModel);

            return objGetActivities.GetCRMNotesbyProducer(objViewProducerNotesOutputModel);
        }
        public List<UserTaskOutputModel> GetTaskbyProducer(ProducerDetailsCRMInputModel objViewProducerTaskInputModel)
        {

            List<ProducerInputGUIDModel> objViewProducerNotesOutputModel = _trackerReportingEnterpriseIntegrationRepository.GetCRMProducerGUID(objViewProducerTaskInputModel);

            return objGetActivities.GetTaskbyProducer(objViewProducerNotesOutputModel);
        }
        public UserCRMDynamicDetailsOutputModel GetCRMDynamicUserDetails(String UserID)
        {
            return objGetActivities.GetCRMDynamicUserDetails(UserID);
        }

        //public List<DNBLookupOutputModel> GetDBNCompanyLookup(string CompanyName, string State, string CountryCode)
        //{
        //    return objGetDNBLookupDetails.GetDBNCompanyLookup(CompanyName, State, CountryCode);
        //}

        public List<CRMCompletedActivitiesOutputModel> GetCRMCompletedActivitiesByProducer(ProducerDetailsCRMInputModel objProducerDetailsCRMInputModel)
        {
            List<ProducerInputGUIDModel> objViewProducerNotesOutputModel = _trackerReportingEnterpriseIntegrationRepository.GetCRMProducerGUID(objProducerDetailsCRMInputModel);

            return objGetActivities.GetCRMCompletedActivitiesByProducer(objViewProducerNotesOutputModel);
        }
        public List<MeetingDetailsOutputModel> GetCRMMeetingByBranch(BranchDetailsCRMInputModel objViewBranchMeetingInputModel)
        {
            List<ProducerInputGUIDModel> objViewBranchMeetingOutputModel = _trackerReportingEnterpriseIntegrationRepository.GetCRMBranchGUID(objViewBranchMeetingInputModel);

            return objGetActivities.GetCRMMeetingByBranch(objViewBranchMeetingOutputModel);
        }

        public List<CRMCompletedActivitiesOutputModel> GetCRMCompletedActivitiesByCustomer(CustomerProfileInputModel objCustomerProfileInputModel)
        {
            List<CustomerInputGUIDModel> objCRMCompletedActivitiesByCustomer = _trackerReportingEnterpriseIntegrationRepository.GetCustomerGUID(objCustomerProfileInputModel);

            if (objCRMCompletedActivitiesByCustomer.Count > 0)
            {
                return objGetActivities.GetCRMCompletedActivitiesbyCustomer(objCRMCompletedActivitiesByCustomer);
            }
            else
            {
                return new List<CRMCompletedActivitiesOutputModel>();
            }            
        }
        public List<UserTaskOutputModel> GetCRMTaskByCustomer(CustomerProfileInputModel objCustomerProfileInputModel)
        {
            List<CustomerInputGUIDModel> objCRMTaskByCustomer = _trackerReportingEnterpriseIntegrationRepository.GetCustomerGUID(objCustomerProfileInputModel);
            if (objCRMTaskByCustomer.Count > 0)
            {
                return objGetActivities.GetCRMTaskbyCustomer(objCRMTaskByCustomer);
            }
            else
            {
                return new List<UserTaskOutputModel>();
            }            
        }
        public List<NotesDetailsOutputModel> GetNotesbyCustomer(CustomerProfileInputModel objCustomerProfileInputModel)
        {
            List<CustomerInputGUIDModel> objViewCustomerNotesOutputModel = _trackerReportingEnterpriseIntegrationRepository.GetCustomerGUID(objCustomerProfileInputModel);

            if (objViewCustomerNotesOutputModel.Count > 0)
            {
                return objGetActivities.GetCRMNotesbyCustomer(objViewCustomerNotesOutputModel);
            }
            else
            {
                return new List<NotesDetailsOutputModel>();
            }
        }

        public List<MeetingDetailsInfoOutputModel> GetMeetingbyCustomer(CustomerProfileInputModel objCustomerProfileInputModel)
        {

            List<CustomerInputGUIDModel> objViewCustomerMeetingOutputModel = _trackerReportingEnterpriseIntegrationRepository.GetCustomerGUID(objCustomerProfileInputModel);
            if (objViewCustomerMeetingOutputModel.Count > 0)
            {
                return objGetActivities.GetCRMMeetingbyCustomer(objViewCustomerMeetingOutputModel);
            }
            else
            {
                return new List<MeetingDetailsInfoOutputModel>();
            }
        }
        public SummaryActivityOutputModel GetTravelScorecard(SummaryActivityInputModel objSummaryActivityInputModel)
        {
            return objGetActivities.GetTravelScorecard(objSummaryActivityInputModel);
        }

        public List<ROVOutputModel> GetROVReport(ROVInputModel loadReportInputModel)
        {
            List<ROVOutputModel> objRovOutputModel = _trackerReportingEnterpriseIntegrationRepository.GetROVReport(loadReportInputModel);

            AccountingMonthClosedDatesOutputModel accountingMonthClosedDates = _trackerReportingEnterpriseIntegrationRepository.GetAccountingMonthClosedDatesRov(loadReportInputModel);

            List<ROVOutputModel> objROVReportOutputModel =  objGetActivities.GetRovVisitUpdate(objRovOutputModel, accountingMonthClosedDates.StartDate, accountingMonthClosedDates.EndDate);

            return objROVReportOutputModel;
            //return _trackerReportingRepository.GetROVReport(loadReportInputModel);
        }
        #region ROV Exprot
        public StringBuilder GetROVReportExcel(ROVInputModel loadReportInputModel)
        {
            StringBuilder strHTML = new StringBuilder();
            List<ROVOutputModel> rovReports = new List<ROVOutputModel>();
            rovReports = _trackerReportingEnterpriseIntegrationRepository.GetROVReport(loadReportInputModel);
            //strHTML = SpreadSheetXMLGeneratorRovExprot(rovReports, loadReportInputModel);
            strHTML = strHTML.Append(SpreadSheetXLSXGeneratorRovExprot(rovReports, loadReportInputModel));
            return strHTML;
        }
        private StringBuilder SpreadSheetXMLGeneratorRovExprot(List<ROVOutputModel> obj1, ROVInputModel obj2)
        {
            StringBuilder strHTML = new StringBuilder();

            strHTML.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            strHTML.AppendLine("<?mso-application progid=\"Excel.Sheet\"?>");
            strHTML.AppendLine("<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:x=\"urn:schemas-microsoft-com:office:excel\" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:html=\"https://www.w3.org/TR/html401/\">");
            strHTML.AppendLine("<ss:Styles>");
            strHTML.AppendLine("<Style ss:ID=\"Default\" ss:Name=\"Normal\">");
            strHTML.AppendLine("<Alignment ss:Vertical=\"Bottom\"/>");
            strHTML.AppendLine("<Borders/>");
            strHTML.AppendLine("<Font ss:FontName=\"Calibri\" x:Family=\"Swiss\" ss:Size=\"11\" ss:Color=\"#000000\"/>");
            strHTML.AppendLine("<Interior/>");
            strHTML.AppendLine("<NumberFormat/>");
            strHTML.AppendLine("<Protection/>");
            strHTML.AppendLine("</Style>");
            strHTML.AppendLine("<Style ss:ID=\"s62\">");
            strHTML.AppendLine("<Alignment ss:Vertical=\"Bottom\"/>");
            strHTML.AppendLine("<Borders/>");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" ss:Bold=\"1\"/>");
            strHTML.AppendLine("<Interior/>");
            strHTML.AppendLine("<NumberFormat/>");
            strHTML.AppendLine("<Protection/>");
            strHTML.AppendLine("</Style>");
            strHTML.AppendLine("<Style ss:ID=\"s63\">");
            strHTML.AppendLine("<Alignment ss:Vertical=\"Bottom\"/>");
            strHTML.AppendLine("<Borders/>");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" x:Family=\"Swiss\" ss:Color=\"#FFFFFF\" ss:Bold=\"1\"/>");
            strHTML.AppendLine("<Interior ss:Color=\"#000000\" ss:Pattern=\"Solid\"/>");
            strHTML.AppendLine("<NumberFormat/>");
            strHTML.AppendLine("<Protection/>");
            strHTML.AppendLine("</Style>");
            strHTML.AppendLine("<Style ss:ID=\"s84\">");
            strHTML.AppendLine("<Borders>");
            strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"2\"/>");
            strHTML.AppendLine("</Borders>");
            strHTML.AppendLine("<Font ss:FontName=\"Arial\" ss:Size=\"10\" ss:Color=\"#0000FF\"/>");
            strHTML.AppendLine("</Style>");
            strHTML.AppendLine("<Style ss:ID=\"s65\">");
            strHTML.AppendLine("<Borders>");
            strHTML.AppendLine("<Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            strHTML.AppendLine("<Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            strHTML.AppendLine("</Borders>");
            strHTML.AppendLine("</Style>");
            strHTML.AppendLine("</ss:Styles>");
            strHTML.AppendLine("<Worksheet ss:Name=\"ROVReport\">");
            strHTML.AppendLine("<Table>");
            strHTML.AppendLine("<Column ss:Index=\"1\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"2\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"3\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"4\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"5\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"6\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"7\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Column ss:Index=\"8\" ss:AutoFitWidth=\"1\" ss:Width=\"110\"/>");
            strHTML.AppendLine("<Row ss:StyleID=\"s62\">");
            strHTML.AppendLine("<Cell><Data ss:Type=\"String\">ROV Report</Data></Cell>");

            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Producer Region</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Producer Branch</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Producer Name </Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Producer Visits Count </Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">Total Gross Premium </Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\"> YOY Submission</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">YOY Quoted</Data></Cell>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s63\"><Data ss:Type=\"String\">YOY Bound</Data></Cell>");
            strHTML.AppendLine("</Row>");


            var cts = obj1;

            foreach (var item in cts)
            {
                strHTML.AppendLine("<Row>");
                strHTML.AppendLine("<Cell><Data ss:Type=\"String\">" + item.ProducerRegion + "</Data></Cell>");
                strHTML.AppendLine("<Cell><Data ss:Type=\"String\">" + item.ProducerBranch + "</Data></Cell>");
                strHTML.AppendLine("<Cell><Data ss:Type=\"String\">" + item.ProducerName + "</Data></Cell>");
                strHTML.AppendLine("<Cell><Data ss:Type=\"String\">" + item.ProducerVisitsCount + "</Data></Cell>");
                strHTML.AppendLine("<Cell><Data ss:Type=\"String\">" + item.TotalPremium + "</Data></Cell>");
                strHTML.AppendLine("<Cell><Data ss:Type=\"String\">" + item.YOYSubmission + "</Data></Cell>");
                strHTML.AppendLine("<Cell><Data ss:Type=\"String\">" + item.YOYQuoted + "</Data></Cell>");
                strHTML.AppendLine("<Cell><Data ss:Type=\"String\">" + item.YOYBound + "</Data></Cell>");
                strHTML.AppendLine("</Row>");
            }
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">Selected Search Criteria</Data></Cell>");
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("<Row>");
            int ICount = 0;

            foreach (PropertyInfo info in typeof(ROVInputModel).GetProperties())
            {
                List<string> oTheList = info.GetValue(obj2, null) as List<string>;
                string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                if (info.GetValue(obj2, null) != null && info.GetValue(obj2, null).ToString() != "0" && info.GetValue(obj2, null).ToString() != "")
                {
                    if (!info.PropertyType.Name.Contains("List"))
                    {
                        var value = info.GetValue(obj2, null);
                        var filter = info.Name + ":" + value + ";";
                        if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "PageNumber" && info.Name != "PageSize")
                        {
                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                strHTML.AppendLine("</Row>");
                                strHTML.AppendLine("<Row>");
                            }
                            strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");
                        }

                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(listValue))
                        {
                            var filter = info.Name + ":" + listValue + ";";

                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                strHTML.AppendLine("</Row>");
                                strHTML.AppendLine("<Row>");
                            }

                            //strHTML.AppendLine("<td colspan=1><font color='#0000FF' >" + filter + "</font></td>");
                            strHTML.AppendLine("<Cell ss:StyleID=\"s84\"><Data ss:Type=\"String\">" + filter + "</Data></Cell>");


                        }
                    }

                }

            }
            strHTML.AppendLine("</Row>");
            strHTML.AppendLine("</Table></Worksheet></Workbook>");
            return strHTML;
        }

        private string SpreadSheetXLSXGeneratorRovExprot(List<ROVOutputModel> obj1, ROVInputModel obj2)
        {
            string outputFilePath = string.Empty;
            try
            {
                outputFilePath = ExcelEngine.GetXLOutputPath("ROVReport", obj2.UserID);
                int xlRowStartIndex = 1;
                UInt32Value sheeIdValue = 1;
                string[] xlWidthCollection = { "23", "23", "60", "23", "23", "23", "23", "23" };
                using (SpreadsheetDocument xlDocument = SpreadsheetDocument.Create(outputFilePath, SpreadsheetDocumentType.Workbook))
                {
                    //Create new xl worksheet part and new sheet
                    WorksheetPart xlWorksheetPart = ExcelEngine.CreateXLWorksheetPartAndSheets(xlDocument, sheeIdValue, "ROVReport");

                    using (var xlWriter = OpenXmlWriter.Create(xlWorksheetPart))
                    {
                        List<OpenXmlAttribute> xmlAttribute = null;
                        xlWriter.WriteStartElement(new Worksheet());
                        //Set Column Width 
                        ExcelEngine.SetXLColumnWidth(xmlAttribute, xlWriter, xlWidthCollection);
                        xlWriter.WriteStartElement(new SheetData());

                        //For Download Report Header Row XML Attribute
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, xlRowStartIndex.ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        //Download Report Header - Write XL Header Text
                        ExcelEngine.WriteDataToExcel(xlWriter, "ROV Report", "string", 5);
                        //For Download Report Header Value End Element
                        xlWriter.WriteEndElement();

                        //For XL Header XML Attribute
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (xlRowStartIndex + 1).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Producer Region", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Producer Branch", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Producer Name", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Producer Visits Count", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Total Gross Premium", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "YOY Submission", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "YOY Quoted", "string", 1);
                        ExcelEngine.WriteDataToExcel(xlWriter, "YOY Bound", "string", 1);
                        //ForHeader Value End Element
                        xlWriter.WriteEndElement();

                        //To Write XL Rows
                        int rowIndex = 0;
                        var cts = obj1;
                        foreach (var item in cts)
                        {
                            xmlAttribute = new List<OpenXmlAttribute>();
                            xmlAttribute.Add(new OpenXmlAttribute("r", null, (rowIndex + (xlRowStartIndex + 2)).ToString()));
                            xlWriter.WriteStartElement(new Row(), xmlAttribute);
                            ExcelEngine.WriteDataToExcel(xlWriter, item.ProducerRegion, "string", 4);
                            ExcelEngine.WriteDataToExcel(xlWriter, item.ProducerBranch, "string", 4);
                            ExcelEngine.WriteDataToExcel(xlWriter, item.ProducerName, "string", 4);
                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item.ProducerVisitsCount), "number", 6);
                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item.TotalPremium), "number", 3);
                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item.YOYSubmission), "number", 3);
                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item.YOYQuoted), "number", 3);
                            ExcelEngine.WriteDataToExcel(xlWriter, Convert.ToString(item.YOYBound), "number", 3);
                           
                            //ForHeader Value End Element
                            xlWriter.WriteEndElement();
                            rowIndex++;
                        }

                        //To Write Blank Row.
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (rowIndex + (xlRowStartIndex + 2)).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        ExcelEngine.WriteDataToExcel(xlWriter, string.Empty, "string", 4);
                        //For row value end element
                        xlWriter.WriteEndElement();
                        rowIndex++;

                        //To Write Filter Rows header
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (rowIndex + (xlRowStartIndex + 2)).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        ExcelEngine.WriteDataToExcel(xlWriter, "Selected Search Criteria", "string", 7);
                        //For row value end element
                        xlWriter.WriteEndElement();
                        rowIndex++;

                        //To Write Filter Rows
                        xmlAttribute = new List<OpenXmlAttribute>();
                        xmlAttribute.Add(new OpenXmlAttribute("r", null, (rowIndex + (xlRowStartIndex + 2)).ToString()));
                        xlWriter.WriteStartElement(new Row(), xmlAttribute);
                        foreach (PropertyInfo info in typeof(ROVInputModel).GetProperties())
                        {
                            List<string> oTheList = info.GetValue(obj2, null) as List<string>;
                            string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, "|");
                            if (info.GetValue(obj2, null) != null && info.GetValue(obj2, null).ToString() != "0" && info.GetValue(obj2, null).ToString() != "")
                            {
                                if (!info.PropertyType.Name.Contains("List"))
                                {
                                    var value = info.GetValue(obj2, null);
                                    var filter = info.Name + ":" + value + ";";
                                    if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "PageNumber" && info.Name != "PageSize")
                                    {
                                        ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    }
                                }
                                else
                                {
                                    if (!string.IsNullOrEmpty(listValue))
                                    {
                                        var filter = info.Name + ":" + listValue + ";";
                                        ExcelEngine.WriteDataToExcel(xlWriter, filter, "string", 7);
                                    }
                                }
                            }
                        }
                        //For row value end element
                        xlWriter.WriteEndElement();

                        //For final end element
                        xlWriter.WriteStartElement(new Workbook());
                        xlWriter.WriteStartElement(new Worksheet());
                    }

                    //Create XL Workbook Part.
                    ExcelEngine.CreateXLWorkbookPart(xlDocument);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outputFilePath;
        }

        #endregion
    }
}
