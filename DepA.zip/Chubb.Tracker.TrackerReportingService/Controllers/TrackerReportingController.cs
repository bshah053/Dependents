using Chubb.Tracker.ServiceModel.TrackingReporting;
using Chubb.Tracker.TrackerReportingService.Controllers;
using Chubb.Tracker.TrackerReportingService.Facade.Interfaces;
using Chubb.Tracker.EnterpriseIntegration.CRM.Model;
using Chubb.Tracker.EnterpriseIntegration.DNB.Model;
using Chubb.Tracker.Framework.Unity;
using Chubb.Tracker.Framework.Logging;
using System;
using System.Collections.Generic;
using System.Net;
using System.Web.Http;
using System.Net.Http;
using System.Web.Http.Description;
using Chubb.Tracker.Framework.Helper;
using System.Text;
using System.Web.UI;
using System.Net.Http.Headers;
using Chubb.Tracker.TrackerReportingService;
using System.IO;
using System.Web;
using Chubb.Tracker.Framework.ExcelEngine;
using System.Web.Http.Results;
using Chubb.Tracker.ServiceModel.Submission;

namespace Chubb.Tracker.TrackerReportingServices.Controllers
{
    [UserValidate]
    public class TrackerReportingController : TrackerReportingBaseController
    {
        //GET ICRMContactsFacade  //
        private readonly ITrackerReportingEnterpriseIntegrationFacade _trackerReportingEnterpriseIntegrationFacade;
        private readonly ITrackerReportingFacade _trackerReportingFacade;
        private static ILogWrapper _logger;


        public TrackerReportingController(ILogWrapper logger, ITrackerReportingFacade trackerReportingFacade, ITrackerReportingEnterpriseIntegrationFacade trackerReportingCRMFacade)
        {
            _logger = logger;
            _logger.DeclaringType = this.GetType();
            _trackerReportingFacade = trackerReportingFacade;
            _trackerReportingEnterpriseIntegrationFacade = trackerReportingCRMFacade;

        }
        ///// <summary>
        ///// Load Underwriter New Business Goals Hit Ratio Details
        ///// </summary>
        ///// <remarks>
        ///// Load Underwriter New Business Goals Hit Ratio Details<br></br>
        ///// Required Fields : UserID, AccountMonth, AccountYear,TimeFrame
        ///// </remarks>
        ///// <param name="UWNBHitRatioDetails">LoadUWGoalsInputModel</param>
        ///// <returns>UWDashboardGridOutputModel</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<UWNewBusinessGoalsHitRatioOutputModel>))]
        //[HttpPost]
        //[Route("reports/underwriters/newbusiness/hitratio")]
        //public IHttpActionResult GetUnderWriterNewBusinessHitRatio([FromBody]LoadUWGoalsInputModel UWNBHitRatioDetails)
        //{
        //    _logger.TraceStart();
        //    List<UWNewBusinessGoalsHitRatioOutputModel> trackingReportingGridOutputData = new List<UWNewBusinessGoalsHitRatioOutputModel>
        //    {
        //        new UWNewBusinessGoalsHitRatioOutputModel
        //        {
        //        BoundFromQuoted ="BoundFromQuoted",
        //        Goal =50,
        //        BoundCount=12,
        //        QuoteCount=20,
        //        BoundPolicesVsQuotes="BoundPolicesVsQuotes(YTD)",
        //        Quoted="Quoted",
        //        BoundOutofQuoteText="BoundFromQuoted"
        //        }
        //    };
        //    _logger.TraceEnd();
        //    return Ok(trackingReportingGridOutputData);

        //}

        ///// <summary>
        ///// Load Underwriter New Business Goals Quote Ratio Details
        ///// </summary>
        ///// <remarks>
        ///// Load Underwriter New Business Goals Quote Ratio Details<br></br>
        ///// Required Fields : UserID, AccountMonth, AccountYear,TimeFrame
        ///// </remarks>
        ///// <param name="UWNBQuoteRatioDetails">LoadUWGoalsInputModel</param>
        ///// <returns>UWDashboardGridOutputModel</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<UWNewBusinessGoalsQuoteRatioOutputModel>))]
        //[HttpPost]
        //[Route("reports/underwriters/newbusiness/quoteratio")]  // NA
        //public IHttpActionResult GetUnderWriterNewBusinessQuoteRatio([FromBody]LoadUWGoalsInputModel UWNBQuoteRatioDetails)
        //{
        //    if (String.IsNullOrEmpty(UWNBQuoteRatioDetails.UserID) || String.IsNullOrEmpty(UWNBQuoteRatioDetails.AccountMonth)
        //      || String.IsNullOrEmpty(UWNBQuoteRatioDetails.TimeFrame) || UWNBQuoteRatioDetails.AccountYear == 0)
        //    {
        //        if (String.IsNullOrEmpty(UWNBQuoteRatioDetails.UserID))
        //            return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
        //        if (String.IsNullOrEmpty(UWNBQuoteRatioDetails.AccountMonth))
        //            return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
        //        if (UWNBQuoteRatioDetails.AccountYear == 0)
        //            return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
        //        if (String.IsNullOrEmpty(UWNBQuoteRatioDetails.TimeFrame))
        //            return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
        //    }
        //    _logger.TraceStart();
        //    List<UWNewBusinessGoalsQuoteRatioOutputModel> trackingReportingGridOutputData = _trackerReportingFacade.GetUnderWriterNewBusinessQuoteRatioData(UWNBQuoteRatioDetails);
        //    _logger.TraceEnd();
        //    if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
        //    {
        //        return Ok(trackingReportingGridOutputData);
        //    }
        //    else
        //    {
        //        return Content(HttpStatusCode.NotFound, String.Format("No Underwriter New Business Goals Quote Ratio Records found for UserID: {0}", UWNBQuoteRatioDetails.UserID));
        //    }
        //}

        ///// <summary>
        ///// Load Underwriter New Business Travel Details
        ///// </summary>
        ///// <remarks>
        ///// Load Underwriter New Business Travel Details<br></br>
        ///// Required Fields : UserID, AccountMonth, AccountYear,TimeFrame
        ///// </remarks>
        ///// <param name="UWNBTravelDetails">LoadUWGoalsInputModel</param>
        ///// <returns>UWDashboardGridOutputModel</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<UWNewBusinessGoalsTravelOutputModel>))]
        //[HttpPost]
        //[Route("reports/underwriters/travels/details")]  // NA
        //public IHttpActionResult GetUnderWriterTravelDetails([FromBody]LoadUWGoalsInputModel UWNBTravelDetails)
        //{
        //    List<UWNewBusinessGoalsTravelOutputModel> trackingReportingGridOutputData = new List<UWNewBusinessGoalsTravelOutputModel>
        //    {
        //        new UWNewBusinessGoalsTravelOutputModel
        //        {

        //        Travel ="Travel",
        //        ProducerVisits ="Producer Visits",
        //        PVYtdCount =52,
        //        PVGoalYtdCount=50,
        //        PVGoalForYear=System.DateTime.Now ,
        //        PVGoalForYearCount=200,
        //        CustomerVisits="Customer Visits",
        //        CVYtdCount =22,
        //        CVGoalYtdCount=25,
        //        CVGoalForYear=System.DateTime.Now ,
        //        CVGoalForYearCount=100
        //        }
        //    };
        //    return Ok(trackingReportingGridOutputData);

        //}

        ///// <summary>
        ///// Load UnderWriter Sumamry New Business Lost and Decline Details
        ///// </summary>
        ///// <remarks>
        ///// Load UnderWriter Sumamry New Business Lost and Decline Details<br></br>
        ///// Required Fields : UserID, AccountMonth, AccountYear,TimeFrame
        ///// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,
        ///// AccountYear - Account Year Integer - 2018, 2019 etc.,
        ///// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" 
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>UWDashboardGridOutputModel</returns>
        ///// <response code="200">Record found</response>GetUWSummaryNewBusinessLostandDeclineDetails
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<UWSummaryNBLostAndDeclineOutputModel>))]
        //[HttpPost]
        //[Route("reports/underwriters/newbusiness/lostanddeclined/details")]   // NA
        //public IHttpActionResult GetUWSummaryNewBusinessLostandDeclineDetails([FromBody]LoadReportInputModel loadReportInputModel)
        //{
        //    if (String.IsNullOrEmpty(loadReportInputModel.UserID) || String.IsNullOrEmpty(loadReportInputModel.AccountMonth)
        //     || String.IsNullOrEmpty(loadReportInputModel.TimeFrame) || loadReportInputModel.AccountYear == 0)
        //    {
        //        if (String.IsNullOrEmpty(loadReportInputModel.UserID))
        //            return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
        //        if (String.IsNullOrEmpty(loadReportInputModel.AccountMonth))
        //            return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
        //        if (loadReportInputModel.AccountYear == 0)
        //            return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
        //        if (String.IsNullOrEmpty(loadReportInputModel.TimeFrame))
        //            return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
        //    }
        //    _logger.TraceStart();
        //    List<UWSummaryNBLostAndDeclineOutputModel> trackingReportingGridOutputData = _trackerReportingFacade.GetUWSummaryNewBusinessLostAndDeclineDetails(loadReportInputModel);
        //    _logger.TraceEnd();
        //    if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
        //    {
        //        return Ok(trackingReportingGridOutputData);
        //    }
        //    else
        //    {
        //        return Content(HttpStatusCode.NotFound, String.Format("No Scorecard Records found for UserID: {0}", loadReportInputModel.UserID));
        //    }
        //    //List<UWSummaryNBLostAndDeclineOutputModel> trackingReportingGridOutputData = new List<UWSummaryNBLostAndDeclineOutputModel>
        //    //{
        //    //    new UWSummaryNBLostAndDeclineOutputModel
        //    //    {
        //    //    Status = "Quoted",
        //    //    EffectiveDate = System.DateTime.Now ,
        //    //    GrossForecast   = 2000 ,
        //    //    ProducerName   = "Marsh",
        //    //    Customer   = "JBJ Farms Inc",
        //    //    ConfidenceFactor   = 3,
        //    //    PolicyNumber ="G56789123",
        //    //    IsWriteAccess = 67,
        //    //    Details = new DetailsInputModel
        //    //    {
        //    //        RecordNo = 5,
        //    //        CompanyName = "Company_1",
        //    //        GroupName = "Group_1",
        //    //        Subgroup = "Subgroup_1",
        //    //        Division = "Division_1",
        //    //        PolicyNumber = "125MBSL"
        //    //    }
        //    //    }
        //    //};
        //    // return Ok(trackingReportingGridOutputData);

        //}


        ///// <summary>
        ///// Load UnderWriter Sumamry New Business Lost and Decline Details
        ///// </summary>
        ///// <remarks>
        ///// Load UnderWriter Sumamry New Business Lost and Decline Details<br></br>
        ///// Required Fields : UserID, AccountMonth, AccountYear,TimeFrame
        ///// </remarks>
        ///// <param name="UWSummaryRNLostAndDeclineDetails">LoadReportInputModel</param>
        ///// <returns>UWDashboardGridOutputModel</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<UWSummaryRNLostAndDeclineOutputModel>))]
        //[HttpPost]
        //[Route("reports/underwriters/renewals/lostanddeclined/details")]  // NA
        //public IHttpActionResult GetUWSummaryRenewalsLostandDeclineDetails([FromBody]LoadReportInputModel UWSummaryRNLostAndDeclineDetails)
        //{
        //    List<UWSummaryRNLostAndDeclineOutputModel> trackingReportingGridOutputData = new List<UWSummaryRNLostAndDeclineOutputModel>
        //    {
        //        new UWSummaryRNLostAndDeclineOutputModel
        //        {
        //        EffectiveDate = System.DateTime.Now ,
        //        GrossForecast   = 2000 ,
        //        ProducerName   = "Marsh",
        //        Customer   = "JBJ Farms Inc",
        //        ConfidenceFactor   = 3,
        //        PolicyNumber ="G56789123",
        //        IsWriteAccess = 67,
        //        Details = new DetailsInputModel
        //        {
        //            RecordNo = 5,
        //            CompanyName = "Company_1",
        //            GroupName = "Group_1",
        //            Subgroup = "Subgroup_1",
        //            Division = "Division_1",
        //            PolicyNumber = "125MBSL"
        //        }
        //        }
        //    };
        //    return Ok(trackingReportingGridOutputData);

        //}

        ///// <summary>
        ///// Load data for Forecast By Segment report
        ///// </summary>
        ///// <remarks>
        ///// Load data for Scorecard Summary data<br></br>
        ///// Required Parameters : UserID, ScrenId, AccountMonth, AccountYear, TimeFrame
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>ForecastBySegmentOutputModel</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<ForecastBySegmentOutputModel>))]
        //[HttpPost]
        //[Route("reports/businessegments/forecasts")]   // NA
        //public IHttpActionResult GetForecastBySegment(LoadReportInputModel loadReportInputModel)
        //{
        //    List<ForecastBySegmentOutputModel> tasksOutputModel = new List<ForecastBySegmentOutputModel>
        //    {
        //        new ForecastBySegmentOutputModel
        //        {
        //            Insured = "EG America, LLC",
        //            EffectiveDate = Convert.ToDateTime("04/01/2018"),
        //            ExpirationDate = Convert.ToDateTime("04/01/2019"),
        //            Product = "Storaqge Tanks AST/UST",
        //            Producer = "AON",
        //            Type = "New",
        //            Status = "Quoted",
        //            ExpiringPremium = 104924,
        //            Forecast = 115327,
        //            Confidence = 4,
        //            CreditedRegion = "Midwest",
        //            UWLast = "Mora",
        //            AccountMonth = "April",
        //            PolicyNumber = "042MBF",
        //            Details = new DetailsInputModel
        //            {
        //                RecordNo = 5,
        //                CompanyName = "Agricultural Division",
        //                GroupName = "Agricuture",
        //                Subgroup = "Rain & Hail",
        //                Division = "Corp.",
        //                PolicyNumber = "125MBSL"
        //            }
        //        }
        //    };

        //    return Ok(tasksOutputModel);
        //}

        /// <summary>
        /// Load data for Scorecard Summary(ScreenName: Scorecard Overview)
        /// </summary>
        /// <remarks>
        /// Load data for Scorecard Summary data<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>
        /// </remarks>
        /// <param name="loadReportInputModel">LoadReportInputModel</param>
        /// <returns>ScorecardOverviewOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(ScorecardOverviewOutputModel))]
        [HttpPost]
        [Route("reports/scorecards/overviewreports/scorecards/overview")]   // R3
        public IHttpActionResult GetScorecardOverview(LoadReportInputModel loadReportInputModel)
        {

            if (String.IsNullOrEmpty(loadReportInputModel.UserID) || String.IsNullOrEmpty(loadReportInputModel.AccountMonth)
             || String.IsNullOrEmpty(loadReportInputModel.TimeFrame) || loadReportInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(loadReportInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(loadReportInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (loadReportInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(loadReportInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<ScorecardOverviewOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<ScorecardOverviewOutputModel>>(() => _trackerReportingFacade.GetScorecardOverview(loadReportInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Scorecard Records found for UserID: {0}", loadReportInputModel.UserID));
            }
        }

        /// <summary>
        /// Load data for Scorecard amount per division data (ScreenName: Scorecard Amount)
        /// </summary>
        /// <remarks>
        /// Load data for Scorecard amount per division data<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>
        /// DisplayResultBy - Should be fed as 'Segment' or 'PortFolio Class'
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>ScorecardAmountPerDivionOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ScorecardAmountPerDivionOutputModel>))]
        [HttpPost]
        [Route("reports/scorecards/divisions/forecasts")]  // R2
        public IHttpActionResult GetScorecardAmountPerDivision(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {

            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<ScorecardAmountPerDivionOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<ScorecardAmountPerDivionOutputModel>>(() => _trackerReportingFacade.GetScorecardAmountPerDivision(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Scorecard amount per divison found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }

        }

        /// <summary>
        /// Load data for Net Scorecard amount per division data (ScreenName: Net Scorecard Amount)
        /// </summary>
        /// <remarks>
        /// Load data for Net Scorecard amount per division data<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>
        /// DisplayResultBy - Should be fed as 'Segment' or 'PortFolio Class'
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>ScorecardAmountPerDivionOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ScorecardAmountPerDivionOutputModel>))]
        [HttpPost]
        [Route("reports/netscorecards/divisions/forecasts")]  // R2
        public IHttpActionResult GetNetScorecardAmountPerDivision(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {

            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<ScorecardAmountPerDivionOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<ScorecardAmountPerDivionOutputModel>>(() => _trackerReportingFacade.GetNetScorecardAmountPerDivision(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Scorecard amount per divison found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }

        }

        /// <summary>
        /// Load data for Regional Scorecard amount per Region (ScreenName: Regional Scorecard Amount)
        /// </summary>
        /// <remarks>
        /// Load data for Scorecard amount per division data<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>
        /// DisplayResultBy - Should be fed as 'Segment' or 'PortFolio Class'
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>ScorecardAmountPerDivionOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="204">Record not found</response>
        [ResponseType(typeof(IEnumerable<RegionalScorecardAmountPerRegionOutputModel>))]
        [HttpPost]
        [Route("reports/regionalscorecards/Regional/forecasts")]  // R2
        public IHttpActionResult GetRegionalScorecardAmountPerRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {

            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<RegionalScorecardAmountPerRegionOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<RegionalScorecardAmountPerRegionOutputModel>>(() => _trackerReportingFacade.GetRegionalScorecardAmountPerRegion(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("No Scorecard amount per divison found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }

        }

        /// <summary>
        /// Load data for Net Scorecard amount per Region (ScreenName: Net Scorecard Amount)
        /// </summary>
        /// <remarks>
        /// Load data for Net Scorecard amount per division data<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>
        /// DisplayResultBy - Should be fed as 'Segment' or 'PortFolio Class'
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>ScorecardAmountPerDivionOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="204">Record not found</response>
        [ResponseType(typeof(IEnumerable<RegionalScorecardAmountPerRegionOutputModel>))]
        [HttpPost]
        [Route("reports/netscorecards/Regional/forecasts")]  // R2
        public IHttpActionResult GetNetScorecardAmountPerRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {

            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<RegionalScorecardAmountPerRegionOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<RegionalScorecardAmountPerRegionOutputModel>>(() => _trackerReportingFacade.GetNetScorecardAmountPerRegion(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("No Scorecard amount per divison found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }

        }

        /// <summary>
        /// Load data for Scorecard new business by status (ScreenName: Scorecard New Business)
        /// </summary>
        /// <remarks>
        /// Load data for Scorecard new business by status<br></br>
        /// Required Parameters : UserID, ScrenId, AccountMonth, AccountYear, TimeFrame
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,
        /// AccountYear - Account Year Integer - 2018, 2019 etc.,
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" ,
        /// DisplayResultBy - Should be fed as 'Segment' or 'PortFolio Class'
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>ScorecardAmountPerDivionOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ScorecardByStatusOutputModel>))]
        [HttpPost]
        [Route("reports/scorecards/newbusiness")]  // R2
        public IHttpActionResult GetScorecardNewBusinessByStatus(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<ScorecardByStatusOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<ScorecardByStatusOutputModel>>(() => _trackerReportingFacade.GetScorecardNewBusinessByStatus(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Scorecard amount per divison found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }

        }

        /// <summary>
        /// Load data for Regional Scorecard new business by status (ScreenName: Regional Scorecard New Business)
        /// </summary>
        /// <remarks>
        /// Load data for Regional Scorecard new business by status<br></br>
        /// Required Parameters : UserID, ScrenId, AccountMonth, AccountYear, TimeFrame
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,
        /// AccountYear - Account Year Integer - 2018, 2019 etc.,
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" ,
        /// DisplayResultBy - Should be fed as 'Segment' or 'PortFolio Class'
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>RegionalScorecardByStatusOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="204">Record not found</response>
        [ResponseType(typeof(IEnumerable<RegionalScorecardNewBusinessByStatusOutputModel>))]
        [HttpPost]
        [Route("reports/regionalscorecards/newbusiness")]  // R2
        public IHttpActionResult GetRegionalScorecardNewBusinessByStatus(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<RegionalScorecardNewBusinessByStatusOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<RegionalScorecardNewBusinessByStatusOutputModel>>(() => _trackerReportingFacade.GetRegionalScorecardNewBusinessByStatus(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("No Scorecard amount per divison found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }
        }


        /// <summary>
        /// Load data for Scorecard Renewal by status (ScreenName: Scorecard Renewal)
        /// </summary>
        /// <remarks>
        /// Load data for Scorecard Renewal business by status<br></br>
        /// Required Parameters : UserID,  AccountMonth, AccountYear, TimeFrame.<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12".<br></br>
        /// DisplayResultBy - Should be fed as 'Segment' or 'PortFolio Class'
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>ScorecardAmountPerDivionOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ScorecardRenewalByStatusOutputModel>))]
        [HttpPost]
        [Route("reports/scorecards/renewals")]  // R2
        public IHttpActionResult GetScorecardRenewalByStatus(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<ScorecardRenewalByStatusOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<ScorecardRenewalByStatusOutputModel>>(() => _trackerReportingFacade.GetScorecardRenewalByStatus(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Scorecard amount per divison found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }

        }

        /// <summary>
        /// Load data for Regional Scorecard Renewal by status (ScreenName: Regional Scorecard Renewal)
        /// </summary>
        /// <remarks>
        /// Load data for Regional Scorecard Renewal business by status<br></br>
        /// Required Parameters : UserID,  AccountMonth, AccountYear, TimeFrame.<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12".<br></br>
        /// DisplayResultBy - Should be fed as 'Segment' or 'PortFolio Class'
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>ScorecardAmountPerDivionOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="204">Record not found</response>
        [ResponseType(typeof(IEnumerable<RegionalScorecardRenewalByStatusOutputModel>))]
        [HttpPost]
        [Route("reports/regionalscorecards/renewals")]  // R2
        public IHttpActionResult GetRegionalScorecardRenewalByStatus(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<RegionalScorecardRenewalByStatusOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<RegionalScorecardRenewalByStatusOutputModel>>(() => _trackerReportingFacade.GetRegionalScorecardRenewalByStatus(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("No Scorecard amount per divison found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }

        }

        #region Filter

        /// <summary>
        /// Load data for Underwriter filter control  (ScreenName: Underwriter Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Underwriter filter control
        /// </remarks>        
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/underwriters")]  // R2
        public IHttpActionResult GetUnderwriterFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetUnderwriterFilter("UnderWriter"));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No data found for Underwriter filter control");
            }
        }

        /// <summary>
        /// Load data for Underwriter Assistant filter control  (ScreenName: Underwriter Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Underwriter Assistant filter control
        /// </remarks>        
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/underwriterassistants")]  // R2
        public IHttpActionResult GetUnderwriterAssistantFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetUnderwriterFilter("UnderwriterAssistant"));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No data found for Underwriter Assistant filter control");
            }
        }

        /// <summary>
        /// Load data for equity firm filter control  (ScreenName: EquityFirm Filter)
        /// </summary>
        /// <remarks>
        /// Load data for equity firm filter control
        /// </remarks>        
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/equityfirm")]  // R2
        public IHttpActionResult GetequityfirmFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetequityfirmFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No data found for Underwriter filter control");
            }
        }

        /// <summary>
        /// Load data for Relationship Manager filter control (ScreenName: Relationship Manager filter)
        /// </summary>
        /// <remarks>
        /// Load data for Relationship Manager filter control
        /// </remarks>        
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/relationshipmanager")]  // R2
        public IHttpActionResult GetRelationshipManagerFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetRelationshipManagerFilter());
            _logger.TraceEnd();

            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No data found for Relationship Manager filter control");
            }
        }

        //TRKR-7661
        /// <summary>
        /// Load data for CAB Description filter control (ScreenName: CAB Description filter)
        /// </summary>
        /// <remarks>
        /// Load data for CAB Description filter control
        /// </remarks>        
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/cabdescription")]  // R2
        public IHttpActionResult GetCABDescriptionFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCABDescriptionFilter());
            _logger.TraceEnd();

            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No data found for Relationship Manager filter control");
            }
        }

        /// <summary>
        /// Load data for Relationship Manager filter control (ScreenName: Relationship Manager filter)
        /// </summary>
        /// <remarks>
        /// Load data for Relationship Manager filter control
        /// </remarks>        
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/industrypractice")]  // R2
        public IHttpActionResult GetIndustryPracticeFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetIndustryPracticeFilter());
            _logger.TraceEnd();

            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No data found for Relationship Manager filter control");
            }
        }
        /// <summary>
        /// Load data for Industry Practice Detail filter control (ScreenName: Relationship Manager filter)
        /// </summary>
        /// <remarks>
        /// Load data Industry Practice Detail filter control
        /// </remarks>        
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/industrypracticeDetail")]  // R2
        public IHttpActionResult GetIndustryPracticeDetailFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetIndustryPracticeDetailFilter());
            _logger.TraceEnd();

            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No data found for Industry Practice Detail filter control");
            }
        }
        /// <summary>
        /// Load data for SIC Code filter control(ScreenName: SIC Code Filter)
        /// </summary>
        /// <remarks>
        /// Load data for SIC Code filter control
        /// </remarks>        
        /// <returns>SICOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<SICOutputModel>))]
        [HttpPost]
        [Route("filters/siccode")]  // R2
        public IHttpActionResult GetSICCodeFilter()
        {
            _logger.TraceStart();
            List<SICOutputModel> dropdownOutputValues = UtilityHelper.ProcessException<List<SICOutputModel>>(() => _trackerReportingFacade.GetSICCodeFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No data found for SIC code filter control");
            }
        }
        /// <summary>
        /// Load data for Company filter control(ScreenName: Company Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Company filter control<br></br>
        /// Required Parameters : UserID
        /// </remarks>
        /// <param name="UserID">string</param>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpGet]
        [Route("filters/companies")]  // R2
        public IHttpActionResult GetCompanyFilter(string UserID)
        {
            if (String.IsNullOrEmpty(UserID))
            {
                return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
            }
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCompanyFilter(UserID));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No data found for Company filter control for UserID: {0}", UserID));
            }
        }

        /// <summary>
        /// Load data for Division filter control(ScreenName: Division Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Division filter control<br></br>
        /// Required Parameters : UserID<br></br>
        /// Optional Parametrs : Company(Multiselect)
        /// </remarks>
        /// <param name="UserID">string</param>
        /// <param name="Company">string</param>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/companies/divisions")]  // R2
        public IHttpActionResult GetDivisionFilter(string UserID, List<string> Company)
        {
            if (String.IsNullOrEmpty(UserID))
            {
                return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
            }
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetDivisionFilter(UserID, Company));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No data found for Division filter control for UserID: {0}", UserID));
            }
        }

        /// <summary>
        /// Load data for Owner Unit filter control(ScreenName: Activities)
        /// </summary>
        /// <remarks>
        /// Load data for Owner Unit filter control<br></br>
        /// Required Parameters : UserID<br></br>
        /// Optional Parametrs : Company(Multiselect)
        /// </remarks>
        /// <param name="UserID">string</param>
        /// <param name="Company">string</param>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/companies/ownerunits")]  // R2
        public IHttpActionResult GetOwnerUnitFilter(string UserID, List<string> Company)
        {
            if (String.IsNullOrEmpty(UserID))
            {
                return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
            }
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetOwnerUnitFilter(UserID, Company));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No data found for Division filter control for UserID: {0}", UserID));
            }
        }
        /// <summary>
        /// Load data for Unit filter control(ScreenName: Unit Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Unit filter control<br></br>
        /// Required Parameters : UserID<br></br>
        /// Optional Parametrs : Company,Division(Multiselect)
        /// </remarks>
        /// <param name="UnitFilterData">UnitFilterData</param>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/companies/divisions/units")]  // R2
        public IHttpActionResult GetUnitFilter(UnitFilterData UnitFilterData)
        {
            if (String.IsNullOrEmpty(UnitFilterData.UserID))
            {
                return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
            }
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetUnitFilter(UnitFilterData));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No data found for Unit filter control for UserID: {0}", UnitFilterData.UserID));
            }
        }

        /// <summary>
        /// Load data for Segment filter control (ScreenName: Segment Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Segment filter control<br></br>
        /// Required Parameters : UserID<br></br>
        /// optional Parameters : Company,Division,Unit(Multiselect)
        /// </remarks>
        /// <param name="segmentFilterData">SegmentFilterData</param>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/companies/divisions/units/segments")]  // R2
        public IHttpActionResult GetSegmentFilter(SegmentFilterData segmentFilterData)
        {
            if (String.IsNullOrEmpty(segmentFilterData.UserID))
            {
                return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
            }
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetSegmentFilter(segmentFilterData));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No data found for Segment filter control for UserID: {0}", segmentFilterData.UserID));
            }
        }

        /// <summary>
        /// Load data for Subsegment filter control (ScreenName: Subsegment Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Subsegment filter control<br></br>
        /// Required Parameters : UserID<br></br>
        /// optional Parameters : Company,Division,Unit,Segmemnt(Multiselect)
        /// </remarks>
        /// <param name="subsegmentFilterData">SubsegmentFilterData</param>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="204">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/companies/divisions/units/segments/subsegments")]  // R2
        public IHttpActionResult GetSubSegmentFilter(SubsegmentFilterData subsegmentFilterData)
        {
            if (String.IsNullOrEmpty(subsegmentFilterData.UserID))
            {
                return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
            }
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetSubSegmentFilter(subsegmentFilterData));
            _logger.TraceEnd();
            if (dropdownOutputValues != null && dropdownOutputValues.Count > 0)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("No data found for Subsegment filter control for UserID: {0}", subsegmentFilterData.UserID));
            }
        }

        /// <summary>
        /// Load data for MCC filter control (ScreenName: MCC Filter)
        /// </summary>
        /// <remarks>
        /// Load data for MCC filter control<br></br>
        /// Required Parameters : UserID<br></br>
        /// optional Parameters : Company,Division,Unit,Segmemnt(Multiselect)
        /// </remarks>
        /// <param name="mccFilterData">mccFilterData</param>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/companies/divisions/units/segments/mcc")]  // R2 - TRKR-7584
        public IHttpActionResult GetMCCFilter(MCCFilterData mccFilterData)
        {
            if (String.IsNullOrEmpty(mccFilterData.UserID))
            {
                return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
            }
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetMCCFilter(mccFilterData));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No data found for mcc filter control for UserID: {0}", mccFilterData.UserID));
            }
        }

        /// <summary>
        /// Load data for Portfolio Class filter control (ScreenName: Portfolio Class Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Portfolio Class filter control<br></br>
        /// Required Parameters : UserID<br></br>
        /// optional Parameters : Company,Division,Unit,Segmemnt,Subsegment(Multiselect)
        /// </remarks>
        /// <param name="portfolioClassFilterData">PortfolioClassFilterData</param>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/companies/divisions/units/segments/portfolioclasses")]  // R2
        public IHttpActionResult GetPortfolioClassFilter(PortfolioClassFilterData portfolioClassFilterData)
        {
            if (String.IsNullOrEmpty(portfolioClassFilterData.UserID))
            {
                return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
            }
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetPortfolioClassFilter(portfolioClassFilterData));

            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No data found for Portfolio Class filter control for UserID: {0}", portfolioClassFilterData.UserID));
            }
        }

        /// <summary>
        /// Load data for Status filter control (ScreenName: Status Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Status filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/status")]  // R2
        public IHttpActionResult GetStatusFilter()
        {

            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetStatusFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Status filter control");
            }
        }

        /// <summary>
        /// Load data for Incumbent filter control(ScreenName: Incumbent Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Incumbent filter control<br></br>
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/incumbents")]  // R2
        public IHttpActionResult GetIncumbentFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetIncumbentFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Incumbent filter control");
            }
        }

        /// <summary>
        /// Load data for Currency filter control (ScreenName: Currency Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Currency filter control<br></br>
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/currencies")]  // R2
        public IHttpActionResult GetCurrencyFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCurrencyFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Currency filter control");
            }
        }

        /// <summary>
        /// Load data for Underwriter Branch filter control(ScreenName: Underwriter Branch Filter)
        /// </summary>
        /// <remarks>
        ///  Load data for Underwriter Batch filter control<br></br>
        /// This filter option is not available in wireframe filter section. Assuming this will be available in the filters.<br></br>
        /// Optional Parametrs : Region
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/uwregion/uwbranches")]  // R2
        public IHttpActionResult GetUWBranchFilter([FromBody]List<string> Region)
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetUWBranchFilter(Region));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Underwriter Batch filter control");
            }
        }

        /// <summary>
        /// Load data for Product filter control (ScreenName: Product Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Product filter control<Br></Br>
        /// This filter option is not available in wireframe filter section. Assuming this will be available in the filters.
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/products")]  // R2
        public IHttpActionResult GetProductFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetProductFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Product filter control");
            }
        }

        /// <summary>
        /// Load data for Industry filter control (ScreenName: Industry Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Industry filter control<br></br>
        /// This filter option is not available in wireframe filter section. Assuming this will be available in the filters.
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/industries")]  // R2
        public IHttpActionResult GetIndustryFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetIndustryFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Industry filter control");
            }
        }


        /// <summary>
        /// Load data for Credited Branch filter control (ScreenName: Credited Branch Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Credited Branch filter control<br></br>
        /// Optional Parametrs : Region
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/creditedregion/creditedbranches")]  // R2
        public IHttpActionResult GetCreditedBranchFilter([FromBody]List<string> Region)
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCreditedBranchFilter(Region));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Credited Branch filter control");
            }
        }

        /// <summary>
        /// <returns>CreditedRegionBranchOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="204">Record not found</response>
        /// </summary>
        /// <returns></returns>
        [ResponseType(typeof(IEnumerable<CreditedRegionBranchOutputModel>))]
        [HttpPost]
        [Route("filters/creditedregionbranches")]  // R2
        public IHttpActionResult GetCreditedRegionBranchFilter()
        {
            _logger.TraceStart();
            List<CreditedRegionBranchOutputModel> creditedRegionBranchOutputValues = UtilityHelper.ProcessException<List<CreditedRegionBranchOutputModel>>(() => _trackerReportingFacade.GetCreditedRegionBranchFilter());
            _logger.TraceEnd();
            if (creditedRegionBranchOutputValues.Count > 0 && creditedRegionBranchOutputValues != null)
            {
                return Ok(creditedRegionBranchOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, "No data found for Credited Region Branch");
            }
        }

        /// <summary>
        /// Load data for RelationshipType filter control (ScreenName: RelationshipType Filter)
        /// </summary>
        /// <remarks>
        /// Load data for RelationshipType filter control<br></br>
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/relationshiptype")]  // R2
        public IHttpActionResult GetRelationshipTypeFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetRelationshipTypeFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for RelationshipType filter control");
            }
        }
        /// <summary>
        /// Load data for Credited Region filter control(ScreenName: RelationshipType Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Credited Region filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/creditedregions")]  // R2
        public IHttpActionResult GetCreditedRegionFilter()
        {

            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCreditedRegionFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Credited Region filter control");
            }
        }
        /// <summary>
        /// Load data for CRM Call Type filter control (ScreenName: CRM Call Type Filter)
        /// </summary>
        /// <remarks>
        /// Load data for CRM Call Type filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/dynamics/calltype")]  // R2
        public IHttpActionResult GetCRMCallTypeFilter()
        {

            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCRMCallTypeFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for CRM Call Type filter control");
            }
        }

        /// <summary>
        /// Load data for CRM Event Type filter control (ScreenName: CRM Event Type Filter)
        /// </summary>
        /// <remarks>
        /// Load data for CRM Event Type filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/dynamics/eventtype")]  // R2
        public IHttpActionResult GetCRMEventTypeFilter()
        {

            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCRMEventTypeFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for CRM Event Type filter control");
            }
        }
        /// <summary>
        /// Load data for filter values
        /// </summary>
        /// <remarks>
        /// Load data for filter control
        /// </remarks>
        /// <returns>FilterValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/dynamics/cornerstone")]  // R2
        public IHttpActionResult GetFilterTypeValue()
        {

            _logger.TraceStart();
            List<DropdownOutputValues> filterValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCornerstoneValues());
            _logger.TraceEnd();
            if (filterValues.Count > 0 && filterValues != null)
            {
                return Ok(filterValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for filter control");
            }
        }
        /// <summary>
        /// Load data for CRM Chubb Market Segment filter control(ScreenName: CRM Chubb Segment Filter)
        /// </summary>
        /// <remarks>
        /// Load data for CRMChubb Market Segment filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/dynamics/chubbmarketsegment")]  // R2
        public IHttpActionResult GetCRMChubbMarketSegmentFilter()
        {

            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCRMChubbMarketSegmentFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for CRM Call Type filter control");
            }
        }
        /// <summary>
        /// Load data for CRM Activity Type filter control(ScreenName: CRM Activity Type Filter)
        /// </summary>
        /// <remarks>
        /// Load data for CRM Activity Type filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/dynamics/activitytype")]  // R2
        public IHttpActionResult GetCRMActivityTypeFilter()
        {

            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCRMActivityTypeFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for CRM Activity Type filter control");
            }
        }
        /// <summary>
        /// Load data for CRM Contact Type filter control(ScreenName: CRM Contact Type Filter)
        /// </summary>
        /// <remarks>
        /// Load data for CRM Contact Type filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/dynamics/contacttype")]  // R2
        public IHttpActionResult GetCRMContactTypeFilter()
        {

            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCRMContactTypeFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for CRM Contact Type filter control");
            }
        }


        /// <summary>
        /// Load data for CRM Role filter control(ScreenName: Contact search)
        /// </summary>
        /// <remarks>
        /// Load data for CRM Role filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/dynamics/crmrole")]  // R2
        public IHttpActionResult GetCRMRoleFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCRMRoleFilter());

            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for CRM Role filter control");
            }
        }

        /// <summary>
        /// Load data for CRM ProductSpecialization control(ScreenName: Contact search)
        /// </summary>
        /// <remarks>
        /// Load data for CRM ProductSpecialization filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/dynamics/productspecialization")]  // R2
        public IHttpActionResult GetCRMProductSpecializationFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCRMProductSpecializationFilter());

            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for CRM product specialization filter control");
            }
        }

        /// <summary>
        /// Load data for CRM IndustrySpecialization control(ScreenName: Contact search)
        /// </summary>
        /// <remarks>
        /// Load data for CRM ProductSpecialization filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/dynamics/industryspecialization")]  // R2
        public IHttpActionResult GetCRMIndustrySpecializationFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCRMIndustrySpecializationFilter());

            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for CRM industry specialization filter control");
            }
        }

        /// <summary>
        /// Load data for CRM ChubbBusinessUnit control(ScreenName: Contact search)
        /// </summary>
        /// <remarks>
        /// Load data for CRM ChubbBusinessUnit filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/dynamics/cubbbusinessunit")]  // R2
        public IHttpActionResult GetCRMChubbBusinessUnitFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCRMChubbBusinessUnitFilter());

            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for CRM Chubb business unit filter control");
            }
        }

        /// <summary>
        /// Load data for CRM Company Owner Type filter control(ScreenName: CRM Company Owner Type Filter)
        /// </summary>
        /// <remarks>
        /// Load data for CRM Company Owner Type filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/dynamics/companyownertype")]  // R2
        public IHttpActionResult GetCRMCompanyOwnerTypeFilter()
        {

            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCRMCompanyOwnerTypeFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for CRM Company Owner Type filter control");
            }
        }
        /// <summary>
        /// Load data for CRM User Type filter control(ScreenName: CRM User Type Filter)
        /// </summary>
        /// <remarks>
        /// Load data for CRM User Type filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/dynamics/usertype")]  // R2
        public IHttpActionResult GetCRMUserTypeFilter()
        {

            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCRMUserTypeFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for CRM User Type filter control");
            }
        }
        /// <summary>
        /// Load data for CRM Status Type filter control(ScreenName: CRM Status Type Filter)
        /// </summary>
        /// <remarks>
        /// Load data for CRM Status Type filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/dynamics/statustype")]  // R2
        public IHttpActionResult GetCRMStatusTypeFilter()
        {

            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCRMStatusTypeFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for CRM Status Type filter control");
            }
        }
        /// <summary>
        /// Load data for CRM Producer filter control(ScreenName: CRM Producer Filter)
        /// </summary>
        /// <remarks>
        /// Load data for CRM Producer filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/dynamics/producer")]  // R2
        public IHttpActionResult GetCRMProducerFilter()
        {

            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCRMProducerFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for CRM Producer filter control");
            }
        }
        /// <summary>
        /// Load data for Capacity filter control(ScreenName:Capacity Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Capacity filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/capacities")]  // R2

        public IHttpActionResult GetCapacityFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCapacityFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Capacity filter control");
            }
        }

        /// <summary>
        /// Load data for Insured City filter control(ScreenName: Insured City Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Insured City filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/insuredstate/insuredcities")]  // R2
        public IHttpActionResult GetInsuredCityFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetInsuredCityFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for  Insured City filter control");
            }
        }

        /// <summary>
        /// Load data for Insured State filter control(ScreenName: Insured State Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Insured State filter control<br></br>
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/insuredstates")]  // R2
        public IHttpActionResult GetInsuredStateFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetInsuredStateFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for  Insured State filter control");
            }
        }

        /// <summary>
        /// Load data for PGroup filter control(ScreenName: PGroup Filter)
        /// </summary>
        /// <remarks>
        /// Load data for PGroup filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/pgroups")]  // R2
        public IHttpActionResult GetPGroupFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetPGroupFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for PGroup filter control");
            }
        }

        /// <summary>
        /// Load data for CustomerGroup filter control(ScreenName: CustomerGroup Filter)
        /// </summary>
        /// <remarks>
        /// Load data for CustomerGroup filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/Customergroups")]  // R2
        public IHttpActionResult GetCustomerGroupFilter()//TRKR-5701
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCustomerGroupFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for CustomerGroup filter control");
            }
        }

        /// <summary>
        /// Load data for Producer Branch filter control(ScreenName: Producer Branch Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Producer Branch filter control<br></br>
        /// Optional Parametrs : Region,ProducerName,PASCode<br></br>
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/producerregion/producerbranches")] // R2
        public IHttpActionResult GetProducerBranchFilter([FromBody]ProducerBranchFilterInputModel objProducerBranchFilterInputModel)
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetProducerBranchFilter(objProducerBranchFilterInputModel));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Producer Branch filter control");
            }
        }

        /// <summary>
        /// Load data for Producer region filter control(ScreenName: Producer Region Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Producer region filter control<br></br>
        /// Optional Parametrs : ProducerName , PASCode<br></br>
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/producerregions")] // R2
        public IHttpActionResult GetProducerRegionFilter([FromBody]ProducerRegionFilterInputModel objProducerBranchFilterInputModel)
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetProducerRegionFilter(objProducerBranchFilterInputModel));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Producer region filter control");
            }
        }


        /// <summary>
        /// Load data for Producer City filter control(ScreenName: Producer City Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Producer City filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/producerstate/producercities")]  // R2
        public IHttpActionResult GetProducerCityFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetProducerCityFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Producer City filter control");
            }
        }



        /// <summary>
        /// Load data for Producer state filter control(ScreenName: Producer State Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Producer state filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/producerstates")]  // R2
        public IHttpActionResult GetProducerStateFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetProducerStateFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Producer state filter control");
            }
        }


        /// <summary>
        /// Load data for Producer Group filter control(ScreenName: Producer Group Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Producer Group filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/producergroups")]  // R2
        public IHttpActionResult GetProducerGroupFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetProducerGroupFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Producer Group filter control");
            }
        }

        /// <summary>
        /// Load data for TClass filter control(ScreenName: TClass Filter)
        /// </summary>
        /// <remarks>
        ///  Load data for TClass filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/tclasses")]  // R2
        public IHttpActionResult GetTClassFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetTClassFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for TClass filter control");
            }
        }

        /// <summary>
        /// Load data for Terror Coverage filter control(ScreenName: Terror Coverage Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Terror Coverage filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/terrorcoverage")]  // R2
        public IHttpActionResult GetTerrorCoverageFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetTerrorCoverageFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Terror Coverage filter control");
            }
        }

        /// <summary>
        /// Load Data for Accounting Month Filter Control(ScreenName: Accounting Month)
        /// </summary>
        /// <remarks>
        /// Load Data for Accounting Month Filter Control.
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/AccountingMonth")]  // R2
        public IHttpActionResult GetAccountingMonthFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetAccountingMonthFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Accounting Month filter control");
            }

        }

        /// <summary>
        /// Load Data for Accounting Year Filter Control.(ScreenName: Accounting Year)
        /// </summary>
        /// <remarks>
        /// Load Data for Accounting Year Filter Control.
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/AccountingYear")]  // R2
        public IHttpActionResult GetAccountingYearFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetAccountingYearFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Accounting Year filter control");
            }
        }

        /// <summary>
        /// Load Data for Target Type Filter Control.(ScreenName: Target Type Filter)
        /// </summary>
        /// <remarks>
        /// Load Data for Target Type Filter Control.
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/TargetType")]  // R2
        public IHttpActionResult GetTargetTypeFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetTargetTypeFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Target Type filter control");
            }
        }

        /// <summary>
        /// Load Data for Transaction Type Filter Control.(ScreenName: Transaction Type Filter)
        /// </summary>
        /// <remarks>
        /// Load Data for Transaction Type Filter Control.
        /// </remarks>       
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/TransactionType")]  // R2
        public IHttpActionResult GetTransactionTypeFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetTransactionTypeFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Transaction Type filter control");
            }

        }

        /// <summary>
        /// Load Data for Program Filter Control.(ScreenName: Program Filter)
        /// </summary>
        /// <remarks>
        /// Load Data for Program Filter Control.
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/Program")]  // R2
        public IHttpActionResult GetProgramFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetProgramFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Transaction Type filter control");
            }
        }

        /// <summary>
        /// Load Data for Marketing Manager Filter.(ScreenName: Marketing Manager Filter)
        /// </summary>
        /// <remarks>
        /// Load Data for Marketing Manager Filter.
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/MarketingManager")]  // R2
        public IHttpActionResult GetMarketingManagerFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetMarketingManagerFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Marketing Manager filter control");
            }
        }


        /// <summary>
        /// Load Data for DataSource filter.(ScreenName: DataSource Filter)
        /// </summary>
        /// <remarks>
        /// Load Data for DataSource filter.
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/DataSource")]  // R2
        public IHttpActionResult GetDataSourceFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetDataSourceFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for DataSource filter control");
            }

        }

        /// <summary>
        /// Load Data for Chubb Industry filter.(ScreenName: Chubb Industry Filter)
        /// </summary>
        /// <remarks>Load Data for Chubb Industry filter.</remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/ChubbIndustry")]  // R2
        public IHttpActionResult GetChubbIndustryFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetChubbIndustryFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Chubb Industry filter control");
            }
        }

        /// <summary>
        /// Load Data for Under Writer Region filter.(ScreenName: UnderWriter Region Filter)
        /// </summary>
        /// <remarks>
        ///  Load Data for Under Writer Region filter.
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/UWRegion")]  // R2
        public IHttpActionResult GetUWRegionFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetUWRegionFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Under Writer Region filter control");
            }
        }



        /// <summary>
        /// Load data for Customer filter control(ScreenName: Customer Filter)
        /// </summary>
        /// <remarks>
        /// Load data for Customer filter control.<br></br>  
        /// Optional Parametrs : AccountType,DunsNumber <br></br>
        /// </remarks>
        /// <returns>CustomerFilterOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>      
        [ResponseType(typeof(IEnumerable<CustomerFilterOutputModel>))]
        [HttpPost]
        [Route("filters/Customer")] // R4
        public IHttpActionResult GetCustomerFilter([FromBody]CustomerFilterInputModel CustomerFilterInputModel)
        {
            _logger.TraceStart();
            List<CustomerFilterOutputModel> dropdownOutputValues = UtilityHelper.ProcessException<List<CustomerFilterOutputModel>>(() => _trackerReportingFacade.GetCustomerFilter(CustomerFilterInputModel));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Customer filter control");
            }
        }

        /// <summary>
        /// Created for To Get Insured Details based on DNB Number/Insured Number
        /// </summary>
        /// <param name="DBNumber"></param>
        /// <returns></returns>
        [ResponseType(typeof(IEnumerable<InsuredDNBDetailOutputModel>))]
        [HttpPost]
        [Route("users/{DBNumber}/insured")]
        public IHttpActionResult GetInsuredDetailByDBNumber(string DBNumber)
        {
            if (String.IsNullOrEmpty(DBNumber))
            {
                return Content(HttpStatusCode.BadRequest, "DB Number not passed for the request");
            }
            _logger.TraceStart();
            List<InsuredDNBDetailOutputModel> insuredDetails = UtilityHelper.ProcessException<List<InsuredDNBDetailOutputModel>>(() => _trackerReportingFacade.GetInsuredDetailByDBNumber(DBNumber));
            _logger.TraceEnd();

            if (insuredDetails != null && insuredDetails.Count > 0)
            {
                return Ok(insuredDetails);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("No Insured Details found for DBNumber: {0}", DBNumber));
            }
        }

        /// <summary>
        /// Created for to get producer Details based on producer code
        /// </summary>
        /// <param name="producercode"></param>
        /// <returns></returns>
        [ResponseType(typeof(IEnumerable<ProducerDetailOutputModel>))]
        [HttpPost]
        [Route("filters/{producercode}/producer")]
        public IHttpActionResult GetProducerDetailsByCode(string producercode)
        {
            if (String.IsNullOrEmpty(producercode))
            {
                return Content(HttpStatusCode.BadRequest, "producercode not passed for the request");
            }
            _logger.TraceStart();
            List<ProducerDetailOutputModel> producerDetails = UtilityHelper.ProcessException<List<ProducerDetailOutputModel>>(() => _trackerReportingFacade.GetProducerDetailsByCode(producercode));
            _logger.TraceEnd();

            if (producerDetails != null && producerDetails.Count > 0)
            {
                return Ok(producerDetails);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("No Producer Details found for ProducerCode: {0}", producercode));
            }
        }

        /// <summary>
        /// Created for to get Impediment 
        /// </summary>
        /// <returns></returns>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/Impediment")]
        public IHttpActionResult GetImpediment()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetImpediment());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, "No data found for Impediment");
            }
        }

        /// <summary>
        /// Created for to get Successful Producer 
        /// </summary>
        /// <returns></returns>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/SuccessfulProducer")]
        public IHttpActionResult GetSuccessfulProducer()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetSuccessfulProducer());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, "No data found for Successful Producer");
            }
        }

        /// <summary>
        /// Created for to get LostReason based on the status 
        /// </summary>
        /// <returns></returns>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/status/LostReason")]
        public IHttpActionResult GetLostReasonByStatus(LostReasonInputModel lostReasonInputModel)
        {
            if (String.IsNullOrEmpty(lostReasonInputModel.Status))
            {
                return Content(HttpStatusCode.BadRequest, "status not passed for the request");
            }

            string Status = lostReasonInputModel.Status;
            string Unit = string.IsNullOrEmpty(lostReasonInputModel.Unit) ? null : lostReasonInputModel.Unit;
            string Segment = string.IsNullOrEmpty(lostReasonInputModel.Segment) ? null : lostReasonInputModel.Segment;

            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetLostReasonByStatus(Status, Unit, Segment));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, "No data found for Lost Reason");
            }
        }


        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("filters/{uwbranch}/uwregion")]
        public IHttpActionResult GetUWRegionByUWBranch(string uwBranch)
        {
            if (String.IsNullOrEmpty(uwBranch))
            {
                return Content(HttpStatusCode.BadRequest, "UWBranch not passed for the request");
            }
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetUWRegionByUWBranch(uwBranch));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues[0].Text);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, "No data found for UW Branch");
            }
        }

        #endregion

        ///// <summary>
        ///// Load data for Maximum Forecast Amount filter control
        ///// </summary>
        ///// <remarks>
        ///// 
        ///// </remarks>
        ///// <returns>DropdownOutputValues</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        //[HttpPost]
        //[Route("filters/maximumforecast")]  // NA
        //public IHttpActionResult GetMaximumForecastAmount()
        //{
        //    _logger.TraceStart();
        //    DropdownOutputValues dropdownOutputValues = UtilityHelper.ProcessException<DropdownOutputValues>(() => _trackerReportingFacade.GetMaximumForecastAmount());
        //    _logger.TraceEnd();
        //    return Ok(dropdownOutputValues);
        //}


        ///// <summary>
        ///// Load data for Customer Branch Summary InForce and Pipeline By Line of Business
        ///// </summary>
        ///// <remarks>
        ///// Load data for Customer Branch Summary InForce and Pipeline By Line of Business<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>BranchSummaryInForceandPipelineLOB</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<BranchSummaryInForceandPipelineLOB>))]
        //[HttpPost]
        //[Route("reports/branch/lineofbusiness/inforceandpipeline")]  // NA
        //public IHttpActionResult GetBranchSummaryInForceandPipelineLOB(LoadReportInputModel loadReportInputModel)
        //{
        //    List<BranchSummaryInForceandPipelineLOB> branchSummaryInForceandPipelineLOBs = new List<BranchSummaryInForceandPipelineLOB>
        //    {
        //        new BranchSummaryInForceandPipelineLOB
        //        {
        //            Company = "Commercial Insurance",
        //            Division = "Commercial Insurance Division",
        //            Unit = "A&H",
        //            Segment = "Emplloyee Benefits",
        //            InForceForecast = 1000,
        //            InForceExpiringPremium = 1000,
        //            InForceCount = 10,
        //            NewBusinessPipeLine = 1000,
        //            NewBusinessForecast = 1000,
        //            NewBusinessCount = 10,
        //            RenewalsForecast = 1000,
        //            RenewalsCount = 10,
        //            TotalPipeline = 1000,
        //            TotalForecast = 1000
        //        }
        //    };

        //    return Ok(branchSummaryInForceandPipelineLOBs);
        //}

        ///// <summary>
        ///// Load data for Customer Branch Summary Lost and Declined By Line Of Business
        ///// </summary>
        ///// <remarks>
        ///// Load data for Customer Branch Summary Lost and Declined By Line Of Business<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>BranchSummaryLostandDeclinedLOB</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<BranchSummaryLostandDeclinedLOB>))]
        //[HttpPost]
        //[Route("reports/branch/lineofbusiness/lostanddeclined")]  // NA
        //public IHttpActionResult GetBranchSummaryLostandDeclinedLOB(LoadReportInputModel loadReportInputModel)
        //{
        //    List<BranchSummaryLostandDeclinedLOB> branchSummaryLostandDeclinedLOBs = new List<BranchSummaryLostandDeclinedLOB>
        //    {
        //        new BranchSummaryLostandDeclinedLOB
        //        {
        //            Company = "Commercial Insurance",
        //            Division = "Commercial Insurance Division",
        //            Unit = "A&H",
        //            Segment = "Emplloyee Benefits",
        //            NewBusinessQuotedLostForecast = 1000,
        //            NewBusinessQuotedLostCount = 10,
        //            NewBusinessDeclinedForecast = 1000,
        //            NewBusinessDeclinedCount = 50,
        //            RenewalsLostForecast = 100,
        //            RenewalsLostExpiringPremium = 100,
        //            RenewalsLostCount = 10,
        //            RenewalsDeclinedForecast = 1000,
        //            RenewalsDeclinedCount = 50
        //        }
        //    };

        //    return Ok(branchSummaryLostandDeclinedLOBs);
        //}

        /// <summary>
        /// Load data forDetail report(ScreenName: Detail Report)
        /// </summary>
        /// <remarks>
        /// Load data for Detail report<Br></Br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,<Br></Br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.,<Br></Br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <Br></Br>
        /// If user choose EffectiveDate /Expiration Date/CreateDate/BoundDate value. They need to pass the Datefilter flag for the Respective Filter value <br></br>
        /// DateFilterFlag  - EFFDATE, EXPDATE, CREDATE, BOUNDDATE<br></br>
        /// EquityType value: ('Private Equity' or 'Non-Private Equity')<br></br>
        /// If you choose Chubb industry value . SICTYPE Value - Need to pass  one of the  Mandatory value ("Risk SIC" or "DNB SIC" )<br></br>
        /// </remarks>
        /// <param name="loadReportInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>CustomerBranchDetailReport</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DetailReport>))]
        [HttpPost]
        [Route("reports/details")]  // R2
        public IHttpActionResult GetDetailReport(TrackingReportingCommonFilterInputModel loadReportInputModel)
        {
            if (String.IsNullOrEmpty(loadReportInputModel.UserID) || String.IsNullOrEmpty(loadReportInputModel.AccountMonth)
            || String.IsNullOrEmpty(loadReportInputModel.TimeFrame) || loadReportInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(loadReportInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(loadReportInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (loadReportInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(loadReportInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();
            List<DetailReport> detailReports = UtilityHelper.ProcessException<List<DetailReport>>(() => _trackerReportingFacade.GetDetailReport(loadReportInputModel));
            _logger.TraceEnd();
            if (detailReports != null && detailReports.Count > 1)
            {
                //var response = new HttpResponseMessage();
                //response.Headers.Add("HeaderValue", "TestValue");
                //response.Content
                //return new ResponseMessageResult(response);
                return Ok(detailReports);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("No Detail report Records found for UserID: {0}", loadReportInputModel.UserID));
            }

        }
        /// <summary>
        /// For ArchiveDetails Report 
        /// </summary>
        /// <param name="loadReportInputModel"></param>
        /// <returns></returns>
        [ResponseType(typeof(IEnumerable<DetailReport>))]
        [HttpPost]
        [Route("reports/archive/details")]  // R2
        public IHttpActionResult GetArchiveDetailReport(TrackingReportingCommonFilterInputModel loadReportInputModel)
        {
            if (String.IsNullOrEmpty(loadReportInputModel.UserID) || String.IsNullOrEmpty(loadReportInputModel.AccountMonth)
            || String.IsNullOrEmpty(loadReportInputModel.TimeFrame) || loadReportInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(loadReportInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(loadReportInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (loadReportInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(loadReportInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();
            List<DetailReport> archivedetailReports = UtilityHelper.ProcessException<List<DetailReport>>(() => _trackerReportingFacade.GetArchiveDetailReport(loadReportInputModel));
            _logger.TraceEnd();
            if (archivedetailReports != null && archivedetailReports.Count > 1)
            {
                //var response = new HttpResponseMessage();
                //response.Headers.Add("HeaderValue", "TestValue");
                //response.Content
                //return new ResponseMessageResult(response);
                return Ok(archivedetailReports);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("No Detail report Records found for UserID: {0}", loadReportInputModel.UserID));
            }

        }
        /// <summary>
        /// Created for Target Report
        /// </summary>
        /// <param name="loadReportInputModel"></param>
        /// <returns></returns>
        [ResponseType(typeof(IEnumerable<TargetReportOutputModel>))]
        [HttpPost]
        [Route("reports/targetsummary")]
        public IHttpActionResult GetTargetReport(TrackingReportingCommonFilterInputModel loadReportInputModel)
        {
            if (String.IsNullOrEmpty(loadReportInputModel.UserID) || String.IsNullOrEmpty(loadReportInputModel.AccountMonth)
            || String.IsNullOrEmpty(loadReportInputModel.TimeFrame) || loadReportInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(loadReportInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(loadReportInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (loadReportInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(loadReportInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();
            List<TargetReportOutputModel> targetReports = UtilityHelper.ProcessException<List<TargetReportOutputModel>>(() => _trackerReportingFacade.GetTargetReport(loadReportInputModel));
            _logger.TraceEnd();
            if (targetReports != null && targetReports.Count > 1)
            {
                return Ok(targetReports);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("No Target report Records found for UserID: {0}", loadReportInputModel.UserID));
            }

        }

        /// <summary>
        /// Load data for Insured report(ScreenName: Insured Report)
        /// </summary>
        /// <remarks>
        /// Load data for Insured report<Br></Br>
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,<Br></Br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.,<Br></Br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <Br></Br>
        /// Need to pass Underwriter Id for Underwriter name since drop down value passing uderwriter ID.<br></br> 
        /// Effective and Expiration Date,ConfidenceFactor Output format changed into String<br></br> 
        /// Sort by: EffectiveDate,ExpirationDate,GrossForecast,ProducerName,ProducerCity,Customer<br></br> 
        /// Product,ConfidenceFactor,Source,RecordNo,CompanyName,GroupName,SubGroup,Division,PolicyNumber,Type,Status,Underwriter,CreditedRegion,Month,Expiring<br></br>
        /// Pass the exact Insured name to avoid the time out issue. We are getting the records using like search based on Insured name<Br></Br>
        /// We are displaying below 100 records only . if Records crosses more than 100, we are showing  message -More than 100 records returned. Please refine your search!<br></br>
        /// </remarks>
        /// <param name="loadReportInputModel">InsuredSearchFilterInputModel</param>
        /// <returns>DetailReport</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<InsuredReport>))]
        [HttpPost]
        [Route("reports/Insured")]  // R2
        public HttpResponseMessage GetInsuredReport(InsuredSearchFilterInputModel loadReportInputModel)
        {

            if (String.IsNullOrEmpty(loadReportInputModel.UserID))
            {
                var response = Request.CreateResponse(HttpStatusCode.BadRequest, "UserID not passed for the request");
                //return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                return response;
            }


            _logger.TraceStart();

            InsuredReportOutputModel detailReports = UtilityHelper.ProcessException<InsuredReportOutputModel>(() => _trackerReportingFacade.GetInsuredReport(loadReportInputModel));
            _logger.TraceEnd();
            if ((detailReports.InsuredReport != null) && (detailReports.Pagination != null))
            {

                if ((detailReports.InsuredReport.Count > 1 && detailReports.Pagination.TotalCount < 50000))
                {
                    var response = Request.CreateResponse(HttpStatusCode.OK, detailReports);
                    return response;

                }
                else
                {
                    var response = Request.CreateResponse(HttpStatusCode.OK, "More than 50000 records returned. Please refine your search!");
                    response.Headers.Add("NoContent", "More than 50000 records returned.Please refine your search!");
                    return response;
                }

            }
            else
            {
                var response = Request.CreateResponse(HttpStatusCode.NoContent, "No Insured report records found for the search criteria");
                response.Headers.Add("NoContent", "No Insured report records found for the search criteria");
                return response;
                //return Content(HttpStatusCode.NoContent, "No Insured report records found for the search criteria");
            }

        }
        /// <summary>
        /// Load data for ArchiveInsured report(ScreenName: archiveInsured Report)
        /// </summary>
        /// <remarks>
        /// Load data for ArchiveInsured report<Br></Br>
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,<Br></Br>
        /// AccountYear - Account Year Integer - 2011, 2010 etc.,<Br></Br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <Br></Br>
        /// Need to pass Underwriter Id for Underwriter name since drop down value passing uderwriter ID.<br></br> 
        /// Effective and Expiration Date,ConfidenceFactor Output format changed into String<br></br> 
        /// Sort by: EffectiveDate,ExpirationDate,GrossForecast,ProducerName,ProducerCity,Customer<br></br> 
        /// Product,ConfidenceFactor,Source,RecordNo,CompanyName,GroupName,SubGroup,Division,PolicyNumber,Type,Status,Underwriter,CreditedRegion,Month,Expiring<br></br>
        /// Pass the exact Insured name to avoid the time out issue. We are getting the records using like search based on Insured name<Br></Br>
        /// We are displaying below 100 records only . if Records crosses more than 100, we are showing  message -More than 100 records returned. Please refine your search!<br></br>
        /// </remarks>
        /// <param name="loadReportInputModel">InsuredSearchFilterInputModel</param>
        /// <returns>DetailReport</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<InsuredReport>))]
        [HttpPost]
        [Route("reports/archive/Insured")]  // R2
        public HttpResponseMessage GetarchiveInsuredReport(InsuredSearchFilterInputModel loadReportInputModel)
        {

            if (String.IsNullOrEmpty(loadReportInputModel.UserID))
            {
                var response = Request.CreateResponse(HttpStatusCode.BadRequest, "UserID not passed for the request");
                //return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                return response;
            }


            _logger.TraceStart();

            InsuredReportOutputModel detailReports = UtilityHelper.ProcessException<InsuredReportOutputModel>(() => _trackerReportingFacade.GetArchiveInsuredReport(loadReportInputModel));
            _logger.TraceEnd();
            if ((detailReports.InsuredReport != null) && (detailReports.Pagination != null))
            {

                if ((detailReports.InsuredReport.Count > 1 && detailReports.Pagination.TotalCount < 50000))
                {
                    var response = Request.CreateResponse(HttpStatusCode.OK, detailReports);
                    return response;

                }
                else
                {
                    var response = Request.CreateResponse(HttpStatusCode.OK, "More than 50000 records returned. Please refine your search!");
                    response.Headers.Add("NoContent", "More than 50000 records returned.Please refine your search!");
                    return response;
                }

            }
            else
            {
                var response = Request.CreateResponse(HttpStatusCode.NoContent, "No Insured report records found for the search criteria");
                response.Headers.Add("NoContent", "No Insured report records found for the search criteria");
                return response;
                //return Content(HttpStatusCode.NoContent, "No Insured report records found for the search criteria");
            }

        }


        ///// <summary>
        ///// Load data for Customer Branch Summary Additional Lines Not Targeted
        ///// </summary>
        ///// <remarks>
        ///// Load data for Customer Branch Summary Additional Lines Not Targeted<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// Assuming DOOR3 can take the count from the Tracker API response and show it in the header line.<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>CustomerBranchSummaryNotTargeted</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<CustomerBranchSummaryNotTargeted>))]
        //[HttpPost]
        //[Route("reports/branch/customer/nottargeted")]  // NA
        //public IHttpActionResult GetCustomerBranchSummaryNotTargeted(LoadReportInputModel loadReportInputModel)
        //{
        //    List<CustomerBranchSummaryNotTargeted> customerBranchSummaryNotTargeted = new List<CustomerBranchSummaryNotTargeted>
        //    {
        //        new CustomerBranchSummaryNotTargeted
        //        {
        //            Line = "Marine",
        //            Reason = "Exposure"
        //        }
        //    };

        //    return Ok(customerBranchSummaryNotTargeted);
        //}

        ///// <summary>
        ///// Load data for In Force and Pipeline by customer location
        ///// </summary>
        ///// <remarks>
        ///// Load data for In Force and Pipeline by customer location<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>CustomerNationalSummaryInforceandPipeline</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<CustomerNationalSummaryInforceandPipeline>))]
        //[HttpPost]
        //[Route("reports/national/customer/inforceandpipeline")]  // NA
        //public IHttpActionResult GetCustomerNationalSummaryInforceandPipeline(LoadReportInputModel loadReportInputModel)
        //{
        //    List<CustomerNationalSummaryInforceandPipeline> customerNationalSummaryInforceandPipelines = new List<CustomerNationalSummaryInforceandPipeline>
        //    {
        //        new CustomerNationalSummaryInforceandPipeline
        //        {
        //            CustomerCityState = "Boston",
        //            CustomerAddress = "123 Broadway, Boston, MA 10036",
        //            InForceForecast = 1000,
        //            ExpiringForecast = 1000,
        //            InForceCount = 1,
        //            NewBusinessPipeline = 1000,
        //            NewBusinessForecast = 1000,
        //            NewBusinessCount = 2,
        //            RenewalsForecast = 1000,
        //            RenewalsCount = 2,
        //            TotalPipeLine = 1000,
        //            TotalForecast = 1000
        //        }
        //    };

        //    return Ok(customerNationalSummaryInforceandPipelines);
        //}

        ///// <summary>
        ///// Load data for Lost and Declined by customer location
        ///// </summary>
        ///// <remarks>
        ///// Load data for Lost and Declined by customer location<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>CustomerNationalSummaryLostandDeclinedByLocation</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<CustomerNationalSummaryLostandDeclinedByLocation>))]
        //[HttpPost]
        //[Route("reports/national/customer/location/lostanddeclined")]  // NA
        //public IHttpActionResult GetCustomerNationalSummaryLostandDeclinedByLocation(LoadReportInputModel loadReportInputModel)
        //{
        //    List<CustomerNationalSummaryLostandDeclinedByLocation> customerNationalSummaryLostandDeclinedByLocations = new List<CustomerNationalSummaryLostandDeclinedByLocation>
        //    {
        //        new CustomerNationalSummaryLostandDeclinedByLocation
        //        {
        //            CustomerCityState = "Boston",
        //            CustomerAddress = "123 Broadway, Boston, MA 10036",
        //            NewBusinessQuotedLostForecast = 1000,
        //            NewBusinessQuotedLostCount = 10,
        //            NewBusinessDeclinedForecast = 1000,
        //            NewBusinessDeclinedCount = 77,
        //            RenewalsLostForecast = 100,
        //            RenewalsLostExpiringPremium = 100,
        //            RenewalsLostCount = 10,
        //            RenewalsDeclinedForecast = 1000,
        //            RenewalsDeclinedCount = 77
        //        }
        //    };

        //    return Ok(customerNationalSummaryLostandDeclinedByLocations);
        //}

        ///// <summary>
        ///// Load data for Chubb Customers Branch Summary Lost and Declined By Customers
        ///// </summary>
        ///// <remarks>
        ///// Load data for Chubb Customers Branch Summary Lost and Declined By Customers<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>CustomersBranchSummaryILostandDeclinedCustomer</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<CustomersBranchSummaryILostandDeclinedCustomer>))]
        //[HttpPost]
        //[Route("reports/branch/customer/lostanddeclined")]  // NA
        //public IHttpActionResult GetCustomersBranchSummaryILostandDeclinedCustomer(LoadReportInputModel loadReportInputModel)
        //{
        //    List<CustomersBranchSummaryILostandDeclinedCustomer> customersBranchSummaryILostandDeclinedCustomers = new List<CustomersBranchSummaryILostandDeclinedCustomer>
        //    {
        //        new CustomersBranchSummaryILostandDeclinedCustomer
        //        {
        //            CustomerName = "ABC Company",
        //            CustomerCityState = "Fords, NJ",
        //            NewBusinessQuotedLostForecast = 1000,
        //            NewBusinessQuotedLostCount = 10,
        //            NewBusinessDeclinedForecast = 1000,
        //            NewBusinessDeclinedCount = 50,
        //            RenewalsLostForecast = 100,
        //            RenewalsLostExpiringPremium = 100,
        //            RenewalsLostCount = 10,
        //            RenewalsDeclinedForecast = 1000,
        //            RenewalsDeclinedCount = 50
        //        }
        //    };

        //    return Ok(customersBranchSummaryILostandDeclinedCustomers);
        //}

        ///// <summary>
        ///// Load data for Chubb Customers Branch Summary InForce and Pipeline By Customers
        ///// </summary>
        ///// <remarks>
        ///// Load data for Chubb Customers Branch Summary InForce and Pipeline By Customers<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>CustomersBranchSummaryInForceandPipelineCustomer</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<CustomersBranchSummaryInForceandPipelineCustomer>))]
        //[HttpPost]
        //[Route("reports/branch/customer/inforceandpipeline")]  // NA
        //public IHttpActionResult GetCustomersBranchSummaryInForceandPipelineCustomer(LoadReportInputModel loadReportInputModel)
        //{
        //    List<CustomersBranchSummaryInForceandPipelineCustomer> customersBranchSummaryInForceandPipelineCustomers = new List<CustomersBranchSummaryInForceandPipelineCustomer>
        //    {
        //        new CustomersBranchSummaryInForceandPipelineCustomer
        //        {
        //            CustomerName = "ABC Company",
        //            CustomerCityState = "Fords, NJ",
        //            InForceForecast = 1000,
        //            InForceExpiring = 1000,
        //            InForceCount = 1,
        //            RenewalsForecast = 1000,
        //            RenewalsCount = 2,
        //            TotalPipeline = 1000,
        //            TotalForecast = 1000
        //        }
        //    };

        //    return Ok(customersBranchSummaryInForceandPipelineCustomers);
        //}

        ///// <summary>
        ///// Load data for Customer Stewardship Plan Load
        ///// </summary>
        ///// <remarks>
        /////  Load data for Customer Stewardship Plan Load<Br></Br>
        ///// Required Parameters : UserID<Br></Br>
        ///// </remarks>
        ///// <param name="UserID">String</param>
        ///// <returns>CustomerStewardshipPlan</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<CustomerStewardshipPlan>))]
        //[HttpPost]
        //[Route("reports/customer/StewardshipPlan")]  // NA
        //public IHttpActionResult GetCustomerStewardshipPlan(string UserID)
        //{
        //    CustomerStewardshipPlan customerStewardshipPlan = new CustomerStewardshipPlan
        //    {
        //        RenewalStrategy = new List<RenewalStrategyModel>
        //        {
        //            new RenewalStrategyModel
        //            {
        //                StrategyID = 1256,
        //                UserID = "g9gopi",
        //                StrategyType = "Lorem Ipsum",
        //                Owner = "Lorem Ipsum",
        //                Date = Convert.ToDateTime("02/15/2018")
        //            }
        //        },
        //        Services = new List<ServicesModel>
        //        {
        //            new ServicesModel
        //            {
        //                ServiceID = 5421,
        //                UserID = "g9gopi",
        //                Service = "Lorem Ipsum",
        //                Owner = "Lorem Ipsum",
        //                Date = Convert.ToDateTime("02/15/2018")
        //            }
        //        },
        //        NewLinesAdded = new List<NewLinesModel>
        //        {
        //            new NewLinesModel
        //            {
        //                LineID = 87563,
        //                UserID = "g9gopi",
        //                LineName = "Line Name",
        //                Premium = 12234,
        //                EffectiveDate = Convert.ToDateTime("02/15/2018")
        //            }
        //        },
        //        ClaimsServices = new List<ClaimsServicesModel>
        //        {
        //            new ClaimsServicesModel
        //            {
        //                ClaimsID = 465132,
        //                UserID = "g9gopi",
        //                ClaimsServiceType = "Lorem Ipsum",
        //                Owner = "Lorem Ipsum",
        //                Date = Convert.ToDateTime("02/15/2018"),
        //                DueDate = Convert.ToDateTime("02/15/2018")
        //            }
        //        },
        //        RetentionPercentage = 90,
        //        RetainedCount = 90,
        //        LostCount = 10
        //    };

        //    return Ok(customerStewardshipPlan);
        //}

        ///// <summary>
        ///// Load data for Customer National Summary
        ///// </summary>
        ///// <remarks>
        ///// Load data for Customer National Summary <Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>CustomerSummaryOverview</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<CustomerSummaryOverview>))]
        //[HttpPost]
        //[Route("reports/customer/overview")]  // NA
        //public IHttpActionResult GetCustomerSummaryOverview(LoadReportInputModel loadReportInputModel)
        //{
        //    List<CustomerSummaryOverview> customerSummaryOverviews = new List<CustomerSummaryOverview>
        //    {
        //        new CustomerSummaryOverview
        //        {
        //            Year = 2017,
        //            InForceForecast = 1050,
        //            PolicyCount = 9,
        //            HistoricalFlag = true
        //        }
        //    };

        //    return Ok(customerSummaryOverviews);
        //}

        ///// <summary>
        ///// Load data for Producer Branch Summary Glance Overview
        ///// </summary>
        ///// <remarks>
        ///// Load data for Producer Branch Summary Glance Overview<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>ProducerBranchSummaryGlanceOverview</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(ProducerBranchSummaryGlanceOverview))]
        //[HttpPost]
        //[Route("reports/branch/producer/overview")]  // NA
        //public IHttpActionResult GetProducerBranchSummaryGlanceOverview(LoadReportInputModel loadReportInputModel)
        //{
        //    ProducerBranchSummaryGlanceOverview producerBranchSummaryGlanceOverviews = new ProducerBranchSummaryGlanceOverview
        //    {
        //        SubmissionQuoteRatio = 22,
        //        SubmissionEfficiencyRatio = 25,
        //        SubmissionHitRatio = 25,
        //        YOYSubmittedRatio = 50.36F,
        //        YOYQuotedRatio = 50.36F,
        //        YOYBoundRatio = 50.36F,
        //        RenewalRetenion = 23,
        //        EstimatedAnnualPlacement = 3111111,
        //        NewBusinessBoundForecast = 890000,
        //        RenewalBoundForecast = 1994081,
        //        TotalBoundForecast = 1994081
        //    };

        //    return Ok(producerBranchSummaryGlanceOverviews);
        //}

        ///// <summary>
        ///// Load data for Producer Branch Summary Lost and Declined by Business Segment
        ///// </summary>
        ///// <remarks>
        ///// Load data for Producer Branch Summary Lost and Declined by Business Segment<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>ProducerBranchSummaryLostandDeclinedbyBusinessSegment</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<ProducerBranchSummaryLostandDeclinedbyBusinessSegment>))]
        //[HttpPost]
        //[Route("reports/branch/producer/businesssegment/lostanddeclined")]  // NA
        //public IHttpActionResult GetProducerBranchSummaryLostandDeclinedbyBusinessSegment(LoadReportInputModel loadReportInputModel)
        //{
        //    List<ProducerBranchSummaryLostandDeclinedbyBusinessSegment> producerBranchSummaries = new List<ProducerBranchSummaryLostandDeclinedbyBusinessSegment>
        //    {
        //        new ProducerBranchSummaryLostandDeclinedbyBusinessSegment
        //        {
        //            BusinessSegment = "Agriculture",
        //            NewbusinessQuotedLostAmount = 1000,
        //            NewbusinessQuotedLostCount = 10,
        //            NewbusinessDeclinedAmount = 1000,
        //            NewbusinessDeclinedCount = 50,
        //            RenewalsLostForecast = 100,
        //            RenewalsLostBaseOrExpiring = 100,
        //            RenewalsLostCount = 10,
        //            RenewalsDeclinedAmount = 1000,
        //            RenewalsDeclinedCount = 50
        //        }

        //    };

        //    return Ok(producerBranchSummaries);
        //}

        ///// <summary>
        ///// Load data for Producer Branch Summary Producer Plan
        ///// </summary>
        ///// <remarks>
        ///// Load data for Producer Branch Summary Producer Plan<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>ProducerBranchSummaryProducerPlanList</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<ProducerBranchSummaryProducerPlanList>))]
        //[HttpPost]
        //[Route("reports/branch/producer/producerplanlist")]  // NA
        //public IHttpActionResult GetProducerBranchSummaryProducerPlanList(LoadReportInputModel loadReportInputModel)
        //{
        //    List<ProducerBranchSummaryProducerPlanList> producerBranchSummaryProducerPlanLists = new List<ProducerBranchSummaryProducerPlanList>
        //    {
        //        new ProducerBranchSummaryProducerPlanList
        //        {
        //            ProdProfileID = 1254,
        //            ProdProfileName = "",
        //            CornerstoneProfile = 0,
        //            ProdProfileOwner = "",
        //            ProdProfileOwnerRegion = "",
        //            ProdProfileOwnerBranch = "",
        //            ProdProfileAddressCity = "",
        //            ProdProfileAddressStPr = "",
        //            ProdProfileAddressZip = ""
        //        }

        //    };

        //    return Ok(producerBranchSummaryProducerPlanLists);
        //}

        ///// <summary>
        ///// Load data for Producer Branch Summary Renewals by Business Segment
        ///// </summary>
        ///// <remarks>
        ///// Load data for Producer Branch Summary Renewals by Business Segment<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>ProducerBranchSummaryRenewalsbyBusinessSegment</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<ProducerBranchSummaryRenewalsbyBusinessSegment>))]
        //[HttpPost]
        //[Route("reports/branch/producer/businesssegment/renewals")]  // NA
        //public IHttpActionResult GetProducerBranchSummaryRenewalsbyBusinessSegment(LoadReportInputModel loadReportInputModel)
        //{
        //    List<ProducerBranchSummaryRenewalsbyBusinessSegment> producerBranchSummaries = new List<ProducerBranchSummaryRenewalsbyBusinessSegment>
        //    {
        //        new ProducerBranchSummaryRenewalsbyBusinessSegment
        //        {
        //            BusinessSegment = "Agriculture",
        //            SubmittedCount = 10,
        //            SubmittedAmount = 1000,
        //            QuotedCount = 10,
        //            QuotedAmount = 1000,
        //            BoundCount = 10,
        //            BoundAmount = 1000,
        //            Retention = 42.88F,
        //            BoundForecast = 4900
        //        }

        //    };

        //    return Ok(producerBranchSummaries);
        //}

        ///// <summary>
        ///// Get data for Producer National Summary Glance Overview
        ///// </summary>
        ///// <remarks>
        ///// Get data for Producer National Summary Glance Overview<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>ProducerNationalSummaryGlanceOverview</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(ProducerNationalSummaryGlanceOverview))]
        //[HttpPost]
        //[Route("reports/national/producer/overview")]  // NA
        //public IHttpActionResult GetProducerNationalSummaryGlanceOverview(LoadReportInputModel loadReportInputModel)
        //{
        //    ProducerNationalSummaryGlanceOverview producerNationalSummaryGlanceOverview = new ProducerNationalSummaryGlanceOverview
        //    {
        //        SubmissionQuoteRatio = 22,
        //        SubmissionEfficiencyRatio = 25,
        //        SubmissionHitRatio = 25,
        //        YOYSubmittedRatio = 50.36F,
        //        YOYQuotedRatio = 50.36F,
        //        YOYBoundRatio = 50.36F,
        //        RenewalRetenion = 23,
        //        EstimatedAnnualPlacement = 12111111,
        //        NewBusinessBoundForecast = 9990000,
        //        RenewalBoundForecast = 1994081,
        //        TotalBoundForecast = 1994081
        //    };

        //    return Ok(producerNationalSummaryGlanceOverview);
        //}


        ///// <summary>
        ///// Load data for Producer National Summary Lost and Declined by Producer Location
        ///// </summary>
        ///// <remarks>
        ///// Load data for Producer National Summary Lost and Declined by Producer Location<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>ProducerNationalSummaryLostandDeclinedbyProducerLocation</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<ProducerNationalSummaryLostandDeclinedbyProducerLocation>))]
        //[HttpPost]
        //[Route("reports/national/producer/producerlocation/lostanddeclined")]  // NA
        //public IHttpActionResult GetProducerNationalSummaryLostandDeclinedbyProducerLocation(LoadReportInputModel loadReportInputModel)
        //{
        //    List<ProducerNationalSummaryLostandDeclinedbyProducerLocation> producerNationalSummaries = new List<ProducerNationalSummaryLostandDeclinedbyProducerLocation>
        //    {
        //        new ProducerNationalSummaryLostandDeclinedbyProducerLocation
        //        {
        //            BranchOrUnderwriter = "Long Island",
        //            NewbusinessQuotedLostAmount = 1000,
        //            NewbusinessQuotedLostCount = 10,
        //            NewbusinessDeclinedAmount = 1000,
        //            NewbusinessDeclinedCount = 50,
        //            RenewalsLostForecast = 100,
        //            RenewalsLostBaseOrExpiring = 100,
        //            RenewalsLostCount = 10,
        //            RenewalsDeclinedAmount = 1000,
        //            RenewalsDeclinedCount = 50
        //        }

        //    };

        //    return Ok(producerNationalSummaries);
        //}

        ///// <summary>
        ///// Load data for Producer Branch Summary New business Grid by Business Segment
        ///// </summary>
        ///// <remarks>
        ///// Load data for Producer Branch Summary New business Grid by Business Segment<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>ProducerNationalSummaryNewBusinessbyBusinessSegment</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<ProducerNationalSummaryNewBusinessbyBusinessSegment>))]
        //[HttpPost]
        //[Route("reports/national/producer/businesssegment/newbusiness")]  // NA
        //public IHttpActionResult GetProducerNationalSummaryNewBusinessbyBusinessSegment(LoadReportInputModel loadReportInputModel)
        //{
        //    List<ProducerNationalSummaryNewBusinessbyBusinessSegment> producerNationalSummaries = new List<ProducerNationalSummaryNewBusinessbyBusinessSegment>
        //    {
        //        new ProducerNationalSummaryNewBusinessbyBusinessSegment
        //        {
        //            BusinessSegment = "Agriculture",
        //            TargetedCount = 10,
        //            TargetedEstimatedAmount = 1000,
        //            SubmittedCount = 10,
        //            SubmittedEstimatedAmount = 1000,
        //            QuotedCount = 10,
        //            QuotedEstimatedAmount = 1000,
        //            QuoteRatio = 42.88F,
        //            BoundCount = 10,
        //            BoundEfficiencyRatio = 42.88F,
        //            BoundHitRatio = 42.88F,
        //            BoundForecast = 4900
        //        }

        //    };

        //    return Ok(producerNationalSummaries);
        //}

        ///// <summary>
        ///// Get data for Producer National Summary New business Grid
        ///// </summary>
        ///// <remarks>
        ///// Get data for Producer National Summary New business Grid<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>ProducerNationalSummaryNewBusinessbyProducerLocation</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<ProducerNationalSummaryNewBusinessbyProducerLocation>))]
        //[HttpPost]
        //[Route("reports/national/producer/producerlocation/newbusiness")]  // NA
        //public IHttpActionResult GetProducerNationalSummaryNewBusinessbyProducerLocation(LoadReportInputModel loadReportInputModel)
        //{
        //    List<ProducerNationalSummaryNewBusinessbyProducerLocation> producerNationalSummaries = new List<ProducerNationalSummaryNewBusinessbyProducerLocation>
        //    {
        //        new ProducerNationalSummaryNewBusinessbyProducerLocation
        //        {
        //            RegionOrCity = "New York, NY",
        //            TargetedCount = 10,
        //            TargetedEstimatedAmount = 1000,
        //            SubmittedCount = 10,
        //            SubmittedEstimatedAmount = 1000,
        //            QuotedCount = 10,
        //            QuotedEstimatedAmount = 1000,
        //            QuoteRatio = 42.88F,
        //            BoundCount = 10,
        //            BoundEfficiencyRatio = 42.88F,
        //            BoundHitRatio = 42.88F,
        //            BoundForecast = 4900
        //        }

        //    };

        //    return Ok(producerNationalSummaries);
        //}

        ///// <summary>
        ///// Get data for Producer National Summary Producer Plan
        ///// </summary>
        ///// <remarks>
        ///// Get data for Producer National Summary Producer Plan<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>ProducerNationalSummaryProducerPlanList</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<ProducerNationalSummaryProducerPlanList>))]
        //[HttpPost]
        //[Route("reports/national/producer/producerplanlist")]  // NA
        //public IHttpActionResult GetProducerNationalSummaryProducerPlanList(LoadReportInputModel loadReportInputModel)
        //{
        //    List<ProducerNationalSummaryProducerPlanList> producerNationalSummaries = new List<ProducerNationalSummaryProducerPlanList>
        //    {
        //        new ProducerNationalSummaryProducerPlanList
        //        {
        //            ProdProfileID = 1254,
        //            ProdProfileName = "",
        //            CornerstoneProfile = 0,
        //            ProdProfileOwner = "",
        //            ProdProfileOwnerRegion = "",
        //            ProdProfileOwnerBranch = "",
        //            ProdProfileAddressCity = "",
        //            ProdProfileAddressStPr = "CA",
        //            ProdProfileAddressZip = "92614"
        //        }

        //    };

        //    return Ok(producerNationalSummaries);
        //}

        ///// <summary>
        ///// Get data for Producer National Summary Renewals by Producer Location
        ///// </summary>
        ///// <remarks>
        ///// Get data for Producer National Summary Renewals by Producer Location<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>ProducerNationalSummaryRenewalsbyProducerLocation</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<ProducerNationalSummaryRenewalsbyProducerLocation>))]
        //[HttpPost]
        //[Route("reports/national/producer/producerlocation/renewals")]  // NA
        //public IHttpActionResult GetProducerNationalSummaryRenewalsbyProducerLocation(LoadReportInputModel loadReportInputModel)
        //{
        //    List<ProducerNationalSummaryRenewalsbyProducerLocation> producerNationalSummaries = new List<ProducerNationalSummaryRenewalsbyProducerLocation>
        //    {
        //        new ProducerNationalSummaryRenewalsbyProducerLocation
        //        {
        //            RegionOrCity = "NewYork, NY",
        //            SubmittedCount = 10,
        //            SubmittedAmount = 1000,
        //            QuotedCount = 10,
        //            QuotedAmount = 1000,
        //            BoundCount = 10,
        //            BoundAmount= 1000,
        //            Retention = 10,
        //            BoundForecast = 1000
        //        }

        //    };

        //    return Ok(producerNationalSummaries);
        //}

        ///// <summary>
        ///// Load Producer Plan of General Business Outlook
        ///// </summary>
        ///// <remarks>
        ///// Load Producer Plan of General Business Outlook<Br></Br>
        ///// Required Parameters : UserID, ProducerProfileID<Br></Br>
        ///// </remarks>
        ///// <param name="producerPlanInput">ProducerPlanInput</param>
        ///// <returns>ProducerPlanGeneralBusinessOutlook</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<ProducerPlanGeneralBusinessOutlook>))]
        //[HttpPost]
        //[Route("reports/producer/plan/generalbusinessoutlook")]  // NA
        //public IHttpActionResult GetProducerPlanGeneralBusinessOutlook(ProducerPlanInput producerPlanInput)
        //{
        //    List<ProducerPlanGeneralBusinessOutlook> producerPlans = new List<ProducerPlanGeneralBusinessOutlook>
        //    {
        //        new ProducerPlanGeneralBusinessOutlook
        //        {
        //            GeneralBusinessOutlook = "",
        //            ProducerProfileID = 465132
        //        }

        //    };

        //    return Ok(producerPlans);
        //}

        ///// <summary>
        ///// Load Producer Plan Glance
        ///// </summary>
        ///// <remarks>
        ///// Load Producer Plan Glance<Br></Br>
        ///// Required Parameters : UserID, ProducerProfileID<Br></Br>
        ///// </remarks>
        ///// <param name="producerPlanInput">ProducerPlanInput</param>
        ///// <returns>ProducerPlanGlanceOverview</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<ProducerPlanGlanceOverview>))]
        //[HttpPost]
        //[Route("reports/producer/plan/overview")]  // NA
        //public IHttpActionResult GetProducerPlanGlanceOverview(ProducerPlanInput producerPlanInput)
        //{
        //    List<ProducerPlanGlanceOverview> producerPlans = new List<ProducerPlanGlanceOverview>
        //    {
        //        new ProducerPlanGlanceOverview
        //        {
        //            EstimatedTotalAnnualPlacements = 41251,
        //            TargetedPremium = 250000
        //        }

        //    };

        //    return Ok(producerPlans);
        //}

        ///// <summary>
        ///// Load Producer Plan of Goals
        ///// </summary>
        ///// <remarks>
        ///// Load Producer Plan of Goals<Br></Br>
        ///// Required Parameters : UserID, ProducerProfileID<Br></Br>
        ///// </remarks>
        ///// <param name="producerPlanInput">ProducerPlanInput</param>
        ///// <returns>ProducerPlanGoals</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<ProducerPlanGoals>))]
        //[HttpPost]
        //[Route("reports/producer/plan/goals")]  // NA
        //public IHttpActionResult GetProducerPlanGoals(ProducerPlanInput producerPlanInput)
        //{
        //    List<ProducerPlanGoals> producerPlans = new List<ProducerPlanGoals>
        //    {
        //        new ProducerPlanGoals
        //        {
        //            ProdProfileID = 45124,
        //            ProdProfileOfficeID = 542,
        //            CompanyName = "A&H Commercial",
        //            Unit = "A&H",
        //            TopCarrier1 = "North American Specialty Insurance",
        //            TopCarrier2 = "BerkShire Hathaway",
        //            TopCarrier3 = "Atlantic Mutual",
        //            InForceBoundForecast = 100000,
        //            TargetPremium = 10000,
        //            TargetedLine = 1,
        //            EstimatedPenetration = 0.00M,
        //            EstimatedTotalAnnualPlacement = 3000,
        //            Comments = "Comments"
        //        }

        //    };

        //    return Ok(producerPlans);
        //}

        ///// <summary>
        ///// Load Producer Plan of Growth Outlook Tactics
        ///// </summary>
        ///// <remarks>
        ///// Load Producer Plan of Growth Outlook Tactics <Br></Br>
        ///// Required Parameters : UserID, ProducerProfileID <Br></Br>
        ///// </remarks>
        ///// <param name="producerPlanInput">ProducerPlanInput</param>
        ///// <returns>ProducerPlanGrowthOutlookTactics</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<ProducerPlanGoals>))]
        //[HttpPost]
        //[Route("reports/producer/plan/growthoutlooktactics")]  // NA
        //public IHttpActionResult GetProducerPlanGrowthOutlookTactics(ProducerPlanInput producerPlanInput)
        //{
        //    List<ProducerPlanGrowthOutlookTactics> producerPlans = new List<ProducerPlanGrowthOutlookTactics>
        //    {
        //        new ProducerPlanGrowthOutlookTactics
        //        {
        //            InternalStrategiesOpportName = "",
        //            ProducerProfileID = 465
        //        }

        //    };

        //    return Ok(producerPlans);
        //}

        ///// <summary>
        ///// Save General Business Outlook of Producer Plan
        ///// </summary>
        ///// <remarks>
        ///// Save General Business Outlook of Producer Plan  <Br></Br>
        ///// Required Parameters : UserID, ProducerProfileID, GeneralBusinessOutlookSave General Business Outlook of Producer Plan  <Br></Br>
        ///// </remarks>
        ///// <param name="producerPlan">ProducerPlanGeneralBusinessOutlookSave</param>
        ///// <response code="200">Saved Successfully</response>
        ///// <response code="404">Failed to save</response>
        //[HttpPost]
        //[Route("reports/producer/plan/savegeneralbusinessoutlook")]  // NA
        //public IHttpActionResult SaveProducerPlanGeneralBusinessOutlook(ProducerPlanGeneralBusinessOutlookSave producerPlan)
        //{
        //    return Ok();
        //}

        ///// <summary>
        ///// Add a Goals of Producer Plan
        ///// </summary>
        ///// <remarks>
        ///// Add a Goals of Producer Plan <Br></Br> 
        ///// Required Parameters : UserID, ProdProfileID, CompanyName, Unit, InForceBoundForecast<Br></Br>
        ///// </remarks>
        ///// <param name="producerPlanGoalsSave">ProducerPlanGoalsSave</param>
        ///// <response code="200">Saved Successfully</response>
        ///// <response code="404">Failed to save</response>
        //[HttpPost]
        //[Route("reports/producer/plan/savegoals")]  // NA
        //public IHttpActionResult SaveProducerPlanGoals(ProducerPlanGoalsSave producerPlanGoalsSave)
        //{
        //    return Ok();
        //}

        ///// <summary>
        ///// Add a Goals Comment of Producer Plan
        ///// </summary>
        ///// <remarks>
        ///// Add a Goals Comment of Producer Plan <Br></Br>
        ///// Required Parameters : UserID, ProdProfileID, CompanyName, Unit<Br></Br>
        ///// </remarks>
        ///// <param name="producerPlanGoalsCommentsSave">ProducerPlanGoalsCommentsSave</param>
        ///// <response code="200">Saved Successfully</response>
        ///// <response code="404">Failed to save</response>
        //[HttpPost]
        //[Route("reports/producer/plan/savegoalcomments")]  // NA
        //public IHttpActionResult SaveProducerPlanGoalsComments(ProducerPlanGoalsCommentsSave producerPlanGoalsCommentsSave)
        //{
        //    return Ok();
        //}

        ///// <summary>
        ///// Save Growth Outlook Tactics of Producer Plan
        ///// </summary>
        ///// <remarks>
        ///// Save Growth Outlook Tactics of Producer Plan <Br></Br>
        ///// Required Parameters : UserID, ProdProfileID, InternalStrategiesOpportName<Br></Br>
        ///// </remarks>
        ///// <param name="producerPlanGrowthOutlookTacticsSave">ProducerPlanGrowthOutlookTacticsSave</param>
        ///// <response code="200">Saved Successfully</response>
        ///// <response code="404">Failed to save</response>
        //[HttpPost]
        //[Route("reports/producer/plan/savegrowthoutlooktactics")]  // NA
        //public IHttpActionResult SaveProducerPlanGrowthOutlookTactics(ProducerPlanGrowthOutlookTacticsSave producerPlanGrowthOutlookTacticsSave)
        //{
        //    return Ok();
        //}

        ///// <summary>
        ///// UnderWriter Summary Pipeline Details
        ///// </summary>
        ///// <remarks>
        ///// UnderWriter Summary Pipeline Details<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,
        ///// AccountYear - Account Year Integer - 2018, 2019 etc.,
        ///// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" 
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>UWSummaryPipelineDetails</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<UWSummaryPipelineDetails>))]
        //[HttpPost]
        //[Route("reports/underwriters/pipeline/details")]  // NA
        //public IHttpActionResult GetUWSummaryPipelineDetails(LoadReportInputModel loadReportInputModel)
        //{
        //    if (String.IsNullOrEmpty(loadReportInputModel.UserID) || String.IsNullOrEmpty(loadReportInputModel.AccountMonth)
        //     || String.IsNullOrEmpty(loadReportInputModel.TimeFrame) || loadReportInputModel.AccountYear == 0)
        //    {
        //        if (String.IsNullOrEmpty(loadReportInputModel.UserID))
        //            return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
        //        if (String.IsNullOrEmpty(loadReportInputModel.AccountMonth))
        //            return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
        //        if (loadReportInputModel.AccountYear == 0)
        //            return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
        //        if (String.IsNullOrEmpty(loadReportInputModel.TimeFrame))
        //            return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
        //    }
        //    _logger.TraceStart();
        //    List<UWSummaryPipelineDetails> trackingReportingGridOutputData = _trackerReportingFacade.GetUWSummaryPipelineDetails(loadReportInputModel);
        //    _logger.TraceEnd();
        //    if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
        //    {
        //        return Ok(trackingReportingGridOutputData);
        //    }
        //    else
        //    {
        //        return Content(HttpStatusCode.NotFound, String.Format("No Scorecard Records found for UserID: {0}", loadReportInputModel.UserID));
        //    }


        //}

        ///// <summary>
        ///// UnderWriter Summary Report Details
        ///// </summary>
        ///// <remarks>
        ///// UnderWriter Summary Report Details<Br></Br>
        ///// Required Parameters : UserID<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>UWSummaryKeyReportDetails</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<UWSummaryKeyReportDetails>))]
        //[HttpPost]
        //[Route("reports/underwriters/keyreport/details")]  // NA
        //public IHttpActionResult GetUWSummaryKeyReportDetails(LoadReportInputModel loadReportInputModel)
        //{
        //    List<UWSummaryKeyReportDetails> uWSummaryKeyReportDetails = new List<UWSummaryKeyReportDetails>
        //    {
        //        new UWSummaryKeyReportDetails
        //        {
        //            KeyReports = "",
        //            ReportMenuID = 32
        //        }

        //    };

        //    return Ok(uWSummaryKeyReportDetails);
        //}

        ///// <summary>
        ///// UW Manager Overview Section 
        ///// </summary>
        ///// <remarks>
        ///// UW Manager Overview Section <Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>UWSummaryGlanceOverview</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(UWSummaryGlanceOverview))]
        //[HttpPost]
        //[Route("reports/underwriters/overview")]  // NA
        //public IHttpActionResult GetUWSummaryGlanceOverview(LoadReportInputModel loadReportInputModel)
        //{
        //    UWSummaryGlanceOverview uWSummaryGlanceOverviews = new UWSummaryGlanceOverview
        //    {

        //        PipelineTotal = 1500,
        //        ForecastTotal = 1300,
        //        PlanTotal = 110000,
        //        TargetedCount = 2,
        //        TargetedAmount = 200,
        //        SubmittedCount = 3,
        //        SubmittedAmount = 300,
        //        QuotedCount = 6,
        //        QuotedAmount = 600,
        //        BoundCount = 4,
        //        BoundAmount = 400
        //    };

        //    return Ok(uWSummaryGlanceOverviews);
        //}

        ///// <summary>
        ///// UnderWriter Region Summary Pipeline By Branch or UnderWriter
        ///// </summary>
        ///// <remarks>
        ///// UnderWriter Region Summary Pipeline By Branch or UnderWriter<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>UWRegionSummaryPipelineByBranchOrUW</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<UWRegionSummaryPipelineByBranchOrUW>))]
        //[HttpPost]
        //[Route("reports/underwriters/region/pipeline/details")]  // NA
        //public IHttpActionResult GetUWRegionSummaryPipelineByBranchOrUW(LoadReportInputModel loadReportInputModel)
        //{
        //    List<UWRegionSummaryPipelineByBranchOrUW> uWRegionSummaryPipelineByBranchOrUWs = new List<UWRegionSummaryPipelineByBranchOrUW>
        //    {
        //        new UWRegionSummaryPipelineByBranchOrUW
        //        {
        //            BrachOrUW = "Long Island",
        //            Details  = new PipelineByUWDetailModel
        //            {
        //                PolicyNumber = "123MSBL",
        //                NewBusinessPipelineUSD = 1000,
        //                NewBusinessPipelineCount = 10,
        //                NewBusinessForecastUSD = 1000,
        //                RenewalsForeCastUSD = 1000,
        //                RenewalsForeCasCount = 10,
        //                TotalForeCastUSD = 2000,
        //                TotalPipelineUSD = 2000,
        //                TotalPipelineCount = 50
        //            },
        //            NewBusinessPipelineUSD = 20000,
        //            NewBusinessForecastUSD = 20,
        //            RenewalsForeCastUSD = 20000,
        //            RenewalsForeCasCount = 25,
        //            TotalForeCastUSD = 4900,
        //            TotalPipelineUSD = 40000,
        //            TotalPipelineCount = 50
        //        }

        //    };

        //    return Ok(uWRegionSummaryPipelineByBranchOrUWs);
        //}

        ///// <summary>
        ///// UnderWriter Region Summary Lost And Declined By Branch or UnderWriter
        ///// </summary>
        ///// <remarks>
        ///// UnderWriter Region Summary Lost And Declined By Branch or UnderWriter<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>UWRegionSummaryLostAndDeclinedByBranchOrUW</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<UWRegionSummaryLostAndDeclinedByBranchOrUW>))]
        //[HttpPost]
        //[Route("reports/underwriters/region/lostanddeclined/details")]  // NA
        //public IHttpActionResult GetUWRegionSummaryLostAndDeclinedByBranchOrUW(LoadReportInputModel loadReportInputModel)
        //{
        //    List<UWRegionSummaryLostAndDeclinedByBranchOrUW> uWRegionSummaries = new List<UWRegionSummaryLostAndDeclinedByBranchOrUW>
        //    {
        //        new UWRegionSummaryLostAndDeclinedByBranchOrUW
        //        {
        //            BrachOrUW = "Long Island",
        //            Details  = new LostAndDeclinedByBranchDetailModel
        //            {
        //                PolicyNumber = "123MSBL",
        //                NewBusinessQuotedLostUSD = 1000,
        //                NewBusinessQuotedLostCount = 10,
        //                NewBusinessDeclinedUSD = 1000,
        //                NewBusinessDeclinedCount = 10,
        //                RenewalsLostForeCastUSD = 1000,
        //                RenewalsLostBaseOrExpiringUSD = 2000,
        //                RenewalsLostForeCasCount = 20,
        //                RenewalsDeclinedUSD = 1000,
        //                RenewalsDeclined = 20
        //            },
        //            NewBusinessQuotedLostUSD = 1000,
        //            NewBusinessQuotedLostCount = 10,
        //            NewBusinessDeclinedUSD = 1000,
        //            NewBusinessDeclinedCount = 50,
        //            RenewalsLostForeCastUSD = 100,
        //            RenewalsLostBaseOrExpiringUSD = 100,
        //            RenewalsLostForeCasCount = 10,
        //            RenewalsDeclinedUSD = 1000,
        //            RenewalsDeclined = 50
        //        }

        //    };

        //    return Ok(uWRegionSummaries);
        //}

        ///// <summary>
        ///// UnderWriter Region Summary at a Glance
        ///// </summary>
        ///// <remarks>
        ///// UnderWriter Region Summary at a Glance<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>UWRegionSummaryGlance</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(UWRegionSummaryGlance))]
        //[HttpPost]
        //[Route("reports/underwriters/region/overview")]  // NA
        //public IHttpActionResult GetUWRegionSummaryGlance(LoadReportInputModel loadReportInputModel)
        //{
        //    UWRegionSummaryGlance uWRegionSummaries = new UWRegionSummaryGlance
        //    {
        //        TargetCount = 68,
        //        TargetUSD = 60000,
        //        SubmissionsCount = 99,
        //        SubmissionsUSD = 80000,
        //        QuotedCount = 45,
        //        QuotedCountUSD = 30000,
        //        BoundCount = 39,
        //        BoundCountUSD = 20081,
        //        PipelineUSD = 190081,
        //        ForeCastUSD = 130081,
        //        PlanUSD = 110000,
        //        RegionGoalYear = Convert.ToDateTime("12/05/2018")

        //    };

        //    return Ok(uWRegionSummaries);
        //}

        ///// <summary>
        ///// UnderWriter Forecast Targets Pipeline Details
        ///// </summary>
        ///// <remarks>
        ///// UnderWriter Forecast Targets Pipeline Details<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,
        ///// AccountYear - Account Year Integer - 2018, 2019 etc.,
        ///// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" 
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>UWPipelineDetails</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<UWPipelineDetails>))]
        //[HttpPost]
        //[Route("reports/underwriters/pipeline/targets/details")]  // NA
        //public IHttpActionResult GetUWPipelineDetailsTargets(LoadReportInputModel loadReportInputModel)
        //{
        //    if (String.IsNullOrEmpty(loadReportInputModel.UserID) || String.IsNullOrEmpty(loadReportInputModel.AccountMonth)
        //     || String.IsNullOrEmpty(loadReportInputModel.TimeFrame) || loadReportInputModel.AccountYear == 0)
        //    {
        //        if (String.IsNullOrEmpty(loadReportInputModel.UserID))
        //            return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
        //        if (String.IsNullOrEmpty(loadReportInputModel.AccountMonth))
        //            return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
        //        if (loadReportInputModel.AccountYear == 0)
        //            return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
        //        if (String.IsNullOrEmpty(loadReportInputModel.TimeFrame))
        //            return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
        //    }
        //    _logger.TraceStart();
        //    List<UWPipelineDetails> trackingReportingGridOutputData = _trackerReportingFacade.GetUWPipelineDetailsTargets(loadReportInputModel);
        //    _logger.TraceEnd();
        //    if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
        //    {
        //        return Ok(trackingReportingGridOutputData);
        //    }
        //    else
        //    {
        //        return Content(HttpStatusCode.NotFound, String.Format("No Scorecard Records found for UserID: {0}", loadReportInputModel.UserID));
        //    }

        //}

        ///// <summary>
        ///// UnderWriter Forecast Renewal Pipeline Details
        ///// </summary>
        ///// <remarks>
        ///// UnderWriter Forecast Renewal Pipeline Details<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,
        ///// AccountYear - Account Year Integer - 2018, 2019 etc.,
        ///// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" 
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>UWPipelineDetails</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<UWPipelineDetails>))]
        //[HttpPost]
        //[Route("reports/underwriters/pipeline/renewals/details")]  // NA
        //public IHttpActionResult GetUWPipelineDetailsRenewals(LoadReportInputModel loadReportInputModel)
        //{
        //    if (String.IsNullOrEmpty(loadReportInputModel.UserID) || String.IsNullOrEmpty(loadReportInputModel.AccountMonth)
        //     || String.IsNullOrEmpty(loadReportInputModel.TimeFrame) || loadReportInputModel.AccountYear == 0)
        //    {
        //        if (String.IsNullOrEmpty(loadReportInputModel.UserID))
        //            return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
        //        if (String.IsNullOrEmpty(loadReportInputModel.AccountMonth))
        //            return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
        //        if (loadReportInputModel.AccountYear == 0)
        //            return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
        //        if (String.IsNullOrEmpty(loadReportInputModel.TimeFrame))
        //            return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
        //    }
        //    _logger.TraceStart();
        //    List<UWPipelineDetails> trackingReportingGridOutputData = _trackerReportingFacade.GetUWPipelineDetailsRenewals(loadReportInputModel);
        //    _logger.TraceEnd();
        //    if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
        //    {
        //        return Ok(trackingReportingGridOutputData);
        //    }
        //    else
        //    {
        //        return Content(HttpStatusCode.NotFound, String.Format("No Scorecard Records found for UserID: {0}", loadReportInputModel.UserID));
        //    }

        //}

        ///// <summary>
        ///// UnderWriter Forecast New Business Pipeline Details
        ///// </summary>
        ///// <remarks>
        ///// UnderWriter Forecast New Business Pipeline Details<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,
        ///// AccountYear - Account Year Integer - 2018, 2019 etc.,
        ///// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" 
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>UWPipelineDetails</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<UWPipelineDetails>))]
        //[HttpPost]
        //[Route("reports/underwriters/pipeline/newbusiness/details")]  // NA
        //public IHttpActionResult GetUWPipelineDetailsNewBusiness(LoadReportInputModel loadReportInputModel)
        //{
        //    if (String.IsNullOrEmpty(loadReportInputModel.UserID) || String.IsNullOrEmpty(loadReportInputModel.AccountMonth)
        //     || String.IsNullOrEmpty(loadReportInputModel.TimeFrame) || loadReportInputModel.AccountYear == 0)
        //    {
        //        if (String.IsNullOrEmpty(loadReportInputModel.UserID))
        //            return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
        //        if (String.IsNullOrEmpty(loadReportInputModel.AccountMonth))
        //            return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
        //        if (loadReportInputModel.AccountYear == 0)
        //            return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
        //        if (String.IsNullOrEmpty(loadReportInputModel.TimeFrame))
        //            return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
        //    }
        //    _logger.TraceStart();
        //    List<UWPipelineDetails> trackingReportingGridOutputData = _trackerReportingFacade.GetUWPipelineDetailsNewBusiness(loadReportInputModel);
        //    _logger.TraceEnd();
        //    if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
        //    {
        //        return Ok(trackingReportingGridOutputData);
        //    }
        //    else
        //    {
        //        return Content(HttpStatusCode.NotFound, String.Format("No Scorecard Records found for UserID: {0}", loadReportInputModel.UserID));
        //    }

        //}

        ///// <summary>
        ///// UnderWriter Branch Summary Pipeline By UnderWriter
        ///// </summary>
        ///// <remarks>
        ///// UnderWriter Branch Summary Pipeline By UnderWriter<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>UWBranchSummaryPipelineByUW</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<UWBranchSummaryPipelineByUW>))]
        //[HttpPost]
        //[Route("reports/underwriters/branch/underwriter/pipeline")]  // NA
        //public IHttpActionResult GetUWBranchSummaryPipelineByUW(LoadReportInputModel loadReportInputModel)
        //{
        //    List<UWBranchSummaryPipelineByUW> uWBranchSummaries = new List<UWBranchSummaryPipelineByUW>
        //    {
        //        new UWBranchSummaryPipelineByUW
        //        {
        //            UnderWriter = "Darius Davidson",
        //            Details  = new UWBranchSummaryPipelineSubModel
        //            {
        //                PolicyNumber = "123MSBL",
        //                NewBusinessPipelineUSD = 1000,
        //                NewBusinessPipelineCount = 2,
        //                NewBusinessForecastdUSD = 1000,
        //                RenewalsForeCastUSD = 1000,
        //                RenewalsForeCastCount = 1,
        //                Company = "Environmental",
        //                ForecastUSD = 2000,
        //                TotalInPipelineUSD = 5000,
        //                TotalInPipelineCount = 10
        //            },
        //            NewBusinessPipelineUSD = 3000,
        //            NewBusinessPipelineCount = 4,
        //            NewBusinessForecastdUSD = 2000,
        //            RenewalsForeCastUSD = 1000,
        //            RenewalsForeCastCount = 2,
        //            Company = "Environmental",
        //            ForecastUSD = 4000,
        //            TotalInPipelineUSD = 7000,
        //            TotalInPipelineCount = 20
        //        }

        //    };

        //    return Ok(uWBranchSummaries);
        //}

        ///// <summary>
        ///// UnderWriter Branch Summary Lost And Declined By Branch
        ///// </summary>
        ///// <remarks>
        ///// UnderWriter Branch Summary Lost And Declined By Branch<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>UWBranchSummaryLostAndDeclinedByBranch</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<UWBranchSummaryLostAndDeclinedByBranch>))]
        //[HttpPost]
        //[Route("reports/underwriters/branch/branch/lostanddeclined")]  // NA
        //public IHttpActionResult GetUWBranchSummaryLostAndDeclinedByBranch(LoadReportInputModel loadReportInputModel)
        //{
        //    List<UWBranchSummaryLostAndDeclinedByBranch> uWBranchSummaries = new List<UWBranchSummaryLostAndDeclinedByBranch>
        //    {
        //        new UWBranchSummaryLostAndDeclinedByBranch
        //        {
        //            BrachOrUW = "Egor Smith",
        //            Details  = new UWBranchSummaryLostAndDeclinedSubModel
        //            {
        //                PolicyNumber = "123MSBL",
        //                NewBusinessQuotedLostUSD = 100,
        //                NewBusinessQuotedLostCount = 10,
        //                NewBusinessDeclinedUSD = 100,
        //                NewBusinessDeclinedCount = 20,
        //                RenewalsLostForeCastUSD = 100,
        //                RenewalsLostForeBaseAndExpiringUSD = 100,
        //                RenewalslLostForeCasCount = 10,
        //                RenewalsDeclinedUSD = 1000,
        //                RenewalsDeclinedCount = 20
        //            },
        //            NewBusinessQuotedLostUSD = 1000,
        //            NewBusinessQuotedLostCount = 10,
        //            NewBusinessDeclinedUSD = 1000,
        //            NewBusinessDeclinedCount = 50,
        //            RenewalsLostForeCastUSD = 100,
        //            RenewalsLostForeBaseAndExpiringUSD = 100,
        //            RenewalslLostForeCasCount = 10,
        //            RenewalsDeclinedUSD = 1000,
        //            RenewalsDeclinedCount = 50
        //        }

        //    };

        //    return Ok(uWBranchSummaries);
        //}

        ///// <summary>
        ///// UnderWriter Branch Summary at a Glance
        ///// </summary>
        ///// <remarks>
        ///// UnderWriter Branch Summary at a Glance<Br></Br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        ///// </remarks>
        ///// <param name="loadReportInputModel">LoadReportInputModel</param>
        ///// <returns>UWBranchSummaryGlance</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(UWBranchSummaryGlance))]
        //[HttpPost]
        //[Route("reports/underwriters/branch/overview")]  // NA
        //public IHttpActionResult GetUWBranchSummaryGlance(LoadReportInputModel loadReportInputModel)
        //{
        //    UWBranchSummaryGlance uWBranchSummaries = new UWBranchSummaryGlance
        //    {
        //        TargetCount = 20,
        //        TargetUSD = 5300,
        //        SubmissionsCount = 6,
        //        SubmissionsUSD = 2400,
        //        QuotedCount = 12,
        //        QuotedCountUSD = 4000,
        //        BoundCount = 15,
        //        BoundCountUSD = 2500,
        //        PipelineUSD = 14100,
        //        ForeCastUSD = 9000,
        //        PlanUSD = 110000,
        //        RegionGoalYear = Convert.ToDateTime("15/02/2018")

        //    };

        //    return Ok(uWBranchSummaries);
        //}

        /////// <summary>
        /////// Underwriter New Business Goals
        /////// </summary>
        /////// <remarks>
        /////// Underwriter New Business Goals<Br></Br>
        /////// Required Parameters : UserID, TimeFrame<br></br>
        /////// </remarks>
        /////// <param name="underwriterNewBusinessGoalsFilter">UnderwriterNewBusinessGoalsFilter</param>
        /////// <returns>UnderwriterNewBusinessGoals</returns>
        /////// <response code="200">Record found</response>
        /////// <response code="404">Record not found</response>
        ////[ResponseType(typeof(UnderwriterNewBusinessGoals))]
        ////[HttpPost]
        ////[Route("reports/underwriters/goals/newbusiness")]
        ////public IHttpActionResult GetUnderwriterNewBusinessGoals(UnderwriterNewBusinessGoalsFilter underwriterNewBusinessGoalsFilter)
        ////{
        ////    UnderwriterNewBusinessGoals underwriterNewBusinessGoals = new UnderwriterNewBusinessGoals
        ////    {

        ////        YearlyGoal = 10000,
        ////        GoalForTimeFrame = 12897,
        ////        GoalsAchieved = 4000,
        ////        PercentageOfYearlyGoal = 30,
        ////        TimeFrame = "",
        ////        VisitsType = "Customer Visit",
        ////        Status = ""

        ////    };

        ////    return Ok(underwriterNewBusinessGoals);
        ////}

        ///// <summary>
        ///// Add Producer Plan for Producer Branch Summary 
        ///// </summary>
        ///// <remarks>
        ///// Add Producer Plan for Producer Branch Summary <br></br>
        ///// Required Parameters : UserID, ProdProfileName, ProdProfileOwner, ProdProfileOwnerRegion,<br></br>
        ///// ProdProfileOwnerBranch, ProdProfileAddressCity, ProdProfileAddressStPr, ProdProfileAddressZip
        ///// </remarks>
        ///// <param name="producerPlan">ProducerPlanSave</param>
        ///// <response code="200">Saved Successfully</response>
        ///// <response code="404">Failed to save</response>
        //[HttpPost]
        //[Route("reports/producer/saveplan")]  // NA
        //public IHttpActionResult SaveProducerPlan(ProducerPlanSave producerPlan)
        //{
        //    return Ok();
        //}

        ///// <summary>
        ///// UnderWriter Summary Report Details
        ///// </summary>
        ///// <remarks>
        ///// UnderWriter Summary Report Details<br></br>
        ///// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame, Title, ReportMenuID, ReportTypeId
        ///// </remarks>
        ///// <param name="bookmarkSave">bookmarkSave</param>
        ///// <response code="200">Saved Successfully</response>
        ///// <response code="404">Failed to save</response>
        //[HttpPost]
        //[Route("reports/savebookmark")]  // NA
        //public IHttpActionResult SaveBookmark(BookmarkSave bookmarkSave)
        //{
        //    return Ok();
        //}

        /////// <summary>
        /////// Get CRM Contacts based on producer Name. 
        /////// </summary>
        /////// <remarks>
        /////// Get CRM Contacts based on producer Name.    
        /////// Required Parameters : ProducerName
        /////// Optional Parameters :       
        /////// </remarks>
        /////// <param name="objContactDetailsInputModel">objContactDetailsInputModel</param>
        /////// <returns>ContactOutputModel</returns>
        /////// <response code="200">Record found</response>
        /////// <response code="404">Record not found</response>
        ////[ResponseType(typeof(IEnumerable<ContactOutputModel>))]
        ////[HttpPost]
        ////[Route("GetCRMContactsByProducerCityState")]
        ////public IHttpActionResult GetCRMContactsByProducerCityState(ContactDetailsInputModel objContactDetailsInputModel)
        ////{

        ////    List<ContactOutputModel> objGetCrmContactsbyProdLocation = _trackerReportingEnterpriseIntegrationFacade.GetContactbyprodlocation(objContactDetailsInputModel);
        ////    return Ok(objGetCrmContactsbyProdLocation);

        ////}

        /// <summary>
        /// Get CRM Contacts based on Customer Details(ScreenName: CRM Contacts Based on Customer)
        /// </summary>
        /// <remarks>
        /// Get CRM Contacts based on Customer Details<br></br>
        /// Required Parameters : Customer Name<br></br>
        /// Optional Parameters : ClientID,pageNumber,PageSize 
        /// </remarks>
        /// <param name="objCustomerProfileInputModel"></param>
        /// <returns>ContactOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ContactOutputModel>))]
        [HttpPost]
        [Route("dynamics/customers/contacts")]  // R4
        public IHttpActionResult GetCRMContactsByCustomer(CustomerProfileInputModel objCustomerProfileInputModel)
        {
            _logger.TraceStart();

            if ((!string.IsNullOrEmpty(objCustomerProfileInputModel.Name)))
            {
                List<ContactOutputModel> objGetCRMContactsByCustomer = UtilityHelper.ProcessException<List<ContactOutputModel>>(() => _trackerReportingEnterpriseIntegrationFacade.GetContactbyCustomer(objCustomerProfileInputModel));
                _logger.TraceEnd();
                if (objGetCRMContactsByCustomer.Count > 0)
                {
                    return Ok(objGetCRMContactsByCustomer);
                }
                else
                {
                    return Content(HttpStatusCode.NotFound, String.Format("No CRM Customer Contacts Record found for Customer Name: {0}", objCustomerProfileInputModel.Name));
                }
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "Customer Name value not passed for the request.");
            }
        }


        /// <summary>
        /// Get CRM Contacts based on Producer Details(ScreenName: CRM Contacts Based on Producer)
        /// </summary>
        /// <remarks>
        /// Get CRM Contacts based on Producer Details<br></br>
        /// Required Parameters : Producer Name <br></br>
        /// Optional Parameters : Region, Branch, pageNumber,PageSize   <br></br>
        /// We are displaying the contacts based on Producer name. Door 3 need to do the refine search like Jo,John search from  producer API output contacts.
        /// </remarks>
        /// <param name="objVProducerDetailsInputModel"></param>
        /// <returns>ContactOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ContactOutputModel>))]
        [HttpPost]
        [Route("dynamics/producers/contacts")]  // R3
        public IHttpActionResult GetCRMContactsByProducer(ProducerDetailsCRMInputModel objVProducerDetailsInputModel)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            List<ContactOutputModel> objGetCRMContactsByProducer = UtilityHelper.ProcessException<List<ContactOutputModel>>(() => _trackerReportingEnterpriseIntegrationFacade.GetContactbyProducer(objVProducerDetailsInputModel));
            _logger.TraceEnd();
            if (objGetCRMContactsByProducer.Count > 0)
            {
                return Ok(objGetCRMContactsByProducer);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No CRM Producer Contacts Record found for Producer Name: {0}", objVProducerDetailsInputModel.Name));
            }

        }

        //[ResponseType(typeof(SummaryActivityOutputModel))]
        //[HttpPost]
        //[Route("dynamics/search/summaryactivities")]
        //public IHttpActionResult GetTravelScorecard(SummaryActivityInputModel objSummaryActivityInputModel)
        //{
        //    _logger.TraceStart();
        //    SummaryActivityOutputModel objSummaryActivitiesOutputModel = UtilityHelper.ProcessException<SummaryActivityOutputModel>(() => _trackerReportingEnterpriseIntegrationFacade.GetTravelScorecard(objSummaryActivityInputModel));
        //    _logger.TraceEnd();

        //    if (objSummaryActivitiesOutputModel != null)
        //        //&& objSummaryActivitiesOutputModel.VisitsCount > 0)
        //    {
        //        return Ok(objSummaryActivitiesOutputModel);
        //    }
        //    else
        //    {
        //        return Content(HttpStatusCode.NoContent, "No Activities found for the Respective Search Criteria");
        //    }
        //}

        ///// <summary>
        ///// Get CRM Meetings based on Customer Details(ScreenName: CRM Meeting Based on Customer)
        ///// </summary>
        ///// <remarks>
        ///// Get CRM Meetings based on Customer Details<br></br>
        ///// Required Parameters : Customer Name or Dunsnumber<br></br>
        ///// Optional Parameters : Customer Address1 ,Customer Address2,city,State,zipcode       
        ///// </remarks>
        ///// <param name="objViewCustomerMeetingInputModel"></param>
        ///// <returns>MeetingDetailsOutputModel</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<MeetingDetailsOutputModel>))]
        //[HttpPost]
        //[Route("dynamics/customers/appointments")]  // NA
        //public IHttpActionResult GetCRMMeetingsByCustomer(CustomerDetailsInputModel objViewCustomerMeetingInputModel)
        //{
        //    _logger.TraceStart();
        //    if ((!string.IsNullOrEmpty(objViewCustomerMeetingInputModel.Name)) || (!string.IsNullOrEmpty(objViewCustomerMeetingInputModel.DunsNumber)))
        //    {
        //        List<MeetingDetailsOutputModel> objGetCRMMeetingsByCustomer = UtilityHelper.ProcessException<List<MeetingDetailsOutputModel>>(() => _trackerReportingEnterpriseIntegrationFacade.GetMeetingbyCustomer(objViewCustomerMeetingInputModel));
        //        _logger.TraceEnd();
        //        if (objGetCRMMeetingsByCustomer.Count > 0 && objGetCRMMeetingsByCustomer != null)
        //        {
        //            return Ok(objGetCRMMeetingsByCustomer);
        //        }
        //        else
        //        {
        //            return Content(HttpStatusCode.NotFound, String.Format("No CRM Customer Meeting Record found for Customer Name: {0}", objViewCustomerMeetingInputModel.Name));
        //        }
        //    }
        //    else
        //    {
        //        return Content(HttpStatusCode.NotFound, "Customer Name  or Dunsnumber any one of the value not passed for the request.");
        //    }

        //}


        ///// <summary>
        ///// Get CRM Dynamic User details by user Id
        ///// </summary>
        ///// <remarks>
        ///// Get CRM Dynamic User details by user Id<br></br>
        ///// Required Parameters : UserID<br></br>
        ///// Optional Parameters :  
        ///// </remarks>
        ///// <param name="UserID">String</param>
        ///// <returns>ViewMeetingDetailsOutputModel</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<UserCRMDynamicDetailsOutputModel>))]
        //[HttpGet]
        //[Route("dynamics/users/{UserID}/profile")]  // NA
        //public IHttpActionResult GetCRMDynamicUserDetailsByUserID(String UserID)
        //{

        //    if (String.IsNullOrEmpty(UserID))
        //    {
        //        return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
        //    }
        //    _logger.TraceStart();
        //    UserCRMDynamicDetailsOutputModel objGetCRMDynamicUserdetails = UtilityHelper.ProcessException<UserCRMDynamicDetailsOutputModel>(() => _trackerReportingEnterpriseIntegrationFacade.GetCRMDynamicUserDetails(UserID));
        //    _logger.TraceEnd();
        //    if (objGetCRMDynamicUserdetails != null)
        //    {
        //        return Ok(objGetCRMDynamicUserdetails);
        //    }
        //    else
        //    {
        //        return Content(HttpStatusCode.NotFound, String.Format("No CRM Dynmaic records  found for UserID: {0}", UserID));
        //    }

        //}
        /// <summary>
        /// Get CRM Meetings based on Producer Details(ScreenName: CRM Meeting Based on Producer)
        /// </summary>
        /// <remarks>
        /// Get CRM Contacts based on Producer Details<br></br>
        /// Required Parameters : Producer Name <br></br>
        /// Optional Parameters : Region, Branch, pageNumber,PageSize
        /// </remarks>
        /// <param name="objViewProducerMeetingInputModel"></param>
        /// <returns>MeetingDetailsCRMOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<MeetingDetailsInfoOutputModel>))]
        [HttpPost]
        [Route("dynamics/producers/appointments")]  // R3
        public IHttpActionResult GetCRMMeetingByProducer(ProducerDetailsCRMInputModel objViewProducerMeetingInputModel)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }

            List<MeetingDetailsInfoOutputModel> objGetCRMMeetingsByProducer = UtilityHelper.ProcessException<List<MeetingDetailsInfoOutputModel>>(() => _trackerReportingEnterpriseIntegrationFacade.GetMeetingbyProducer(objViewProducerMeetingInputModel));
            _logger.TraceEnd();
            if (objGetCRMMeetingsByProducer.Count > 0 && objGetCRMMeetingsByProducer != null)
            {
                return Ok(objGetCRMMeetingsByProducer);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("No CRM Producer Meeting Record found for Producer Name: {0}", objViewProducerMeetingInputModel.Name));
            }

        }

        ///// <summary>
        ///// Get CRM Branch Meetings based on branch name
        ///// </summary>
        ///// <remarks>
        ///// Get CRM Contacts based on Producer Details<br></br>
        ///// Required Parameters : UserID <br></br>
        ///// Optional Parameters : Branch, pageNumber,PageSize
        ///// </remarks>
        ///// <param name="objViewBranchrMeetingInputModel"></param>
        ///// <returns>MeetingDetailsCRMOutputModel</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<MeetingDetailsOutputModel>))]
        //[HttpPost]
        //[Route("dynamics/branch/appointments")]  // R3
        //public IHttpActionResult GetCRMMeetingByBranch(BranchDetailsCRMInputModel objViewBranchMeetingInputModel)
        //{
        //    _logger.TraceStart();
        //    if (!ModelState.IsValid)
        //    {
        //        return Content(HttpStatusCode.BadRequest, ModelState);
        //    }

        //    List<MeetingDetailsOutputModel> objGetCRMMeetingsByBranch = UtilityHelper.ProcessException<List<MeetingDetailsOutputModel>>(() => _trackerReportingEnterpriseIntegrationFacade.GetCRMMeetingByBranch(objViewBranchMeetingInputModel));
        //    _logger.TraceEnd();
        //    if (objGetCRMMeetingsByBranch.Count > 0 && objGetCRMMeetingsByBranch != null)
        //    {
        //        return Ok(objGetCRMMeetingsByBranch);
        //    }
        //    else
        //    {
        //        return Content(HttpStatusCode.NotFound, String.Format("No CRM Branch Meeting Record found for UserID: {0}", objViewBranchMeetingInputModel.UserID));
        //    }

        //}
        ///// <summary>
        ///// Get CRM Notes Attachments based on Producer Details
        ///// </summary>
        ///// <remarks>
        ///// Get CRM Notes Attachments based on Producer Details<br></br>
        ///// Required Parameters : Producer Name <br></br>
        ///// Optional Parameters : Region, Branch, pageNumber,PageSize
        /////  </remarks>
        ///// <param name="objViewProducerNotesInputModel"></param>
        ///// <returns>NotesDetailsOutputModel</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<AttachmentsDetailsOutputModel>))]
        //[HttpPost]
        //[Route("dynamics/producers/attachments")] // R3
        //public IHttpActionResult GetCRMAttachmenstByProducer(ProducerDetailsCRMInputModel objViewProducerNotesInputModel)
        //{
        //    _logger.TraceStart();
        //    if (!ModelState.IsValid)
        //    {
        //        return Content(HttpStatusCode.BadRequest, ModelState);
        //    }
        //    List<AttachmentsDetailsOutputModel> objGetCRMAttachmentsByProducer = UtilityHelper.ProcessException<List<AttachmentsDetailsOutputModel>>(() => _trackerReportingEnterpriseIntegrationFacade.GetAttachmentsbyProducer(objViewProducerNotesInputModel));
        //    _logger.TraceEnd();
        //    if (objGetCRMAttachmentsByProducer.Count > 0)
        //    {
        //        return Ok(objGetCRMAttachmentsByProducer);
        //    }
        //    else
        //    {
        //        return Content(HttpStatusCode.NotFound, String.Format("No CRM Producer attachments Record found for Producer Name: {0}", objViewProducerNotesInputModel.Name));

        //    }

        //}

        /// <summary>
        /// Get CRM Notes based on Producer Details(ScreenName: CRM Notes Based on Producer)
        /// </summary>
        /// <remarks>
        /// Get CRM Notes based on Producer Details<br></br>
        /// Required Parameters : Producer Name <br></br>
        /// Optional Parameters : Region, Branch, pageNumber,PageSize
        /// </remarks>
        /// <param name="objViewProducerNotesInputModel"></param>
        /// <returns>NotesDetailsOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<NotesDetailsOutputModel>))]
        [HttpPost]
        [Route("dynamics/producers/notes")] //R3
        public IHttpActionResult GetCRMNotesByProducer(ProducerDetailsCRMInputModel objViewProducerNotesInputModel)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            List<NotesDetailsOutputModel> objGetCRMMeetingsByProducer = UtilityHelper.ProcessException<List<NotesDetailsOutputModel>>(() => _trackerReportingEnterpriseIntegrationFacade.GetNotesbyProducer(objViewProducerNotesInputModel));
            _logger.TraceEnd();
            if (objGetCRMMeetingsByProducer.Count > 0)
            {
                return Ok(objGetCRMMeetingsByProducer);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("No CRM Producer Notes Record found for Producer Name: {0}", objViewProducerNotesInputModel.Name));

            }

        }
        /// <summary>
        /// Get CRM Task based on Producer Details(ScreenName: CRM Task Based on Producer)
        /// </summary>
        /// <remarks>
        /// Get CRM Task based on Producer Details<br></br>
        /// Required Parameters : Producer Name <br></br>
        /// Optional Parameters : Region, Branch, pageNumber,PageSize
        /// </remarks>
        /// <param name="objViewProducerTaskInputModel"></param>
        /// <returns>UserTaskOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<UserTaskOutputModel>))]
        [HttpPost]
        [Route("dynamics/producers/tasks")] //R3
        public IHttpActionResult GetCRMTaskByProducer(ProducerDetailsCRMInputModel objViewProducerTaskInputModel)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }

            List<UserTaskOutputModel> objGetCRMTaskByProducer = UtilityHelper.ProcessException<List<UserTaskOutputModel>>(() => _trackerReportingEnterpriseIntegrationFacade.GetTaskbyProducer(objViewProducerTaskInputModel));
            _logger.TraceEnd();
            if (objGetCRMTaskByProducer.Count > 0)
            {
                return Ok(objGetCRMTaskByProducer);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("No CRM Producer Task Record found for Producer Name: {0}", objViewProducerTaskInputModel.Name));

            }

        }
        ///// <summary>
        ///// Load data for brokerlookup Details Summary data
        ///// </summary>
        ///// <remarks>
        ///// Get producers brokerlookup Details by ProducerName<br></br>
        ///// Required Parameters :
        ///// Optional parameters :ProducerName,ProducerCode,MasterCode,NationalCode,LegacyCode,ProducerState,ProducerCity,ProducingBranchCode,LegacySource
        ///// </remarks>
        ///// <param name="producerLookupInputModel">ProducerLookupInputModel</param>
        ///// <returns>ProducerLookupOutputModel</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(ProducerLookupOutputModel))]
        //[HttpPost]
        //[Route("reports/producer/brokerlookup")]  // NA
        //public IHttpActionResult GetProducerLookupOverview(ProducerLookupInputModel producerLookupInputModel)
        //{
        //    //if (!ModelState.IsValid)
        //    //{
        //    //    return Content(HttpStatusCode.BadRequest, ModelState);
        //    //}



        //    if ((producerLookupInputModel.ProducerName == "") && (producerLookupInputModel.ProducerCode == "") &&(producerLookupInputModel.LegacyCode =="") && (producerLookupInputModel.ProducerState =="")&& (producerLookupInputModel.ProducerCity =="")
        //        && (producerLookupInputModel.ProducingBranchCode=="") && (producerLookupInputModel.NationalCode=="")&& (producerLookupInputModel.MasterCode=="") && (producerLookupInputModel.LegacySource =="")) 

        //    {
        //        return Content(HttpStatusCode.NotFound, "Please Enter Search Criteria!");
        //    }

        //   _logger.TraceStart();
        //    List<ProducerLookupOutputModel> producerLookupOutputModel = _trackerReportingFacade.GetProducerLookupOverview(producerLookupInputModel);
        //    _logger.TraceEnd();


        //    if (producerLookupOutputModel.Count > 0 && producerLookupOutputModel != null)
        //    {
        //        return Ok(producerLookupOutputModel);
        //    }
        //    else
        //    {
        //        return Content(HttpStatusCode.NotFound, String.Format("ProducerLookUp Records Not found for this ProducerName:{0}", producerLookupInputModel.ProducerName));
        //    }

        //}

        ///// <summary>
        ///// Get producers DNBCompanyLookup Details by InsuredName(ScreenName: DNBCompanyLookup)
        ///// </summary>
        ///// <remarks>
        ///// Get producers DNBCompanyLookup Details by InsuredName <br></br>
        ///// Required Parameters : CompanyName,State<br></br>
        ///// Optional Parameters : 
        ///// </remarks>
        ///// <param name="CompanyName"></param>
        ///// <param name="StateCode"></param>
        ///// <returns>DNBLookupOutputModel</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<DNBLookupOutputModel>))]
        //[HttpGet]
        //[Route("reports/producer/dnbcompanylookup")]  // R2
        //public IHttpActionResult GetDNBCompanyLookup(string CompanyName, string StateCode)
        //{
        //    if (String.IsNullOrEmpty(CompanyName) || String.IsNullOrEmpty(StateCode))
        //    {
        //        if (String.IsNullOrEmpty(CompanyName))
        //            return Content(HttpStatusCode.BadRequest, "CompanyName not passed for the request");
        //        if (String.IsNullOrEmpty(StateCode))
        //            return Content(HttpStatusCode.BadRequest, "StateCode not passed for the request");
        //    }

        //    _logger.TraceStart();
        //    List<DNBLookupOutputModel> objDNBLookupOutputModel = UtilityHelper.ProcessException<List<DNBLookupOutputModel>>(() => _trackerReportingFacade.GetDNBCompanyLookup(CompanyName, StateCode));
        //    _logger.TraceEnd();
        //    if (objDNBLookupOutputModel.Count > 0 && objDNBLookupOutputModel != null)
        //    {
        //        return Ok(objDNBLookupOutputModel);
        //    }
        //    else
        //    {
        //        return Content(HttpStatusCode.NotFound, String.Format("DBNLookupDetails Not found for this CompanyName:{0}", CompanyName));
        //    }
        //}



        #region UnderWriter Glance
        /// <summary>
        /// Load UnderWriter Sumamry At a Glance(ScreenName: UW Summary Glance)
        /// </summary>
        /// <remarks>
        /// Load UnderWriter Sumamry At a Glance Details<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>
        /// <b>TopCarrier</b> Refers to Incumbent Field
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>UWDashboardGridOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<UWSummaryAtGlanceoutputModel>))]
        [HttpPost]
        [Route("reports/summary/glance")] // R3
        public IHttpActionResult GetUWSummaryAtGlance([FromBody]TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {

            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<UWSummaryAtGlanceoutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<UWSummaryAtGlanceoutputModel>>(() => _trackerReportingFacade.GetUWSummaryAtGlance(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Underwriter Glance Records found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }

        }
        #endregion


        //#region  UnderWriter NewBusiness
        ///// <summary>
        ///// Load UnderWriter Sumamry New Business
        ///// </summary>
        ///// <remarks>
        ///// Load UnderWriter Sumamry New Buiness Details<br></br>
        ///// Required Fields : UserID, AccountMonth, AccountYear,TimeFrame
        ///// </remarks>
        ///// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        ///// <returns>UWDashboardGridOutputModel</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<UWSummaryNewBusinessoutputModel>))]
        //[HttpPost]
        //[Route("reports/underwriters/Summary/NewBusinessDetails")] // R2
        //public IHttpActionResult GetUWSummaryNewBusinessDetails([FromBody]TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        //{
        //    if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
        //     || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
        //    {
        //        if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
        //            return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
        //        if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
        //            return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
        //        if (trackingReportingCommonFilterInputModel.AccountYear == 0)
        //            return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
        //        if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
        //            return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
        //    }
        //    _logger.TraceStart();
        //    List<UWSummaryNewBusinessoutputModel> trackingReportingGridOutputData = _trackerReportingFacade.GetUWSummaryNewBusiness(trackingReportingCommonFilterInputModel);
        //    _logger.TraceEnd();
        //    if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
        //    {
        //        return Ok(trackingReportingGridOutputData);
        //    }
        //    else
        //    {
        //        return Content(HttpStatusCode.NotFound, String.Format("No Underwriter NewBusiness Records found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
        //    }


        //}
        //#endregion


        #region  UnderWriter NewBusinessTotal
        /// <summary>
        /// Load UnderWriter Sumamry New Business(ScreenName: UW Summary New Business)
        /// </summary>
        /// <remarks>
        /// Load UnderWriter Sumamry New Buiness Details Total<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>
        /// <b>TopCarrier</b> Refers to Incumbent Field
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>UWDashboardGridOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<UWSummaryNewBusinessoutputModel>))]
        [HttpPost]
        [Route("reports/Summary/NewBusinessDetailsTotal")] // R3
        public IHttpActionResult GetUWSummaryNewBusinessDetailsTotal([FromBody]TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();
            List<UWSummaryNewBusinessoutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<UWSummaryNewBusinessoutputModel>>(() => _trackerReportingFacade.GetUWSummaryNewBusinessTotal(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Underwriter NewBusiness Records found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }


        }
        #endregion

        //#region UnderWriter Renewal
        ///// <summary>
        ///// Load UnderWriter Sumamry Renewal
        ///// </summary>
        ///// <remarks>
        ///// Load UnderWriter Sumamry Renewal Details<br></br>
        ///// Required Fields : UserID, AccountMonth, AccountYear,TimeFrame
        ///// </remarks>
        ///// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        ///// <returns>UWDashboardGridOutputModel</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<UWSummaryRenewaloutputModel>))]
        //[HttpPost]
        //[Route("reports/underwriters/Summary/RenewalDetails")] // R2
        //public IHttpActionResult GetUWSummaryRenewalDetails([FromBody]TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        //{
        //    if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
        //     || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
        //    {
        //        if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
        //            return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
        //        if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
        //            return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
        //        if (trackingReportingCommonFilterInputModel.AccountYear == 0)
        //            return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
        //        if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
        //            return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
        //    }
        //    _logger.TraceStart();
        //    List<UWSummaryRenewaloutputModel> trackingReportingGridOutputData = _trackerReportingFacade.GetUWSummaryRenewal(trackingReportingCommonFilterInputModel);
        //    _logger.TraceEnd();
        //    if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
        //    {
        //        return Ok(trackingReportingGridOutputData);
        //    }
        //    else
        //    {
        //        return Content(HttpStatusCode.NotFound, String.Format("No UnderWriter Sumarry Renewal Records found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
        //    }
        // }
        //#endregion


        #region UnderWriter Renewal Total
        /// <summary>
        /// Load UnderWriter Sumamry Renewal Total(ScreenName: UW Summary Renewal)
        /// </summary>
        /// <remarks>
        /// Load UnderWriter Sumamry Renewal Details Total<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>
        /// <b>TopCarrier</b> Refers to Incumbent Field
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>UWDashboardGridOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<UWSummaryRenewaloutputModel>))]
        [HttpPost]
        [Route("reports/Summary/RenewalDetailsTotal")] // R3
        public IHttpActionResult GetUWSummaryRenewalDetailsTotal([FromBody]TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();
            List<UWSummaryRenewaloutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<UWSummaryRenewaloutputModel>>(() => _trackerReportingFacade.GetUWSummaryRenewalTotal(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No UnderWriter Sumarry Renewal Records found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }
        }
        #endregion

        //#region UnderWriter TotalForecast
        ///// <summary>
        ///// Load UnderWriter Sumamry TotalForecast
        ///// </summary>
        ///// <remarks>
        ///// Load UnderWriter Sumamry TotalForecast Details<br></br>
        ///// Required Fields : UserId, AccountMonth, AccountYear,TimeFrame
        ///// </remarks>
        ///// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        ///// <returns>UWDashboardGridOutputModel</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<UWSummaryTotalforecasteoutputModel>))]
        //[HttpPost]
        //[Route("reports/underwriters/Summary/TotalForecastDetails")] // R2
        //public IHttpActionResult GetUWSummaryTotalForecastDetails([FromBody]TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        //{
        //    if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
        //     || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
        //    {
        //        if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
        //            return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
        //        if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
        //            return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
        //        if (trackingReportingCommonFilterInputModel.AccountYear == 0)
        //            return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
        //        if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
        //            return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
        //    }
        //    _logger.TraceStart();
        //    List<UWSummaryTotalforecasteoutputModel> trackingReportingGridOutputData = _trackerReportingFacade.GetUWSummaryTotalForecast(trackingReportingCommonFilterInputModel);
        //    _logger.TraceEnd();
        //    if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
        //    {
        //        return Ok(trackingReportingGridOutputData);
        //    }
        //    else
        //    {
        //        return Content(HttpStatusCode.NotFound, String.Format("No UnderWriter Forecast Records found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
        //    }
        //}
        //#endregion

        #region UnderWriter TotalForecast Total
        /// <summary>
        /// Load UnderWriter Sumamry TotalForecast Total(ScreenName: UW Summary TotalForecast Total)
        /// </summary>
        /// <remarks>
        /// Load UnderWriter Sumamry TotalForecast Details Total<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>
        /// <b>TopCarrier</b> Refers to Incumbent Field
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>UWDashboardGridOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<UWSummaryTotalforecasteoutputModel>))]
        [HttpPost]
        [Route("reports/Summary/TotalForecastDetailsTotal")] // R3
        public IHttpActionResult GetUWSummaryTotalForecastDetailsTotal([FromBody]TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<UWSummaryTotalforecasteoutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<UWSummaryTotalforecasteoutputModel>>(() => _trackerReportingFacade.GetUWSummaryTotalForecastTotal(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No UnderWriter Forecast Records found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }
        }
        #endregion

        #region Underwriter Goals NewBusiness
        /// <summary>
        /// Load UnderWriter Goals NewBusiness(ScreenName: UW Goals New Business)
        /// </summary>
        /// <remarks>
        /// Load UnderWriter Goals NewBusiness Details<br></br>
        /// Required Fields : UserId, AccountMonth, AccountYear,TimeFrame
        /// </remarks>
        /// <param name="loadReportInputModel">LoadReportInputModel</param>
        /// <returns>UWDashboardGridOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<UWGoalsNewBusinessOutputModel>))]
        [HttpPost]
        [Route("reports/underwriters/Goals/NewBusiness")] // R2
        public IHttpActionResult GetUWGoalsNewBusiness([FromBody]LoadReportInputModel loadReportInputModel)
        {
            if (String.IsNullOrEmpty(loadReportInputModel.UserID) || String.IsNullOrEmpty(loadReportInputModel.AccountMonth)
             || String.IsNullOrEmpty(loadReportInputModel.TimeFrame) || loadReportInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(loadReportInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(loadReportInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (loadReportInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(loadReportInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<UWGoalsNewBusinessOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<UWGoalsNewBusinessOutputModel>>(() => _trackerReportingFacade.GetUWGoalsNewBusiness(loadReportInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Goals New Business found for UserID: {0}", loadReportInputModel.UserID));
            }
        }
        #endregion

        #region Underwriter SaveGoals NewBusiness
        /// <summary>
        ///SaveGoals Amounts based on UserID(ScreenName: UW SaveGoals New Business)
        /// </summary>
        /// <remarks>
        /// Required Parameters : userID,GoalAmount<br></br>
        /// </remarks>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("reports/underwriters/savegoals/NewBusiness")]
        public IHttpActionResult GetUWSaveGoalsNewBusiness(string UserID, long GoalAmount)
        {

            if (String.IsNullOrEmpty(UserID))
            {

                return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");

            }
            if (GoalAmount == null)
            {
                return Content(HttpStatusCode.BadRequest, "Goal Amount not passed for the request");
            }

            _logger.TraceStart();

            string objOutputModel = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.GetUWSaveGoalsNewBusiness(UserID, GoalAmount));
            _logger.TraceEnd();
            if (objOutputModel != null)
            {
                return Ok(objOutputModel);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for UserID: {0}", UserID));
            }
        }

        #endregion

        #region UnderWriter Goals HitRatio
        /// <summary>
        /// Load UnderWriter Goals HitRatio(ScreenName: UW Goals Hitratio)
        /// </summary>
        /// <remarks>
        /// Load UnderWriter Goals HitRatio Details<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>
        /// </remarks>
        /// <param name="loadReportInputModel">LoadReportInputModel</param>
        /// <returns>UWDashboardGridOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<UWGoalsHitQuoteRatioOutputModel>))]
        [HttpPost]
        [Route("reports/underwriters/Goals/HitRatio")] // R2
        public IHttpActionResult GetUWGoalsHitRatio([FromBody]LoadReportInputModel loadReportInputModel)
        {
            if (String.IsNullOrEmpty(loadReportInputModel.UserID) || String.IsNullOrEmpty(loadReportInputModel.AccountMonth)
             || String.IsNullOrEmpty(loadReportInputModel.TimeFrame) || loadReportInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(loadReportInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(loadReportInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (loadReportInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(loadReportInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<UWGoalsHitQuoteRatioOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<UWGoalsHitQuoteRatioOutputModel>>(() => _trackerReportingFacade.GetUWGoalsHitRatio(loadReportInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Goals Hit Ratio found for UserID: {0}", loadReportInputModel.UserID));
            }
        }
        #endregion

        #region UnderWriter Goals HitRatio Details
        /// <summary>
        /// Load UnderWriter Goals HitRatio Details(ScreenName: UW Goals Hitratio Details)
        /// </summary>
        /// <remarks>
        /// Load UnderWriter Goals HitRatio Details<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>
        /// </remarks>
        /// <param name="loadReportInputModel">LoadReportInputModel</param>
        /// <returns>UWDashboardGridOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<UWGoalsHitQuoteRatioDetailsOutputModel>))]
        [HttpPost]
        [Route("reports/underwriters/Goals/HitRatioDetails")] // R2
        public IHttpActionResult GetUWGoalsHitRatioDetails([FromBody]LoadReportInputModel loadReportInputModel)
        {
            if (String.IsNullOrEmpty(loadReportInputModel.UserID) || String.IsNullOrEmpty(loadReportInputModel.AccountMonth)
            || String.IsNullOrEmpty(loadReportInputModel.TimeFrame) || loadReportInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(loadReportInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(loadReportInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (loadReportInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(loadReportInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();

            UWGoalsHitQuoteRatioDetailsOutputModel trackingReportingGridOutputData = UtilityHelper.ProcessException<UWGoalsHitQuoteRatioDetailsOutputModel>(() => _trackerReportingFacade.GetUWGoalsHitRatioDetails(loadReportInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Details.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Goals Hit Ratio Records found for UserID: {0}", loadReportInputModel.UserID));
            }

        }
        #endregion

        #region Travel Goal
        /// <summary>
        /// Get Travel Goals details  (ScreenName: UW Travel Goal)
        /// </summary>
        /// <remarks>
        /// Get Travel Goals details<br></br>
        /// Required Parameters : UserID,AccountingMonth,AccountingYear,TimeFrame,VisitType <br></br>      
        /// AccountingMonth - Account month string - Can represent "March", "Mar", "Current" etc.,<br></br>
        /// AccountingYear - Account Year Integer - 2018, 2019 etc.,<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12"<br></br>
        /// VisitType - i.e., Producer, Customer<br></br>
        /// </remarks>
        /// <param name="goalsInputModel">TravelGoalsInputModel</param>
        /// <returns>TravelGoalOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(TravelGoalsOutputModel))]
        [HttpPost]
        [Route("reports/underwriters/goals/travel")] // R3
        public IHttpActionResult GetTravelGoals(TravelGoalsInputModel goalsInputModel)
        {
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();
            TravelGoalsOutputModel trackingReportingGridOutputData = UtilityHelper.ProcessException<TravelGoalsOutputModel>(() => _trackerReportingFacade.GetTravelGoals(goalsInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Travel Goals Records found for UserID: {0}", goalsInputModel.UserID));
            }


        }
        #endregion

        #region  TravelSaveGoals 
        /// <summary>
        ///TravelSaveGoals Amounts based on UserID(ScreenName: UW Travel SaveGoal)
        /// </summary>
        /// <remarks>
        /// Required Parameters : userID,GoalAmount,VisitsType<br></br>
        /// VisitsType Would be Customer,Producer or All <br></br>
        /// </remarks>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("reports/underwriters/savegoals/travel")]
        public IHttpActionResult GetTravelSaveGoals(string UserID, long GoalAmount, string VisitType)
        {

            if (String.IsNullOrEmpty(UserID))
            {

                return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");

            }
            if (GoalAmount == null)
            {
                return Content(HttpStatusCode.BadRequest, "Goal Amount not passed for the request");
            }

            _logger.TraceStart();

            string objOutputModel = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.GetTravelSaveGoals(UserID, GoalAmount, VisitType));
            _logger.TraceEnd();
            if (objOutputModel != null)
            {
                return Ok(objOutputModel);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for UserID: {0}", UserID));
            }
        }

        #endregion

        #region UnderWriter Goals QuoteRatio Details
        /// <summary>
        /// Load UnderWriter Goals QuoteRatio Details(ScreenName: UW QuoteRatio Detail)
        /// </summary>
        /// <remarks>
        /// Load UnderWriter Goals QuoteRatio Details<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>
        /// </remarks>
        /// <param name="loadReportInputModel">LoadReportInputModel</param>
        /// <returns>UWDashboardGridOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<UWGoalsHitQuoteRatioDetailsOutputModel>))]
        [HttpPost]
        [Route("reports/underwriters/Goals/QuoteRatioDetails")] // R2
        public IHttpActionResult GetUWGoalsQuoteRatioDetails([FromBody]LoadReportInputModel loadReportInputModel)
        {
            if (String.IsNullOrEmpty(loadReportInputModel.UserID) || String.IsNullOrEmpty(loadReportInputModel.AccountMonth)
            || String.IsNullOrEmpty(loadReportInputModel.TimeFrame) || loadReportInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(loadReportInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(loadReportInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (loadReportInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(loadReportInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();
            UWGoalsHitQuoteRatioDetailsOutputModel trackingReportingGridOutputData = UtilityHelper.ProcessException<UWGoalsHitQuoteRatioDetailsOutputModel>(() => _trackerReportingFacade.GetUWGoalsQuoteRatioDetails(loadReportInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Details.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Goals  Quote Ratio found for UserID: {0}", loadReportInputModel.UserID));
            }

        }
        #endregion

        #region Forecast Summary
        /// <summary>
        /// Load Forecast Summary Details (ScreenName: Forecast Summary)
        /// </summary>
        /// <remarks>
        /// Load Forecast Summary  Details by Raw Data.<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>ForecastByBusinessSegmentOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ForecastByBusinessSegmentOutputModel>))]
        [HttpPost]
        [Route("reports/forecastsummarydetails")] // R2
        public IHttpActionResult GetForecastSummary([FromBody]TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<ForecastByBusinessSegmentOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<ForecastByBusinessSegmentOutputModel>>(() => _trackerReportingFacade.GetForecastSummary(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Forecast  Records found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }


        }

        /// <summary>
        /// Load Forecast Summary Details with Company,Division,Unit,Segment wise total.(ScreenName: Forecast Summary InDetail)
        /// </summary>
        /// <remarks>
        /// Load Forecast Summary Details with Company,Division,Unit,Segment wise total.<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>
        ///  If you choose Chubb industry value . SICTYPE Value - Need to pass  one of the  Mandatory value ("Risk SIC" or "D&B SIC" )<br></br>
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>ForecastByBusinessSegmentOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ForecastByBusinessSegmentOutputModel>))]
        [HttpPost]
        [Route("reports/forecastsummarydetailstotal")] // R2
        public IHttpActionResult GetForecastSummaryTotal([FromBody]TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
            || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<ForecastByBusinessSegmentOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<ForecastByBusinessSegmentOutputModel>>(() => _trackerReportingFacade.GetForecastSummaryTotal(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Forecast  Records found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }
        }
        #endregion

        #region Forecast Region
        /// <summary>
        /// Load Forecast Region Details (ScreenName: Forecast Region)
        /// </summary>
        /// <remarks>
        /// Load Forecast Region  Details .<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>ForecastByBusinessSegmentOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ForecastRegionDataOutputModel>))]
        [HttpPost]
        [Route("reports/ForecastRegionDetails")] // R2
        public IHttpActionResult GetForecastRegion([FromBody]TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<ForecastRegionDataOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<ForecastRegionDataOutputModel>>(() => _trackerReportingFacade.GetForecastRegion(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Forecast  Records found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }


        }

        /// <summary>
        /// Load Forecast Summary Details with Company,Division,Unit,Segment wise total.(ScreenName: Forecast Summary In-detail)
        /// </summary>
        /// <remarks>
        /// Load Forecast Summary Details with Company,Division,Unit,Segment wise total.<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>
        /// If you choose Chubb industry value . SICTYPE Value - Need to pass  one of the  Mandatory value ("Risk SIC" or "D&B SIC" )<br></br>
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>ForecastByBusinessSegmentOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ForecastRegionDataOutputModel>))]
        [HttpPost]
        [Route("reports/ForecastRegionDetailsTotal")] // R2
        public IHttpActionResult GetForecastRegionTotal([FromBody]TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
            || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<ForecastRegionDataOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<ForecastRegionDataOutputModel>>(() => _trackerReportingFacade.GetForecastRegionTotal(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Forecast  Records found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }
        }
        #endregion

        /// <summary>
        /// Save the Filter details for recently viewed and saved report details (ScreenName: FilterDetails)
        /// </summary>
        /// <remarks>
        /// Save the Filter details for recently viewed and saved report details <br></br>
        /// Required Fields : UserId, ReportType, SystemReportName,Persistencetype,BreadCrumb,FilterDetail  <br></br>
        /// For Persistencetype need to pass :Temporary/Permanent
        /// Recently viewed need to pass Temporary |Saved report need to pass Permanent<br></br>
        /// ReportType and System ReportName need to pass from the below list <br></br>
        /// Report Type(Select any one)- Chubb ,Customer,Producer,Contacts,Activities <br></br>
        /// System ReportName - DetailReport,TrackerQueue,Summary,Pipeline Details,Profile Report,Forecast,Scorecard,Statistics Report,Net Scorecard,Travel Efficiency,Renewals,Home Office Margin,Goals,PostMortem,Stewardship Report,Producer Production Report,Producer Plan,NetProfit,Contact,Activities<br></br>
        /// FilterDetail – Need to pass the structured Json (filter value).Note: need to pass the \ (slash) before the “(double quotes).<br></br>
        /// FilterId – For recently viewed we have to pass the value as 0(zero). Example: 0 |For saved report we have to pass the value for filterId . The value returned from recent view Report.
        /// </remarks>
        /// <param name="loadFilterInputModel">LoadFilterInputModel</param>
        /// <returns>FilterDataOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<FilterDataOutputModel>))]
        [HttpPost]
        [Route("reports/savefilters")] // R2
        public IHttpActionResult SaveFilterDetails([FromBody]LoadFilterInputModel loadFilterInputModel)
        {
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            if (loadFilterInputModel.MoreFilterDetails is null || loadFilterInputModel.MoreFilterDetails == "")
            {
                loadFilterInputModel.MoreFilterDetails = "{}";
            }
            _logger.TraceStart();

            FilterDataOutputModel trackingReportingGridOutputData = UtilityHelper.ProcessException<FilterDataOutputModel>(() => _trackerReportingFacade.SaveFilterDetails(loadFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Filter ID Records found for UserID: {0}", loadFilterInputModel.UserID));
            }
        }

        /// <summary>
        /// Delete data for Saved Filter(ScreenName: DeleteSavedFilter)
        /// </summary>
        /// <remarks>
        /// Delete data for Submission Routing<br></br>
        /// Required Parameters : FilterID
        /// </remarks>
        /// <param name="FilterID">string</param>
        /// <returns>DeleteMessage</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<string>))]
        [HttpPost]
        [Route("reports/deletesavefilter")]  // R3
        public IHttpActionResult DeleteSavedFilterData([FromBody] List<string> FilterID)
        {
            if (FilterID.Count == 0)
            {
                return Content(HttpStatusCode.BadRequest, "FilterID not passed for the request");
            }
            else if (FilterID.Count > 0)
            {
                if (String.IsNullOrEmpty(FilterID[0]))
                {
                    return Content(HttpStatusCode.BadRequest, "FilterID not passed for the request");
                }
            }
            _logger.TraceStart();
            string objGetDeleteStatus = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.DeleteSavedFilterData(FilterID));
            _logger.TraceEnd();
            if (objGetDeleteStatus != null)
            {
                return Ok("Records Deleted from saved Report");
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Datas are deleted for the Respective Saved Id");
            }
        }

        #region Forecast Variation
        /// <summary>
        /// Get the foreacast variation details(ScreenName: Forecast Variation)
        /// </summary>
        /// <remarks>
        /// Based on increment and decrement of (Forecast change and  forecast ) columns to decide the  change column icon like (uparrow symbol  and downarrow symbol)<br></br>
        /// Required Parameters : UserID<br></br>
        /// </remarks>
        /// <param name="forecastVariationInputModel">forecastVariationInputModel</param>
        /// <returns>VariationOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ForecastVariationOutputModel>))]
        [HttpPost]

        [Route("reports/forecast/variation")] // 
        public IHttpActionResult GetForecastVariation(ForecastVariationInputModel forecastVariationInputModel)
        {
            if (String.IsNullOrEmpty(forecastVariationInputModel.UserID) || forecastVariationInputModel.ForecastStartDate == null
                || forecastVariationInputModel.ForecastEndDate == null)
            {
                if (String.IsNullOrEmpty(forecastVariationInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (forecastVariationInputModel.ForecastStartDate == null)
                    return Content(HttpStatusCode.BadRequest, "ForecastStartDate not passed for the request");
                if (forecastVariationInputModel.ForecastEndDate == null)
                    return Content(HttpStatusCode.BadRequest, "ForecastEndDate not passed for the request");
            }
            _logger.TraceStart();

            List<ForecastVariationOutputModel> objVariationOutputModel = UtilityHelper.ProcessException<List<ForecastVariationOutputModel>>(() => _trackerReportingFacade.GetForecastVariation(forecastVariationInputModel));
            _logger.TraceEnd();
            if (objVariationOutputModel.Count > 0 && objVariationOutputModel != null)
            {
                return Ok(objVariationOutputModel);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for UserID: {0}", forecastVariationInputModel.UserID));
            }
        }

        #region ForecastVariationExcel
        /// <summary>
        /// Load data for ForecastVariation report Excel
        /// </summary>
        /// <remarks>
        /// Load data for ForecastVariation report<Br></Br>
        /// Required Parameters : UserID<Br></Br>
        /// </remarks>
        /// <param name="forecastVariationInputModel">ForecastVariationInputModel</param>
        /// <returns>ForecastVariationOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ForecastVariationOutputModel>))]
        [HttpPost]
        [Route("reports/forecastvariationexcel")]  // R2
        public IHttpActionResult GetForecastVariationExcel([FromBody]ForecastVariationInputModel forecastVariationInputModel)
        {
            string strFileName = string.Empty;
            if (String.IsNullOrEmpty(forecastVariationInputModel.UserID))
            {
                if (String.IsNullOrEmpty(forecastVariationInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");

            }
            IHttpActionResult response = null;
            _logger.TraceStart();
            var strHTML = _trackerReportingFacade.GetForecastVariationExcel(forecastVariationInputModel);
            strFileName = strHTML.ToString();
            _logger.TraceEnd();
            if (strFileName != "")
            {
                var httpResponseMessage = new HttpResponseMessage(System.Net.HttpStatusCode.OK);
                var dataBytes = File.ReadAllBytes(strFileName);
                //adding bytes to memory stream   
                var dataStream = new MemoryStream(dataBytes);
                httpResponseMessage.Content = new StreamContent(dataStream);
                httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
                httpResponseMessage.Content.Headers.ContentDisposition.FileName = Path.GetFileName(strFileName);
                httpResponseMessage.Content.Headers.ContentType = new MediaTypeHeaderValue("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

                response = ResponseMessage(httpResponseMessage);
            }

            if (response != null)
            {
                if (strFileName != "") ExcelEngine.DeleteFile(strFileName);
                return response;
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No ForecastVariation Record found for the Respective Search Criteria");
            }

        }
        #endregion

        #endregion

        /// <summary>
        /// Fetch the Filter details for recently viewed and saved report details (ScreenName: Recently viewed)
        /// </summary>
        /// <remarks>
        /// Fetch the Filter details for recently viewed and saved report details <br></br>
        /// Required Fields : UserId,Persistencetype,PageNumber,PageSize <br></br>
        /// Optional Fields : ReportType, SystemReportName,FilterID <br></br>
        /// For Persistencetype need to pass :Temporary/Permanent <br></br>
        /// Recently viewed need to pass Temporary |Saved report need to pass Permanent
        /// </remarks>
        /// <param name="getFilterInputModel">GetFilterInputModel</param>
        /// <returns>GetFilterOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<FilterDataOutputModel>))]
        [HttpPost]
        [Route("reports/recentlyviewed")] // R2
        public IHttpActionResult GetMySavedOrRecentViewReports([FromBody]GetFilterInputModel getFilterInputModel)
        {
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();

            List<GetFilterOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<GetFilterOutputModel>>(() => _trackerReportingFacade.GetMySavedOrRecentViewReports(getFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Filter ID Records found for UserID: {0}", getFilterInputModel.UserID));
            }

        }




        #region UnderWriter Goals QuoteRatio
        /// <summary>
        /// Load UnderWriter Goals QuoteRatio(ScreenName: UW QuoteRatio)
        /// </summary>
        /// <remarks>
        /// Load UnderWriter Goals QuoteRatio Details<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>
        /// </remarks>
        /// <param name="loadReportInputModel">LoadReportInputModel</param>
        /// <returns>UWGoalsHitQuoteRatioOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<UWGoalsHitQuoteRatioOutputModel>))]
        [HttpPost]
        [Route("reports/underwriters/Goals/QuoteRatio")] // R2
        public IHttpActionResult GetUWGoalsQuoteRatio([FromBody]LoadReportInputModel loadReportInputModel)
        {
            if (String.IsNullOrEmpty(loadReportInputModel.UserID) || String.IsNullOrEmpty(loadReportInputModel.AccountMonth)
             || String.IsNullOrEmpty(loadReportInputModel.TimeFrame) || loadReportInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(loadReportInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(loadReportInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (loadReportInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(loadReportInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<UWGoalsHitQuoteRatioOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<UWGoalsHitQuoteRatioOutputModel>>(() => _trackerReportingFacade.GetUWGoalsQuoteRatio(loadReportInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Goals QuoteRatio found for UserID: {0}", loadReportInputModel.UserID));
            }
        }
        #endregion

        /// <summary>
        /// Load Chubb5000 detail List Details(ScreenName: Chubb5000)
        /// </summary>
        /// <remarks>
        /// Load Chubb5000 detail List Grid Details<br></br>
        /// Required Fields : UserID, AccountingMonth, AccountingYear,TimeFrame
        /// </remarks>
        /// <param name="chubb5000DetailListInputModel">Chubb5000DetailListInputModel</param>
        /// <returns>Chubb5000DetailListOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<Chubb5000DetailListOutputModel>))]
        [HttpPost]
        [Route("reports/client/chubb5000detaillist")] // R3
        public IHttpActionResult GetChubb5000DetailListDetails([FromBody]Chubb5000DetailListInputModel chubb5000DetailListInputModel)
        {
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();

            List<Chubb5000DetailListOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<Chubb5000DetailListOutputModel>>(() => _trackerReportingFacade.GetChubb5000DetailListDetails(chubb5000DetailListInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Chubb5000 DetailList Records found for UserID: {0}", chubb5000DetailListInputModel.UserID));
            }
        }


        ///// <summary>
        ///// Fetch the Producer Profile Goals details  
        ///// </summary>
        ///// <remarks>
        ///// Fetch the Producer Profile Goals details  <br></br>
        ///// Required Fields : ProducerProfileName <br></br>
        ///// </remarks>
        ///// <param name="ProducerProfileName">string</param>
        ///// <returns>GetFilterOutputModel</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<GetProducerGoalsOutputModel>))]
        //[HttpGet]
        //[Route("producer/getplangoals")] // NA
        //public IHttpActionResult GetProfilePlanGoalReport(string ProducerProfileName)
        //{
        //    if (String.IsNullOrEmpty(ProducerProfileName))
        //    {
        //        return Content(HttpStatusCode.BadRequest, "ProducerProfileName not passed for the request");
        //    }
        //    _logger.TraceStart();
        //    List<GetProducerGoalsOutputModel> trackingReportingGridOutputData = _trackerReportingFacade.GetProfilePlanGoalReport(ProducerProfileName);
        //    _logger.TraceEnd();
        //    if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
        //    {
        //        return Ok(trackingReportingGridOutputData);
        //    }
        //    else
        //    {
        //        return Content(HttpStatusCode.NotFound, String.Format("No Producer Profile Goals Records found for ProducerProfileName: {0}", ProducerProfileName));
        //    }

        //}


        ///// <summary>
        ///// Save the Producer Profile Goals details
        ///// </summary>
        ///// <remarks>
        ///// Save the Producer Profile Goals details <br></br>
        ///// Required Fields : ProducerProfileID , ProducerProfileOfficeID   <br></br>
        ///// User Can editable only the mentionend fields <br></br>
        ///// EstimatedTotalAnnualplacements,TargetLine,TargetedPremium, TopCarriers1,TopCarriers2,TopCarriers3,Comments <br></br>
        ///// </remarks>
        ///// <param name="getproducerProfileInputModel">ProducerProfileGoalModel</param>
        ///// <returns>trackingReportingGridOutputData</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(String))]
        //[HttpPost]
        //[Route("producer/saveplangoals/")] // NA
        //public IHttpActionResult SaveProfilePlanGoalReport(List<ProducerProfileGoalModel> getproducerProfileInputModel)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return Content(HttpStatusCode.BadRequest, ModelState);
        //    }
        //    _logger.TraceStart();
        //    string  trackingReportingGridOutputData = _trackerReportingFacade.SaveProfilePlanGoalReport(getproducerProfileInputModel);
        //    _logger.TraceEnd();
        //    if (trackingReportingGridOutputData != string.Empty && trackingReportingGridOutputData != null)
        //    {
        //        return Ok(trackingReportingGridOutputData);
        //    }
        //    else
        //    {
        //        return Content(HttpStatusCode.NotFound, String.Format("No Records updated for ProducerProfileName: {0}", getproducerProfileInputModel[0].ProducerProfileName));
        //    }

        //}


        ///// <summary>
        ///// Add the Producer Profile Goals details
        ///// </summary>
        ///// <remarks>
        ///// Add the Producer Profile Goals details <br></br>
        ///// Required Fields : ProducerProfile Name ,Company ,Unit  <br></br>
        ///// Optional Fields :EstimatedTotalAnnualplacements,EstimatedPenetration,TargetLine,TargetedPremium, TopCarriers1,TopCarriers2,TopCarriers3,Comments <br></br>
        ///// </remarks>
        ///// <param name="getproducerProfileInputModel">AddProducerProfileGoalModel</param>
        ///// <returns>trackingReportingGridOutputData</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(String))]
        //[HttpPost]
        //[Route("producer/addplangoals")] // NA
        //public IHttpActionResult AddProfilePlanGoalReport(List<AddProducerProfileGoalModel> getproducerProfileInputModel)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return Content(HttpStatusCode.BadRequest, ModelState);
        //    }
        //    _logger.TraceStart();
        //    string trackingReportingGridOutputData = _trackerReportingFacade.AddProfilePlanGoalReport(getproducerProfileInputModel);
        //    _logger.TraceEnd();
        //    if (trackingReportingGridOutputData != string.Empty && trackingReportingGridOutputData != null)
        //    {
        //        return Ok(trackingReportingGridOutputData);
        //    }
        //    else
        //    {
        //        return Content(HttpStatusCode.NotFound, String.Format("No Records updated for ProducerProfileName: {0}", getproducerProfileInputModel[0].ProducerProfileName));
        //    }

        //}


        ///// <summary>
        ///// Fetch the Producer Profile Goals at Glance details  
        ///// </summary>
        ///// <remarks>
        ///// Fetch the Producer Profile Goals at Glance  details  <br></br>
        ///// Required Fields : ProducerProfileName <br></br>
        ///// </remarks>
        ///// <param name="ProducerProfileName">string</param>
        ///// <returns>GetFilterOutputModel</returns>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<GetProducerAtGlanceOutputModel>))]
        //[HttpGet]
        //[Route("producer/profile/atglance")] // NA
        //public IHttpActionResult GetProfileAtGlance(string ProducerProfileName)
        //{
        //    if (String.IsNullOrEmpty(ProducerProfileName))
        //    {
        //        return Content(HttpStatusCode.BadRequest, "ProducerProfileName not passed for the request");
        //    }
        //    _logger.TraceStart();
        //    GetProducerAtGlanceOutputModel trackingReportingGridOutputData = _trackerReportingFacade.GetProfileAtGlance(ProducerProfileName);
        //    _logger.TraceEnd();
        //    if ( trackingReportingGridOutputData.EstimatedTotalAnnualPlacement != null &&  trackingReportingGridOutputData.TotalTargetPremium != null)
        //    {
        //        return Ok(trackingReportingGridOutputData);
        //    }
        //    else
        //    {
        //        return Content(HttpStatusCode.NotFound, String.Format("No Producer Profile Glance Records found for ProducerProfileName: {0}", ProducerProfileName));
        //    }

        //}


        /// <summary>
        /// Load data for Producer filter control(ScreenName: Producer filter)
        /// </summary>
        /// <remarks>
        /// Load data for Producer filter control.<br></br>
        /// Optional Parametrs : Region,Branch, PASCode <br></br>
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>      
        [ResponseType(typeof(IEnumerable<ProducerFilterOutputModel>))]
        [HttpPost]
        [Route("filters/producer")] // R3
        public IHttpActionResult GetProducerFilter([FromBody]ProducerFilterInputModel objProducerFilterInputModel)
        {
            _logger.TraceStart();
            List<ProducerFilterOutputModel> dropdownOutputValues = UtilityHelper.ProcessException<List<ProducerFilterOutputModel>>(() => _trackerReportingFacade.GetProducerFilter(objProducerFilterInputModel));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Producer filter control");
            }
        }
        /// <summary>
        /// Load data for PASCode filter control(ScreenName: PasCode filter)
        /// </summary>
        /// <remarks>
        /// Load data for PASCode filter control.<br></br>        
        /// Optional Parametrs : Producer Name,Region,Branch <br></br>
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/PASCode")] // R3
        public IHttpActionResult GetPASCodeFilter([FromBody]PasCodeFilterInputModel objPasCodeFilterInputModel)
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetPASCodeFilter(objPasCodeFilterInputModel));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for PASCode filter control");
            }
        }





        /// <summary>
        /// Get records Tracker Queue grids (ScreenName: Non-Dynamics UW Dashboard)
        /// </summary>
        /// <remarks>
        /// Get records Tracker Queue grids <br></br>
        /// Required Fields : UserID, AccountMonth, AccountYear,TimeFrame<br></br>
        /// Timeframe possible options are - MTD, YTD, R3
        /// </remarks>
        /// <param name="trackerQueueInputModel">LoadDashboardReportInputModel</param>
        /// <returns>TrackerQueueDetails</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(TrackerQueueDetailsOutputModel))]
        [HttpPost]
        [Route("reports/trackerqueue")] // R2
        public IHttpActionResult GetTrackerQueueDetails([FromBody]TrackerQueueInputModel trackerQueueInputModel)
        {
            if (String.IsNullOrEmpty(trackerQueueInputModel.UserID) || String.IsNullOrEmpty(trackerQueueInputModel.AccountMonth)
              || String.IsNullOrEmpty(trackerQueueInputModel.TimeFrame) || trackerQueueInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackerQueueInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackerQueueInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackerQueueInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackerQueueInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }

            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();
            List<TrackerQueueDetailsOutputModel> trackerQueueDetails = UtilityHelper.ProcessException<List<TrackerQueueDetailsOutputModel>>(() => _trackerReportingFacade.GetTrackerQueue(trackerQueueInputModel));
            _logger.TraceEnd();
            if (trackerQueueDetails.Count > 0 && trackerQueueDetails != null)
            {
                return Ok(trackerQueueDetails);
            }
            else
            {

                return Content(HttpStatusCode.NotFound, String.Format("No Tracker Queue Records found for UserID: {0}", trackerQueueInputModel.UserID));
            }
        }

        #region Download
        /// <summary>
        /// Get the Noncore Elements data 
        /// </summary>
        /// <remarks>
        /// Required Parameters : userID<br></br>
        /// </remarks>
        /// <returns>NonCoreElementsOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<NonCoreElementsOutputModel>))]
        [HttpPost]
        [Route("reports/noncoreelements")]
        public IHttpActionResult GetNonCoreElements(string userID)
        {
            if (String.IsNullOrEmpty(userID))
            {
                return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
            }
            _logger.TraceStart();
            List<NonCoreElementsOutputModel> objVariationOutputModel = UtilityHelper.ProcessException<List<NonCoreElementsOutputModel>>(() => _trackerReportingFacade.GetNonCoreElements(userID));
            _logger.TraceEnd();
            if (objVariationOutputModel.Count > 0 && objVariationOutputModel != null)
            {
                return Ok(objVariationOutputModel);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for UserID: {0}", userID));
            }
        }

        /// <summary>
        /// Get the Core Elements data 
        /// </summary>
        /// <remarks>
        /// Required Parameters : userID<br></br>
        /// </remarks>
        /// <returns>CoreElementsOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<CoreElementsOutputModel>))]
        [HttpPost]
        [Route("reports/coreelements")]
        public IHttpActionResult GetCoreElements(string userID)
        {
            if (String.IsNullOrEmpty(userID))
            {
                return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
            }
            _logger.TraceStart();
            List<CoreElementsOutputModel> objVariationOutputModel = UtilityHelper.ProcessException<List<CoreElementsOutputModel>>(() => _trackerReportingFacade.GetCoreElements(userID));
            _logger.TraceEnd();
            if (objVariationOutputModel.Count > 0 && objVariationOutputModel != null)
            {
                return Ok(objVariationOutputModel);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for UserID: {0}", userID));
            }
        }

        /// <summary>
        /// Get the Core Elements data 
        /// </summary>
        /// <remarks>
        /// Required Parameters : userID<br></br>
        /// </remarks>
        /// <returns>MultiNoncoreElementsOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<MultiNoncoreElementsOutputModel>))]
        [HttpPost]
        [Route("reports/multinoncoreelements")]
        public IHttpActionResult GetMultiNoncoreElements(string userID)
        {
            if (String.IsNullOrEmpty(userID))
            {
                return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
            }
            _logger.TraceStart();
            List<MultiNoncoreElementsOutputModel> objVariationOutputModel = UtilityHelper.ProcessException<List<MultiNoncoreElementsOutputModel>>(() => _trackerReportingFacade.GetMultiNoncoreElements(userID));
            _logger.TraceEnd();
            if (objVariationOutputModel.Count > 0 && objVariationOutputModel != null)
            {
                return Ok(objVariationOutputModel);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for UserID: {0}", userID));
            }
        }



        /// <summary>
        /// Customize download 
        /// </summary>
        /// <remarks>
        /// Required Parameters : UserID,AccountMonth,AccountYear,TimeFrame,CoreElements<br></br>
        /// If it is DetailReport Export Send InsulLogic = 'N' and InsuredSearch Export send InsulLogic = 'Y'
        /// </remarks>
        /// <returns>HttpResponseMessage</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>

        [HttpPost]
        [Route("reports/retrieve")]
        public IHttpActionResult ExportData(ExportInputModel exportInputModel)
            {
            string strFileName;
            if (String.IsNullOrEmpty(exportInputModel.UserID))
            {
                if (String.IsNullOrEmpty(exportInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(exportInputModel.StrCore[0]))
                    return Content(HttpStatusCode.BadRequest, "CoreElements not passed for the request");
            }
            if (exportInputModel.InsulLogic == null || exportInputModel.InsulLogic == "")
            {
                exportInputModel.InsulLogic = "N";
            }
            //if (exportInputModel.Currency == null || exportInputModel.Currency == "")
            //{
            //    exportInputModel.Currency = "USD";
            //}
            IHttpActionResult response = null;
            _logger.TraceStart();
            var strHTML = _trackerReportingFacade.ExportData(exportInputModel);
            strFileName = strHTML.ToString();
            _logger.TraceEnd();
            if (strHTML.ToString() != "")
            {
                var httpResponseMessage = new HttpResponseMessage(System.Net.HttpStatusCode.OK);
                var dataBytes = File.ReadAllBytes(strFileName);
                //adding bytes to memory stream   
                var dataStream = new MemoryStream(dataBytes);
                httpResponseMessage.Content = new StreamContent(dataStream);
                httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
                httpResponseMessage.Content.Headers.ContentDisposition.FileName = Path.GetFileName(strFileName);
                httpResponseMessage.Content.Headers.ContentType = new MediaTypeHeaderValue("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                response = ResponseMessage(httpResponseMessage);
            }

            if (response != null)
            {
                ExcelEngine.DeleteFile(strFileName);
                return response;
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for UserID: {0}", exportInputModel.UserID));
            }
        }

        /// <summary>
        ///Saved core elements based on UserID
        /// </summary>
        /// <remarks>
        /// Required Parameters : userID,coreElements<br></br>
        /// </remarks>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("reports/savedprofilecoreelements")]
        public IHttpActionResult SavedProfileCoreElements(SavedProfileCoreElementInputModel savedProfileCoreElementInputModel)
        {

            if (String.IsNullOrEmpty(savedProfileCoreElementInputModel.UserID))
            {

                return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");

            }

            _logger.TraceStart();

            string objOutputModel = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.SavedProfileCoreElements(savedProfileCoreElementInputModel));
            _logger.TraceEnd();
            if (objOutputModel != null)
            {
                return Ok(objOutputModel);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for UserID: {0}", savedProfileCoreElementInputModel.UserID));
            }
        }


        /// <summary>
        ///Saved Noncore elements based on UserID
        /// </summary>
        /// <remarks>
        /// Required Parameters : userID,nonCoreElements<br></br>
        /// </remarks>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("reports/savedprofilenoncoreelements")]
        public IHttpActionResult SavedProfileNonCoreElements(SavedProfileNonCoreElementInputModel savedProfileNonCoreElementInputModel)
        {

            if (String.IsNullOrEmpty(savedProfileNonCoreElementInputModel.UserID))
            {

                return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");

            }


            _logger.TraceStart();
            string objOutputModel = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.SavedProfileNonCoreElements(savedProfileNonCoreElementInputModel));
            _logger.TraceEnd();
            if (objOutputModel != null)
            {
                return Ok(objOutputModel);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for UserID: {0}", savedProfileNonCoreElementInputModel.UserID));
            }
        }
        #endregion

        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("reports/savedprofilemultinoncoreelements")]
        public IHttpActionResult SavedProfileMultiNonCoreElements(SavedProfileMultiNonCoreElementInputModel savedProfileMultiNonCoreElementInputModel)
        {
            if (String.IsNullOrEmpty(savedProfileMultiNonCoreElementInputModel.UserID))
            {
                return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
            }

            _logger.TraceStart();
            string objOutputModel = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.SavedProfileMultiNonCoreElements(savedProfileMultiNonCoreElementInputModel));
            _logger.TraceEnd();
            if (objOutputModel != null)
            {
                return Ok(objOutputModel);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for UserID: {0}", savedProfileMultiNonCoreElementInputModel.UserID));
            }
        }

        ///// <summary>
        ///// Add the User input page Details 
        ///// </summary>
        ///// <remarks>
        /////
        ///// </remarks>
        ///// <param name="TrackQueueInputPageInputModel">trackQueueInputPageInputModel</param>
        ///// <response code="200">Record found</response>
        ///// <response code="404">Record not found</response>
        //[ResponseType(typeof(IEnumerable<>))]
        [HttpPost]
        [Route("reports/saveOrupdaterecords")]  //R2
        public IHttpActionResult SavedOrUpdateUserRecords([FromBody]TrackQueueInputPageInputModel trackQueueInputPageInputModel)
        {

            _logger.TraceStart();
            string UserDetails = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.SaveOrUpdateRecords(trackQueueInputPageInputModel));
            _logger.TraceEnd();

            if (UserDetails != string.Empty && UserDetails != null)
            {
                return Content(HttpStatusCode.NotFound, "Record inserted successfully!");

            }
            else
            {
                return Content(HttpStatusCode.NotFound, "Record Not inserted successfully!");
            }

        }

        #region Broker Profile Summary
        /// <summary>
        /// Load Broker Profile Summary 
        /// </summary>
        /// <remarks>
        /// Load Broker Profile Summary .<br></br>
        /// Required Fields : UserID, AccountMonth, AccountYear,TimeFrame,Choice
        /// </remarks>
        /// <param name="brokerProfileInputModel">BrokerProfileInputModel</param>
        /// <returns>ForecastByBusinessSegmentOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<BrokerProfileOutputModel>))]
        [HttpPost]
        [Route("reports/BrokerProfileSummary")] // R2
        public IHttpActionResult GetBrokerProfile([FromBody]BrokerProfileInputModel brokerProfileInputModel)
        {
            if (String.IsNullOrEmpty(brokerProfileInputModel.UserID) || String.IsNullOrEmpty(brokerProfileInputModel.AccountMonth)
             || String.IsNullOrEmpty(brokerProfileInputModel.TimeFrame) || brokerProfileInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(brokerProfileInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(brokerProfileInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (brokerProfileInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(brokerProfileInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<BrokerProfileOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<BrokerProfileOutputModel>>(() => _trackerReportingFacade.GetBrokerProfile(brokerProfileInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Broker Profile  Records found for UserID: {0}", brokerProfileInputModel.UserID));
            }


        }
        #endregion

        /// <summary>
        /// Get CRM Completed Activities based on Producer Details.
        /// </summary>
        /// <remarks>
        /// Get CRM Completed Activities based on Producer Details<br></br>
        /// Required Parameters : Producer Name <br></br>
        /// Optional Parameters : Region, Branch, pageNumber,PageSize
        ///  </remarks>
        /// <param name="objProducerDetailsCRMInputModel">ProducerDetailsCRMInputModel</param>
        /// <returns>CRMCompletedActivitiesOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<CRMCompletedActivitiesOutputModel>))]
        [HttpPost]
        [Route("dynamics/producers/completedactivities")] // R3
        public IHttpActionResult GetCRMCompletedActivitiesByProducer(ProducerDetailsCRMInputModel objProducerDetailsCRMInputModel)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            List<CRMCompletedActivitiesOutputModel> objGetCRMCompletedActivitiesByProducer = UtilityHelper.ProcessException<List<CRMCompletedActivitiesOutputModel>>(() => _trackerReportingEnterpriseIntegrationFacade.GetCRMCompletedActivitiesByProducer(objProducerDetailsCRMInputModel));
            _logger.TraceEnd();
            if (objGetCRMCompletedActivitiesByProducer.Count > 0)
            {
                return Ok(objGetCRMCompletedActivitiesByProducer);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No CRM Producer Completed Activites Record found for Producer Name: {0}", objProducerDetailsCRMInputModel.Name));

            }

        }

        /// <summary>
        /// Load data for ROV report
        /// </summary>
        /// <remarks>
        /// Load data for ROV report<Br></Br>
        /// Required Parameters : UserID<Br></Br>
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,<Br></Br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.,<Br></Br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <Br></Br>
        /// </remarks>
        /// <param name="loadReportInputModel">ROVInputModel</param>
        /// <returns>ROVoutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ROVOutputModel>))]
        [HttpPost]
        [Route("reports/rovreport")]  // R2
        public IHttpActionResult GetROVReport(ROVInputModel loadReportInputModel)
        {
            if (String.IsNullOrEmpty(loadReportInputModel.UserID))
            {
                if (String.IsNullOrEmpty(loadReportInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");

            }
            _logger.TraceStart();
            List<ROVOutputModel> rovReports = UtilityHelper.ProcessException<List<ROVOutputModel>>(() => _trackerReportingEnterpriseIntegrationFacade.GetROVReport(loadReportInputModel));

            _logger.TraceEnd();
            if (rovReports.Count > 0 && rovReports != null)
            {
                return Ok(rovReports);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No ROV report Records found for UserID: {0}", loadReportInputModel.UserID));
            }

        }
        /// <summary>
        /// Get the List of Producer Details based on the Producer filter (Name,Region,Branch,PASCode).
        /// </summary>
        /// <remarks>
        /// Get the List of Producer Details based on the Producer filter (Name,Region,Branch,PASCode).<br></br>
        /// Required Parameters :   <br></br>
        /// Optional Parameters : ,Producer Name , PASCode, Region, Branch ,ProfileOwner,pageNumber,PageSize<br></br>
        /// ProfileOwner- need to Pass profile ownerID<br></br>
        /// SortBy  : ProducerName, ProducerBranchName,ProducerBranch,ProducerRegion
        ///  </remarks>
        /// <param name="objProducerDetailsInputModel"></param>
        /// <returns>ProducerReportOuputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ProducerReportOuputModel>))]
        [HttpPost]
        [Route("reports/producers")] // R3
        public IHttpActionResult GetProducerReport(ProducerReportInputModel objProducerDetailsInputModel)
        {
            _logger.TraceStart();
            //if ((string.IsNullOrEmpty(objProducerDetailsInputModel.ProducerName[0])) &&
            //    (string.IsNullOrEmpty(objProducerDetailsInputModel.PASCode[0])) &&
            //    (string.IsNullOrEmpty(objProducerDetailsInputModel.ProducerRegion[0]))&&
            //    (string.IsNullOrEmpty(objProducerDetailsInputModel.ProducerBranch[0])))
            //{
            //    return Content(HttpStatusCode.NotFound, String.Format("Choose atleast one required filter : Producer Name, PASCode, Region, Branch"));
            //}

            List<ProducerReportOuputModel> objGetProducerDetials = UtilityHelper.ProcessException<List<ProducerReportOuputModel>>(() => _trackerReportingFacade.GetProducerReport(objProducerDetailsInputModel));
            _logger.TraceEnd();
            if (objGetProducerDetials.Count > 0)
            {
                return Ok(objGetProducerDetials);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Producer Record found for the given search "));

            }

        }
        /// <summary>
        /// Get the Producer Profile Info based on the Producer filter (Name,Region,Branch).
        /// </summary>
        /// <remarks>
        /// Get the Producer Profile Info based on the Producer filter (Name,Region,Branch).<br></br>
        /// Required Parameters : Producer Name <br></br>
        /// Optional Parameters : Region, Branch, pageNumber,PageSize<br></br>
        /// Hint: For National producer name info - You need to pass only National Producer Name alone , Region and Branch should be blank. Example :AON <br></br>
        /// For Branch Producer Info - You Need  to pass National producer Name , Branch and Region<br></br>
        ///  </remarks>
        /// <param name="objProducerDetailsInputModel"></param>
        /// <returns>ProducerKeyProfileOuputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ProducerKeyprofileInputModel>))]
        [HttpPost]
        [Route("reports/producerprofile")] // R3
        public IHttpActionResult GetProducerKeyProfile(ProducerKeyprofileInputModel objProducerDetailsInputModel)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }

            List<ProducerKeyProfileOuputModel> objGetProducerDetials = UtilityHelper.ProcessException<List<ProducerKeyProfileOuputModel>>(() => _trackerReportingFacade.GetProducerKeyProfile(objProducerDetailsInputModel));
            _logger.TraceEnd();
            if (objGetProducerDetials.Count > 0)
            {
                return Ok(objGetProducerDetials);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Producer Record found for Producer Name: {0}", objProducerDetailsInputModel.ProducerName));

            }

        }

        /// <summary>
        /// Save Submission Routing Report Detials
        /// </summary>
        /// <remarks>
        /// Save Submission Routing Report Detials<br></br>
        /// Required Parameters : ReportName , Schedule  <br></br>
        /// Schedule value should be follow any one of the value : ToNight | Weekly | BiWeekly | Monthly | Quarterly | Annual <br></br>
        /// Output Column value : <Br></Br>
        /// ProducerInformation:Producer Name|Producer State|Producer City|Producer Region|Producer Branch|Producer First Name|Producer Last Name|Producer Email|Producer Code <br></br>
        /// BusinessUnits:Company|Division|Unit|Segment|Sub Segment|Portfolio Class<br></br>
        /// InsuredInformation: Insured Name|Insured Address|Insured City|Insured State/Province|Insured Zip|DnB Number|Public/Private|DnB SIC Code|Commercial Credit Score <br></br>
        /// PolicyData:Accounting Month | Forecast|Accounting Year |Incumbent|Base or Expiring |Policy Number|Bind Date |Product|Confidence Factor|Credited Region|Industry |Risk SIC Code|Credited Branches | Effective Date |Status | Expiration Date |Type |Create Date <br></br>
        /// UWInformation :Underwriter First Name |Underwriter Last Name |Underwriter Login Name |Underwriting Region |Underwriting Branch 
        /// </remarks>
        /// <param name="objSubmissionRoutingInputModel"></param>
        /// <returns>SuccessMessage</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<String>))]
        [HttpPost]
        [Route("reports/savesubmissionrouting")] //R3
        public IHttpActionResult SaveSubmissionRouting(SubmissionRoutingModel objSubmissionRoutingInputModel)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            string objGetSubmissionRoutingStatus = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.SaveSubmissionRouting(objSubmissionRoutingInputModel));
            _logger.TraceEnd();
            if (objGetSubmissionRoutingStatus != null)
            {
                return Ok(objGetSubmissionRoutingStatus);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Datas are Saved for SubmissionRouting");
            }

        }

        /// <summary>
        /// Load data for Submission Routing
        /// </summary>
        /// <remarks>
        /// Load data for Submission Routing<br></br>
        /// Required Parameters : UserID
        /// </remarks>
        /// <param name="UserID">string</param>
        /// <returns>GetSubmissionRouting</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<GetSubmissionRouting>))]
        [HttpGet]
        [Route("reports/loadsubmissionrouting")]  // R3
        public IHttpActionResult GetSubmissionRoutingData(string UserID)
        {
            if (String.IsNullOrEmpty(UserID))
            {
                return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
            }
            _logger.TraceStart();
            List<GetSubmissionRouting> getSubmissionRouting = UtilityHelper.ProcessException<List<GetSubmissionRouting>>(() => _trackerReportingFacade.GetSubmissionRoutingData(UserID));
            _logger.TraceEnd();
            if (getSubmissionRouting.Count > 0 && getSubmissionRouting != null)
            {
                return Ok(getSubmissionRouting);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No data found for Submission Routing for UserID: {0}", UserID));
            }
        }
        /// <summary>
        /// Delete data for Submission Routing
        /// </summary>
        /// <remarks>
        /// Delete data for Submission Routing<br></br>
        /// Required Parameters : UserID
        /// </remarks>
        /// <param name="ScheduleID">string</param>
        /// <returns>DeleteMessage</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<string>))]
        [HttpGet]
        [Route("reports/deletesubmissionrouting")]  // R3
        public IHttpActionResult DeleteSubmissionRoutingData(string ScheduleID)
        {
            if (String.IsNullOrEmpty(ScheduleID))
            {
                return Content(HttpStatusCode.BadRequest, "ScheduleID not passed for the request");
            }
            _logger.TraceStart();
            string objGetSubmissionRoutingStatus = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.DeleteSubmissionRoutingData(ScheduleID));
            _logger.TraceEnd();
            if (objGetSubmissionRoutingStatus != null)
            {
                return Ok(objGetSubmissionRoutingStatus);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Datas are deleted for SubmissionRouting");
            }
        }
        /// <summary>
        /// Edit data for Submission Routing
        /// </summary>
        /// <remarks>
        /// Edit data for Submission Routing<br></br>
        /// Required Parameters : ScheduleID
        /// </remarks>
        /// <param name="ScheduleID">string</param>
        /// <returns>SubmissionRoutingInputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<SubmissionRoutingModel>))]
        [HttpGet]
        [Route("reports/Updatesubmissionrouting")]  // R3
        public IHttpActionResult UpdateSubmissionRoutingData(string ScheduleID)
        {
            if (String.IsNullOrEmpty(ScheduleID))
            {
                return Content(HttpStatusCode.BadRequest, "ScheduleID not passed for the request");
            }
            _logger.TraceStart();
            SubmissionRoutingModel getSubmissionRouting = UtilityHelper.ProcessException<SubmissionRoutingModel>(() => _trackerReportingFacade.UpdateSubmissionRoutingData(ScheduleID));
            _logger.TraceEnd();
            if (getSubmissionRouting != null)
            {
                return Ok(getSubmissionRouting);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No data found for Submission Routing for ScheduleID: {0}", ScheduleID));
            }
        }
        /// <summary>
        /// Get Customer Profile Summary 
        /// </summary>
        /// <remarks>
        /// Load the data to customer profile grids <br></br>
        /// Required Fields : UserID, AccountMonth, AccountYear,TimeFrame<br></br>
        /// </remarks>
        /// <param name="customerProfilesummaryInputModel">CustomerPofileSummaryInputModel</param>
        /// <returns>customerSummary</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(CustomerProfileSummaryOutputModel))]
        [HttpPost]
        [Route("reports/customerprofilesummary")] // R3
        public IHttpActionResult GetCustomerProfileSummary([FromBody]CustomerPofileSummaryInputModel customerProfilesummaryInputModel)
        {
            if (String.IsNullOrEmpty(customerProfilesummaryInputModel.UserID) || String.IsNullOrEmpty(customerProfilesummaryInputModel.AccountingMonth)
              || String.IsNullOrEmpty(customerProfilesummaryInputModel.TimeFrame) || customerProfilesummaryInputModel.AccountingYear == 0)
            {
                if (String.IsNullOrEmpty(customerProfilesummaryInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(customerProfilesummaryInputModel.AccountingMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (customerProfilesummaryInputModel.AccountingYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(customerProfilesummaryInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }

            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();
            List<CustomerProfileSummaryOutputModel> customerSummary = UtilityHelper.ProcessException<List<CustomerProfileSummaryOutputModel>>(() => _trackerReportingFacade.GetCustomerProfileSummary(customerProfilesummaryInputModel));
            _logger.TraceEnd();
            if (customerSummary.Count > 0 && customerSummary != null)
            {
                return Ok(customerSummary);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for UserID: {0}", customerProfilesummaryInputModel.UserID));
            }
        }


        /// <summary>
        /// Load the Data for Owner Region filter.
        /// </summary>
        /// <remarks>Load the Data for Owner Region filter.</remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/ownerregion")]  // R3
        public IHttpActionResult GetOwnerRegionFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetOwnerRegionFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Owner Region filter control");
            }
        }
        /// <summary>
        /// Load the Data for Est Placement filter.
        /// </summary>
        /// <remarks>Load the Data for Owner Region filter.</remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/estplacement")]  // R3
        public IHttpActionResult GetEstPlacementFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetEstPlacementFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Owner Region filter control");
            }
        }
        /// <summary>
        /// Load the Data for TPA Filter.
        /// </summary>
        /// <remarks>Load the Data for TPA filter.</remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/tpa")]  // R3
        public IHttpActionResult GetTPAFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetTPAFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for TPA filter");
            }
        }
        /// <summary>
        /// Load the Data for TScore.
        /// </summary>
        /// <remarks>Load the Data for TScore.</remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/tscore")]  // R3
        public IHttpActionResult GetTScore()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetTScore());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Tscore filter");
            }
        }
        /// <summary>
        /// Load the Data for ProfileOwner filter.
        /// </summary>
        /// <remarks>Load the Data for Profile Owner filter.</remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/customer/profileowner")]  // R3
        public IHttpActionResult GetCustomerProfileOwnerFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCustomerProfileOwnerFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Customer Profile Owner filter control");
            }
        }

        /// <summary>
        /// Load the Data for Producer ProfileOwner Filter.
        /// </summary>
        /// <remarks>Load the Data for Producer ProfileOwner Filter</remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/producer/profileowner")]  // R3
        public IHttpActionResult GetProducerProfileOwnerFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetProducerProfileOwnerFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Producer Profile Owner filter control");
            }
        }

        #region Product Brokered
        /// <summary>
        /// Load the Data for Product Brokered filter.
        /// </summary>
        /// <remarks>Load the Data for Product Brokered filter.</remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/producer/ProductBrokered")]  // R3
        public IHttpActionResult GetProducerProductBrokeredFilter(int brokerId, int BrokerOfficeId)
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetProducerProductBrokeredFilter(brokerId, BrokerOfficeId));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for producer Brokered filter control");
            }
        }

        #endregion

        #region Top Carrier
        /// <summary>
        /// Load the Data for Top Carrier filter.
        /// </summary>
        /// <remarks>Load the Data for Top Carrier filter.</remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/topCarrier")]  // R3
        public IHttpActionResult GetTopCarrierFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetTopCarrierFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Top Carrier filter control");
            }
        }
        #endregion

        #region CurrentAccountingMonthYear
        /// <summary>
        /// Load the Data for CurrentAccountingYearMonth.
        /// </summary>
        /// <remarks>Load the Data for CurrentAccountingYearMonth.</remarks>
        /// <returns>CurrentAccountingYearMonthOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<CurrentAccountingYearMonthOutputModel>))]
        [HttpPost]
        [Route("filters/currentaccountingyearmonth")]  // R4
        public IHttpActionResult GetCurrentAccountingYearMonth()
        {
            _logger.TraceStart();
            CurrentAccountingYearMonthOutputModel dropdownOutputValues = UtilityHelper.ProcessException<CurrentAccountingYearMonthOutputModel>(() => _trackerReportingFacade.GetCurrentAccountingYearMonth());
            _logger.TraceEnd();
            if (dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No data to Load");
            }
        }
        #endregion

        /// <summary>
        /// Load the Data for Producer Scorecard .
        /// </summary>
        /// <remarks>Load the Data for Producer Scorecard Filter</remarks>
        ///  Required Fields : UserID, AccountingMonth, AccountingYear,TimeFrame ,TopNo<br></br>
        /// <returns>ProducerscorecardOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>

        [ResponseType(typeof(IEnumerable<ProducerScorecardFilterOutputModel>))]
        [HttpPost]
        [Route("reports/producers/scorecard")] // R3
        public IHttpActionResult GetProducerScorecardvalue(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TopBy) || trackingReportingCommonFilterInputModel.TopNo == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TopBy))
                    return Content(HttpStatusCode.BadRequest, "TopBy not passed for the request");
                if (trackingReportingCommonFilterInputModel.TopNo == 0)
                    return Content(HttpStatusCode.BadRequest, "TopNo not passed for the request");
            }
            _logger.TraceStart();
            List<ProducerScorecardFilterOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<ProducerScorecardFilterOutputModel>>(() => _trackerReportingFacade.GetProducerScorecardvalue(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Producer Scorecard found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }


        }

        /// <summary>
        /// Get Insured Lost and Declined Business details
        /// </summary>
        /// <remarks>
        /// Load the data to Insured  Lost and Declined Business Grid <br></br>
        /// Required Fields : ClientID<br></br>
        /// Optional Parameters : PageNumber,PageSize,sortBy,OrderBy<br></br>
        /// SortBy :Insured |Type |EffectiveDate|Division|Segment|Product|Producer|status|Expiring|Forecast|CreditedRegion|UWName<br></br>
        /// Total Lost Forecast : Expiring |Forecast<BR></BR>
        /// Total Lost count : Forecast<BR></BR>
        /// Comments : Type  (Get type Value result)<br></br>
        /// </remarks>
        /// Give the full Company name <br></br>
        /// <param name="LostandDeclinedInsuredInputModel">lostandDeclinedInsuredInputModel</param>
        /// <returns>customerSummary</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(LostandDeclinedBusinessOutputModel))]
        [HttpPost]
        [Route("insured/lostdeclinedbusiness")] // R4
        public IHttpActionResult GetInsuredLostandDeclinedBusiness(LostandDeclinedInsuredInputModel lostandDeclinedInsuredInputModel)
        {
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();
            List<LostandDeclinedBusinessOutputModel> lostandDeclinedBusiness = UtilityHelper.ProcessException<List<LostandDeclinedBusinessOutputModel>>(() => _trackerReportingFacade.GetInsuredLostandDeclinedBusiness(lostandDeclinedInsuredInputModel));
            _logger.TraceEnd();
            if (lostandDeclinedBusiness.Count > 0 && lostandDeclinedBusiness != null)
            {
                return Ok(lostandDeclinedBusiness);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientID: {0}", lostandDeclinedInsuredInputModel.ClientID));
            }
        }
        /// <summary>
        /// Get the pipelines details for Dynamcis.
        /// </summary>
        /// <remarks>
        /// Loads the Pipelines details based on the status -Target alone.<br></br>
        /// Required Fields : User EmailID<br></br>
        /// Optional Parameters : AccountMonth,AccountYear,TimeFrame,AccountName,AccountType,Forecast<br></br>
        /// </remarks>
        /// <param name="objDynamicPipelinesInputModel"></param>
        /// <returns>DynamicsPipelinesDetails</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(DynamicPipelinesOutputModel))]
        [HttpPost]
        [Route("dynamics/pipelines")] // R4 Dynamics Mobile
        public IHttpActionResult GetDynamicsPipelinesDetails(DynamicPipelinesInputModel objDynamicPipelinesInputModel)
        {
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();
            List<DynamicPipelinesOutputModel> DynamicsPipelinesDetails = UtilityHelper.ProcessException<List<DynamicPipelinesOutputModel>>(() => _trackerReportingFacade.GetDynamicsPipelinesDetails(objDynamicPipelinesInputModel));
            _logger.TraceEnd();
            if (DynamicsPipelinesDetails.Count > 0 && DynamicsPipelinesDetails != null)
            {
                return Ok(DynamicsPipelinesDetails);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for User: {0}", objDynamicPipelinesInputModel.UserEmailID));
            }
        }

        /// <summary>
        /// Insert Stewardship Underwritting Records.
        /// </summary>
        /// <remarks>
        /// Required Fields : ClientName<br></br>
        /// </remarks>
        /// <param name="objUnderwrittingInputModel"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("reports/stewardship/underwritting")] // R4 
        public IHttpActionResult Underwritting(UnderwrittingInputModel objUnderwrittingInputModel)
        {
            if (String.IsNullOrEmpty(objUnderwrittingInputModel.Underwritting))
                return Content(HttpStatusCode.BadRequest, "Underwritting not passed for the request");

            if (String.IsNullOrEmpty(objUnderwrittingInputModel.ClientName))
                return Content(HttpStatusCode.BadRequest, "ClientName not passed for the request");

            _logger.TraceStart();
            string saveUnderwritting = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.SaveUnderwritting(objUnderwrittingInputModel));
            _logger.TraceEnd();
            if (saveUnderwritting != null)
            {
                return Ok(saveUnderwritting);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Datas are Saved for Stewardship Underwritting");
            }
        }

        /// <summary>
        /// Insert Stewardship ClaimsHandling Records.
        /// </summary>
        /// <remarks>
        /// Required Fields : ClientName<br></br>
        /// </remarks>
        /// <param name="objClaimsHandlingInputModel"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("reports/stewardship/claimshandling")] // R4 
        public IHttpActionResult ClaimsHandling(ClaimsHandlingInputModel objClaimsHandlingInputModel)
        {
            if (String.IsNullOrEmpty(objClaimsHandlingInputModel.ClaimsHandling))
                return Content(HttpStatusCode.BadRequest, "ClaimsHandling not passed for the request");

            if (String.IsNullOrEmpty(objClaimsHandlingInputModel.ClientName))
                return Content(HttpStatusCode.BadRequest, "ClientName not passed for the request");

            _logger.TraceStart();
            string saveClaimsHandling = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.SaveClaimsHandling(objClaimsHandlingInputModel));
            _logger.TraceEnd();
            if (saveClaimsHandling != null)
            {
                return Ok(saveClaimsHandling);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Datas are Saved for Stewardship ClaimsHandling");
            }
        }

        /// <summary>
        /// Insert Stewardship RelationShip Records.
        /// </summary>
        /// <remarks>
        /// Required Fields : ClientName<br></br>
        /// </remarks>
        /// <param name="objRelationShipInputModel"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("reports/stewardship/relationShip")] // R4 
        public IHttpActionResult RelationShip(RelationShipInputModel objRelationShipInputModel)
        {
            if (String.IsNullOrEmpty(objRelationShipInputModel.Relationship))
                return Content(HttpStatusCode.BadRequest, "Relationship not passed for the request");

            if (String.IsNullOrEmpty(objRelationShipInputModel.ClientName))
                return Content(HttpStatusCode.BadRequest, "ClientName not passed for the request");

            _logger.TraceStart();
            string saveRelationShip = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.SaveRelationShip(objRelationShipInputModel));
            _logger.TraceEnd();
            if (saveRelationShip != null)
            {
                return Ok(saveRelationShip);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Datas are Saved for Stewardship RelationShip");
            }
        }

        /// <summary>
        /// Insert Stewardship CarrierThreat Records.
        /// </summary>
        /// <remarks>
        /// Required Fields : ClientName<br></br>
        /// </remarks>
        /// <param name="objCarrierThreatsInputModel"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("reports/stewardship/carrierthreat")] // R4 
        public IHttpActionResult CarrierThreat(CarrierThreatsInputModel objCarrierThreatsInputModel)
        {
            if (String.IsNullOrEmpty(objCarrierThreatsInputModel.CarrierThreat))
                return Content(HttpStatusCode.BadRequest, "CarrierThreat not passed for the request");

            if (String.IsNullOrEmpty(objCarrierThreatsInputModel.ClientName))
                return Content(HttpStatusCode.BadRequest, "ClientName not passed for the request");

            _logger.TraceStart();
            string saveCarrierThreat = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.SaveCarrierThreat(objCarrierThreatsInputModel));
            _logger.TraceEnd();
            if (saveCarrierThreat != null)
            {
                return Ok(saveCarrierThreat);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Datas are Saved for Stewardship CarrierThreat");
            }
        }

        /// <summary>
        /// Insert Stewardship ProducerRecordThreat Records.
        /// </summary>
        /// <remarks>
        /// Required Fields : ClientName<br></br>
        /// </remarks>
        /// <param name="objSaveProducerRecordThreatInputModel"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("reports/stewardship/producerrecordthreat")] // R4 
        public IHttpActionResult ProducerRecordThreat(ProducerRecordThreatsInputModel objSaveProducerRecordThreatInputModel)
        {
            if (String.IsNullOrEmpty(objSaveProducerRecordThreatInputModel.ProducerRecordThreat))
                return Content(HttpStatusCode.BadRequest, "ProducerRecordThreat not passed for the request");

            if (String.IsNullOrEmpty(objSaveProducerRecordThreatInputModel.ClientName))
                return Content(HttpStatusCode.BadRequest, "ClientName not passed for the request");

            _logger.TraceStart();
            string saveProducerRecordThreat = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.SaveProducerRecordThreat(objSaveProducerRecordThreatInputModel));
            _logger.TraceEnd();
            if (saveProducerRecordThreat != null)
            {
                return Ok(saveProducerRecordThreat);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Datas are Saved for Stewardship ProducerRecordThreat");
            }
        }

        /// <summary>
        /// Load Stewardship Underwritting data,based on the ClientID.
        /// </summary>
        ///  Required Fields : ClientName<br></br>
        /// <returns>UnderwrittingOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>

        [ResponseType(typeof(IEnumerable<UnderwrittingOutputModel>))]
        [HttpGet]
        [Route("reports/stewardship/underwritting")] // R4
        public IHttpActionResult Underwritting(string clientName)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            List<UnderwrittingOutputModel> objgetunderwritting = UtilityHelper.ProcessException<List<UnderwrittingOutputModel>>(() => _trackerReportingFacade.GetUnderwritting(clientName));
            _logger.TraceEnd();
            if (objgetunderwritting != null && objgetunderwritting.Count != 0)
            {
                return Ok(objgetunderwritting);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientName: {0}", clientName));
            }

        }

        /// <summary>
        /// Load Stewardship ClaimsHandling data,based on the ClientID.
        /// </summary>
        ///  Required Fields : ClientName<br></br>
        /// <returns>ClaimsHandlingOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>

        [ResponseType(typeof(IEnumerable<ClaimsHandlingOutputModel>))]
        [HttpGet]
        [Route("reports/stewardship/claimshandling")] // R4
        public IHttpActionResult ClaimsHandling(string clientName)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            List<ClaimsHandlingOutputModel> objGetClaimsHandling = UtilityHelper.ProcessException<List<ClaimsHandlingOutputModel>>(() => _trackerReportingFacade.GetClaimsHandling(clientName));
            _logger.TraceEnd();
            if (objGetClaimsHandling != null && objGetClaimsHandling.Count != 0)
            {
                return Ok(objGetClaimsHandling);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientName: {0}", clientName));
            }

        }

        /// <summary>
        /// Load Stewardship Relationship data,based on the ClientID.
        /// </summary>
        ///  Required Fields : ClientName<br></br>
        /// <returns>RelationShipOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>

        [ResponseType(typeof(IEnumerable<RelationShipOutputModel>))]
        [HttpGet]
        [Route("reports/stewardship/relationship")] // R4
        public IHttpActionResult Relationship(string clientName)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            List<RelationShipOutputModel> objGetRelationship = UtilityHelper.ProcessException<List<RelationShipOutputModel>>(() => _trackerReportingFacade.GetRelationship(clientName));
            _logger.TraceEnd();
            if (objGetRelationship != null && objGetRelationship.Count != 0)
            {
                return Ok(objGetRelationship);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientName: {0}", clientName));
            }

        }

        /// <summary>
        /// Load Stewardship CarrierThreatS data,based on the ClientID.
        /// </summary>
        ///  Required Fields : ClientName<br></br>
        /// <returns>CarrierThreatsOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>

        [ResponseType(typeof(IEnumerable<CarrierThreatsOutputModel>))]
        [HttpGet]
        [Route("reports/stewardship/carrierthreats")] // R4
        public IHttpActionResult CarrierThreats(string clientName)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            List<CarrierThreatsOutputModel> objGetCarrierThreats = UtilityHelper.ProcessException<List<CarrierThreatsOutputModel>>(() => _trackerReportingFacade.GetCarrierThreats(clientName));
            _logger.TraceEnd();
            if (objGetCarrierThreats != null && objGetCarrierThreats.Count != 0)
            {
                return Ok(objGetCarrierThreats);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientName: {0}", clientName));
            }

        }


        /// <summary>
        /// Load Stewardship ProducerRecordThreats data,based on the ClientID.
        /// </summary>
        ///  Required Fields : ClientName<br></br>
        /// <returns>ProducerRecordThreatsOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>

        [ResponseType(typeof(IEnumerable<ProducerRecordThreatsOutputModel>))]
        [HttpGet]
        [Route("reports/stewardship/producerrecordthreats")] // R4
        public IHttpActionResult ProducerRecordThreats(string clientName)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            List<ProducerRecordThreatsOutputModel> objProducerRecordThreats = UtilityHelper.ProcessException<List<ProducerRecordThreatsOutputModel>>(() => _trackerReportingFacade.GetProducerRecordThreats(clientName));
            _logger.TraceEnd();
            if (objProducerRecordThreats != null && objProducerRecordThreats.Count != 0)
            {
                return Ok(objProducerRecordThreats);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientName: {0}", clientName));
            }

        }

        /// <summary>
        /// Insert Stewardship LoseNote Records.
        /// </summary>
        /// <remarks>
        /// Required Fields : ClientName,LossNote<br></br>
        /// </remarks>
        /// <param name="objLossNoteInputModel"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("reports/stewardship/lossnote")] // R4 
        public IHttpActionResult LossNote(LossNoteInputModel objLossNoteInputModel)
        {
            if (String.IsNullOrEmpty(objLossNoteInputModel.LossNote))
                return Content(HttpStatusCode.BadRequest, "LossNote not passed for the request");

            if (String.IsNullOrEmpty(objLossNoteInputModel.ClientName))
                return Content(HttpStatusCode.BadRequest, "ClientName not passed for the request");

            _logger.TraceStart();
            string saveLossNote = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.SaveLossNote(objLossNoteInputModel));
            _logger.TraceEnd();
            if (saveLossNote != null)
            {
                return Ok(saveLossNote);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Datas are Saved for Stewardship LossNote");
            }
        }

        /// <summary>
        /// Insert Stewardship AccountMarketed Records.
        /// AccountMarketed field input like Y or N ,If customer enter Y,Reason is mandatory.If customer enter N,Reason is not mandatory. 
        /// </summary>
        /// <remarks>
        /// Required Fields : ClientName,AccountMarketed<br></br>
        /// </remarks>
        /// <param name="objAccountMarketedInputModel"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("reports/stewardship/accountmarketed")] // R4 
        public IHttpActionResult AccountMarketed(AccountMarketedInputModel objAccountMarketedInputModel)
        {


            if ((String.IsNullOrEmpty(objAccountMarketedInputModel.AccountMarketed) || (String.IsNullOrEmpty(objAccountMarketedInputModel.ClientName))))
            {

                if (String.IsNullOrEmpty(objAccountMarketedInputModel.AccountMarketed))
                    return Content(HttpStatusCode.BadRequest, "AccountMarketed not passed for the request");

                if (String.IsNullOrEmpty(objAccountMarketedInputModel.ClientName))
                    return Content(HttpStatusCode.BadRequest, "ClientName not passed for the request");

            }
            _logger.TraceStart();
            string saveAccountMarketed = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.SaveAccountMarketed(objAccountMarketedInputModel));
            _logger.TraceEnd();
            if (saveAccountMarketed != null)
            {
                return Ok(saveAccountMarketed);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Datas are Saved for Stewardship AccountMarketed");
            }
        }


        /// <summary>
        /// Insert Stewardship RenewalStrategy Records.
        /// </summary>
        /// <remarks>
        /// Required Fields : Stratagy,Owner,ClientName,Date<br></br>
        /// </remarks>
        /// <param name="objRenewalStrategyInputModel"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("reports/stewardship/renewalstrategy")] // R4 
        public IHttpActionResult RenewalStrategy(RenewalStrategyInputModel objRenewalStrategyInputModel)
        {
            if (!objRenewalStrategyInputModel.Date.HasValue)
            {
                return Content(HttpStatusCode.BadRequest, "Date not passed for the request");
            }


            if ((String.IsNullOrEmpty(objRenewalStrategyInputModel.Stratagy) || (String.IsNullOrEmpty(objRenewalStrategyInputModel.ClientName))
             || (String.IsNullOrEmpty(objRenewalStrategyInputModel.Owner))))
            {
                if (String.IsNullOrEmpty(objRenewalStrategyInputModel.Stratagy))
                    return Content(HttpStatusCode.BadRequest, "Stratagy not passed for the request");

                if (String.IsNullOrEmpty(objRenewalStrategyInputModel.ClientName))
                    return Content(HttpStatusCode.BadRequest, "ClientName not passed for the request");

                if (String.IsNullOrEmpty(objRenewalStrategyInputModel.Owner))
                    return Content(HttpStatusCode.BadRequest, "Owner not passed for the request");
            }

            _logger.TraceStart();
            string renewalStrategyInputModel = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.SaveRenewalStrategy(objRenewalStrategyInputModel));
            _logger.TraceEnd();
            if (renewalStrategyInputModel != null)
            {
                return Ok(renewalStrategyInputModel);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Datas are Saved for Stewardship RenewalStrategy");
            }
        }

        /// <summary>
        /// Insert Stewardship RiskEngineeringService Records.
        /// </summary>
        /// <remarks>
        /// Required Fields : Service,Owner,ClientName,Date<br></br>
        /// </remarks>
        /// <param name="objRiskEngineeringServiceInputModel"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("reports/stewardship/riskengineeringservice")] // R4 
        public IHttpActionResult RiskEngineeringService(RiskEngineeringServiceInputModel objRiskEngineeringServiceInputModel)
        {

            if (!objRiskEngineeringServiceInputModel.Date.HasValue)
            {
                return Content(HttpStatusCode.BadRequest, "Date not passed for the request");
            }


            if ((String.IsNullOrEmpty(objRiskEngineeringServiceInputModel.Service) || (String.IsNullOrEmpty(objRiskEngineeringServiceInputModel.ClientName))
             || (String.IsNullOrEmpty(objRiskEngineeringServiceInputModel.Owner))))
            {

                if (String.IsNullOrEmpty(objRiskEngineeringServiceInputModel.Service))
                    return Content(HttpStatusCode.BadRequest, "Service not passed for the request");

                if (String.IsNullOrEmpty(objRiskEngineeringServiceInputModel.ClientName))
                    return Content(HttpStatusCode.BadRequest, "ClientName not passed for the request");

                if (String.IsNullOrEmpty(objRiskEngineeringServiceInputModel.Owner))
                    return Content(HttpStatusCode.BadRequest, "Owner not passed for the request");
            }

            _logger.TraceStart();
            string riskEngineeringService = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.SaveRiskEngineeringService(objRiskEngineeringServiceInputModel));
            _logger.TraceEnd();
            if (riskEngineeringService != null)
            {
                return Ok(riskEngineeringService);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Datas are Saved for Stewardship RiskEngineeringService");
            }
        }

        /// <summary>
        /// Insert Stewardship ClaimServices Records.
        /// </summary>
        /// <remarks>
        /// Required Fields : Service,Owner,ClientName,Date,duedate<br></br>
        /// </remarks>
        /// <param name="objClaimServicesInputModel"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("reports/stewardship/claimservices")] // R4 
        public IHttpActionResult ClaimServices(ClaimServicesInputModel objClaimServicesInputModel)
        {
            if (!objClaimServicesInputModel.Date.HasValue)
            {
                return Content(HttpStatusCode.BadRequest, "Date not passed for the request");
            }
            if (!objClaimServicesInputModel.DueDate.HasValue)
            {
                return Content(HttpStatusCode.BadRequest, "DueDate not passed for the request");
            }

            if ((String.IsNullOrEmpty(objClaimServicesInputModel.Service) || (String.IsNullOrEmpty(objClaimServicesInputModel.ClientName))
             || (String.IsNullOrEmpty(objClaimServicesInputModel.Owner))))
            {

                if (String.IsNullOrEmpty(objClaimServicesInputModel.Service))
                    return Content(HttpStatusCode.BadRequest, "Service not passed for the request");

                if (String.IsNullOrEmpty(objClaimServicesInputModel.ClientName))
                    return Content(HttpStatusCode.BadRequest, "ClientName not passed for the request");

                if (String.IsNullOrEmpty(objClaimServicesInputModel.Owner))
                    return Content(HttpStatusCode.BadRequest, "Owner not passed for the request");

            }
            _logger.TraceStart();
            string claimServices = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.SaveClaimServices(objClaimServicesInputModel));
            _logger.TraceEnd();
            if (claimServices != null)
            {
                return Ok(claimServices);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Datas are Saved for Stewardship ClaimServices");
            }
        }

        /// <summary>
        /// Load Stewardship RenewalStrategy data,based on the ClientID.
        /// </summary>
        /// <remarks>
        /// Required Fields : ClientName<br></br>
        /// </remarks>
        /// <param name="clientName"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(RenewalStrategyOutputModel))]
        [HttpGet]
        [Route("reports/stewardship/renewalstrategy")] // R4 
        public IHttpActionResult RenewalStrategy(string clientName)
        {
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();
            List<RenewalStrategyOutputModel> renewalStrategy = UtilityHelper.ProcessException<List<RenewalStrategyOutputModel>>(() => _trackerReportingFacade.GetRenewalStrategy(clientName));

            _logger.TraceEnd();
            if (renewalStrategy != null && renewalStrategy.Count != 0)
            {
                return Ok(renewalStrategy);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientName: {0}", clientName));
            }
        }

        /// <summary>
        /// Load Stewardship RiskengineeringService data,based on the ClientID.
        /// </summary>
        /// <remarks>
        /// Required Fields : ClientName<br></br>
        /// </remarks>
        /// <param name="clientName"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(RiskEngineeringServiceOutputModel))]
        [HttpGet]
        [Route("reports/stewardship/riskengineeringservice")] // R4 
        public IHttpActionResult RiskengineeringService(string clientName)
        {
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();
            List<RiskEngineeringServiceOutputModel> riskengineering = UtilityHelper.ProcessException<List<RiskEngineeringServiceOutputModel>>(() => _trackerReportingFacade.GetRiskengineeringService(clientName));

            _logger.TraceEnd();
            if (riskengineering != null && riskengineering.Count != 0)
            {
                return Ok(riskengineering);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientName: {0}", clientName));
            }
        }

        /// <summary>
        /// Load Stewardship ClaimServices data,based on the ClientID.
        /// </summary>
        /// <remarks>
        /// Required Fields : ClientName<br></br>
        /// </remarks>
        /// <param name="clientName"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(RiskEngineeringServiceOutputModel))]
        [HttpGet]
        [Route("reports/stewardship/claimservices")] // R4 
        public IHttpActionResult ClaimServices(string clientName)
        {
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();
            List<ClaimServicesOutputModel> claimServices = UtilityHelper.ProcessException<List<ClaimServicesOutputModel>>(() => _trackerReportingFacade.GetClaimServices(clientName));

            _logger.TraceEnd();
            if (claimServices != null && claimServices.Count != 0)
            {
                return Ok(claimServices);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientName: {0}", clientName));
            }
        }

        /// <summary>
        /// Load Stewardship LossNote data,based on the ClientID.
        /// </summary>
        /// <remarks>
        /// Required Fields : ClientName<br></br>
        /// </remarks>
        /// <param name="clientName"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(LossNoteOutputModel))]
        [HttpGet]
        [Route("reports/stewardship/lossnotes")] // R4 
        public IHttpActionResult LossNotes(string clientName)
        {
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();
            List<LossNoteOutputModel> lossNotes = UtilityHelper.ProcessException<List<LossNoteOutputModel>>(() => _trackerReportingFacade.GetLossNotes(clientName));

            _logger.TraceEnd();
            if (lossNotes != null && lossNotes.Count != 0)
            {
                return Ok(lossNotes);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientName: {0}", clientName));
            }
        }

        /// <summary>
        /// Load Stewardship AccountMarketed data,based on the ClientID.
        /// </summary>
        /// <remarks>
        /// Required Fields : ClientName<br></br>
        /// </remarks>
        /// <param name="clientName"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(AccountMarketedOuputModel))]
        [HttpGet]
        [Route("reports/stewardship/accountMarketed")] // R4 
        public IHttpActionResult AccountMarketed(string clientName)
        {
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();
            List<AccountMarketedOuputModel> accountMarketed = UtilityHelper.ProcessException<List<AccountMarketedOuputModel>>(() => _trackerReportingFacade.GetAccountMarketed(clientName));

            _logger.TraceEnd();
            if (accountMarketed != null && accountMarketed.Count != 0)
            {
                return Ok(accountMarketed);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientName: {0}", clientName));
            }
        }
        /// <summary>
        /// Get the dropdown details for input Pages.
        /// </summary>
        /// <remarks>
        /// Loads the dropdown details based on the page.<br></br>
        /// Required Fields : strIds, Login_id<br></br>
        /// Optional Parameters :<br></br>
        /// </remarks>
        /// <param name="fullScreenDropdownModel"></param>
        /// <returns>fullScreenDropdownModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(DropdownOutputValues))]
        [HttpPost]
        [Route("filter/DropDownDetails")] // 
        public IHttpActionResult PageDropdownDetails(ScreenDropdownInputModel screenDropdownModel)
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetPageDropdownDetails(screenDropdownModel));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                //return Content(HttpStatusCode.NotFound, "No Load data for dropdown Controls");
                return Content(HttpStatusCode.NotFound, String.Format("No data found for dropdown filter control for UserID: {0}", screenDropdownModel.UserID));
            }


        }

        /// <summary>
        /// Load Stewardship Coverage data,based on the ClientID.
        /// </summary>
        /// <remarks>
        /// Required Fields : ClientName<br></br>
        /// </remarks>
        /// <param name="clientName"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(StewardshipCoverageOutputModel))]
        [HttpGet]
        [Route("reports/stewardship/coverage")] // R4 
        public IHttpActionResult StewardshipCoverage(string clientName)
        {
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();
            List<StewardshipCoverageOutputModel> coverage = UtilityHelper.ProcessException<List<StewardshipCoverageOutputModel>>(() => _trackerReportingFacade.GetStewardshipCoverage(clientName));

            _logger.TraceEnd();
            if (coverage != null && coverage.Count != 0)
            {
                return Ok(coverage);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientName: {0}", clientName));
            }
        }

        /// <summary>
        /// Load Stewardship LineOfBusiness data,based on the ClientID.
        /// </summary>
        /// <remarks>
        /// Required Fields : ClientName<br></br>
        /// </remarks>
        /// <param name="clientName"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(StewardshipLineOfBusinessOutputModel))]
        [HttpGet]
        [Route("reports/stewardship/lineofbusiness")] // R4 
        public IHttpActionResult StewardshipLineOfBusiness(string clientName)
        {
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();
            List<StewardshipLineOfBusinessOutputModel> coverage = UtilityHelper.ProcessException<List<StewardshipLineOfBusinessOutputModel>>(() => _trackerReportingFacade.GetStewardshipLineOfBusiness(clientName));

            _logger.TraceEnd();
            if (coverage != null && coverage.Count != 0)
            {
                return Ok(coverage);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientName: {0}", clientName));
            }
        }

        /// <summary>
        /// Insert Stewardship LineOfBusinessComment Records.
        /// </summary>
        /// <remarks>
        /// Required Fields : ClientName,RecordNumber,Comment<br></br>
        /// </remarks>
        /// <param name="objBusinessCommentInputModel"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("reports/stewardship/lineofbusinesscomment")] // R4 
        public IHttpActionResult StewardshipLineOfBusinessComment(StewardshipBusinessCommentInputModel objBusinessCommentInputModel)
        {
            if ((String.IsNullOrEmpty(objBusinessCommentInputModel.ClientName) || objBusinessCommentInputModel.RecordNumber == 0)
             || String.IsNullOrEmpty(objBusinessCommentInputModel.Comment))
            {
                if (String.IsNullOrEmpty(objBusinessCommentInputModel.ClientName))
                    return Content(HttpStatusCode.BadRequest, "ClientName not passed for the request");

                if (String.IsNullOrEmpty(objBusinessCommentInputModel.Comment))
                    return Content(HttpStatusCode.BadRequest, "Comment not passed for the request");

                if (objBusinessCommentInputModel.RecordNumber == 0)
                    return Content(HttpStatusCode.BadRequest, "RecordNumber not passed for the request");

            }
            _logger.TraceStart();
            string stewardshipLineOfBusinessComment = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.SaveStewardshipLineOfBusinessComment(objBusinessCommentInputModel));
            _logger.TraceEnd();
            if (stewardshipLineOfBusinessComment != null)
            {
                return Ok(stewardshipLineOfBusinessComment);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Datas are Saved for Stewardship LineOfBusinessComment");
            }
        }

        /// <summary>
        /// Load Stewardship Account data,based on the clientName.
        /// </summary>
        /// <remarks>
        /// Required Fields : ClientName<br></br>
        /// </remarks>
        /// <param name="clientName"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(AccountOutputModel))]
        [HttpGet]
        [Route("reports/stewardship/account")] // R4 
        public IHttpActionResult StewardshipAccount(string clientName)
        {
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();
            List<AccountOutputModel> accountMarketed = UtilityHelper.ProcessException<List<AccountOutputModel>>(() => _trackerReportingFacade.GetAccount(clientName));

            _logger.TraceEnd();
            if (accountMarketed != null && accountMarketed.Count != 0)
            {
                return Ok(accountMarketed);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientName: {0}", clientName));
            }
        }


        /// <summary>
        /// Load Insured Glance details,based on the client Id.
        /// </summary>
        /// <remarks>
        ///  Load Insured Glance details,based on the client Id.<br></br>
        /// Required Fields : ClientID<br></br>
        /// </remarks>
        /// <param name="ClientID"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(InsuredGlanceOutputModel))]
        [HttpGet]
        [Route("insured/glancedetails")] // R4 
        public IHttpActionResult GetInsuredGlanceDetails(int ClientID)
        {
            if (ClientID != null || ClientID != 0)
            {
                _logger.TraceStart();
                List<InsuredGlanceOutputModel> InsuredGlanceDetails = UtilityHelper.ProcessException<List<InsuredGlanceOutputModel>>(() => _trackerReportingFacade.GetInsuredGlanceDetails(ClientID));

                _logger.TraceEnd();
                if (InsuredGlanceDetails != null && InsuredGlanceDetails.Count != 0)
                {
                    return Ok(InsuredGlanceDetails);
                }
                else
                {
                    return Content(HttpStatusCode.NotFound, String.Format("No Records found for Client ID: {0}", ClientID));
                }
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("Invalid Client ID"));
            }
        }


        /// <summary>
        /// Load Insured Historical Forecast details,based on the client Id.
        /// </summary>
        /// <remarks>
        ///  Load Insured Historical Forecast details,based on the client Id.<br></br>
        /// Required Fields : ClientID<br></br>
        /// </remarks>
        /// <param name="ClientID"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(InsuredHistoricalForecastOutputModel))]
        [HttpGet]
        [Route("insured/historicalforecastdetails")] // R4 
        public IHttpActionResult GetInsuredHistoricalForecastDetails(int ClientID)
        {
            if (ClientID != null || ClientID != 0)
            {
                _logger.TraceStart();
                List<InsuredHistoricalForecastOutputModel> InsuredHistoricalForecastDetails = UtilityHelper.ProcessException<List<InsuredHistoricalForecastOutputModel>>(() => _trackerReportingFacade.GetInsuredHistoricalForecastDetails(ClientID));

                _logger.TraceEnd();
                if (InsuredHistoricalForecastDetails != null && InsuredHistoricalForecastDetails.Count != 0)
                {
                    return Ok(InsuredHistoricalForecastDetails);
                }
                else
                {
                    return Content(HttpStatusCode.NotFound, String.Format("No Records found for Client ID: {0}", ClientID));
                }
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("Invalid Client ID"));
            }

        }

        /// <summary>
        /// Load Insured information details,based on the client Id.
        /// </summary>
        /// <remarks>
        /// Load Insured information details,based on the client Id.<br></br>
        /// Required Fields : ClientID<br></br>
        /// </remarks>
        /// <param name="ClientID"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(InsuredInformationOutputModel))]
        [HttpGet]
        [Route("insured/insuredinformationDetails")] // R4 
        public IHttpActionResult GetInsuredInformationDetails(int ClientID)
        {
            if (ClientID != null || ClientID != 0)
            {
                _logger.TraceStart();
                List<InsuredInformationOutputModel> InsuredInformationDetails = UtilityHelper.ProcessException<List<InsuredInformationOutputModel>>(() => _trackerReportingFacade.GetInsuredInformationDetails(ClientID));
                _logger.TraceEnd();
                if (InsuredInformationDetails != null && InsuredInformationDetails.Count != 0)
                {
                    return Ok(InsuredInformationDetails);
                }
                else
                {
                    return Content(HttpStatusCode.NotFound, String.Format("No Records found for Client ID: {0}", ClientID));
                }
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("Invalid Client ID"));
            }

        }

        /// <summary>
        /// Getting Stewardship rentention percentage,based on the clientName.
        /// </summary>
        /// <remarks>
        /// Required Fields : ClientName<br></br>
        /// </remarks>
        /// <param name="clientName"></param>
        /// <returns>string</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(StewardshipRententionOuputModel))]
        [HttpGet]
        [Route("reports/stewardship/rentention")] // R4 
        public IHttpActionResult StewardshipRentention(string clientName)
        {
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();
            List<StewardshipRententionOuputModel> rentention = UtilityHelper.ProcessException<List<StewardshipRententionOuputModel>>(() => _trackerReportingFacade.GetStewardshipRentention(clientName));

            _logger.TraceEnd();
            if (rentention != null && rentention.Count != 0)
            {
                return Ok(rentention);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientName: {0}", clientName));
            }
        }

        /// <summary>
        /// Get Insured Current Inforce summary details.
        /// </summary>
        /// <remarks>
        /// Get Insured Current Inforce summary details.<br></br>
        /// Required Fields : ClientID<br></br>
        /// Optional Parameters : PageNumber,PageSize,sortBy,OrderBy<br></br>
        /// SortBy :Insured |Type |EffectiveDate|Division|Segment|Product|Producer|status|Expiring|Forecast|CreditedRegion|UWName<br></br>
        /// Total Lost Forecast : Expiring |Forecast<BR></BR>
        /// Total Lost count : Forecast<BR></BR>
        /// Comments : Type  (Get type Value result)<br></br>
        /// </remarks>      
        /// <param name="objlostandDeclinedInsuredInputModel">lostandDeclinedInsuredInputModel</param>
        /// <returns>InsuredSummary</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(InsuredSummaryOutputModel))]
        [HttpPost]
        [Route("insured/currentinforcesummary")] // R4
        public IHttpActionResult GetInsuredCurrentInforceSummary(LostandDeclinedInsuredInputModel objlostandDeclinedInsuredInputModel)
        {
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();
            List<InsuredSummaryOutputModel> InsuredCurrentInforceSummary = UtilityHelper.ProcessException<List<InsuredSummaryOutputModel>>(() => _trackerReportingFacade.GetInsuredCurrentInforceSummary(objlostandDeclinedInsuredInputModel));
            _logger.TraceEnd();
            if (InsuredCurrentInforceSummary.Count > 0 && InsuredCurrentInforceSummary != null)
            {
                return Ok(InsuredCurrentInforceSummary);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientID: {0}", objlostandDeclinedInsuredInputModel.ClientID));
            }
        }

        /// <summary>
        /// Get Insured Target summary details.
        /// </summary>
        /// <remarks>
        ///Get Insured Target summary details..<br></br>
        /// Required Fields : ClientID<br></br>
        /// Optional Parameters : PageNumber,PageSize,sortBy,OrderBy<br></br>
        /// SortBy :Insured |Type |EffectiveDate|Division|Segment|Product|Producer|status|Expiring|Forecast|CreditedRegion|UWName<br></br>
        /// Total Lost Forecast : Expiring |Forecast<BR></BR>
        /// Total Lost count : Forecast<BR></BR>
        /// Comments : Type  (Get type Value result)<br></br>
        /// </remarks>      
        /// <param name="objlostandDeclinedInsuredInputModel">lostandDeclinedInsuredInputModel</param>
        /// <returns>InsuredSummary</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(InsuredSummaryOutputModel))]
        [HttpPost]
        [Route("insured/targetsummary")] // R4
        public IHttpActionResult GetInsuredTargetSummary(LostandDeclinedInsuredInputModel objlostandDeclinedInsuredInputModel)
        {
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();
            List<InsuredSummaryOutputModel> InsuredTargetSummary = UtilityHelper.ProcessException<List<InsuredSummaryOutputModel>>(() => _trackerReportingFacade.GetInsuredTargetSummary(objlostandDeclinedInsuredInputModel));
            _logger.TraceEnd();
            if (InsuredTargetSummary.Count > 0 && InsuredTargetSummary != null)
            {
                return Ok(InsuredTargetSummary);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientID: {0}", objlostandDeclinedInsuredInputModel.ClientID));
            }
        }


        /// <summary>
        /// Delete Insured Summary Details.
        /// </summary>
        /// <remarks>
        /// Delete Insured Summary Details.<br></br>
        /// Required Fields : ClientID,Product No<br></br>      
        /// </remarks>      
        /// <param name="ClientID"></param>
        ///<param name="ProductNo"></param>        
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("insured/deletesummarydetails")] // R4
        public IHttpActionResult DeleteInsuredSummaryDetails(int ClientID, int ProductNo)
        {
            if ((ClientID != null || ClientID != 0) && (ProductNo != null || ProductNo != 0))
            {
                _logger.TraceStart();
                string objOutputModel = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.DeleteInsuredSummaryDetails(ClientID, ProductNo));
                _logger.TraceEnd();
                if (objOutputModel != null)
                {
                    return Ok(objOutputModel);
                }
                else
                {
                    return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientID: {0}", ClientID));
                }
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("Invalid Client ID"));
            }

        }


        /// <summary>
        /// Get CRM Completed Activities based on Customer Details.
        /// </summary>
        /// <remarks>
        /// Get CRM Completed Activities based on Customer Details<br></br>
        /// Required Parameters : Customer Name <br></br>
        /// Optional Parameters : ClientID, pageNumber,PageSize
        ///  </remarks>
        /// <param name="objCustomerProfileInputModel">objCustomerProfileInputModel</param>
        /// <returns>CRMCompletedActivitiesOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<CRMCompletedActivitiesOutputModel>))]
        [HttpPost]
        [Route("dynamics/customers/completedactivities")] // R3
        public IHttpActionResult GetCRMCompletedActivitiesByCustomer(CustomerProfileInputModel objCustomerProfileInputModel)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            List<CRMCompletedActivitiesOutputModel> objGetCRMCompletedActivitiesByCustomer = UtilityHelper.ProcessException<List<CRMCompletedActivitiesOutputModel>>(() => _trackerReportingEnterpriseIntegrationFacade.GetCRMCompletedActivitiesByCustomer(objCustomerProfileInputModel));
            _logger.TraceEnd();
            if (objGetCRMCompletedActivitiesByCustomer.Count > 0)
            {
                return Ok(objGetCRMCompletedActivitiesByCustomer);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No CRM Customers Completed Activites Record found for Customer Name: {0}", objCustomerProfileInputModel.Name));

            }

        }

        /// <summary>
        /// Get CRM Task based on Customer Details
        /// </summary>
        /// <remarks>
        /// Get CRM Task based on Customer Details<br></br>
        /// Required Parameters : Customer Name <br></br>
        /// Optional Parameters : ClientID,pageNumber,PageSize
        /// </remarks>
        /// <param name="objCustomerProfileInputModel"></param>
        /// <returns>UserTaskOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<UserTaskOutputModel>))]
        [HttpPost]
        [Route("dynamics/customers/tasks")] //R3
        public IHttpActionResult GetCRMTaskByCustomer(CustomerProfileInputModel objCustomerProfileInputModel)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }

            List<UserTaskOutputModel> objGetCRMTaskByCustomer = UtilityHelper.ProcessException<List<UserTaskOutputModel>>(() => _trackerReportingEnterpriseIntegrationFacade.GetCRMTaskByCustomer(objCustomerProfileInputModel));
            _logger.TraceEnd();
            if (objGetCRMTaskByCustomer.Count > 0)
            {
                return Ok(objGetCRMTaskByCustomer);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("No CRM Producer Task Record found for Customer Name: {0}", objCustomerProfileInputModel.Name));

            }
        }

        /// <summary>
        /// Get CRM Notes based on Customer Details
        /// </summary>
        /// <remarks>
        /// Get CRM Notes based on Customer Details<br></br>
        /// Required Parameters : Customer Name <br></br>
        /// Optional Parameters : ClientID, pageNumber,PageSize
        /// </remarks>
        /// <param name="objCustomerProfileInputModel"></param>
        /// <returns>NotesDetailsOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<NotesDetailsOutputModel>))]
        [HttpPost]
        [Route("dynamics/customers/notes")] //R3
        public IHttpActionResult GetCRMNotesByCustomers(CustomerProfileInputModel objCustomerProfileInputModel)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            List<NotesDetailsOutputModel> objGetCRMMeetingsByCustomer = UtilityHelper.ProcessException<List<NotesDetailsOutputModel>>(() => _trackerReportingEnterpriseIntegrationFacade.GetNotesbyCustomer(objCustomerProfileInputModel));
            _logger.TraceEnd();
            if (objGetCRMMeetingsByCustomer.Count > 0)
            {
                return Ok(objGetCRMMeetingsByCustomer);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("No CRM Customer Notes Record found for Customer Name: {0}", objCustomerProfileInputModel.Name));

            }

        }

        /// <summary>
        /// Get CRM Meetings based on Customer Details
        /// </summary>
        /// <remarks>
        /// Get CRM Contacts based on Customer Details<br></br>
        /// Required Parameters : Customer Name <br></br>
        /// Optional Parameters : ClientID, pageNumber,PageSize
        /// </remarks>
        /// <param name="objCustomerProfileInputModel"></param>
        /// <returns>MeetingDetailsCRMOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<MeetingDetailsInfoOutputModel>))]
        [HttpPost]
        [Route("dynamics/customers/appointments")]  // R3
        public IHttpActionResult GetCRMMeetingByCustomer(CustomerProfileInputModel objCustomerProfileInputModel)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }

            List<MeetingDetailsInfoOutputModel> objGetCRMMeetingsByCustomer = UtilityHelper.ProcessException<List<MeetingDetailsInfoOutputModel>>(() => _trackerReportingEnterpriseIntegrationFacade.GetMeetingbyCustomer(objCustomerProfileInputModel));
            _logger.TraceEnd();
            if (objGetCRMMeetingsByCustomer.Count > 0 && objGetCRMMeetingsByCustomer != null)
            {
                return Ok(objGetCRMMeetingsByCustomer);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("No CRM Customer Meeting Record found for Customer Name: {0}", objCustomerProfileInputModel.Name));
            }

        }


        /// <summary>
        ///  Get Policies Target Details.
        /// </summary>
        /// <remarks>
        ///  Get Policies Target Details.<br></br>
        ///  Required Parameters : user ID <br></br>        
        /// </remarks>
        /// <param name="UserID"></param> 
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<PoliciesTargetsOutputModel>))]
        [HttpGet]
        [Route("policies/targets")]
        public IHttpActionResult GetPoliciesTarget(string UserID)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }

            List<PoliciesTargetsOutputModel> objGetPoliciesTarget = UtilityHelper.ProcessException<List<PoliciesTargetsOutputModel>>(() => _trackerReportingFacade.GetPoliciesTarget(UserID));
            _logger.TraceEnd();
            if (objGetPoliciesTarget.Count > 0 && objGetPoliciesTarget != null)
            {
                return Ok(objGetPoliciesTarget);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Policies Target details are found for the User ID: {0}", UserID));
            }

        }

        /// <summary>
        /// Exlude Insured Summary Details.
        /// </summary>
        /// <remarks>
        /// Exlude Insured Summary Details.<br></br>
        /// Required Fields : ClientID,Record No<br></br>      
        /// </remarks>      
        /// <param name="objInsuredSummaryExludeAccountsInputModel"></param>         
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("insured/excludesummarydetails")] // R4
        public IHttpActionResult ExcludeInsuredSummaryDetails(InsuredSummaryExludeAccountsInputModel objInsuredSummaryExludeAccountsInputModel)
        {

            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }

            string objOutputModel = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.ExcludeInsuredSummaryDetails(objInsuredSummaryExludeAccountsInputModel));

            _logger.TraceEnd();
            if (objOutputModel != null)
            {
                return Ok(objOutputModel);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientID: {0}", objInsuredSummaryExludeAccountsInputModel.ClientID));
            }

        }

        /// <summary>
        /// Include Insured Summary Details.
        /// </summary>
        /// <remarks>
        /// Include Insured Summary Details.<br></br>
        /// Required Fields : ClientID,Record No<br></br>      
        /// </remarks>                          
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("insured/includesummarydetails")] // R4
        public IHttpActionResult IncludeInsuredSummaryDetails(string ClientID, List<string> RecordNo)
        {

            _logger.TraceStart();
            string objOutputModel = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.IncludeInsuredSummaryDetails(ClientID, RecordNo));

            _logger.TraceEnd();
            if (objOutputModel != null)
            {
                return Ok(objOutputModel);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientID: {0}", ClientID));
            }

        }


        /// <summary>
        ///  Get Insured DNB search details.
        /// </summary>
        /// <remarks>
        /// Get Insured DNB search details.<br></br>
        ///  Required Parameters : Client ID <br></br>        
        /// </remarks>
        /// <param name="ClientID"></param> 
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<InsuredDNBSearchOutputModel>))]
        [HttpGet]
        [Route("insured/dnbdetails")]//R4
        public IHttpActionResult GetInsuredDNBDetails(string ClientID)
        {
            _logger.TraceStart();
            if ((String.IsNullOrEmpty(ClientID)))
            {
                return Content(HttpStatusCode.NotFound, String.Format("Invalid Client ID"));
            }

            List<InsuredDNBSearchOutputModel> objGetInsuredDNBDetails = UtilityHelper.ProcessException<List<InsuredDNBSearchOutputModel>>(() => _trackerReportingFacade.GetInsuredDNBDetails(ClientID));
            _logger.TraceEnd();
            if (objGetInsuredDNBDetails.Count > 0 && objGetInsuredDNBDetails != null)
            {
                return Ok(objGetInsuredDNBDetails);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Insured DNB Search  details are found for the Client ID: {0}", ClientID));
            }

        }

        /// <summary>
        ///  Get DNB Hierarchy search details.
        /// </summary>
        /// <remarks>
        /// Get DNB Hierarchy search details.<br></br>
        ///  Required Parameters : DunsNo  <br></br>        
        /// </remarks>
        /// <param name="DunsNo"></param> 
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DNBHierarchySearchOutputModel>))]
        [HttpGet]
        [Route("insured/dnbhierarchysearch")]//R4
        public IHttpActionResult GetInsuredDNBHierarchySearch(string DunsNo)
        {
            _logger.TraceStart();
            if ((String.IsNullOrEmpty(DunsNo)))
            {
                return Content(HttpStatusCode.NotFound, String.Format("Invalid DunsNo "));
            }

            List<DNBHierarchySearchOutputModel> objGetInsuredDNBHierarchySearch = UtilityHelper.ProcessException<List<DNBHierarchySearchOutputModel>>(() => _trackerReportingFacade.GetInsuredDNBHierarchySearch(DunsNo));
            _logger.TraceEnd();
            if (objGetInsuredDNBHierarchySearch.Count > 0 && objGetInsuredDNBHierarchySearch != null)
            {
                return Ok(objGetInsuredDNBHierarchySearch);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Insured DNB Hierarchy Search  details are found for the DunsNo : {0}", DunsNo));
            }

        }

        /// <summary>
        /// Update Insured Information Details.
        /// </summary>
        /// <remarks>
        /// Update Insured Information Details.<br></br>
        /// Required Fields : ClientID, UserId (UpdatedBy)<br></br>      
        /// </remarks>      
        /// <param name="objUpdateInsuredInputModel"></param>                
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("insured/updateinsuredinformation")] // R4
        public IHttpActionResult UpdateInsuredInformation(UpdateInsuredInputModel objUpdateInsuredInputModel)
        {

            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            string objOutputModel = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.UpdateInsuredInformation(objUpdateInsuredInputModel));

            _logger.TraceEnd();
            if (objOutputModel != null)
            {
                return Ok(objOutputModel);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientID: {0}", objUpdateInsuredInputModel.ClientID));
            }

        }


        /// <summary>
        /// Get Exclude Current Business Account  details.
        /// </summary>
        /// <remarks>
        ///Get Exclude Current Business Account details..<br></br>
        /// Required Fields : ClientID<br></br>
        /// </remarks>      
        /// <param name="ClientID"></param>
        /// <returns>InsuredSummary</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(InsuredCurrentInforceMappingOutputModel))]
        [HttpPost]
        [Route("insured/viewexcludecurrentbusinessaccounts")] // R4
        public IHttpActionResult GetExcludeCurrentBusinessAccounts(int ClientID)
        {
            if (ClientID.ToString().Length > 4)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();
            List<InsuredCurrentInforceMappingOutputModel> objGetExcludeCurrentBusinessAccounts = UtilityHelper.ProcessException<List<InsuredCurrentInforceMappingOutputModel>>(() => _trackerReportingFacade.GetExcludeCurrentBusinessAccounts(ClientID));
            _logger.TraceEnd();
            if (objGetExcludeCurrentBusinessAccounts.Count > 0 && objGetExcludeCurrentBusinessAccounts != null)
            {
                return Ok(objGetExcludeCurrentBusinessAccounts);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientID: {0}", ClientID));
            }
        }

        /// <summary>
        /// Get Exclude Lost Decline Business Account  details.
        /// </summary>
        /// <remarks>
        ///Get Exclude Lost Decline Business Account details..<br></br>
        /// Required Fields : ClientID<br></br>
        /// </remarks>      
        /// <param name="ClientID"></param>
        /// <returns>InsuredSummary</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(InsuredCurrentInforceMappingOutputModel))]
        [HttpPost]
        [Route("insurd/viewexcludelostdeclinedbusinessaccounts")] // R4
        public IHttpActionResult GetExcludeLostDeclinedBusinessAccounts(int ClientID)
        {
            if (ClientID.ToString().Length > 4)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            _logger.TraceStart();

            List<InsuredCurrentInforceMappingOutputModel> objGetExcludeLostDeclinedBusinessAccounts = UtilityHelper.ProcessException<List<InsuredCurrentInforceMappingOutputModel>>(() => _trackerReportingFacade.GetExcludeLostDeclinedBusinessAccounts(ClientID));
            _logger.TraceEnd();
            if (objGetExcludeLostDeclinedBusinessAccounts.Count > 0 && objGetExcludeLostDeclinedBusinessAccounts != null)
            {
                return Ok(objGetExcludeLostDeclinedBusinessAccounts);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientID: {0}", ClientID));
            }
        }

        /// <summary>
        ///  Get Policies Target Details.
        /// </summary>
        /// <remarks>
        ///  Get Policies Target Details.<br></br>
        ///  Required Parameters : Record GUID <br></br>        
        /// </remarks>
        /// <param name="RecordGUID"></param> 
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<PoliciesTargetDetailsOutputModel>))]
        [HttpGet]
        [Route("policies/targetdetails")]
        public IHttpActionResult GetPoliciesTargetdetails(string RecordGUID)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }

            List<PoliciesTargetDetailsOutputModel> objGetPoliciesTargetdetails = UtilityHelper.ProcessException<List<PoliciesTargetDetailsOutputModel>>(() => _trackerReportingFacade.GetPoliciesTargetdetails(RecordGUID));
            _logger.TraceEnd();
            if (objGetPoliciesTargetdetails.Count > 0 && objGetPoliciesTargetdetails != null)
            {
                return Ok(objGetPoliciesTargetdetails);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Policies Target details are found for the User ID: {0}", RecordGUID));
            }

        }

        /// <summary>
        /// Load data for Insured Account Type
        /// </summary>
        /// <remarks>
        /// Load data for Insured Account Type
        /// </remarks>        
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpGet]
        [Route("filters/insuredaccounttype")]  // R5
        public IHttpActionResult GetInsuredAccountType()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetInsuredAccountType());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No data found for Insured Account Type");
            }
        }

        /// <summary>
        /// Load data for Insured Duns Number
        /// </summary>
        /// <remarks>
        /// Load data for Insured Duns Number<br></br>
        /// Optional Parameters : AccountType, CustomerName.
        /// </remarks>        
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/insureddunsnumber")]  // R5
        public IHttpActionResult GetInsuredDunsNumber(InsuredDunsNumberInputModel InsuredDunsNumberInputModel)
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetInsuredDunsNumber(InsuredDunsNumberInputModel));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No data found for Insured Duns Number");
            }
        }

        /// <summary>
        /// Quick Export file as either PDF or Excel (.xlsx) based on the request.
        /// </summary>
        /// <param name="trackingReportingCommonFilterInputModel"></param>
        /// <remarks>
        /// Required Fields : UserID, AccountMonth, AccountYear,TimeFrame,ReportName,ExportType<br></br>
        /// ReportName parameter : Need to pass Forecast Division or Forecast Region or Scorecard value  <br></br>
        /// ExportType parameter : Need to pass Excel or Pdf  
        /// </remarks>
        /// <response code="200">Record found</response>
        /// <response code="204">Record not found</response>
        /// <returns></returns>
        [HttpPost]
        [Route("reports/quickexport")]
        public IHttpActionResult GetQuickExportToXcelOrPdf([FromBody]TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            string strFileName = string.Empty;
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
            || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.ExportType)
            || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.ExportType))
                    return Content(HttpStatusCode.BadRequest, "ExportType not passed for the request");
            }

            _logger.TraceStart();
            IHttpActionResult response;
            HttpResponseMessage httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK);
            trackingReportingCommonFilterInputModel.ExportType = trackingReportingCommonFilterInputModel.ExportType.ToLower();

            if (trackingReportingCommonFilterInputModel.ExportType == "excel")
            {
                string outputFilePath = _trackerReportingFacade.GetQuickXcelExport(trackingReportingCommonFilterInputModel);
                _logger.TraceEnd();
                if (outputFilePath != "")
                {
                    var dataBytes = File.ReadAllBytes(outputFilePath);
                    //adding bytes to memory stream   
                    var dataStream = new MemoryStream(dataBytes);
                    httpResponseMessage.Content = new StreamContent(dataStream);
                    httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
                    httpResponseMessage.Content.Headers.ContentDisposition.FileName = Path.GetFileName(outputFilePath);
                    httpResponseMessage.Content.Headers.ContentType = new MediaTypeHeaderValue("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                }
            }
            else if (trackingReportingCommonFilterInputModel.ExportType == "pdf")
            {
                var trackingReportingGridOutputDataPDF = _trackerReportingFacade.GetQuickPdfExport(trackingReportingCommonFilterInputModel);
                _logger.TraceEnd();

                var dataStream = new System.IO.MemoryStream(trackingReportingGridOutputDataPDF);
                httpResponseMessage.Content = new StreamContent(dataStream);
                httpResponseMessage.Content.Headers.Add("Access-Control-Expose-Headers", "Content-Disposition");
                httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
                httpResponseMessage.Content.Headers.ContentDisposition.FileName = "Report" + DateTime.Now.ToFileTime() + ".pdf"; ;
                httpResponseMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/pdf");
            }
            response = ResponseMessage(httpResponseMessage);

            if (response != null)
            {
                if (strFileName != "") ExcelEngine.DeleteFile(strFileName);
                return response;
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("No Records found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }
        }



        #region ROVExcel
        /// <summary>
        /// Load data for ROV report Excel
        /// </summary>
        /// <remarks>
        /// Load data for ROV report<Br></Br>
        /// Required Parameters : UserID<Br></Br>
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,<Br></Br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.,<Br></Br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <Br></Br>
        /// </remarks>
        /// <param name="loadReportInputModel">ROVInputModel</param>
        /// <returns>ROVoutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ROVOutputModel>))]
        [HttpPost]
        [Route("reports/rovreportexcel")]  // R2
        public IHttpActionResult GetROVReportExcel([FromBody]ROVInputModel loadReportInputModel)
        {
            string strFileName = string.Empty;
            if (String.IsNullOrEmpty(loadReportInputModel.UserID))
            {
                if (String.IsNullOrEmpty(loadReportInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");

            }
            IHttpActionResult response = null;
            _logger.TraceStart();
            var strHTML = _trackerReportingEnterpriseIntegrationFacade.GetROVReportExcel(loadReportInputModel);
            strFileName = strHTML.ToString();
            _logger.TraceEnd();
            if (strFileName != "")
            {
                var httpResponseMessage = new HttpResponseMessage(System.Net.HttpStatusCode.OK);
                var dataBytes = File.ReadAllBytes(strFileName);
                //adding bytes to memory stream   
                var dataStream = new MemoryStream(dataBytes);
                httpResponseMessage.Content = new StreamContent(dataStream);
                httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
                httpResponseMessage.Content.Headers.ContentDisposition.FileName = Path.GetFileName(strFileName);
                httpResponseMessage.Content.Headers.ContentType = new MediaTypeHeaderValue("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

                response = ResponseMessage(httpResponseMessage);
            }

            if (response != null)
            {
                if (strFileName != "") ExcelEngine.DeleteFile(strFileName);
                return response;
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No ROV Record found for the Respective Search Criteria");
            }

        }
        #endregion

        /*
        /// <summary>
        ///  Get Scorecard Growth Mix Details.
        /// </summary>
        /// <remarks>
        /// Get Scorecard Growth Mix Details.<br></br>
        ///  Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame <br></br>        
        /// </remarks>
        /// <param name="GetScorecardGrowthMixInputModel"></param> 
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<GetScorecardGrowthMixOutputModel>))]
        [HttpPost]
        [Route("reports/scorecards/growthmix")]
        public IHttpActionResult GetScorecardGrowthMix(GetScorecardGrowthMixInputModel GetScorecardGrowthMixInputModel)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }

            List<GetScorecardGrowthMixOutputModel> GetScorecardGrowthMix = UtilityHelper.ProcessException<List<GetScorecardGrowthMixOutputModel>>(() => _trackerReportingFacade.GetScorecardGrowthMix(GetScorecardGrowthMixInputModel));
            _logger.TraceEnd();
            if (GetScorecardGrowthMix.Count > 0 && GetScorecardGrowthMix != null)
            {
                return Ok(GetScorecardGrowthMix);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Scorecard Growth Mix Details are found for the User ID"));
            }

        }
        */

        /// <summary>
        ///Producer Profile Common API For Quick Download
        /// </summary>
        /// <remarks>
        /// Required Fields : UserID, AccountMonth, AccountYear,TimeFrame
        /// ReportName parameter :   Need to pass Forecast Division or Forecast Region value   
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>        
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ForecastByBusinessSegmentOutputModel>))]
        [HttpPost]
        [Route("reports/producerprofiledownload")] // R3
        public IHttpActionResult ProducerProfileDownload([FromBody]TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
            || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();
            var httpResponseMessage = new HttpResponseMessage(System.Net.HttpStatusCode.OK);
            IHttpActionResult response;

            var trackingReportingGridOutputData = _trackerReportingFacade.ProducerProfileDownload(trackingReportingCommonFilterInputModel);

            System.IO.StringWriter sw = new System.IO.StringWriter();
            StringBuilder st1 = new StringBuilder();
            foreach (var item in trackingReportingGridOutputData)
            {
                st1.Append(item);
            }

            _logger.TraceEnd();

            sw.WriteLine(st1);

            httpResponseMessage.Content = new StringContent(sw.ToString());
            httpResponseMessage.Content.Headers.Add("Access-Control-Expose-Headers", "Content-Disposition");
            httpResponseMessage.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
            httpResponseMessage.Content.Headers.ContentDisposition.FileName = "Report" + DateTime.Now.ToFileTime() + ".xls";
            httpResponseMessage.Content.Headers.ContentType = new MediaTypeHeaderValue("application/ms-excel");


            response = ResponseMessage(httpResponseMessage);
            if (response != null)
            {
                return response;
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }

        }

        /// <summary>
        /// Quick download for NewBusinessTotal
        /// </summary>
        /// <remarks>
        /// Required Fields : UserID, AccountMonth, AccountYear,TimeFrame        
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>        
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ForecastByBusinessSegmentOutputModel>))]
        [HttpPost]
        [Route("reports/producerprofile/newbusinesstotaldownload")] // R3
        public IHttpActionResult NewBusinessTotalDownload([FromBody]TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
            || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();
            var httpResponseMessage = new HttpResponseMessage(System.Net.HttpStatusCode.OK);
            IHttpActionResult response;

            var trackingReportingGridOutputData = _trackerReportingFacade.GetUWSummaryNewBusinessTotalDownload(trackingReportingCommonFilterInputModel);

            System.IO.StringWriter sw = new System.IO.StringWriter();
            StringBuilder st1 = new StringBuilder();


            _logger.TraceEnd();

            sw.WriteLine(trackingReportingGridOutputData);

            httpResponseMessage.Content = new StringContent(sw.ToString());
            httpResponseMessage.Content.Headers.Add("Access-Control-Expose-Headers", "Content-Disposition");
            httpResponseMessage.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
            httpResponseMessage.Content.Headers.ContentDisposition.FileName = "Report" + DateTime.Now.ToFileTime() + ".xls";
            httpResponseMessage.Content.Headers.ContentType = new MediaTypeHeaderValue("application/ms-excel");


            response = ResponseMessage(httpResponseMessage);
            if (response != null)
            {
                return response;
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }

        }


        /// <summary>
        /// Quick download for RenewalTotal
        /// </summary>
        /// <remarks>
        /// Required Fields : UserID, AccountMonth, AccountYear,TimeFrame<br></br>
        /// TopCarrier refers to Incumbent field
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>        
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ForecastByBusinessSegmentOutputModel>))]
        [HttpPost]
        [Route("reports/producerprofile/renewaltotaldownload")] // R3
        public IHttpActionResult UWSummaryRenewalTotalDownload([FromBody]TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
            || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();
            var httpResponseMessage = new HttpResponseMessage(System.Net.HttpStatusCode.OK);
            IHttpActionResult response;

            var trackingReportingGridOutputData = _trackerReportingFacade.GetUWSummaryRenewalTotalDownload(trackingReportingCommonFilterInputModel);

            System.IO.StringWriter sw = new System.IO.StringWriter();
            StringBuilder st1 = new StringBuilder();


            _logger.TraceEnd();

            sw.WriteLine(trackingReportingGridOutputData);

            httpResponseMessage.Content = new StringContent(sw.ToString());
            httpResponseMessage.Content.Headers.Add("Access-Control-Expose-Headers", "Content-Disposition");
            httpResponseMessage.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
            httpResponseMessage.Content.Headers.ContentDisposition.FileName = "Report" + DateTime.Now.ToFileTime() + ".xls";
            httpResponseMessage.Content.Headers.ContentType = new MediaTypeHeaderValue("application/ms-excel");


            response = ResponseMessage(httpResponseMessage);
            if (response != null)
            {
                return response;
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }

        }

        /// <summary>
        /// Quick download for TotalForecastTotal 
        /// </summary>
        /// <remarks>
        /// Required Fields : UserID, AccountMonth, AccountYear,TimeFrame         
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>        
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ForecastByBusinessSegmentOutputModel>))]
        [HttpPost]
        [Route("reports/producerprofile/totalforecasttotaldownload")] // R3
        public IHttpActionResult UWSummaryTotalForecastTotalDownload([FromBody]TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
            || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();
            var httpResponseMessage = new HttpResponseMessage(System.Net.HttpStatusCode.OK);
            IHttpActionResult response;

            var trackingReportingGridOutputData = _trackerReportingFacade.GetUWSummaryTotalForecastTotalDownload(trackingReportingCommonFilterInputModel);

            System.IO.StringWriter sw = new System.IO.StringWriter();
            StringBuilder st1 = new StringBuilder();


            _logger.TraceEnd();

            sw.WriteLine(trackingReportingGridOutputData);

            httpResponseMessage.Content = new StringContent(sw.ToString());
            httpResponseMessage.Content.Headers.Add("Access-Control-Expose-Headers", "Content-Disposition");
            httpResponseMessage.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
            httpResponseMessage.Content.Headers.ContentDisposition.FileName = "Report" + DateTime.Now.ToFileTime() + ".xls";
            httpResponseMessage.Content.Headers.ContentType = new MediaTypeHeaderValue("application/ms-excel");


            response = ResponseMessage(httpResponseMessage);
            if (response != null)
            {
                return response;
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }

        }

        /// <summary>
        /// Update Insured Current Inforce Comments Details.
        /// </summary>
        /// <remarks>
        /// Update Insured Current Inforce Comments Details.<br></br>
        /// Required Fields : ClientID,Comments<br></br>      
        /// </remarks>      
        /// <param name="ClientID"></param>   
        /// <param name="Comments"></param>    
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("insured/updatecurrentinforcecomments")] // R4
        public IHttpActionResult UpdateInsuredCurrentInforceComments(int ClientID, String Comments)
        {
            if (String.IsNullOrEmpty(ClientID.ToString()))
            {
                return Content(HttpStatusCode.BadRequest, "Invalid Client ID");
            }
            _logger.TraceStart();
            string objOutputModel = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.UpdateInsuredSummaryComments(ClientID, Comments, 'C'));

            _logger.TraceEnd();
            if (objOutputModel != null)
            {
                return Ok(objOutputModel);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientID: {0}", ClientID));
            }

        }

        /// <summary>
        /// Update Insured Target Summary Comments Details.
        /// </summary>
        /// <remarks>
        /// Update Insured Target Summary Comments Details.<br></br>
        /// Required Fields : ClientID,Comments<br></br>      
        /// </remarks>      
        /// <param name="ClientID"></param>   
        /// <param name="Comments"></param>    
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("insured/updatetargetsummarycomments")] // R4
        public IHttpActionResult UpdateInsuredTargetSummaryComments(int ClientID, String Comments)
        {
            if (String.IsNullOrEmpty(ClientID.ToString()))
            {
                return Content(HttpStatusCode.BadRequest, "Invalid Client ID");
            }
            _logger.TraceStart();
            string objOutputModel = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.UpdateInsuredSummaryComments(ClientID, Comments, 'T'));

            _logger.TraceEnd();
            if (objOutputModel != null)
            {
                return Ok(objOutputModel);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientID: {0}", ClientID));
            }

        }

        /// <summary>
        /// Update Insured Lost Declined Comments Details.
        /// </summary>
        /// <remarks>
        /// Update Insured Lost Declined Comments Details.<br></br>
        /// Required Fields : ClientID,Comments<br></br>      
        /// </remarks>      
        /// <param name="ClientID"></param>   
        /// <param name="Comments"></param>    
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("insured/updatelostdeclinedcomments")] // R4
        public IHttpActionResult UpdateInsuredLostDeclinedComments(int ClientID, String Comments)
        {
            if (String.IsNullOrEmpty(ClientID.ToString()))
            {
                return Content(HttpStatusCode.BadRequest, "Invalid Client ID");
            }
            _logger.TraceStart();
            string objOutputModel = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.UpdateInsuredSummaryComments(ClientID, Comments, 'L'));

            _logger.TraceEnd();
            if (objOutputModel != null)
            {
                return Ok(objOutputModel);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for ClientID: {0}", ClientID));
            }

        }

        /// <summary>
        /// Load Ownerbranch based on Ownerregion
        /// </summary>
        /// <remarks>
        /// Load data for Owner Branch filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/ownerbranch")]  // R2
        public IHttpActionResult GetOwnerBranchFilter([FromBody]List<string> Region)
        {

            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetOwnerBranchFilter(Region));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for Credited Region filter control");
            }
        }

        /// <summary>
        /// Load data for Owner Branch filter control
        /// <response code="200">Record found</response>
        /// <response code="204">Record not found</response>
        /// </summary>
        /// <returns></returns>
        [ResponseType(typeof(IEnumerable<CreditedRegionBranchOutputModel>))]
        [HttpPost]
        [Route("filters/ownerregionbranch")]
        public IHttpActionResult GetOwnerRegionBranchFilters()
        {

            _logger.TraceStart();
            List<CreditedRegionBranchOutputModel> ownerRegionBranchOutputValues = UtilityHelper.ProcessException<List<CreditedRegionBranchOutputModel>>(() => _trackerReportingFacade.GetOwnerRegionBranchFilters());
            _logger.TraceEnd();
            if (ownerRegionBranchOutputValues != null && ownerRegionBranchOutputValues.Count > 0)
            {
                return Ok(ownerRegionBranchOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, "No Load data for Credited Region filter control");
            }
        }


        /// <summary>
        ///  Get Customer Profile Information Details.
        /// </summary>
        /// <remarks>
        /// Get Customer Profile Information Details.<br></br>              
        /// </remarks>
        /// <param name="GetCustomerProfileInformationDetailsInputModel"></param> 
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<GetCustomerProfileInformationDetailsOutputModel>))]
        [HttpPost]
        [Route("reports/customers")]
        public IHttpActionResult GetCustomerProfileInformationDetails(GetCustomerProfileInformationDetailsInputModel GetCustomerProfileInformationDetailsInputModel)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }

            List<GetCustomerProfileInformationDetailsOutputModel> GetCustomerProfileInformationDetails = UtilityHelper.ProcessException<List<GetCustomerProfileInformationDetailsOutputModel>>(() => _trackerReportingFacade.GetCustomerProfileInformationDetails(GetCustomerProfileInformationDetailsInputModel));
            _logger.TraceEnd();
            if (GetCustomerProfileInformationDetails.Count > 0 && GetCustomerProfileInformationDetails != null)
            {
                return Ok(GetCustomerProfileInformationDetails);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Customer Profile Information Details are found"));
            }

        }

        /// <summary>
        ///  Get Net Scorecard by Division.
        /// </summary>
        /// <remarks>
        ///  Get Net Scorecard by Division.<br></br>
        ///  Required Parameters :UserID, AccountMonth, AccountYear, TimeFrame <br></br>        
        /// </remarks>
        /// <param name="GetNetScorecardbyDivisionInputModel"></param> 
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<GetNetScorecardbyDivisionOutputModel>))]
        [HttpPost]
        [Route("reports/scorecards/netscorecardbydivision")]  //R5
        public IHttpActionResult GetNetScorecardbyDivision(GetNetScorecardbyDivisionInputModel GetNetScorecardbyDivisionInputModel)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }

            List<GetNetScorecardbyDivisionOutputModel> GetNetScorecardbyDivision = UtilityHelper.ProcessException<List<GetNetScorecardbyDivisionOutputModel>>(() => _trackerReportingFacade.GetNetScorecardbyDivision(GetNetScorecardbyDivisionInputModel));
            _logger.TraceEnd();
            if (GetNetScorecardbyDivision.Count > 0 && GetNetScorecardbyDivision != null)
            {
                return Ok(GetNetScorecardbyDivision);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Net Scorecard by Division details are found for the User ID"));
            }

        }

        /// <summary>
        ///  Get Net Scorecard by Region.(ScreenName: Net Scorecard)
        /// </summary>
        /// <remarks>
        ///  Get Net Scorecard by Region.<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>        
        /// </remarks>
        /// <param name="GetNetScorecardbyDivisionInputModel"></param> 
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<GetNetScorecardbyRegionOutputModel>))]
        [HttpPost]
        [Route("reports/scorecards/netscorecardbyregion")]  //R5
        public IHttpActionResult GetNetScorecardbyRegion(GetNetScorecardbyDivisionInputModel GetNetScorecardbyDivisionInputModel)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }

            List<GetNetScorecardbyRegionOutputModel> GetNetScorecardbyRegion = UtilityHelper.ProcessException<List<GetNetScorecardbyRegionOutputModel>>(() => _trackerReportingFacade.GetNetScorecardbyRegion(GetNetScorecardbyDivisionInputModel));
            _logger.TraceEnd();
            if (GetNetScorecardbyRegion.Count > 0 && GetNetScorecardbyRegion != null)
            {
                return Ok(GetNetScorecardbyRegion);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Net Scorecard by Region details are found for the User ID"));
            }

        }
        /*
        /// <summary>
        ///  Get Home Office Margin by percentage(ScreenName: HomeOffice By %)
        /// </summary>
        /// <remarks>
        ///  Get Home Office Margin by percentage.<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>           
        /// </remarks>
        /// <param name="GetHomeOfficeMarginInputModel"></param> 
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<GetHomeOfficeMarginbypercentageOutputModel>))]
        [HttpPost]
        [Route("reports/scorecards/HomeOfficeMarginbyPercentage")]  //R5
        public IHttpActionResult GetHomeOfficeMarginbypercentage(GetHomeOfficeMarginInputModel GetHomeOfficeMarginInputModel)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }

            List<GetHomeOfficeMarginbypercentageOutputModel> GetHomeOfficeMarginbypercentage = UtilityHelper.ProcessException<List<GetHomeOfficeMarginbypercentageOutputModel>>(() => _trackerReportingFacade.GetHomeOfficeMarginbypercentage(GetHomeOfficeMarginInputModel));
            _logger.TraceEnd();
            if (GetHomeOfficeMarginbypercentage.Count > 0 && GetHomeOfficeMarginbypercentage != null)
            {
                return Ok(GetHomeOfficeMarginbypercentage);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Home Office Margin by percentage details are found for the User ID"));
            }

        }


        /// <summary>
        ///  Get Home Office Margin by Currency(ScreenName: HomeOffice)
        /// </summary>
        /// <remarks>
        ///  Get Home Office Margin by Currency.<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>     
        /// </remarks>
        /// <param name="GetHomeOfficeMarginInputModel"></param> 
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<GetHomeOfficeMarginbyCurrencyOutputModel>))]
        [HttpPost]
        [Route("reports/scorecards/HomeOfficeMarginbyCurrency")]  //R5
        public IHttpActionResult GetHomeOfficeMarginbyCurrency(GetHomeOfficeMarginInputModel GetHomeOfficeMarginInputModel)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }

            List<GetHomeOfficeMarginbyCurrencyOutputModel> GetHomeOfficeMarginbyCurrency = UtilityHelper.ProcessException<List<GetHomeOfficeMarginbyCurrencyOutputModel>>(() => _trackerReportingFacade.GetHomeOfficeMarginbyCurrency(GetHomeOfficeMarginInputModel));
            _logger.TraceEnd();
            if (GetHomeOfficeMarginbyCurrency.Count > 0 && GetHomeOfficeMarginbyCurrency != null)
            {
                return Ok(GetHomeOfficeMarginbyCurrency);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Home Office Margin by Currency details are found for the User ID"));
            }

        }
        */

        /// <summary>
        /// Quick download PDF for  Forecast by Division And RegionSummary(ScreenName: QuickDownload PDF)
        /// </summary>
        /// <remarks>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame,ReportName<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>
        /// ReportName parameter :  Need to pass Forecast Division or Forecast Region value  
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>        
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>        
        [HttpPost]
        [Route("reports/quickexport/pdf")] // R5
        public IHttpActionResult ForecastDivisionAndRegionDownloadPDF([FromBody]TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
            || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();
            IHttpActionResult response;

            var trackingReportingGridOutputData = _trackerReportingFacade.GetQuickPdfExport(trackingReportingCommonFilterInputModel);
            _logger.TraceEnd();

            var dataStream = new System.IO.MemoryStream(trackingReportingGridOutputData);

            HttpResponseMessage httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK);
            httpResponseMessage.Content = new StreamContent(dataStream);
            httpResponseMessage.Content.Headers.Add("Access-Control-Expose-Headers", "Content-Disposition");
            httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
            httpResponseMessage.Content.Headers.ContentDisposition.FileName = "Report" + DateTime.Now.ToFileTime() + ".pdf"; ;
            httpResponseMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/pdf");

            response = ResponseMessage(httpResponseMessage);
            if (response != null)
            {
                return response;
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }

        }

        /// <summary>
        /// Quick download for Scorecard based on NewBusiness,Renewals,Forecasts.Summary(ScreenName: QuickDownload Scorecard)
        /// </summary>
        /// <remarks>
        /// Required Parameters : UserID, ScrenId, AccountMonth, AccountYear, TimeFrame.<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12"          
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>  
        /// <returns>ScorecardAmountPerDivionOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ScorecardByStatusOutputModel>))]
        [HttpPost]
        [Route("reports/quickexportscorecard/excel")] // R3
        public IHttpActionResult ScorecardDownload([FromBody]TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
              || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();
            var httpResponseMessage = new HttpResponseMessage(System.Net.HttpStatusCode.OK);
            IHttpActionResult response;

            var trackingReportingGridOutputData = _trackerReportingFacade.GetScorecardDownload(trackingReportingCommonFilterInputModel);
            _logger.TraceEnd();

            System.IO.StringWriter sw = new System.IO.StringWriter();
            StringBuilder st1 = new StringBuilder();
            foreach (var item in trackingReportingGridOutputData)
            {
                st1.Append(item);
            }

            _logger.TraceEnd();

            sw.WriteLine(st1);

            httpResponseMessage.Content = new StringContent(sw.ToString());
            httpResponseMessage.Content.Headers.Add("Access-Control-Expose-Headers", "Content-Disposition");
            httpResponseMessage.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
            httpResponseMessage.Content.Headers.ContentDisposition.FileName = "Report" + DateTime.Now.ToFileTime() + ".xls";
            httpResponseMessage.Content.Headers.ContentType = new MediaTypeHeaderValue("application/ms-excel");


            response = ResponseMessage(httpResponseMessage);
            if (response != null)
            {
                return response;
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }


        }


        /// <summary>
        /// Customer word document download Summary(ScreenName: Word Document)
        /// </summary>
        /// <remarks>
        /// </remarks>
        /// <returns>HttpResponseMessage</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>

        [HttpPost]
        [Route("reports/customerprofile/download")]
        public IHttpActionResult ExportCustomerDocument(CustomerProfileDownloadInput objcustomerProfileDownloadInput)
        {

            IHttpActionResult response = null;
            _logger.TraceStart();
            var ExportCustomerPDF = _trackerReportingFacade.ExportCustomerDocument(objcustomerProfileDownloadInput.ClientID);

            _logger.TraceEnd();

            var httpResponseMessage = new HttpResponseMessage(System.Net.HttpStatusCode.OK);
            //Commented to convert to PDF document
            //System.IO.StringWriter sw = new System.IO.StringWriter();
            //sw.WriteLine(strHTML);

            //httpResponseMessage.Content = new StringContent(sw.ToString());
            //httpResponseMessage.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");

            ////string attachment = "attachment;line;filename=CustomerProfile.doc;";

            //httpResponseMessage.Content.Headers.ContentDisposition.FileName = "CustomerProfile" + DateTime.Now.ToFileTime() + ".doc";
            //// httpResponseMessage.Content.Headers.ContentType = new MediaTypeHeaderValue("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            //httpResponseMessage.StatusCode = System.Net.HttpStatusCode.OK;
            //response = ResponseMessage(httpResponseMessage);

            var dataStream = new System.IO.MemoryStream(ExportCustomerPDF);
            httpResponseMessage.Content = new StreamContent(dataStream);
            httpResponseMessage.Content.Headers.Add("Access-Control-Expose-Headers", "Content-Disposition");
            httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
            httpResponseMessage.Content.Headers.ContentDisposition.FileName = "Report" + DateTime.Now.ToFileTime() + ".pdf"; ;
            httpResponseMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/pdf");
            httpResponseMessage.StatusCode = System.Net.HttpStatusCode.OK;
            response = ResponseMessage(httpResponseMessage);

            if (response != null)
            {
                return response;
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Records found for UserID:"));
            }

        }



        /// <summary>
        /// Load data for Bulk Update screen (ScreenName: Bulk Update)
        /// </summary>
        /// <remarks>
        /// Load data for Bulk Update report<Br></Br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<Br></Br>
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,<Br></Br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.,<Br></Br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <Br></Br>
        /// If user choose EffectiveDate /Expiration Date/CreateDate/BoundDate value. They need to pass the Datefilter flag for the Respective Filter value <br></br>
        /// DateFilterFlag  - EFFDATE, EXPDATE, CREDATE, BOUNDDATE<br></br>
        /// EquityType value: ('Private Equity' or 'Non-Private Equity')<br></br>
        /// If you choose Chubb industry value . SICTYPE Value - Need to pass  one of the  Mandatory value ("Risk SIC" or "DNB SIC" )<br></br>
        /// </remarks>
        /// <param name="bulkUpdateLoadInputModel">BulkUpdateLoadInputModel</param>
        /// <returns>BulkUpdateLoad</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<BulkUpdateLoad>))]
        [HttpPost]
        [Route("reports/bulkupdateload")]  // R2
        public IHttpActionResult GetBulkUpdateLoad(BulkUpdateLoadInputModel bulkUpdateLoadInputModel)
        {
            if (String.IsNullOrEmpty(bulkUpdateLoadInputModel.UserID))
            {
                if (String.IsNullOrEmpty(bulkUpdateLoadInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");

            }
            _logger.TraceStart();
            List<BulkUpdateLoad> bulkupdateload = UtilityHelper.ProcessException<List<BulkUpdateLoad>>(() => _trackerReportingFacade.GetBulkUpdateLoad(bulkUpdateLoadInputModel));
            _logger.TraceEnd();
            if (bulkupdateload != null && bulkupdateload.Count >= 1)
            {
                //var response = new HttpResponseMessage();
                //response.Headers.Add("HeaderValue", "TestValue");
                //response.Content
                //return new ResponseMessageResult(response);
                return Ok(bulkupdateload);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("No Records found for UserID: {0}", bulkUpdateLoadInputModel.UserID));
            }

        }

        [ResponseType(typeof(int))]
        [HttpPost]
        [Route("transaction/delete")]
        public IHttpActionResult DeleteTransactionByRecordNo(TransactionInputModel transactionInputModel)
        {
            if (String.IsNullOrEmpty(Convert.ToString(transactionInputModel.RecordNo)) || String.IsNullOrEmpty(transactionInputModel.UserID))
            {
                if (String.IsNullOrEmpty(Convert.ToString(transactionInputModel.RecordNo)))
                    return Content(HttpStatusCode.BadRequest, "Record No not passed for the request");
                if (String.IsNullOrEmpty(transactionInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
            }
            _logger.TraceStart();
            int result = 0;
            result = UtilityHelper.ProcessException<int>(() => _trackerReportingFacade.DeleteTransactionByRecordNo(transactionInputModel));
            _logger.TraceEnd();
            if (result > 0)
            {
                return Ok(result);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("Record not deleted for given Record No : {0}", transactionInputModel.RecordNo));
            }
        }

        [ResponseType(typeof(int))]
        [HttpPost]
        [Route("transaction/copysubmission")]
        public IHttpActionResult CopyTransactionByRecordNo(TransactionInputModel transactionInputModel)
        {
            if (String.IsNullOrEmpty(Convert.ToString(transactionInputModel.RecordNo)))
            {
                if (String.IsNullOrEmpty(Convert.ToString(transactionInputModel.RecordNo)))
                    return Content(HttpStatusCode.BadRequest, "Record No not passed for the request");
            }
            _logger.TraceStart();
            int result = 0;
            result = UtilityHelper.ProcessException<int>(() => _trackerReportingFacade.CopyTransactionByRecordNo(transactionInputModel));
            _logger.TraceEnd();
            if (result > 0)
            {
                return Ok(result);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("Record not copied for given Record No : {0}", transactionInputModel.RecordNo));
            }
        }

        [ResponseType(typeof(int))]
        [HttpPost]
        [Route("transaction/copylinkedsubmission")]
        public IHttpActionResult CopyLinkedSubmissionTransactionByRecordNo(TransactionInputModel transactionInputModel)
        {
            if (String.IsNullOrEmpty(Convert.ToString(transactionInputModel.RecordNo)))
            {
                if (String.IsNullOrEmpty(Convert.ToString(transactionInputModel.RecordNo)))
                    return Content(HttpStatusCode.BadRequest, "Record No not passed for the request");
            }
            _logger.TraceStart();
            int result = 0;
            result = UtilityHelper.ProcessException<int>(() => _trackerReportingFacade.CopyLinkedSubmissionTransactionByRecordNo(transactionInputModel));
            _logger.TraceEnd();
            if (result > 0)
            {
                return Ok(result);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("Record not copied for given Record No : {0}", transactionInputModel.RecordNo));
            }
        }

        [ResponseType(typeof(int))]
        [HttpPost]
        [Route("transaction/nextterm")]
        public IHttpActionResult MoveToNextTermByRecordNo(PostMortemUpdateInputModel portMortemUpdateInputModel)
        {
            if (String.IsNullOrEmpty(Convert.ToString(portMortemUpdateInputModel.RecordNo)) || String.IsNullOrEmpty(portMortemUpdateInputModel.LoginName))
            {
                if (String.IsNullOrEmpty(Convert.ToString(portMortemUpdateInputModel.RecordNo)))
                    return Content(HttpStatusCode.BadRequest, "Record No not passed for the request");
                if (String.IsNullOrEmpty(portMortemUpdateInputModel.LoginName))
                    return Content(HttpStatusCode.BadRequest, "Login Name not passed for the request");
            }
            _logger.TraceStart();
            int result = 0;
            result = UtilityHelper.ProcessException<int>(() => _trackerReportingFacade.MoveToNextTermByRecordNo(portMortemUpdateInputModel));
            _logger.TraceEnd();
            if (result > 0)
            {
                return Ok(result);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("Record not deleted for given Record No : {0}", portMortemUpdateInputModel.RecordNo));
            }
        }

        /// <summary>
        /// Bulk Update Save Api (ScreenName: Bulk Update)
        /// </summary>
        /// <remarks>
        /// Bulk Update Save Api<Br></Br>
        /// Required Parameters : Record Number<Br></Br>
        /// If Repsonse Body has "1" , consider records are successfully updated
        /// </remarks>
        /// <param name="bulkUpdateSave">BulkUpdateSave</param>
        /// <returns></returns>
        /// <response code="200">Record found</response>
        /// 2
        [ResponseType(typeof(int))]
        [HttpPost]
        [Route("reports/bulkupdatesave")]  // R2
        public IHttpActionResult GetBulkUpdateSave(BulkUpdateSave bulkUpdateSave)
        {

            _logger.TraceStart();
            int result = 0;
            result = UtilityHelper.ProcessException<int>(() => _trackerReportingFacade.GetBulkUpdateSave(bulkUpdateSave));
            _logger.TraceEnd();
            if (result > 0)
            {
                return Ok(result);
                //return Content(HttpStatusCode.NoContent, String.Format("Records are updated"));
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("Records are not updated"));
            }

        }


        #region Advanced Sort

        /// <summary>
        /// Get Advanced Sort for detail Report (ScreenName: Advanced Sort)
        /// </summary>
        /// <remarks>
        /// <b>Summary :</b>Get uAdvanced Sort for detail Report<br></br>
        /// <b>Purpose :</b>This API serves purpose to return Advanced Sort for detail Report.
        /// </remarks>
        /// <response code="200">Record Found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/{SortReportName}/advancesort")]
        //[Route("advancesort")]
        public IHttpActionResult GetAdvanceSort(string SortReportName)
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetAdvanceSort(SortReportName));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No data found for Sort control");
            }
        }
        #endregion

        #region HelpFile

        /// <summary>
        ///  Get Help File Details.
        /// </summary>
        /// <remarks>
        ///  Get Help File Details.<br></br>
        ///  Required Parameters : user ID <br></br>        
        /// </remarks>
        /// <param name="UserID"></param> 
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<HelpOutputValues>))]
        [HttpPost]
        [Route("help")]
        public IHttpActionResult GetHelpDetails(string UserID)
        {
            _logger.TraceStart();
            if (!ModelState.IsValid)
            {
                return Content(HttpStatusCode.BadRequest, ModelState);
            }
            HelpOutputValues objhelpDetails = UtilityHelper.ProcessException<HelpOutputValues>(() => _trackerReportingFacade.GetHelpDetails(UserID));
            _logger.TraceEnd();
            if (objhelpDetails != null)
            {
                return Ok(objhelpDetails);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Help Record Data are found for the User ID: {0}", UserID));
            }

        }

        #endregion

        #region HelpFile pdf
        /// <summary>
        /// To Show user manual in browser.
        /// </summary>
        /// <response code="200">File found</response>
        /// <response code="404">File not found</response>
        [HttpGet]
        [Route("help/{fileid}/Document")]
        public HttpResponseMessage GetHelpDocument(int fileid)
        {
            _logger.TraceStart();
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK);

            string filePath = UtilityHelper.ProcessException(() => _trackerReportingFacade.GetHelpFilePath(fileid));

            if (!File.Exists(filePath))
            {
                response.StatusCode = HttpStatusCode.NotFound;
                response.Content = new StringContent(string.Format("File not found: {0}", Path.GetFileName(filePath)));
                return response;
            }

            response.Content = new StreamContent(File.OpenRead(filePath));
            var contentType = MimeMapping.GetMimeMapping(Path.GetExtension(filePath));
            response.Content.Headers.ContentType = new MediaTypeHeaderValue(contentType);
            _logger.TraceEnd();
            return response;
        }
        #endregion

        #region PostMortermDetails

        /// <summary>
        /// Load PostMorterm Details
        /// </summary>
        /// <remarks>
        /// Load data for PostMorterm popup screen<Br></Br>
        /// <returns>Postmotermdetails</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<PostMortemUpdateInputModel>))]
        [HttpGet]
        [Route("reports/{RecordNumber}/postmortermdetails")]
        public IHttpActionResult GetPostmortermDetails(int RecordNumber)
        {

            if (RecordNumber == 0)
            {
                return Content(HttpStatusCode.BadRequest, "Record Number not passed for the request");
            }
            else
            {
                _logger.TraceStart();
                List<PostMortemUpdateInputModel> postmotermdetails = UtilityHelper.ProcessException<List<PostMortemUpdateInputModel>>(() => _trackerReportingFacade.GetPostMortermDetails(RecordNumber));
                _logger.TraceEnd();

                if (postmotermdetails != null && postmotermdetails.Count >= 1)
                {
                    return Ok(postmotermdetails);
                }
                else
                {
                    return Content(HttpStatusCode.NoContent, String.Format("No Records found for Record Number: {0}", RecordNumber));
                }
            }

        }

        #endregion

        #region GetInsuredName
        /// <summary>
        ///  Get all the Insured Names based on the search string.
        /// </summary>
        /// <remarks>
        ///  Get the Insured Names.<br></br>        
        /// </remarks>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<InsuredSearchOutputModel>))]
        [HttpGet]
        [Route("filters/{insuredName}/InsuredNameSearch")]
        public IHttpActionResult GetInsuredName(string insuredName)
        {
            if (String.IsNullOrEmpty(insuredName))
            {
                return Content(HttpStatusCode.BadRequest, "Insured Name not passed for the request");
            }
            _logger.TraceStart();
            List<InsuredSearchOutputModel> dropdownOutputValues = UtilityHelper.ProcessException<List<InsuredSearchOutputModel>>(() => _trackerReportingFacade.GetInsuredName(insuredName));
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, "No data found for the search");
            }
        }

        /// <summary>
        /// To Get result based on wildcard search for insured report filter.
        /// </summary>
        /// <param name="searchvalue"></param>
        /// <returns></returns>
        [ResponseType(typeof(IEnumerable<OptionsGroupItems>))]
        [HttpGet]
        [Route("filters/{searchvalue}/insuredwildcardsearch")]
        public IHttpActionResult GetInsuredWildcardSearchResult(string searchvalue)
        {
            if (String.IsNullOrEmpty(searchvalue))
            {
                return Content(HttpStatusCode.BadRequest, "search value not passed for the request");
            }
            _logger.TraceStart();
            List<OptionsGroupItems> optionsGroupItems = UtilityHelper.ProcessException<List<OptionsGroupItems>>(() => _trackerReportingFacade.GetInsuredWildcardSearchResult(searchvalue));
            _logger.TraceEnd();
            if (optionsGroupItems != null && optionsGroupItems.Count > 0)
            {
                return Ok(optionsGroupItems);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, "No data found for the search");
            }
        }

        #endregion


        #region InputPageRedirection
        /// <summary>
        /// Check the SubGroup and Division forgiven Record number  (ScreenName: Input Page)
        /// </summary>
        /// <remarks>
        /// Return if the record number should be navigated to new or old screen<br></br>
        /// Required Parameters : RecordNumber
        /// </remarks>
        /// <param name="RecordNumber">TrackingReportingCommonFilterInputModel</param>
        /// <returns>RegionalMarginOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>

        [HttpGet]
        [Route("reports/{RecordNumber}/checkNavigation")]  // R2
        public IHttpActionResult GetRecordNavigation(int RecordNumber)
        {
            bool bRecordNavigation = false;
            if (RecordNumber > 0)
            {
                _logger.TraceStart();
                bRecordNavigation = UtilityHelper.ProcessException<bool>(() => _trackerReportingFacade.GetRecordNavigation(RecordNumber));
                _logger.TraceEnd();
            }
            return Ok(new
            {
                value = bRecordNavigation
            });


        }
        #endregion InputPageRedirection

        #region ERC Summary
        /// <summary>
        /// Load ERC Summary (ScreenName: ERC Summary)
        /// </summary>
        /// <remarks>
        /// Load ERC Sumamry Details<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>
        /// DisplayResultBy - Should be fed as 'Time Frame' or 'Credited Region'or 'Segment'or 'PortFolio Class'
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>UWDashboardGridOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ERCSummaryOutputModel>))]
        [HttpPost]
        [Route("reports/ERCsummarydetails")] // R3
        public IHttpActionResult GetERCSummaryDetails([FromBody]TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();
            List<ERCSummaryOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<ERCSummaryOutputModel>>(() => _trackerReportingFacade.GetERCSummaryDetails(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No ERC Summary Records found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }


        }
        #endregion

        #region ERC Detail
        /// <summary>
        /// Load ERC Summary (ScreenName: ERC Detail)
        /// </summary>
        /// <remarks>
        /// Load ERC Sumamry Details<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame<br></br>
        /// AccountMonth - Account month string - Can represent "March", "Mar" etc.<br></br>
        /// AccountYear - Account Year Integer - 2018, 2019 etc.<br></br>
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" <br></br>
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>ERCDetailOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<ERCDetailOutputModel>))]
        [HttpPost]
        [Route("reports/ERCdetail")] // R3
        public IHttpActionResult GetERCDetails([FromBody]TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();
            List<ERCDetailOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<ERCDetailOutputModel>>(() => _trackerReportingFacade.GetERCDetails(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No ERC Detail Records found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }


        }
        #endregion


        #region Surety Scorecard
        /// <summary>
        /// Load data for Surety Production by Bond Category (ScreenName: Surety Production by Bond Category)
        /// </summary>
        /// <remarks>
        /// Load data for Surety Production by Bond Category<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,
        /// AccountYear - Account Year Integer - 2018, 2019 etc.,
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" ,
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>SuretyScorecardByBondCategoryOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<SuretyScorecardByBondCategoryOutputModel>))]
        [HttpPost]
        [Route("reports/suretyscorecard/bondcategory")]  // R2
        public IHttpActionResult GetSuretyScorecardByBondCategory(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<SuretyScorecardByBondCategoryOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<SuretyScorecardByBondCategoryOutputModel>>(() => _trackerReportingFacade.GetSuretyScorecardByBondCategory(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Surety Production By Bond Category found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }

        }

        /// <summary>
        /// Load data for Surety Production by Credited Region (ScreenName: Surety Production by Credited Region)
        /// </summary>
        /// <remarks>
        /// Load data for Surety Production by Credited Region<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,
        /// AccountYear - Account Year Integer - 2018, 2019 etc.,
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" ,
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>SuretyScorecardByCreditedRegionOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<SuretyScorecardByCreditedRegionOutputModel>))]
        [HttpPost]
        [Route("reports/suretyscorecard/creditedregion")]  // R2
        public IHttpActionResult GetSuretyScorecardByCreditedRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<SuretyScorecardByCreditedRegionOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<SuretyScorecardByCreditedRegionOutputModel>>(() => _trackerReportingFacade.GetSuretyScorecardByCreditedRegion(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Surety Production By Credited Region found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }
        }

        #endregion Surety Scorecard

        #region Regional Margin
        /// <summary>
        /// Load data for Regional Margin (ScreenName: Regional Margin)
        /// </summary>
        /// <remarks>
        /// Load data for Regional Margin<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,
        /// AccountYear - Account Year Integer - 2018, 2019 etc.,
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" ,
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>RegionalMarginOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<RegionalMarginOutputModel>))]
        [HttpPost]
        [Route("reports/regionalmargin")]  // R2
        public IHttpActionResult GetRegionalMargin(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<RegionalMarginOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<RegionalMarginOutputModel>>(() => _trackerReportingFacade.GetRegionalMargin(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, String.Format("No Regional Margin found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }

        }
        #endregion Regional Margin

        #region Growth Mix Margin
        /// <summary>
        /// Load data for Growth Mix Margin (ScreenName: Growth Mix Margin)
        /// </summary>
        /// <remarks>
        /// Load data for Growth Mix Margin<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,
        /// AccountYear - Account Year Integer - 2018, 2019 etc.,
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" ,
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>GrowthMixByBusinessOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<GrowthMixByBusinessOutputModel>))]
        [HttpPost]
        [Route("reports/growthmixmargin/businesssegment")]
        public IHttpActionResult GetGrowthMixMarginByBusiness(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<GrowthMixByBusinessOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<GrowthMixByBusinessOutputModel>>(() => _trackerReportingFacade.GetGrowthMixMarginByBusiness(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Growth Mix Margin found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }

        }

        /// <summary>
        /// Load data for Growth Mix Margin (ScreenName: Growth Mix Margin)
        /// </summary>
        /// <remarks>
        /// Load data for Growth Mix Margin<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,
        /// AccountYear - Account Year Integer - 2018, 2019 etc.,
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" ,
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>GrowthMixByBusinessOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<GrowthMixByRegionOutputModel>))]
        [HttpPost]
        [Route("reports/growthmixmargin/region")]
        public IHttpActionResult GetGrowthMixMarginByRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<GrowthMixByRegionOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<GrowthMixByRegionOutputModel>>(() => _trackerReportingFacade.GetGrowthMixMarginByRegion(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Growth Mix Margin found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }

        }

        #endregion Growth Mix Margin

        #region Home Office Margin

        /*
        /// <summary>
        /// Load data for  Home Office Margin Percentage by Business (ScreenName: Home Office Margin %)
        /// </summary>
        /// <remarks>
        /// Load data for Home Office Margin by Percentage<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,
        /// AccountYear - Account Year Integer - 2018, 2019 etc.,
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" 
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>HomeOfficeMarginPercentByBusinessOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<HomeOfficeMarginPercentByBusinessOutputModel>))]
        [HttpPost]
        [Route("reports/homeofficemarginbybusiness/Percentage")] 
        public IHttpActionResult GetHomeOfficeMarginPercentByBusiness(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<HomeOfficeMarginPercentByBusinessOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<HomeOfficeMarginPercentByBusinessOutputModel>>(() => _trackerReportingFacade.GetHomeOfficeMarginPercentByBusiness(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Margin details found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }

        }
        /// <summary>
        /// Load data for Home Office Margin Percentage by Credited Region(ScreenName: Home Office Margin %)
        /// </summary>
        /// <remarks>
        /// Load data for Home Office Margin Percentage by Credited Region<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,
        /// AccountYear - Account Year Integer - 2018, 2019 etc.,
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" 
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>HomeOfficeMarginPercentByCreditedRegionOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<HomeOfficeMarginPercentByCreditedRegionOutputModel>))]
        [HttpPost]
        [Route("reports/homeofficemarginbyregion/Percentage")]
        public IHttpActionResult GetHomeOfficeMarginPercentByCreditedRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<HomeOfficeMarginPercentByCreditedRegionOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<HomeOfficeMarginPercentByCreditedRegionOutputModel>>(() => _trackerReportingFacade.GetHomeOfficeMarginPercentByCreditedRegion(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Margin details found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }

        }
        */

        /// <summary>
        /// Load data for Home Office Margin by Business Segment (ScreenName: Home Office Margin)
        /// </summary>
        /// <remarks>
        /// Load data for Home Office Margin by Business Segment<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,
        /// AccountYear - Account Year Integer - 2018, 2019 etc.,
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" 
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>HomeOfficeMarginByBusinessSegmentOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<HomeOfficeMarginByBusinessSegmentOutputModel>))]
        [HttpPost]
        [Route("reports/homeofficemargin/businesssegment")]
        public IHttpActionResult GetHomeOfficeMarginByBusinessSegment(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<HomeOfficeMarginByBusinessSegmentOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<HomeOfficeMarginByBusinessSegmentOutputModel>>(() => _trackerReportingFacade.GetHomeOfficeMarginByBusinessSegment(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Margin details found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }

        }
        /// <summary>
        /// Load data for Home Office Margin By Credited Region(ScreenName: Home Office Margin)
        /// </summary>
        /// <remarks>
        /// Load data for Home Office Margin By Credited Region<br></br>
        /// Required Parameters : UserID, AccountMonth, AccountYear, TimeFrame
        /// AccountMonth - Account month string - Can represent "March", "Mar", "Current" etc.,
        /// AccountYear - Account Year Integer - 2018, 2019 etc.,
        /// TimeFrame - Represents the time frame value - "MTD", "YTD", "R3", "R12" 
        /// </remarks>
        /// <param name="trackingReportingCommonFilterInputModel">TrackingReportingCommonFilterInputModel</param>
        /// <returns>HomeOfficeMarginByCreditedRegionOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<HomeOfficeMarginByCreditedRegionOutputModel>))]
        [HttpPost]
        [Route("reports/homeofficemargin/region")]
        public IHttpActionResult GetHomeOfficeMarginByCreditedRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
             || String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (String.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<HomeOfficeMarginByCreditedRegionOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<HomeOfficeMarginByCreditedRegionOutputModel>>(() => _trackerReportingFacade.GetHomeOfficeMarginByCreditedRegion(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, String.Format("No Margin details found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }

        }


        #endregion

        #region PasCodeDetails
        /// <summary>
        /// Load PasCodeDetails from accountName (ScreenName: PasCodeDetails)
        /// </summary>
        /// <remarks>
        /// Load PasCodeDetails<br></br>
        /// Required Parameters : AccountName<br></br>
        /// </remarks>
        /// <param name="passCodeDetailsInputModell">PassCodeDetailsInputModell</param>
        /// <returns>PassCodeDetailsOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<PassCodeDetailsOutputModel>))]
        [HttpPost]
        [Route("reports/pasproducerinfo")] // R3
        public IHttpActionResult GetPasCodeDetails([FromBody]PassCodeDetailsInputModell passCodeDetailsInputModell)
        {

            if (String.IsNullOrEmpty(passCodeDetailsInputModell.ProducerAccountName) && String.IsNullOrEmpty(passCodeDetailsInputModell.ProducerAccountGUID)
              && String.IsNullOrEmpty(passCodeDetailsInputModell.ProducerAccountBranchName)
              && String.IsNullOrEmpty(passCodeDetailsInputModell.PASProducerCode)
              && String.IsNullOrEmpty(passCodeDetailsInputModell.PASProducerName)
              && String.IsNullOrEmpty(passCodeDetailsInputModell.PASProducerAddressLine1)
              && String.IsNullOrEmpty(passCodeDetailsInputModell.PASProducerCity)
              && String.IsNullOrEmpty(passCodeDetailsInputModell.PASProducerStateCode)
              && String.IsNullOrEmpty(passCodeDetailsInputModell.PASProducerZipCode)
              && String.IsNullOrEmpty(passCodeDetailsInputModell.PASProducerBranchCode)
              && String.IsNullOrEmpty(passCodeDetailsInputModell.PASProducerBranchName))
            {
                return Content(HttpStatusCode.BadRequest, "Please Provide Atleast one filter");
            }
            if (String.IsNullOrEmpty(passCodeDetailsInputModell.UserEmailID))
            {
                if (String.IsNullOrEmpty(passCodeDetailsInputModell.UserEmailID))
                    return Content(HttpStatusCode.BadRequest, "UserEmailID not passed for the request");
            }
            if (!String.IsNullOrEmpty(passCodeDetailsInputModell.ProducerAccountGUID))
            {
                int guidlength = passCodeDetailsInputModell.ProducerAccountGUID.Length;
                if (guidlength != 36)
                {
                    return Content(HttpStatusCode.BadRequest, "Please Provide Valid GUID");
                }
            }

            _logger.TraceStart();
            List<PassCodeDetailsOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException<List<PassCodeDetailsOutputModel>>(() => _trackerReportingFacade.GetPasCodeDetails(passCodeDetailsInputModell));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData == null)
            {
                return Content(HttpStatusCode.BadRequest, "Please Provide Valid EmailID");
            }
            else
            {
                return Ok(trackingReportingGridOutputData);
            }
            //if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            //{
            //    return Ok(trackingReportingGridOutputData);
            //}
            //else
            //{
            //    return Content(HttpStatusCode.NotFound, String.Format("No PasCode details found for this EmailId: {0}", passCodeDetailsInputModell.EmailID));
            //}


        }
        #endregion

        #region SubmissionSelectUnit
        /// <summary>
        /// Created for to get Unit Segment Details by User ID
        /// </summary>
        /// <param name="userID"></param>
        /// <returns>Unit Segment Details By UserID</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<UnitSegmentDetailsOutputModel>))]
        [HttpGet]
        [Route("policies/submission/{userID}/getunitsegment")]
        public IHttpActionResult GetUnitSegmentDetailsByUserID(string userID)
        {
            if (String.IsNullOrEmpty(userID))
            {
                return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
            }
            else
            {
                _logger.TraceStart();
                List<UnitSegmentDetailsOutputModel> unitSegmentDetails = UtilityHelper.ProcessException<List<UnitSegmentDetailsOutputModel>>(() => _trackerReportingFacade.GetUnitSegmentDetailsByUserID(userID));
                _logger.TraceEnd();

                if (unitSegmentDetails != null && unitSegmentDetails.Count >= 1)
                {
                    return Ok(unitSegmentDetails);
                }
                else
                {
                    return Content(HttpStatusCode.NoContent, String.Format("No Records found for userID: {0}", userID));
                }
            }
        }

        #endregion

        #region MajorAccounts

        /// <summary>
        /// Submission Details
        /// </summary>
        /// <remarks>
        /// Get additional details for a record number<Br></Br>
        /// <returns>Policy details</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<SubmissionDetails>))]
        [HttpGet]
        [Route("submissions/{RecordNumber}")]
        public IHttpActionResult GetSubmissionDetails(int RecordNumber)
        {

            if (RecordNumber == 0)
            {
                return Content(HttpStatusCode.BadRequest, "Record Number not passed for the request");
            }
            else
            {
                _logger.TraceStart();
                List<SubmissionDetails> objMajorAccounts = UtilityHelper.ProcessException<List<SubmissionDetails>>(() => _trackerReportingFacade.GetSubmissionDetails(RecordNumber));
                _logger.TraceEnd();

                if (objMajorAccounts != null && objMajorAccounts.Count >= 1)
                {
                    return Ok(objMajorAccounts);
                }
                else
                {
                    return Content(HttpStatusCode.NoContent, String.Format("No Records found for Record Number: {0}", RecordNumber));
                }
            }
        }
        #endregion

        #region EditProfile Load
        /// <summary>
        /// Load EditProfile  (ScreenName: Edit Profile Load)
        /// </summary>
        /// <remarks>
        /// Load Edit Profile Data<br></br>
        /// Required Parameters : UserID, EmailID<br></br>
        /// </remarks>
        /// <param name="editProfileInputModel">EditProfileInputModel</param>
        /// <returns>UWDashboardGridOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<EditProfileOutputModel>))]
        [HttpPost]
        [Route("users/loadprofile")]
        public IHttpActionResult GetEditProfileDetails([FromBody]EditProfileInputModel editProfileInputModel)
        {
            if (String.IsNullOrEmpty(editProfileInputModel.UserID)
               && String.IsNullOrEmpty(editProfileInputModel.EmailId))
            {
                return Content(HttpStatusCode.BadRequest, "Please Provide Atleast UserId or Email Id");
            }

            _logger.TraceStart();
            List<EditProfileOutputModel> editprofileData = UtilityHelper.ProcessException<List<EditProfileOutputModel>>(() => _trackerReportingFacade.GetEditProfileDetails(editProfileInputModel));
            _logger.TraceEnd();
            if (editprofileData == null)
            {
                return Content(HttpStatusCode.BadRequest, "Please Provide Valid  Email Id");
            }
            else
            {
                return Ok(editprofileData);
            }

        }
        #endregion

        #region Country Filter
        /// <summary>
        /// Load data for CountryName filter control  (ScreenName: CountryName Filter)
        /// </summary>
        /// <remarks>
        /// Load data for CountryName filter control
        /// </remarks>        
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/countryname")]  // R2
        public IHttpActionResult GetCountryNameFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCountryNameFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No data found for Country Name filter control");
            }
        }
        #endregion

        #region EditProfile Save
        /// <summary>
        /// Load EditProfile  (ScreenName: Edit Profile Save)
        /// </summary>
        /// <remarks>
        /// Load Edit Profile Save<br></br>
        /// Required Parameters : UserID, EmailID<br></br>
        /// </remarks>
        /// <param name="editProfileInputModel">EditProfileInputModel</param>
        /// <returns>UWDashboardGridOutputModel</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<string>))]
        [HttpPost]
        [Route("users/saveprofile")]
        public IHttpActionResult GetEditProfileSave([FromBody]EditProfileSaveInputModel editProfileSaveInputModel)
        {
            if (String.IsNullOrEmpty(editProfileSaveInputModel.UserID))
            {
                return Content(HttpStatusCode.BadRequest, "Please Provide Atleast UserId or Email Id");
            }

            _logger.TraceStart();
            string editprofileData = UtilityHelper.ProcessException<string>(() => _trackerReportingFacade.GetEditProfileSave(editProfileSaveInputModel));
            _logger.TraceEnd();
            if (editprofileData == null)
            {
                return Content(HttpStatusCode.BadRequest, "Please Provide Valid  Email Id");
            }
            else
            {
                return Ok(editprofileData);
            }

        }
        #endregion

        #region Linked Reports 
        /// <summary>
        /// To Show user manual in browser.
        /// </summary>
        /// <response code="200">File found</response>
        /// <response code="404">File not found</response>
        [HttpGet]
        [Route("linkedreport/{filename}/Document")]
        public HttpResponseMessage GetLinkedReport(string filename)
        {
            _logger.TraceStart();
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK);

            string filePath = UtilityHelper.ProcessException(() => _trackerReportingFacade.GetLinkedReport(filename));

            if (!File.Exists(filePath))
            {
                response.StatusCode = HttpStatusCode.NotFound;
                response.Content = new StringContent(string.Format("File not found: {0}", Path.GetFileName(filePath)));
                return response;
            }

            response.Content = new StreamContent(File.OpenRead(filePath));
            var contentType = MimeMapping.GetMimeMapping(Path.GetExtension(filePath));

            var documentName = Path.GetFileName(filePath);
            if (documentName.EndsWith(".xlsb") || documentName.EndsWith(".xlsm"))
            {
                response.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
                response.Content.Headers.ContentDisposition.FileName = documentName;
            }

            response.Content.Headers.ContentType = new MediaTypeHeaderValue(contentType);
            _logger.TraceEnd();
            return response;
        }
        #endregion

        #region Target Progression Report
        /// <summary>
        /// To Get TargetProgressionReport Value With Respect To Branch
        /// </summary>
        /// <param name="trackingReportingCommonFilterInputModel"></param>
        /// <returns></returns>
        [ResponseType(typeof(IEnumerable<TargetProgressionByBranchOutputModel>))]
        [HttpPost]
        [Route("reports/targetprogression/branch")] 
        public IHttpActionResult GetTargetProgressionReportsByBranch(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (string.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || string.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
                || string.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (string.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (string.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (string.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<TargetProgressionByBranchOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException(() => _trackerReportingFacade.GetTargetProgressionByBranch(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, string.Format("No Target Progression by Branch amount found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }
        }

        /// <summary>
        /// To Get TargetProgressionReport Value With Respect To Region
        /// </summary>
        /// <param name="trackingReportingCommonFilterInputModel"></param>
        /// <returns></returns>
        [ResponseType(typeof(IEnumerable<TargetProgressionByRegionOutputModel>))]
        [HttpPost]
        [Route("reports/targetprogression/region")]
        public IHttpActionResult GetTargetProgressionReportsByRegion(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (string.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || string.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
                || string.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (string.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (string.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (string.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            List<TargetProgressionByRegionOutputModel> trackingReportingGridOutputData = UtilityHelper.ProcessException(() => _trackerReportingFacade.GetTargetProgressionByRegion(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, string.Format("No Target Progression by Region amount found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }
        }

        /// <summary>
        /// To Get TargetProgressionReport Value With Respect To LOB
        /// </summary>
        /// <param name="trackingReportingCommonFilterInputModel"></param>
        /// <returns></returns>
        [ResponseType(typeof(IEnumerable<TargetProgressionByLobOutputModel>))]
        [HttpPost]
        [Route("reports/targetprogression/lob")]
        public IHttpActionResult GetTargetProgressionReportsByLob(TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            if (string.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID) || string.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth)
               || string.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame) || trackingReportingCommonFilterInputModel.AccountYear == 0)
            {
                if (string.IsNullOrEmpty(trackingReportingCommonFilterInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
                if (string.IsNullOrEmpty(trackingReportingCommonFilterInputModel.AccountMonth))
                    return Content(HttpStatusCode.BadRequest, "AccountMonth not passed for the request");
                if (trackingReportingCommonFilterInputModel.AccountYear == 0)
                    return Content(HttpStatusCode.BadRequest, "AccountYear not passed for the request");
                if (string.IsNullOrEmpty(trackingReportingCommonFilterInputModel.TimeFrame))
                    return Content(HttpStatusCode.BadRequest, "TimeFrame not passed for the request");
            }
            _logger.TraceStart();

            TargetProgressionByLobOutputModel trackingReportingGridOutputData = UtilityHelper.ProcessException(() => _trackerReportingFacade.GetTargetProgressionByLob(trackingReportingCommonFilterInputModel));
            _logger.TraceEnd();
            if (trackingReportingGridOutputData.LobByCompany.Count > 0 && trackingReportingGridOutputData != null)
            {
                return Ok(trackingReportingGridOutputData);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, string.Format("No Target Progression by LoB amount found for UserID: {0}", trackingReportingCommonFilterInputModel.UserID));
            }
        }
        #endregion

        #region Service Branch
        /// <summary>
        /// Load data for Service Branch filter control(ScreenName: Service Branch Filter)
        /// </summary>
        /// <remarks>
        ///  Load data for Service Branch filter control<br></br>
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/servicebranch")]  // R2
        public IHttpActionResult GetServiceBranchFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetServiceBranchFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No data found for Service Branch filter control");
            }
        }
        #endregion
        #region Service Branch
        /// <summary>
        /// Load data for Policy Type filter control(ScreenName: Policy Type Filter)
        /// </summary>
        /// <remarks>
        ///  Load data for Policy Type filter control<br></br>
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/chubbpolicytype")]  // R2
        public IHttpActionResult GetpolicytypeFilter()
        {
            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetPolicyTypeFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No data found for PolicyType filter control");
            }
        }
        #endregion

        #region Deeplink Application

        /// <summary>
        /// To Get Deeplink Application Filters details by application id.
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="applicationID"></param>
        /// <returns></returns>
        [ResponseType(typeof(IEnumerable<DeeplinkAppFiltersResult>))]
        [HttpPost]
        [Route("filters/deeplinkprofile")]
        public IHttpActionResult GetDeeplinkAppFiltersByID(string userID, int applicationID)
        {
             if (String.IsNullOrEmpty(userID))
                return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
            if (applicationID <= 0)
                return Content(HttpStatusCode.BadRequest, "applicationID not passed for the request");

            _logger.TraceStart();
            List<DeeplinkAppFiltersResult> deeplinkAppFiltersResult = UtilityHelper.ProcessException<List<DeeplinkAppFiltersResult>>(() => _trackerReportingFacade.GetDeeplinkAppFiltersByID(userID, applicationID));
            _logger.TraceEnd();

            if (deeplinkAppFiltersResult == null)
            {
                return Content(HttpStatusCode.NoContent, String.Format("No Records found for UserID: {0}", userID));
            }
            else
            {
                return Ok(deeplinkAppFiltersResult);
            }
        }

        #endregion Deeplink Application

        #region Pinned Reports
        /// <summary>
        /// Created to get pinned reports details by User ID
        /// </summary>
        /// <param name="userID"></param>
        /// <returns>Access By UserID</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(string))]
        [HttpGet]
        [Route("reports/pinnedreports")]
        public IHttpActionResult GetPinnedReportsByID(string userID)
        {
            List<string> PinnedReportNames = new List<string>();
            if (String.IsNullOrEmpty(userID))
            {
                return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
            }
            else
            {
                _logger.TraceStart();
                PinnedReportNames = UtilityHelper.ProcessException<List<string>>(() => _trackerReportingFacade.GetPinnedReportsByID(userID));
                _logger.TraceEnd();

                if (PinnedReportNames != null && PinnedReportNames.Count > 1)
                {
                    return Ok(PinnedReportNames);
                }
                else
                {
                    return Content(HttpStatusCode.NoContent, String.Format("No Records found for userID: {0}", userID));
                }
            }

        }


        /// <summary>
        /// Created for insert Pinned Reports details to database.
        /// </summary>
        /// <param name="savePinnedReportsInputModel"></param>
        /// <returns>Save Message</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<string>))]
        [HttpPost]
        [Route("reports/savepinnedreports")]
        public IHttpActionResult SavePinnedReportsByID(SavePinnedReportsInputModel savePinnedReportsInputModel)
        {
            if (String.IsNullOrEmpty(savePinnedReportsInputModel.UserID))
            {
                if (String.IsNullOrEmpty(savePinnedReportsInputModel.UserID))
                    return Content(HttpStatusCode.BadRequest, "UserID not passed for the request");
            }

            _logger.TraceStart();
            string Message = _trackerReportingFacade.SavePinnedReportsByID(savePinnedReportsInputModel);
            _logger.TraceEnd();

            if (Message != null)
            {
                return Ok(Message);
            }
            else
            {
                return Content(HttpStatusCode.NoContent, "Pinned Reports Save failed");
            }
        }

        #endregion

        #region Dynamics contact details
        /// <summary>
        /// Load data for CRM Contact Preference filter control (ScreenName: CRM Contact Preference Filter)
        /// </summary>
        /// <remarks>
        /// Load data for CRM Contact Preference filter control
        /// </remarks>
        /// <returns>DropdownOutputValues</returns>
        /// <response code="200">Record found</response>
        /// <response code="404">Record not found</response>
        [ResponseType(typeof(IEnumerable<DropdownOutputValues>))]
        [HttpPost]
        [Route("filters/dynamics/contactpreference")]  // R2
        public IHttpActionResult GetCRMContactPreferenceFilter()
        {

            _logger.TraceStart();
            List<DropdownOutputValues> dropdownOutputValues = UtilityHelper.ProcessException<List<DropdownOutputValues>>(() => _trackerReportingFacade.GetCRMContactPreferenceFilter());
            _logger.TraceEnd();
            if (dropdownOutputValues.Count > 0 && dropdownOutputValues != null)
            {
                return Ok(dropdownOutputValues);
            }
            else
            {
                return Content(HttpStatusCode.NotFound, "No Load data for CRM Contact Preference filter control");
            }
        }

        #endregion
    }
}
