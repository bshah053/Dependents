﻿#region Namespaces
using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Reflection;
using Chubb.Tracker.Framework.Helper;
using Chubb.Tracker.ServiceModel.TrackingReporting;
using Chubb.Tracker.TrackerReportingService.Data.Implementation;
using System.Text;
#endregion Namespaces

namespace Chubb.Tracker.TrackerReportingService.PDFCommon
{
    /// <summary>
    /// Author			 Created Date		    Last Modified		   Last Modified By		 Comments
    /// Sureshkumar G    03-September-2020                                                   Initial Version.
    ///                                         04-September-2020      Sureshkumar G
    /// </summary>
    public class PDFCommon
    {

        #region Public Methods

        /// <summary>
        /// Generaete HTML Content for PDF header based on report name.
        /// </summary>
        /// <param name="htmlContent"></param>
        /// <param name="sourceTable"></param>
        /// <param name="groupLevel"></param>
        /// <param name="reportHeaderName"></param>
        /// <param name="reportName"></param>
        public static void GenerateHtmlContentForHeader(StringBuilder htmlContent,
           DataTable sourceTable, int groupLevel, string reportHeaderName, string reportName)
        {
            TrackerReportingRepository _trackerReportingRepository = new TrackerReportingRepository();
            List<ExcelColumnMappingOutputModel> excelColumnMappingDetails = _trackerReportingRepository.GetExcelColumnMapping(reportName);
            if (excelColumnMappingDetails != null && excelColumnMappingDetails.Count > 0)
            {
                htmlContent.AppendLine("<center><span  style='font-family: Arial; font-size: 20pt;'>" + reportHeaderName + "</b></span></center><br/><br/>");
                htmlContent.AppendLine("<p align= 'left' style='font-family: Arial; font-size: 10pt; text-align:left'><b>All the figures listed below are in (USD)</b></p>");
                htmlContent.AppendLine("<table ID='Table2'>");

                htmlContent.AppendLine("<thead style='display: table-header-group'><tr>");

                for (int columnIndex = (groupLevel == 2 ? 1 : groupLevel == 5 ? 3 : 0); columnIndex < sourceTable.Columns.Count; columnIndex++)
                {
                    string elementHeaderText = string.Empty;
                    if (groupLevel == 2 && columnIndex == 1)
                    {
                        if (reportName == "RegionalScoreCardAmountPerRegion" || reportName == "RegionalScorecardNewBusinessByStatus"
                            || reportName == "RegionalScorecardRenewalByStatus" || reportName == "NetScorecardAmountPerRegion"
                            || reportName == "GrowthMixByRegion" || reportName == "HomeOfficeByRegion" || reportName == "ERCSummaryByCreditedRegion")
                        {
                            elementHeaderText = "Credited Branch/Region";
                        }
                        else if (reportName == "SuretyScorecardByBondCategory" || reportName == "SuretyScorecardByCreditedRegion")
                        {
                            elementHeaderText = "Bond Category";
                        }
                    }
                    else if (groupLevel == 5 && columnIndex == 3)
                    {
                        if (reportName == "NetScorecardAmountPerDivision" || reportName== "ERCSummaryByBusinessSegment" || reportName == "ERCSummaryByPortfolioClass")
                        {
                            elementHeaderText = "Business Segment";
                        }
                        else if (reportName == "RegionalMargin" || reportName == "GrowthMixByBusiness" || reportName == "HomeOfficeByBusinessSegment")
                        {
                            elementHeaderText = "Line of Business";
                        }
                    }
                    else
                    {
                        elementHeaderText = excelColumnMappingDetails
                            .Where(x => x.ElementName == Convert.ToString(sourceTable.Columns[columnIndex].ColumnName))
                            .Select(x => x.ElementHeaderText).SingleOrDefault();
                    }
                    if (!string.IsNullOrEmpty(elementHeaderText))
                    {

                        if (elementHeaderText == "" || elementHeaderText == "") { htmlContent.AppendLine("<th colspan=1 style='width:25%'  bgcolor='#3980c6' valign=top><font  color='white'>" + elementHeaderText + "</font></th>"); }
                        else { htmlContent.AppendLine("<th colspan=1 bgcolor='#3980c6' valign=top><font color='white'>" + elementHeaderText + "</font></th>"); }

                    }
                }
                htmlContent.AppendLine("</tr></thead>");
            }
        }

        /// <summary>
        /// /Generaete HTML Content for PDF rows based on report name.
        /// </summary>
        /// <param name="htmlContent"></param>
        /// <param name="sourceTable"></param>
        /// <param name="groupLevel"></param>
        public static void GenerateHtmlContentForRows(StringBuilder htmlContent, DataTable sourceTable, int groupLevel, string reportName)
        {
            if (sourceTable != null && sourceTable.Rows.Count > 0)
            {
                //1st Level - Company , Credited Region
                string groupColumnNameOne = Convert.ToString(sourceTable.Columns[0].ColumnName);
                var parentItems = groupLevel == 2 ? sourceTable.AsEnumerable().GroupBy(group => group.Field<string>(groupColumnNameOne)).OrderBy(row => row.Key) :
                    sourceTable.AsEnumerable().GroupBy(group => group.Field<string>(groupColumnNameOne));
                TrackerReportingRepository _trackerReportingRepository = new TrackerReportingRepository();
                List<ExcelColumnMappingOutputModel> excelColumnMappingDetails = _trackerReportingRepository.GetExcelColumnMapping(reportName);

                foreach (var item in parentItems)
                {
                    if (item.Key != null)
                    {
                        htmlContent.AppendLine("<tr>");
                        htmlContent.AppendLine("<td colspan=1 style='width:25%' bgcolor='#8c8c8c' valign=top><font color='black'>" + item.Key + "</font></td>");

                        for (int columnIndex = groupLevel; columnIndex < sourceTable.Columns.Count; columnIndex++)
                        {
                            string columnName = Convert.ToString(sourceTable.Columns[columnIndex].ColumnName);
                            bool IsPercent = (bool)excelColumnMappingDetails
                            .Where(x => x.ElementName == Convert.ToString(sourceTable.Columns[columnIndex].ColumnName))
                            .Select(x => x.IsPercent).SingleOrDefault();

                            if (groupLevel == 2)
                            {
                                if (IsPercent)
                                {
                                    htmlContent.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}",
                                    (item.ToList().OrderBy(row => row.Field<string>(Convert.ToString(sourceTable.Columns[1].ColumnName))).ToList()[0][columnName])) + '%' + "</font></td>");
                                }
                                else
                                {
                                    htmlContent.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}",
                                   (item.ToList().OrderBy(row => row.Field<string>(Convert.ToString(sourceTable.Columns[1].ColumnName))).ToList()[0][columnName])) + "</font></td>");
                                }
                            }
                            else
                            {
                                if (IsPercent)
                                {
                                    htmlContent.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}",
                                    item.ToList()[0][columnName]) + '%' + "</font></td>");
                                }
                                else
                                {
                                    htmlContent.AppendLine("<td colspan=1  bgcolor='#8c8c8c' valign=top><font color='black'>" + String.Format("{0:n0}",
                                        item.ToList()[0][columnName]) + "</font></td>");
                                }
                            }
                        }
                        htmlContent.AppendLine("</tr>");
                    }
                    if (groupLevel > 1)
                    {
                        //2nd Level - Division, Credited Branch
                        string groupColumnNameTwo = Convert.ToString(sourceTable.Columns[1].ColumnName);
                        var ChildLevelItemsOne = item.GroupBy(c => c.Field<string>(groupColumnNameTwo)).ToList();
                        foreach (var itemOne in ChildLevelItemsOne)
                        {
                            if (itemOne.Key != null)
                            {
                                htmlContent.AppendLine("<tr>");
                                htmlContent.AppendLine("<td colspan=1 style='width:25%' bgcolor='#cccccc' width='20%' valign=top><font color='black'>" + itemOne.Key + "</font></td>");

                                for (int columnIndex = groupLevel; columnIndex < sourceTable.Columns.Count; columnIndex++)
                                {
                                    string columnName = Convert.ToString(sourceTable.Columns[columnIndex].ColumnName);
                                    bool IsPercent = (bool)excelColumnMappingDetails
                                    .Where(x => x.ElementName == Convert.ToString(sourceTable.Columns[columnIndex].ColumnName))
                                    .Select(x => x.IsPercent).SingleOrDefault();
                                    if (IsPercent)
                                    {
                                        htmlContent.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", itemOne.ToList()[0][columnName]) + '%' + "</font></td>");
                                    }
                                    else
                                    {
                                        htmlContent.AppendLine("<td colspan=1 bgcolor='#cccccc' valign=top><font color='black'>" + String.Format("{0:n0}", itemOne.ToList()[0][columnName]) + "</font></td>");
                                    }
                                }
                                htmlContent.AppendLine("</tr>");
                            }
                            //3rd Level - Unit
                            if (groupLevel > 2)
                            {
                                string groupColumnNameThree = Convert.ToString(sourceTable.Columns[2].ColumnName);
                                var ChildLevelItemsTwo = itemOne.GroupBy(c => c.Field<string>(groupColumnNameThree)).ToList();
                                foreach (var itemTwo in ChildLevelItemsTwo)
                                {
                                    if (itemTwo.Key != null)
                                    {
                                        htmlContent.AppendLine("<tr>");
                                        htmlContent.AppendLine("<td colspan=1 bgcolor='#e6e6e6' valign=top><font color='black'>" + itemTwo.Key + "</font></td>");

                                        for (int columnIndex = groupLevel; columnIndex < sourceTable.Columns.Count; columnIndex++)
                                        {
                                            string columnName = Convert.ToString(sourceTable.Columns[columnIndex].ColumnName);
                                            bool IsPercent = (bool)excelColumnMappingDetails
                                            .Where(x => x.ElementName == Convert.ToString(sourceTable.Columns[columnIndex].ColumnName))
                                            .Select(x => x.IsPercent).SingleOrDefault();
                                            if (IsPercent)
                                            {
                                                htmlContent.AppendLine("<td colspan=1 bgcolor='#e6e6e6' valign=top><font color='black'>" + String.Format("{0:n0}", itemTwo.ToList()[0][columnName]) + '%' + "</font></td>");
                                            }
                                            else
                                            {
                                                htmlContent.AppendLine("<td colspan=1 bgcolor='#e6e6e6' valign=top><font color='black'>" + String.Format("{0:n0}", itemTwo.ToList()[0][columnName]) + "</font></td>");
                                            }
                                        }
                                        htmlContent.AppendLine("</tr>");
                                    }
                                    //4th Level - Segment
                                    if (groupLevel > 3)
                                    {
                                        string groupColumnNameFour = Convert.ToString(sourceTable.Columns[3].ColumnName);
                                        var ChildLevelItemsThree = itemTwo.GroupBy(c => c.Field<string>(groupColumnNameFour)).ToList();
                                        foreach (var itemThree in ChildLevelItemsThree)
                                        {
                                            if (itemThree.Key != null)
                                            {
                                                htmlContent.AppendLine("<tr>");
                                                htmlContent.AppendLine("<td colspan=1 valign=top><font color='black'>" + itemThree.Key + "</font></td>");

                                                for (int columnIndex = groupLevel; columnIndex < sourceTable.Columns.Count; columnIndex++)
                                                {
                                                    string columnName = Convert.ToString(sourceTable.Columns[columnIndex].ColumnName);

                                                    bool IsPercent = (bool)excelColumnMappingDetails
                                                    .Where(x => x.ElementName == Convert.ToString(sourceTable.Columns[columnIndex].ColumnName))
                                                    .Select(x => x.IsPercent).SingleOrDefault();
                                                    if (IsPercent)
                                                    {
                                                        htmlContent.AppendLine("<td colspan=1 bgcolor='#FFFFFF' valign=top><font color='black'>" + String.Format("{0:n0}",
                                                        itemThree.ToList()[0][columnName]) + '%' + "</font></td>");
                                                    }
                                                    else
                                                    {
                                                        htmlContent.AppendLine("<td colspan=1 bgcolor='#FFFFFF' valign=top><font color='black'>" + String.Format("{0:n0}",
                                                     itemThree.ToList()[0][columnName]) + "</font></td>");
                                                    }
                                                }
                                                htmlContent.AppendLine("</tr>");
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
                htmlContent.AppendLine("</table>");
            }
        }

        /// <summary>
        /// Generaete HTML Content for PDF filter  based on report name.
        /// </summary>
        /// <param name="htmlContent"></param>
        /// <param name="trackingReportingCommonFilterInputModel"></param>
        public static void GenerateHtmlContentForFilters(StringBuilder htmlContent,
            TrackingReportingCommonFilterInputModel trackingReportingCommonFilterInputModel)
        {
            htmlContent.Append("<br/><br/><br/><table ID='Legend'>");
            htmlContent.AppendLine("<tr><td colspan=6 align=center bgcolor='#3980c6' valign=top><font color='white' size=5><b>Report Criteria</b></font></td></tr>");
            htmlContent.AppendLine("<tr>");
            int ICount = 0;

            foreach (PropertyInfo info in typeof(TrackingReportingCommonFilterInputModel).GetProperties())
            {
                List<string> oTheList = info.GetValue(trackingReportingCommonFilterInputModel, null) as List<string>;
                string listValue = UtilityHelper.ListValueToCommaSeperated(oTheList, ";");
                if (info.GetValue(trackingReportingCommonFilterInputModel, null) != null && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "0" && info.GetValue(trackingReportingCommonFilterInputModel, null).ToString() != "")
                {
                    if (!info.PropertyType.Name.Contains("List"))
                    {
                        var value = info.GetValue(trackingReportingCommonFilterInputModel, null);
                        var filter = info.Name + ":" + value + ";";

                        if (info.Name != "OrderBy" && info.Name != "SortBy" && info.Name != "FilterBy" && info.Name != "GroupBy" && info.Name != "PageNumber" && info.Name != "PageSize" && info.Name != "ScreenName" && info.Name != "BrowseByValue" && info.Name != "BrowseByProducer" && info.Name != "BrowseByTitle" && info.Name != "DisableBrowseBy" && info.Name != "UserID")
                        {
                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                htmlContent.AppendLine("</tr><tr>");
                            }
                            htmlContent.AppendLine("<tr><td colspan=3 valign=top><font color='black'>" + info.Name + "</font></td><td colspan=3 valign=top><font color='black'>" + value + "</font></td></tr>");
                        }
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(listValue))
                        {
                            var filter = info.Name + ":" + listValue + ";";
                            if (ICount > 1 && ICount % 4 == 0)
                            {
                                htmlContent.AppendLine("</tr><tr>");
                            }
                            htmlContent.AppendLine("<tr><td colspan=3 valign=top><font color='black'>" + info.Name + "</font></td><td colspan=3 valign=top><font color='black'>" + listValue + "</font></td></tr>");
                        }
                    }
                }
            }

            if (ICount % 4 != 0)
            {
                htmlContent.AppendLine("</tr");
            }
            htmlContent.AppendLine("</table>");
            htmlContent.AppendLine("</table>");

            htmlContent.Append("</body>");
            htmlContent.Append("</html>");

        }

        #endregion Public Methods

        #region Private Methods  

        #endregion Private Methods  
    }
}